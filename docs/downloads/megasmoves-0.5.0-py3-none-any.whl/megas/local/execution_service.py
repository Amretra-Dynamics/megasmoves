"""Authoritative Local coding-agent turn execution.

Every provider uses the same durable Local thread/session/event spine. Codex
keeps its stricter app-server runner; other certified adapters execute through
their native structured adapter and publish into the same broker.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator, Callable
from pathlib import Path
from typing import Optional, Protocol

from megas.adapters.aider import AiderAdapter
from megas.adapters.antigravity import AntigravityAdapter
from megas.adapters.base import BaseAgentAdapter, WorkerEvent, resolve_cli_argv
from megas.adapters.claude import ClaudeCodeAdapter
from megas.adapters.cline import ClineAdapter
from megas.adapters.codex import CodexCliAdapter
from megas.adapters.codex_app_server import stream_codex_app_server
from megas.adapters.cursor import CursorCliAdapter
from megas.adapters.devin import DevinCliAdapter
from megas.adapters.grok_build import GrokBuildAdapter
from megas.adapters.jules import JulesCliAdapter
from megas.adapters.kilo import KiloCodeAdapter
from megas.adapters.opencode import OpenCodeAdapter
from megas.adapters.process_control import process_create_time
from megas.runtime_manifest import _auth_mode, _certification_for

from .broker import LocalEventBroker
from .cancellation import ProcessRegistry
from .models import Session, Thread
from .provider_cancellation import build_provider_canceller
from .store import LocalStore
from .workspace import WorkspaceService


class NativeTurnRunner(Protocol):
    def __call__(self, **kwargs: object) -> AsyncIterator[WorkerEvent]: ...


AdapterFactory = Callable[[list[str]], BaseAgentAdapter]


def _default_adapter_factories() -> dict[str, AdapterFactory]:
    return {
        "aider": AiderAdapter,
        "antigravity": AntigravityAdapter,
        "claude_code": ClaudeCodeAdapter,
        "cline": ClineAdapter,
        "codex_cli": CodexCliAdapter,
        "cursor_cli": CursorCliAdapter,
        "devin_cli": DevinCliAdapter,
        "grok_build": GrokBuildAdapter,
        "jules_cli": JulesCliAdapter,
        "kilo_code": KiloCodeAdapter,
        "opencode": OpenCodeAdapter,
    }


class LocalExecutionService:
    def __init__(
        self,
        store: LocalStore,
        broker: LocalEventBroker,
        process_registry: ProcessRegistry,
        *,
        native_runner: NativeTurnRunner = stream_codex_app_server,
        adapter_factory: Callable[[list[str]], CodexCliAdapter] = CodexCliAdapter,
        adapter_factories: Optional[dict[str, AdapterFactory]] = None,
        certification_checker: Optional[
            Callable[[str, BaseAgentAdapter, Path, str], object]
        ] = None,
    ):
        self.store = store
        self.broker = broker
        self.process_registry = process_registry
        self.native_runner = native_runner
        self.adapter_factory = adapter_factory
        self.adapter_factories = _default_adapter_factories()
        self.adapter_factories["codex_cli"] = adapter_factory
        if adapter_factories:
            self.adapter_factories.update(adapter_factories)
        self.certification_checker = (
            certification_checker or self._default_certification_check
        )
        self.workspace_service = WorkspaceService(store)

    @staticmethod
    def _codex_command_prefix() -> list[str]:
        binary = (os.getenv("MEGAS_CODEX_BINARY") or "").strip()
        if not binary:
            try:
                from megas.core.agent_health import _resolve_binary

                binary = _resolve_binary("codex_cli") or "codex"
            except Exception:
                binary = "codex"
        return resolve_cli_argv(binary)

    @staticmethod
    def _validate_instruction(instruction: str) -> str:
        prompt = str(instruction or "").strip()
        if not prompt:
            raise ValueError("Local turn instruction must not be empty")
        if len(prompt.encode("utf-8")) > 1024 * 1024:
            raise ValueError("Local turn instruction exceeds the 1 MiB limit")
        return prompt

    @staticmethod
    def _default_certification_check(
        provider_id: str,
        adapter: BaseAgentAdapter,
        executable: Path,
        version: str,
    ):
        return _certification_for(
            agent_id=provider_id,
            adapter=adapter,
            executable=executable,
            version=version,
            auth_mode=_auth_mode(provider_id, adapter),
            execution_mode="inspect",
        )

    def _make_adapter(self, provider_id: str, workspace: Path) -> BaseAgentAdapter:
        factory = self.adapter_factories.get(provider_id)
        if factory is None:
            raise ValueError(f"Unsupported Local provider: {provider_id}")
        adapter = factory([str(workspace)])
        executable = adapter.discover_executable()
        if executable is None:
            raise FileNotFoundError(f"{provider_id} is not installed")
        status = str(adapter.health_status())
        if status == "unauthenticated":
            raise PermissionError(f"{provider_id} is not authenticated")
        if status != "available":
            raise RuntimeError(
                f"{provider_id} is not safe to execute in state: {status}"
            )
        version = adapter.detect_version()
        if not version:
            raise RuntimeError(f"{provider_id} version could not be verified")
        decision = self.certification_checker(
            provider_id,
            adapter,
            Path(executable),
            version,
        )
        dec_status = str(getattr(decision, "status", "") or "")
        if dec_status in {"quarantined", "disabled"} or getattr(decision, "certified", False) is not True:
            reason = str(
                getattr(decision, "reason", "quarantined")
            )
            raise PermissionError(
                f"{provider_id} is not runtime-certified to execute: {reason}"
            )
        return adapter

    def _mark_running_from_event(
        self,
        live_session_id: str,
        event: WorkerEvent,
    ) -> None:
        payload = event.payload if isinstance(event.payload, dict) else {}
        raw_pid = payload.get("pid")
        try:
            pid = int(raw_pid) if raw_pid is not None else None
        except (TypeError, ValueError):
            pid = None
        create_time = process_create_time(pid) if pid is not None else None
        with self.store._transaction("EXCLUSIVE") as conn:
            row = conn.execute(
                "SELECT status FROM local_sessions WHERE live_session_id=?",
                (live_session_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Session {live_session_id} not found")
            status = str(row["status"])
            if status in {"accepted", "running"}:
                conn.execute(
                    """
                    UPDATE local_sessions
                    SET status='running', pid=?, process_create_time=?,
                        updated_at=strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                    WHERE live_session_id=?
                    """,
                    (pid, create_time, live_session_id),
                )

    def _bind_or_validate_native_id(
        self,
        *,
        worker_id: str,
        megas_thread_id: str,
        latest_thread: Thread,
        worker_event: WorkerEvent,
    ) -> Thread:
        payload = (
            worker_event.payload
            if isinstance(worker_event.payload, dict)
            else {}
        )
        announced = str(
            payload.get("provider_session_id")
            or payload.get("native_id")
            or payload.get("thread_id")
            or ""
        ).strip()
        if not announced:
            return latest_thread
        if latest_thread.native_thread_id is None:
            self.store.bind_native_thread(megas_thread_id, announced)
            rebound = self.store.get_thread(worker_id, megas_thread_id)
            if rebound is None:
                raise RuntimeError("Native thread binding disappeared")
            return rebound
        if latest_thread.native_thread_id != announced:
            raise RuntimeError(
                f"{latest_thread.provider_id} resumed {announced!r}, expected "
                f"{latest_thread.native_thread_id!r}"
            )
        return latest_thread

    async def _register_provider_cancellation(
        self,
        *,
        live_session_id: str,
        thread: Thread,
    ) -> None:
        native_id = str(thread.native_thread_id or "").strip()
        if not native_id:
            return
        canceller = build_provider_canceller(thread.provider_id, native_id)
        if canceller is None:
            return
        register = getattr(
            self.process_registry,
            "register_provider_canceller",
            None,
        )
        if callable(register):
            await register(live_session_id, canceller)

    async def _unregister_provider_cancellation(
        self,
        live_session_id: str,
    ) -> None:
        unregister = getattr(
            self.process_registry,
            "unregister_provider_canceller",
            None,
        )
        if callable(unregister):
            await unregister(live_session_id)

    async def _publish_event(
        self,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        latest_thread: Thread,
        worker_event: WorkerEvent,
    ) -> Thread:
        if worker_event.event_type == "command_started":
            self._mark_running_from_event(live_session_id, worker_event)
        latest_thread = self._bind_or_validate_native_id(
            worker_id=worker_id,
            megas_thread_id=megas_thread_id,
            latest_thread=latest_thread,
            worker_event=worker_event,
        )
        if worker_event.event_type == "agent_thread_started":
            await self._register_provider_cancellation(
                live_session_id=live_session_id,
                thread=latest_thread,
            )
        current_session = self.store.get_session(live_session_id)
        if current_session is None:
            raise RuntimeError("Durable Local session disappeared")
        await self.broker.append_and_publish(
            latest_thread,
            current_session,
            worker_event,
        )
        return latest_thread

    async def _execute_codex(
        self,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        prompt: str,
        workspace: Path,
        latest_thread: Thread,
        adapter: CodexCliAdapter,
        model: str,
        effort: str,
        timeout_seconds: float,
    ) -> tuple[Thread, bool]:
        from megas.development_continuity import INTERRUPTION_CONTRACT
        failed = False
        command_prefix = self._codex_command_prefix()
        environment = adapter.sanitize_environment(dict(os.environ))
        environment["NO_COLOR"] = "1"

        async def on_process_started(process) -> None:
            await self.process_registry.register(live_session_id, process)

        async def on_process_finished(process) -> None:
            await self.process_registry.unregister(live_session_id, process)

        async for worker_event in self.native_runner(
            binary=command_prefix[0],
            command_prefix=command_prefix,
            prompt=prompt + "\n\nMegas continuity contract:\n" + INTERRUPTION_CONTRACT,
            cwd=Path(workspace),
            environment=environment,
            provider_session_id=latest_thread.native_thread_id or "",
            write_mode=False,
            model=model[:200],
            effort=(
                effort
                if effort in {"minimal", "low", "medium", "high", "xhigh"}
                else ""
            ),
            timeout_sec=timeout_seconds,
            redact_text=adapter.redact_output,
            strict_local_resume=True,
            on_process_started=on_process_started,
            on_process_finished=on_process_finished,
        ):
            if worker_event.event_type == "agent_error":
                status = str(worker_event.payload.get("status") or "")
                failed = (
                    failed
                    or bool(worker_event.payload.get("fatal"))
                    or status == "failed"
                )
            if worker_event.event_type == "command_finished":
                try:
                    failed = (
                        failed
                        or int(worker_event.payload.get("exit_code") or 0) != 0
                    )
                except (TypeError, ValueError):
                    failed = True
            latest_thread = await self._publish_event(
                worker_id=worker_id,
                megas_thread_id=megas_thread_id,
                live_session_id=live_session_id,
                latest_thread=latest_thread,
                worker_event=worker_event,
            )
        return latest_thread, failed

    async def _execute_generic(
        self,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        prompt: str,
        workspace: Path,
        latest_thread: Thread,
        adapter: BaseAgentAdapter,
        model: str,
        effort: str,
        timeout_seconds: float,
    ) -> tuple[Thread, bool]:
        failed = False
        command = {
            "session_id": live_session_id,
            "command_id": live_session_id,
            "instruction": prompt,
            "workdir": str(workspace),
            "timeout_sec": timeout_seconds,
            "context_pack": {
                "agent_type": latest_thread.provider_id,
                "provider_session_id": latest_thread.native_thread_id or "",
                "native_thread_id": latest_thread.native_thread_id or "",
                "megas_thread_id": megas_thread_id,
                "resume_existing": bool(latest_thread.native_thread_id),
                "chat_mode": "agent_chat",
                "source": "local_agent_chat",
                "write_mode": False,
                "model": model[:200],
                "reasoning_effort": effort,
                "worker_id": worker_id,
            },
        }
        async for worker_event in adapter.launch(command):
            if worker_event.event_type == "agent_error":
                failed = failed or bool(
                    worker_event.payload.get("fatal", True)
                )
            if worker_event.event_type == "command_finished":
                try:
                    failed = (
                        failed
                        or int(worker_event.payload.get("exit_code") or 0) != 0
                    )
                except (TypeError, ValueError):
                    failed = True
            latest_thread = await self._publish_event(
                worker_id=worker_id,
                megas_thread_id=megas_thread_id,
                live_session_id=live_session_id,
                latest_thread=latest_thread,
                worker_event=worker_event,
            )
        return latest_thread, failed

    async def execute_turn(
        self,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        instruction: str,
        write_mode: bool = False,
        model: str = "",
        effort: str = "",
        timeout_seconds: float = 900.0,
    ) -> Session:
        session, thread = self.store.get_session_scope(live_session_id)
        if (
            thread.worker_id != worker_id
            or thread.megas_thread_id != megas_thread_id
        ):
            raise PermissionError(
                "Execution scope does not match the durable thread"
            )
        if session.status != "accepted":
            raise ValueError(
                f"Local turn {live_session_id} cannot start from {session.status}"
            )
        if write_mode:
            raise PermissionError(
                "Direct Local write mode is not enabled until controlled-patch "
                "application is connected to the shared provider path."
            )

        latest_thread = thread
        try:
            prompt = self._validate_instruction(instruction)
            workspace = self.workspace_service.resolve_thread_workspace(
                worker_id,
                megas_thread_id,
            )
            adapter = self._make_adapter(thread.provider_id, workspace)
            if thread.provider_id == "codex_cli":
                latest_thread, failed = await self._execute_codex(
                    worker_id=worker_id,
                    megas_thread_id=megas_thread_id,
                    live_session_id=live_session_id,
                    prompt=prompt,
                    workspace=workspace,
                    latest_thread=latest_thread,
                    adapter=adapter,  # type: ignore[arg-type]
                    model=model,
                    effort=effort,
                    timeout_seconds=timeout_seconds,
                )
            else:
                latest_thread, failed = await self._execute_generic(
                    worker_id=worker_id,
                    megas_thread_id=megas_thread_id,
                    live_session_id=live_session_id,
                    prompt=prompt,
                    workspace=workspace,
                    latest_thread=latest_thread,
                    adapter=adapter,
                    model=model,
                    effort=effort,
                    timeout_seconds=timeout_seconds,
                )

            current = self.store.get_session(live_session_id)
            if current is None:
                raise RuntimeError("Durable Local session disappeared")
            if current.status in {
                "cancelling",
                "cancelled",
                "interrupted",
            }:
                return current
            if latest_thread.native_thread_id is None:
                raise RuntimeError(
                    f"{thread.provider_id} turn ended without binding an "
                    "authoritative native thread"
                )
            final_status = "failed" if failed else "completed"
            terminal_reason = (
                f"{thread.provider_id}_reported_failure" if failed else None
            )
            latest_thread = await self._publish_event(
                worker_id=worker_id,
                megas_thread_id=megas_thread_id,
                live_session_id=live_session_id,
                latest_thread=latest_thread,
                worker_event=WorkerEvent(
                    f"session_{final_status}",
                    {
                        "status": final_status,
                        "reason": terminal_reason,
                        "adapter": thread.provider_id,
                        "agent_type": thread.provider_id,
                    },
                ),
            )
            result = self.store.update_session_status(
                live_session_id,
                final_status,
                reason=terminal_reason,
            )
            await self.broker.close_session(live_session_id)
            return result
        except Exception as exc:
            current = self.store.get_session(live_session_id)
            if current is not None and current.status not in {
                "cancelling",
                "cancelled",
                "interrupted",
                "completed",
                "failed",
            }:
                try:
                    await self.broker.append_and_publish(
                        latest_thread,
                        current,
                        WorkerEvent(
                            "agent_error",
                            {
                                "message": (
                                    f"Local {thread.provider_id} execution failed."
                                ),
                                "error_code": type(exc).__name__,
                                "fatal": True,
                            },
                        ),
                    )
                    refreshed = self.store.get_session(live_session_id)
                    if refreshed is not None:
                        await self.broker.append_and_publish(
                            latest_thread,
                            refreshed,
                            WorkerEvent(
                                "session_failed",
                                {
                                    "status": "failed",
                                    "reason": type(exc).__name__,
                                    "adapter": thread.provider_id,
                                    "agent_type": thread.provider_id,
                                },
                            ),
                        )
                finally:
                    self.store.update_session_status(
                        live_session_id,
                        "failed",
                        reason=type(exc).__name__,
                    )
                    await self.broker.close_session(live_session_id)
            raise
        finally:
            await self._unregister_provider_cancellation(live_session_id)
            current = self.store.get_session(live_session_id)
            if current is not None and current.status in {
                "completed",
                "failed",
                "cancelled",
                "interrupted",
            }:
                await self.broker.close_session(live_session_id)
