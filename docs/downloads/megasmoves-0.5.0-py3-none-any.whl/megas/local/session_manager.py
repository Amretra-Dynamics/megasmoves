"""Local runtime manager, single-instance lock, Gateway, and recovery."""

from __future__ import annotations

import asyncio
import hashlib
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO

from megas.adapters.process_control import terminate_process_tree_by_pid

from .protocol import LocalEvent
from .store import LocalStore

_PROCESS_LOCKS: set[str] = set()
_PROCESS_LOCKS_GUARD = threading.Lock()


class LocalSessionManager:
    def __init__(self, db_path: Path):
        self.store = LocalStore(db_path)
        self.store.init_db()
        self.gateway_thread: threading.Thread | None = None
        self.gateway_server = None
        self._lock_file = db_path.parent / ".local_runtime.lock"
        self._lock_handle: BinaryIO | None = None
        self._lock_key: str | None = None

    def acquire_lock(self) -> bool:
        if self._lock_handle is not None:
            return False
        self._lock_file.parent.mkdir(parents=True, exist_ok=True)
        lock_key = str(self._lock_file.resolve())
        with _PROCESS_LOCKS_GUARD:
            if lock_key in _PROCESS_LOCKS:
                return False

        handle = self._lock_file.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt

                handle.seek(0, os.SEEK_END)
                if handle.tell() == 0:
                    handle.write(b"\0")
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, IOError):
            handle.close()
            return False

        with _PROCESS_LOCKS_GUARD:
            if lock_key in _PROCESS_LOCKS:
                self._unlock_handle(handle)
                return False
            _PROCESS_LOCKS.add(lock_key)
        self._lock_handle = handle
        self._lock_key = lock_key
        return True

    @staticmethod
    def _unlock_handle(handle: BinaryIO) -> None:
        try:
            if os.name == "nt":
                import msvcrt

                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()

    def _release_lock(self) -> None:
        handle = self._lock_handle
        lock_key = self._lock_key
        self._lock_handle = None
        self._lock_key = None
        if handle is not None:
            try:
                self._unlock_handle(handle)
            except (OSError, IOError):
                pass
        if lock_key is not None:
            with _PROCESS_LOCKS_GUARD:
                _PROCESS_LOCKS.discard(lock_key)

    @staticmethod
    def _recovery_event(
        *,
        worker_id: str,
        megas_thread_id: str,
        native_thread_id: str | None,
        live_session_id: str,
        reason: str,
    ) -> LocalEvent:
        raw = f"{worker_id}|{megas_thread_id}|{live_session_id}|interrupted"
        event_id = "evt_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]
        occurred_at = datetime.now(timezone.utc).isoformat()
        return LocalEvent(
            event_id=event_id,
            worker_id=worker_id,
            megas_thread_id=megas_thread_id,
            native_thread_id=native_thread_id,
            live_session_id=live_session_id,
            sequence=-1,
            event_type="error",
            created_at=occurred_at,
            payload={
                "schema_version": "megas.conversation-event.v1",
                "event_id": event_id,
                "kind": "error",
                "source": "replay",
                "occurred_at": occurred_at,
                "role": None,
                "native_item_id": None,
                "native_turn_id": None,
                "tool_call_id": None,
                "status": "interrupted",
                "content_text": (
                    "This turn was interrupted when the Local Worker restarted. "
                    "Review the durable timeline before starting another write."
                ),
                "content_json": None,
                "tool_name": None,
                "file_path": None,
                "additions": None,
                "deletions": None,
                "diff_snippet": None,
                "error_code": reason,
                "error_message": None,
                "unsupported_type": None,
                "is_conversation_visible": True,
            },
        )

    @staticmethod
    def _inspect_process(session) -> tuple[str, bool]:
        if session.pid is None and session.process_create_time is None:
            return "process_metadata_missing", False
        if session.pid is None or session.process_create_time is None:
            return "process_metadata_inconsistent", False
        try:
            import psutil
        except ImportError:
            return "process_identity_unverifiable", False

        try:
            process = psutil.Process(session.pid)
            if not process.is_running() or process.status() == psutil.STATUS_ZOMBIE:
                return "process_missing", False
            if abs(process.create_time() - session.process_create_time) > 0.01:
                return "pid_reused", False
            return "process_unobservable_after_restart", True
        except psutil.AccessDenied:
            return "process_identity_unverifiable", False
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            return "process_missing", False
        except OSError:
            return "process_identity_unverifiable", False

    @staticmethod
    def _terminate_recovered_process(session) -> bool:
        coroutine = terminate_process_tree_by_pid(
            session.pid,
            expected_create_time=session.process_create_time,
            timeout=3.0,
        )
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return bool(asyncio.run(coroutine))
        coroutine.close()
        raise RuntimeError(
            "startup_recovery must run before the Local async runtime starts"
        )

    def startup_recovery(self) -> dict[str, list[str]]:
        report: dict[str, list[str]] = {
            "accepted_not_started": [],
            "running": [],
            "cancelling": [],
            "inconsistent": [],
            "orphan_processes_terminated": [],
        }
        for session in self.store.get_active_sessions():
            durable_session, thread = self.store.get_session_scope(
                session.live_session_id
            )
            status = durable_session.status
            process_reason, verified_alive = self._inspect_process(durable_session)

            if status == "accepted":
                if durable_session.pid is None and durable_session.process_create_time is None:
                    reason = "accepted_not_started"
                    report["accepted_not_started"].append(session.live_session_id)
                else:
                    reason = "accepted_process_metadata_inconsistent"
                    report["inconsistent"].append(session.live_session_id)
            elif status == "running":
                reason = process_reason
                report["running"].append(session.live_session_id)
            elif status == "cancelling":
                reason = "cancellation_outcome_unknown_after_restart"
                report["cancelling"].append(session.live_session_id)
            else:
                reason = "recovery_state_inconsistent"
                report["inconsistent"].append(session.live_session_id)

            if verified_alive:
                terminated = self._terminate_recovered_process(durable_session)
                if not terminated:
                    raise RuntimeError(
                        "Refusing to start a new Local runtime while an exact prior "
                        f"turn process remains alive: {session.live_session_id}"
                    )
                report["orphan_processes_terminated"].append(
                    session.live_session_id
                )

            event = self._recovery_event(
                worker_id=thread.worker_id,
                megas_thread_id=thread.megas_thread_id,
                native_thread_id=thread.native_thread_id,
                live_session_id=session.live_session_id,
                reason=reason,
            )
            self.store.reconcile_interrupted_session(
                session.live_session_id,
                reason,
                event,
            )
        return report

    def start_gateway(
        self,
        port: int = 18765,
        websocket_port: int = 0,
    ) -> None:
        if self.gateway_server is not None or self.gateway_thread is not None:
            raise RuntimeError("Local Gateway is already running in this manager")
        if not self.acquire_lock():
            raise RuntimeError("Another Megas Local runtime already owns this database")

        try:
            self.startup_recovery()
            from .gateway_stable_threads import create_server

            try:
                self.gateway_server = create_server(self.store, port)
                self.gateway_server.services.start_websocket(websocket_port)
            except OSError as exc:
                raise RuntimeError(
                    f"Could not bind Local Gateway to 127.0.0.1:{port}: {exc}"
                ) from exc

            actual_port = int(self.gateway_server.server_port)
            self.store.set_setting("gateway_port", {"port": actual_port})
            server = self.gateway_server
            self.gateway_thread = threading.Thread(
                target=server.serve_forever,
                name="megas-local-gateway",
                daemon=True,
            )
            self.gateway_thread.start()
        except Exception:
            if self.gateway_server is not None:
                self.gateway_server.server_close()
                self.gateway_server = None
            self.gateway_thread = None
            self._release_lock()
            raise

    def shutdown(self) -> None:
        server = self.gateway_server
        thread = self.gateway_thread
        self.gateway_server = None
        self.gateway_thread = None
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None:
            thread.join(timeout=2.0)
        self.store.close()
        self._release_lock()
