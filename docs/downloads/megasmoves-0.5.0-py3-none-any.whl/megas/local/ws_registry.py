"""Active Local WebSocket registry keyed by paired device."""

from __future__ import annotations

import asyncio
from collections.abc import Coroutine
from concurrent.futures import Future
from typing import Any, Callable, Protocol

from .store import DeviceRevocationObserver


class ClosableWebSocket(Protocol):
    async def close(self, code: int = 1000, reason: str = "") -> None: ...


class ConnectionRegistration:
    def __init__(
        self,
        registry: "LocalConnectionRegistry",
        device_id: str,
        connection: ClosableWebSocket,
    ):
        self._registry = registry
        self._device_id = device_id
        self._connection = connection
        self._closed = False

    async def unregister(self) -> None:
        if self._closed:
            return
        self._closed = True
        await self._registry._unregister(self._device_id, self._connection)


class LocalConnectionRegistry(DeviceRevocationObserver):
    def __init__(
        self,
        submit_coroutine: Callable[[Coroutine[Any, Any, Any]], Future[Any]],
    ):
        self._submit_coroutine = submit_coroutine
        self._lock = asyncio.Lock()
        self._devices: dict[str, set[ClosableWebSocket]] = {}

    async def register(
        self,
        device_id: str,
        connection: ClosableWebSocket,
    ) -> ConnectionRegistration:
        async with self._lock:
            self._devices.setdefault(device_id, set()).add(connection)
        return ConnectionRegistration(self, device_id, connection)

    async def _unregister(
        self,
        device_id: str,
        connection: ClosableWebSocket,
    ) -> None:
        async with self._lock:
            connections = self._devices.get(device_id)
            if connections is None:
                return
            connections.discard(connection)
            if not connections:
                self._devices.pop(device_id, None)

    async def revoke_device(self, device_id: str) -> None:
        async with self._lock:
            connections = tuple(self._devices.pop(device_id, set()))
        if connections:
            await asyncio.gather(
                *(
                    connection.close(
                        code=1008,
                        reason="Device credential revoked",
                    )
                    for connection in connections
                ),
                return_exceptions=True,
            )

    async def close_all_for_shutdown(self) -> None:
        async with self._lock:
            connections = tuple(
                connection
                for group in self._devices.values()
                for connection in group
            )
            self._devices.clear()
        if connections:
            await asyncio.gather(
                *(
                    connection.close(code=1001, reason="Worker shutting down")
                    for connection in connections
                ),
                return_exceptions=True,
            )

    def on_device_revoked(self, device_id: str) -> None:
        try:
            self._submit_coroutine(self.revoke_device(device_id))
        except RuntimeError:
            # The durable revocation remains authoritative even during shutdown.
            return
