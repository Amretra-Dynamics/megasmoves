"""Short-lived, single-use WebSocket tickets for Megas Local."""

from __future__ import annotations

import hashlib
import secrets
import time
from dataclasses import dataclass

from .errors import AuthenticationError
from .store import DeviceRevocationObserver, LocalStore


@dataclass(frozen=True)
class TicketScope:
    worker_id: str
    device_id: str
    megas_thread_id: str
    live_session_id: str
    origin: str
    protocol: str
    action: str


class TicketService(DeviceRevocationObserver):
    def __init__(
        self,
        store: LocalStore,
        *,
        ttl_seconds: float = 30.0,
        max_outstanding_per_device: int = 20,
    ):
        if ttl_seconds <= 0 or ttl_seconds > 120:
            raise ValueError("Ticket TTL must be between 0 and 120 seconds")
        self.store = store
        self.ttl_seconds = ttl_seconds
        self.max_outstanding_per_device = max_outstanding_per_device
        store.register_device_revocation_observer(self)

    @staticmethod
    def _hash(raw_ticket: str) -> str:
        return hashlib.sha256(raw_ticket.encode("utf-8")).hexdigest()

    @staticmethod
    def _validate_scope_values(scope: TicketScope) -> None:
        values = (
            scope.worker_id,
            scope.device_id,
            scope.megas_thread_id,
            scope.live_session_id,
            scope.origin,
            scope.protocol,
            scope.action,
        )
        if any(not value for value in values):
            raise AuthenticationError("Invalid ticket scope")

    def _validate_durable_scope(self, conn, scope: TicketScope) -> None:
        row = conn.execute(
            """
            SELECT
                t.worker_id,
                s.megas_thread_id,
                d.status,
                d.revoked_at
            FROM local_sessions AS s
            JOIN local_threads AS t
              ON t.megas_thread_id=s.megas_thread_id
            JOIN local_devices AS d
              ON d.id=?
            WHERE s.live_session_id=?
            """,
            (scope.device_id, scope.live_session_id),
        ).fetchone()
        if row is None:
            raise AuthenticationError("Invalid ticket scope")
        if (
            row["worker_id"] != scope.worker_id
            or row["megas_thread_id"] != scope.megas_thread_id
            or row["status"] != "active"
            or row["revoked_at"] is not None
        ):
            raise AuthenticationError("Invalid ticket scope")

    def generate_ticket(self, scope: TicketScope) -> str:
        self._validate_scope_values(scope)
        raw_ticket = f"ws_tkt_{secrets.token_urlsafe(32)}"
        ticket_hash = self._hash(raw_ticket)
        now = time.time()
        with self.store._transaction() as conn:
            self._validate_durable_scope(conn, scope)
            conn.execute(
                "DELETE FROM local_tickets WHERE expires_at<?",
                (now,),
            )
            outstanding = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM local_tickets
                WHERE device_id=? AND status='issued' AND expires_at>=?
                """,
                (scope.device_id, now),
            ).fetchone()["count"]
            if outstanding >= self.max_outstanding_per_device:
                raise AuthenticationError("Too many outstanding tickets")
            conn.execute(
                """
                INSERT INTO local_tickets (
                    ticket_hash,
                    worker_id,
                    device_id,
                    megas_thread_id,
                    live_session_id,
                    origin,
                    protocol,
                    action,
                    expires_at,
                    status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'issued')
                """,
                (
                    ticket_hash,
                    scope.worker_id,
                    scope.device_id,
                    scope.megas_thread_id,
                    scope.live_session_id,
                    scope.origin,
                    scope.protocol,
                    scope.action,
                    now + self.ttl_seconds,
                ),
            )
        return raw_ticket

    def _consume_matching(
        self,
        raw_ticket: str,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        origin: str,
        protocol: str,
        action: str,
        expected_device_id: str | None = None,
    ) -> TicketScope:
        if not all(
            (
                raw_ticket,
                worker_id,
                megas_thread_id,
                live_session_id,
                origin,
                protocol,
                action,
            )
        ):
            raise AuthenticationError("Invalid ticket scope")
        ticket_hash = self._hash(raw_ticket)
        now = time.time()
        with self.store._transaction("EXCLUSIVE") as conn:
            row = conn.execute(
                """
                SELECT
                    worker_id,
                    device_id,
                    megas_thread_id,
                    live_session_id,
                    origin,
                    protocol,
                    action,
                    expires_at,
                    status
                FROM local_tickets
                WHERE ticket_hash=?
                """,
                (ticket_hash,),
            ).fetchone()
            if row is None or row["status"] != "issued" or row["expires_at"] < now:
                raise AuthenticationError("Invalid ticket")
            if (
                row["worker_id"] != worker_id
                or row["megas_thread_id"] != megas_thread_id
                or row["live_session_id"] != live_session_id
                or row["origin"] != origin
                or row["protocol"] != protocol
                or row["action"] != action
                or (
                    expected_device_id is not None
                    and row["device_id"] != expected_device_id
                )
            ):
                raise AuthenticationError("Invalid ticket")

            actual_scope = TicketScope(
                worker_id=row["worker_id"],
                device_id=row["device_id"],
                megas_thread_id=row["megas_thread_id"],
                live_session_id=row["live_session_id"],
                origin=row["origin"],
                protocol=row["protocol"],
                action=row["action"],
            )
            self._validate_durable_scope(conn, actual_scope)
            result = conn.execute(
                """
                UPDATE local_tickets
                SET status='consumed'
                WHERE ticket_hash=? AND status='issued'
                """,
                (ticket_hash,),
            )
            if result.rowcount != 1:
                raise AuthenticationError("Invalid ticket")
            return actual_scope

    def consume_ticket(
        self,
        raw_ticket: str,
        expected_scope: TicketScope,
    ) -> TicketScope:
        self._validate_scope_values(expected_scope)
        return self._consume_matching(
            raw_ticket,
            worker_id=expected_scope.worker_id,
            megas_thread_id=expected_scope.megas_thread_id,
            live_session_id=expected_scope.live_session_id,
            origin=expected_scope.origin,
            protocol=expected_scope.protocol,
            action=expected_scope.action,
            expected_device_id=expected_scope.device_id,
        )

    def consume_for_stream_request(
        self,
        raw_ticket: str,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        origin: str,
        protocol: str = "megas-local-events-v1",
    ) -> TicketScope:
        """Consume a ticket during the HTTP upgrade before any event is sent."""
        return self._consume_matching(
            raw_ticket,
            worker_id=worker_id,
            megas_thread_id=megas_thread_id,
            live_session_id=live_session_id,
            origin=origin,
            protocol=protocol,
            action="stream",
        )

    def revoke_device_tickets(self, device_id: str) -> None:
        with self.store._transaction() as conn:
            conn.execute(
                """
                UPDATE local_tickets
                SET status='revoked'
                WHERE device_id=? AND status='issued'
                """,
                (device_id,),
            )

    def on_device_revoked(self, device_id: str) -> None:
        self.revoke_device_tickets(device_id)
