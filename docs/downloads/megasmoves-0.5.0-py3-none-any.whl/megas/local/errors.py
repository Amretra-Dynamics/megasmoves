"""Megas Local error types."""

class LocalError(Exception):
    """Base class for Megas Local errors."""
    pass

class ConcurrencyConflictError(LocalError):
    """Raised when an atomic transaction fails or a sequence conflicts."""
    pass

class AuthenticationError(LocalError):
    """Raised on invalid pairing or identity verification failure."""
    pass
