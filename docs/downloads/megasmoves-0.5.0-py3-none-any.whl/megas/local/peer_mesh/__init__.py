"""Authenticated app-scoped account relay for MegasMoves devices."""
