"""Owns the local Firebase-UID-scoped peer loop inside MegasMoves.exe."""

from __future__ import annotations

import asyncio
import atexit
import threading
from typing import Any

from .identity import PeerPairingRequired
from .pairing import DevicePairingStore
from .rtc import DirectPeerRtcMesh


class PeerMeshController:
    def __init__(self, firebase_uid: str, *, startup_timeout: float = 30.0, pairing_store=None, mesh_factory=DirectPeerRtcMesh) -> None:
        self._account_subject = firebase_uid
        if pairing_store is None:
            from megas.local.store import LocalStore
            from megas.unified_runtime import local_database_path
            store = LocalStore(local_database_path())
            store.init_db()
            pairing_store = DevicePairingStore(store, firebase_uid)
        self.pairing = pairing_store
        # No thread, socket or key generation occurs before a human pin exists.
        self._initial_pairs = self.pairing.credentials()
        self._mesh_factory = mesh_factory
        self._meshes = {}
        self._credentials = {}
        self._state_lock = threading.RLock()
        self._reconcile_lock = asyncio.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._error_code: str | None = None
        self._ready = threading.Event()
        self._closed = False
        self._thread = threading.Thread(
            target=self._run_loop,
            name="MegasDirectPeerMesh",
            daemon=True,
        )
        self._thread.start()
        if not self._ready.wait(timeout=max(1.0, startup_timeout)):
            self._error_code = "peer_loop_start_timeout"
            return
        if self._loop is None:
            self._error_code = "peer_loop_unavailable"
            return
        future = asyncio.run_coroutine_threadsafe(self._start_mesh(), self._loop)
        try:
            future.result(timeout=max(1.0, startup_timeout))
        except Exception as exc:
            future.cancel()
            self._error_code = f"peer_mesh_start_{type(exc).__name__}"[:80]

    def matches_subject(self, subject: str) -> bool:
        return subject == self._account_subject

    def _run_loop(self) -> None:
        loop = asyncio.new_event_loop()
        self._loop = loop
        asyncio.set_event_loop(loop)
        self._ready.set()
        try:
            loop.run_forever()
        finally:
            pending = asyncio.all_tasks(loop)
            for task in pending:
                task.cancel()
            if pending:
                loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            loop.close()

    def _fanout_packet(self, address, raw):
        # One fixed LAN listener receives broadcasts for every paired device;
        # other discoveries bind ephemeral ports. Each mesh independently checks
        # its pair key and pinned sender before interpreting an authenticated SDP.
        with self._state_lock:
            meshes = tuple(self._meshes.values())
        for mesh in meshes:
            mesh._on_direct_packet(address, raw)

    async def _start_mesh(self):
        await self._reconcile_pairs(self._initial_pairs)
        self._initial_pairs = None

    async def _reconcile_pairs(self, pairs=None):
        async with self._reconcile_lock:
            await self._reconcile_pairs_locked(pairs)

    async def _reconcile_pairs_locked(self, pairs=None):
        try:
            pairs = self.pairing.credentials() if pairs is None else pairs
        except PeerPairingRequired:
            pairs = []
        desired = {pair.device_id: pair for pair in pairs}
        with self._state_lock:
            removed = [identifier for identifier in self._meshes if identifier not in desired or self._credentials.get(identifier) != desired[identifier]]
        for identifier in removed:
            with self._state_lock:
                mesh = self._meshes.pop(identifier)
                self._credentials.pop(identifier, None)
            await mesh.close()
        for identifier, pair in desired.items():
            with self._state_lock:
                if identifier in self._meshes:
                    continue
            mesh = self._mesh_factory(self._account_subject, peer_auth_key=pair.auth_key,
                local_device_id=pair.local_device_id, expected_device_id=identifier,
                rendezvous=pair.rendezvous, protocol_version=2, role="windows")
            try:
                await mesh.start()
                with self._state_lock:
                    self._meshes[identifier] = mesh
                    self._credentials[identifier] = pair
                mesh.discovery.set_packet_handler(self._fanout_packet)
            except Exception:
                await mesh.close()
                self._error_code = "paired_peer_start_failed"
        if not desired:
            self._error_code = "secure_device_pairing_required"
        elif self._meshes:
            self._error_code = None

    def reconcile_pairs(self):
        if self._closed or self._loop is None:
            return
        future = asyncio.run_coroutine_threadsafe(self._reconcile_pairs(), self._loop)
        try:
            future.result(timeout=10)
        except Exception:
            future.cancel()
            self._error_code = "device_pairing_reconcile_failed"

    @property
    def status(self) -> dict[str, Any]:
        with self._state_lock:
            statuses = [dict(mesh.status) for mesh in self._meshes.values()]
        return {
            "started": any(row.get("started") for row in statuses),
            "account_authenticated": any(row.get("account_authenticated") for row in statuses),
            "paired_device_count": len(statuses),
            "direct_peer_count": sum(row.get("direct_peer_count", 0) > 0 for row in statuses),
            "route": "direct_webrtc_only", "relay_configured": False,
            "vpn_service": False, "startup_error": self._error_code,
        }

    async def _dispatch_notification(self, **kwargs):
        # Re-read the existing device authority immediately before dispatch, so
        # a revoked pin cannot use a still-open cached connection.
        await self._reconcile_pairs()
        with self._state_lock:
            meshes = tuple(self._meshes.values())
        if not meshes:
            return {"delivered": False, "reason": "secure_device_pairing_required", "peer_acknowledged": False}
        results = await asyncio.gather(*(mesh.send_notification(**kwargs) for mesh in meshes), return_exceptions=True)
        rows = [row for row in results if isinstance(row, dict)]
        accepted = any(row.get("delivered") is True and row.get("peer_acknowledged") is True for row in rows)
        return {"delivered": accepted, "peer_acknowledged": any(row.get("peer_acknowledged") is True for row in rows),
            "acknowledged_device_count": sum(row.get("peer_acknowledged") is True for row in rows),
            "reason": "android_notification_posted" if accepted else next((row.get("reason") for row in rows if row.get("reason")), "notification_dispatch_failed"),
            "transport": "direct_webrtc"}

    def send_notification(
        self,
        *,
        title: str,
        message: str,
        level: str,
        event_type: str,
    ) -> dict[str, Any]:
        if self._closed or self._loop is None:
            return {
                "delivered": False,
                "reason": self._error_code or "peer_mesh_not_running",
                "peer_acknowledged": False,
            }
        future = asyncio.run_coroutine_threadsafe(
            self._dispatch_notification(
                title=title,
                message=message,
                level=level,
                event_type=event_type,
            ),
            self._loop,
        )
        try:
            return future.result(timeout=10.0)
        except Exception as exc:
            future.cancel()
            return {
                "delivered": False,
                "reason": f"notification_dispatch_{type(exc).__name__}",
                "peer_acknowledged": False,
            }

    def stop(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._loop is not None:
            async def close_all():
                with self._state_lock:
                    meshes = tuple(self._meshes.values())
                    self._meshes.clear()
                    self._credentials.clear()
                await asyncio.gather(*(mesh.close() for mesh in meshes), return_exceptions=True)
            future = asyncio.run_coroutine_threadsafe(close_all(), self._loop)
            try:
                future.result(timeout=5.0)
            except Exception:
                pass
        if self._loop is not None:
            self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=3.0)


_CURRENT_CONTROLLER: PeerMeshController | None = None
_CONTROLLER_LOCK = threading.Lock()


def current_peer_mesh(firebase_uid: str | None = None) -> PeerMeshController | None:
    global _CURRENT_CONTROLLER
    with _CONTROLLER_LOCK:
        if firebase_uid is not None:
            if _CURRENT_CONTROLLER is None or not _CURRENT_CONTROLLER.matches_subject(firebase_uid):
                if _CURRENT_CONTROLLER is not None:
                    _CURRENT_CONTROLLER.stop()
                _CURRENT_CONTROLLER = PeerMeshController(firebase_uid)
        return _CURRENT_CONTROLLER


def start_peer_mesh(firebase_uid: str) -> PeerMeshController:
    return current_peer_mesh(firebase_uid)


def stop_peer_mesh() -> None:
    global _CURRENT_CONTROLLER
    with _CONTROLLER_LOCK:
        if _CURRENT_CONTROLLER is not None:
            _CURRENT_CONTROLLER.stop()
            _CURRENT_CONTROLLER = None


atexit.register(stop_peer_mesh)
