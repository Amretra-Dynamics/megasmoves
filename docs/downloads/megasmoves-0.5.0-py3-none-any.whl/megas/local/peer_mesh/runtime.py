"""Single bounded background reconciler for the direct-peer WebRTC mesh."""

from __future__ import annotations

import atexit
import threading
from collections.abc import Callable
from typing import Any
from .identity import PeerPairingRequired

_REFRESH_SECONDS = 30.0


def _base_status() -> dict[str, Any]:
    return {
        "status": "starting",
        "state": "direct_peer_bootstrap_pending",
        "started": False,
        "account_authenticated": False,
        "direct_peer_count": 0,
        "route": "direct_webrtc_only",
        "relay_configured": False,
        "vpn_service": False,
    }


def _connection_state(status: dict[str, Any]) -> tuple[str, str]:
    if status.get("direct_peer_count", 0) > 0:
        return "connected", "direct_peer_connected"
    if status.get("started"):
        return "discovering", "direct_peer_discovering"
    return "not_connected", "direct_peer_not_connected"


def _reconcile_peer_mesh() -> dict[str, Any]:
    from megas.cli.user_credentials import load_user_token
    from .auth import firebase_uid_from_local_token
    from .controller import current_peer_mesh, start_peer_mesh, stop_peer_mesh

    token = load_user_token()
    if not token:
        stop_peer_mesh()
        return {
            **_base_status(),
            "status": "not_connected",
            "state": "firebase_auth_required",
        }

    firebase_uid = firebase_uid_from_local_token(token, require_fresh_token=False)
    controller = current_peer_mesh()
    if controller is None or not controller.matches_subject(firebase_uid):
        if controller is not None:
            stop_peer_mesh()
        controller = start_peer_mesh(firebase_uid)

    controller.reconcile_pairs()
    status = dict(controller.status)
    status["local_firebase_identity_verified"] = True
    status["status"], status["state"] = _connection_state(status)
    return status


class PeerMeshRuntime:
    """Keeps exactly one reconciliation thread and returns cached status fast."""

    def __init__(self, reconcile: Callable[[], dict[str, Any]] = _reconcile_peer_mesh) -> None:
        self._reconcile = reconcile
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._status = _base_status()
        self._failures = 0

    def status(self) -> dict[str, Any]:
        self.start()
        with self._lock:
            return dict(self._status)

    def start(self) -> None:
        with self._lock:
            if self._stop.is_set():
                return
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = threading.Thread(
                target=self._run,
                name="MegasPeerMeshBootstrap",
                daemon=True,
            )
            self._thread.start()

    def refresh(self) -> None:
        self.start()
        self._wake.set()

    def close(self) -> None:
        self._stop.set()
        self._wake.set()
        thread = self._thread
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                value = self._reconcile()
                if not isinstance(value, dict):
                    raise TypeError("peer_mesh_status_invalid")
                with self._lock:
                    self._status = value
                self._failures = 0
            except Exception as exc:
                self._failures = min(self._failures + 1, 5)
                with self._lock:
                    self._status = {
                        **_base_status(),
                        "status": "not_connected",
                        "state": "secure_device_pairing_required" if isinstance(exc, PeerPairingRequired) else "peer_mesh_error",
                        "error_type": type(exc).__name__,
                    }
            self._wake.wait(timeout=_REFRESH_SECONDS)
            self._wake.clear()


_CURRENT_RUNTIME: PeerMeshRuntime | None = None
_RUNTIME_LOCK = threading.Lock()


def current_peer_mesh_runtime() -> PeerMeshRuntime:
    global _CURRENT_RUNTIME
    with _RUNTIME_LOCK:
        if _CURRENT_RUNTIME is None:
            _CURRENT_RUNTIME = PeerMeshRuntime()
        return _CURRENT_RUNTIME


def peer_mesh_status() -> dict[str, Any]:
    return current_peer_mesh_runtime().status()


def stop_peer_mesh_runtime() -> None:
    global _CURRENT_RUNTIME
    with _RUNTIME_LOCK:
        if _CURRENT_RUNTIME is not None:
            _CURRENT_RUNTIME.close()
            _CURRENT_RUNTIME = None


atexit.register(stop_peer_mesh_runtime)

__all__ = [
    "PeerMeshRuntime",
    "current_peer_mesh_runtime",
    "peer_mesh_status",
    "stop_peer_mesh_runtime",
]
