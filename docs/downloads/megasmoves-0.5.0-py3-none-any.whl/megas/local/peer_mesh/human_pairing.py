"""Human-only native UI adapter. This is deliberately absent from MCP tools."""
from __future__ import annotations

import re

from .pairing import DevicePairingStore


class HumanDevicePairing:
    def __init__(self, pairing_factory=None, changed=None):
        self._factory = pairing_factory or self._current
        self._changed = changed or self._refresh

    @staticmethod
    def _current():
        from megas.cli.user_credentials import load_user_token
        from megas.local.store import LocalStore
        from megas.unified_runtime import local_database_path
        from .auth import firebase_uid_from_local_token
        token = load_user_token()
        if not token:
            raise PermissionError("firebase_auth_required")
        subject = firebase_uid_from_local_token(token, require_fresh_token=False)
        store = LocalStore(local_database_path())
        store.init_db()
        return DevicePairingStore(store, subject)

    @staticmethod
    def _refresh(subject):
        from .controller import current_peer_mesh
        from .runtime import current_peer_mesh_runtime
        controller = current_peer_mesh()
        if controller is not None and controller.matches_subject(subject):
            controller.reconcile_pairs()
        current_peer_mesh_runtime().refresh()

    @staticmethod
    def _devices(pairing):
        rows = []
        for device in pairing.store.list_devices():
            if device.type != "devnet-android":
                continue
            metadata = pairing.store.get_setting("devnet.peer.v2." + device.id)
            if isinstance(metadata, dict) and metadata.get("subject") == pairing.subject:
                rows.append({"device_id": device.id, "fingerprint": metadata.get("fingerprint"),
                             "status": device.status, "scope": "notifications"})
        return rows[:64]

    def call(self, action, params):
        fields = {"status": set(), "offer": set(), "preview": {"payload"},
                  "pin": {"payload", "confirm", "fingerprint"}, "revoke": {"device_id", "confirm"}}
        if action not in fields or not isinstance(params, dict) or set(params) != fields[action]:
            raise ValueError("device_pairing_arguments_invalid")
        pairing = self._factory()
        if action == "status":
            return {"signed_in": True, "devices": self._devices(pairing)}
        if action == "offer":
            return pairing.offer()
        if action == "preview":
            row = pairing.preview(params["payload"])
            return {key: row[key] for key in ("device_id", "fingerprint", "expires_at")}
        if action == "pin":
            result = pairing.pin(params["payload"], confirm=params["confirm"], fingerprint=params["fingerprint"])
        else:
            identifier = params["device_id"]
            if params["confirm"] is not True:
                raise PermissionError("device_pairing_human_confirmation_required")
            if not isinstance(identifier, str) or not re.fullmatch(r"android-[0-9a-f]{32}", identifier):
                raise ValueError("device_pairing_identity_invalid")
            if not any(row["device_id"] == identifier for row in self._devices(pairing)):
                raise PermissionError("device_pairing_account_mismatch")
            pairing.store.revoke_device(identifier, "human", "Human revoked device notification pairing")
            result = {"device_id": identifier, "revoked": True}
        self._changed(pairing.subject)
        return result
