"""Firebase UID-based DHT rendezvous identity shared with Android."""

from __future__ import annotations

import hashlib
import hmac

class PeerIdentityError(ValueError):
    pass


class PeerPairingRequired(PeerIdentityError):
    """No reviewed device-owned secret is available for peer authentication."""


def _validate_uid(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value
        or len(value.encode("utf-8")) > 128
        or any(ord(char) < 0x21 or ord(char) > 0x7E for char in value)
    ):
        raise PeerIdentityError("firebase_uid_invalid")
    return value


def subject_from_token(token: str) -> str:
    """Read the Firebase UID from the protected local ID token, without I/O."""
    from .auth import PeerAuthError, firebase_uid_from_local_token

    try:
        return firebase_uid_from_local_token(token, require_fresh_token=False)
    except PeerAuthError as exc:
        raise PeerIdentityError(str(exc)) from exc


def rendezvous_info_hash(subject: str) -> bytes:
    """Derive the Android-compatible BEP-5 target from a local Firebase UID."""
    uid = _validate_uid(subject)
    return hashlib.sha1(
        b"megasmoves-peer-rendezvous-v1\0" + uid.encode("utf-8")
    ).digest()


def account_peer_key(subject: str) -> bytes:
    """Fail closed: a Firebase UID is public identity, not a pairing secret."""
    _validate_uid(subject)
    raise PeerPairingRequired("secure_device_pairing_required")


def account_peer_proof(
    auth_key: bytes,
    kind: str,
    session_id: str,
    role: str,
    device_id: str,
    nonce: str,
    peer_nonce: str = "",
) -> str:
    if len(auth_key) != 32 or kind not in {"auth", "ack"}:
        raise ValueError("peer_auth_proof_input_invalid")
    message = "\0".join(
        ["MEGAS-P2P-AUTH-v1", kind, session_id, role, device_id, nonce, peer_nonce]
    ).encode("utf-8")
    return hmac.new(auth_key, message, hashlib.sha256).hexdigest()
