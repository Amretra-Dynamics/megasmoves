"""Small IPv4 BEP-5 client for decentralized peer rendezvous.

This is discovery/signaling bootstrap only. It does not relay application data.
Peer payloads use a separate authenticated/encrypted direct transport.
"""

from __future__ import annotations

import asyncio
import ipaddress
import secrets
import socket
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .bencode import BencodeError, decode, encode

BOOTSTRAP_NODES = (
    ("dht.transmissionbt.com", 6881),
    ("dht.libtorrent.org", 25401),
    ("router.bittorrent.com", 6881),
    ("router.utorrent.com", 6881),
)
_MAX_VISITED_NODES = 48
_MAX_NODES_PER_REPLY = 64
_MAX_PEERS_PER_REPLY = 16
_MAX_RETURNED_PEERS = 8
_MAX_ANNOUNCES = 16


@dataclass(slots=True)
class PeerAddress:
    host: str
    port: int
    node_id: bytes = field(default=b"", compare=False)

    def __hash__(self) -> int:
        return hash((self.host, self.port))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PeerAddress):
            return NotImplemented
        return (self.host, self.port) == (other.host, other.port)


def xor_distance(a: bytes, b: bytes) -> int:
    if len(a) != 20 or len(b) != 20:
        return (1 << 160) - 1
    return int.from_bytes(a, "big") ^ int.from_bytes(b, "big")


def parse_compact_nodes(raw: bytes) -> list[PeerAddress]:
    if not isinstance(raw, bytes) or len(raw) % 26 != 0:
        return []
    result: list[PeerAddress] = []
    for offset in range(0, min(len(raw), 26 * _MAX_NODES_PER_REPLY), 26):
        node_id = raw[offset : offset + 20]
        host = str(ipaddress.IPv4Address(raw[offset + 20 : offset + 24]))
        port = int.from_bytes(raw[offset + 24 : offset + 26], "big")
        if port and not ipaddress.IPv4Address(host).is_unspecified:
            result.append(PeerAddress(host, port, node_id=node_id))
    return result


def parse_compact_peers(values: object) -> list[PeerAddress]:
    if not isinstance(values, list):
        return []
    peers: list[PeerAddress] = []
    for value in values[:_MAX_PEERS_PER_REPLY]:
        if not isinstance(value, bytes) or len(value) != 6:
            continue
        host = str(ipaddress.IPv4Address(value[:4]))
        port = int.from_bytes(value[4:], "big")
        if port and not ipaddress.IPv4Address(host).is_unspecified:
            peers.append(PeerAddress(host, port))
    return peers


class _DhtProtocol(asyncio.DatagramProtocol):
    def __init__(self) -> None:
        self.transport: asyncio.DatagramTransport | None = None
        self.waiters: dict[bytes, asyncio.Future[tuple[dict[bytes, Any], tuple[str, int]]]] = {}
        self.packet_handler: Callable[[tuple[str, int], bytes], None] | None = None

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self.transport = transport  # type: ignore[assignment]

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        # App signaling has a non-bencoded frame; it is deliberately kept out
        # of BEP-5 KRPC transactions and is handled by the direct-link layer.
        if data.startswith(b"MEGAS/1\n"):
            if len(data) <= 1200 and self.packet_handler is not None:
                try:
                    self.packet_handler(addr, data)
                except Exception:
                    return
            return
        try:
            message = decode(data, max_bytes=4096)
        except BencodeError:
            return
        if not isinstance(message, dict) or message.get(b"y") not in (b"r", b"e"):
            return
        transaction = message.get(b"t")
        waiter = self.waiters.pop(transaction, None) if isinstance(transaction, bytes) else None
        if waiter is not None and not waiter.done():
            waiter.set_result((message, addr))


class Bep5PeerDiscovery:
    """Queries public DHT nodes and announces one account-scoped presence."""

    def __init__(
        self,
        info_hash: bytes,
        *,
        bootstrap_nodes: tuple[tuple[str, int], ...] = BOOTSTRAP_NODES,
        query_timeout: float = 1.25,
        max_nodes: int = _MAX_VISITED_NODES,
    ) -> None:
        if len(info_hash) != 20:
            raise ValueError("BEP-5 info_hash must be exactly 20 bytes")
        self.info_hash = info_hash
        self.bootstrap_nodes = bootstrap_nodes
        self.query_timeout = max(0.25, min(float(query_timeout), 2.5))
        self.max_nodes = max(1, min(int(max_nodes), _MAX_VISITED_NODES))
        self.node_id = secrets.token_bytes(20)
        self._protocol = _DhtProtocol()
        self._socket: asyncio.DatagramTransport | None = None
        self._bootstrap_cache: list[tuple[str, int]] = []
        self._bootstrap_cache_expires_at = 0.0

    async def start(self) -> None:
        if self._socket is not None:
            return
        loop = asyncio.get_running_loop()
        try:
            transport, protocol = await loop.create_datagram_endpoint(
                lambda: self._protocol,
                local_addr=("0.0.0.0", 42100),
                family=socket.AF_INET,
                allow_broadcast=True,
            )
        except OSError:
            transport, protocol = await loop.create_datagram_endpoint(
                lambda: self._protocol,
                local_addr=("0.0.0.0", 0),
                family=socket.AF_INET,
                allow_broadcast=True,
            )
        self._socket = transport  # type: ignore[assignment]
        self._protocol = protocol  # type: ignore[assignment]

    async def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None
        for waiter in tuple(self._protocol.waiters.values()):
            if not waiter.done():
                waiter.cancel()
        self._protocol.waiters.clear()

    def set_packet_handler(self, handler: Callable[[tuple[str, int], bytes], None] | None) -> None:
        self._protocol.packet_handler = handler

    def send_datagram(self, endpoint: PeerAddress | tuple[str, int], data: bytes) -> None:
        if self._socket is None:
            raise RuntimeError("peer_discovery_not_started")
        if not data.startswith(b"MEGAS/1\n") or len(data) > 1200:
            raise ValueError("direct_peer_datagram_invalid")
        target = (endpoint.host, endpoint.port) if isinstance(endpoint, PeerAddress) else endpoint
        self._socket.sendto(data, target)

    async def _bootstrap_addresses(self) -> list[tuple[str, int]]:
        loop = asyncio.get_running_loop()
        now = loop.time()
        if self._bootstrap_cache and self._bootstrap_cache_expires_at > now:
            return list(self._bootstrap_cache)
        result: list[tuple[str, int]] = []
        for host, port in self.bootstrap_nodes[:4]:
            try:
                entries = await asyncio.wait_for(
                    loop.getaddrinfo(host, port, family=socket.AF_INET, type=socket.SOCK_DGRAM),
                    timeout=2.0,
                )
            except (OSError, asyncio.TimeoutError):
                continue
            result.extend((entry[4][0], entry[4][1]) for entry in entries[:2])
        self._bootstrap_cache = list(dict.fromkeys(result))[:8]
        self._bootstrap_cache_expires_at = now + (300 if self._bootstrap_cache else 30)
        return list(self._bootstrap_cache)

    async def _query(
        self,
        endpoint: tuple[str, int],
        query: bytes,
        arguments: dict[bytes, object],
    ) -> dict[bytes, Any] | None:
        if self._socket is None:
            return None
        loop = asyncio.get_running_loop()
        transaction = secrets.token_bytes(4)
        future: asyncio.Future[tuple[dict[bytes, Any], tuple[str, int]]] = loop.create_future()
        self._protocol.waiters[transaction] = future
        packet = encode(
            {
                b"a": arguments,
                b"q": query,
                b"t": transaction,
                b"y": b"q",
            }
        )
        try:
            self._socket.sendto(packet, endpoint)
            message, _ = await asyncio.wait_for(future, timeout=self.query_timeout)
        except (OSError, asyncio.TimeoutError, BencodeError):
            self._protocol.waiters.pop(transaction, None)
            return None
        response = message.get(b"r")
        return response if isinstance(response, dict) else None

    async def discover(self) -> list[PeerAddress]:
        if self._socket is None:
            await self.start()
        nodes = await self._bootstrap_addresses()
        if not nodes:
            return []

        pending: list[tuple[int, tuple[str, int]]] = [
            ((1 << 160) - 1, endpoint) for endpoint in nodes
        ]
        visited: set[tuple[str, int]] = set()
        announce_tokens: dict[tuple[str, int], bytes] = {}
        peers: set[PeerAddress] = set()

        while pending and len(visited) < self.max_nodes:
            pending.sort(key=lambda item: item[0])
            batch: list[tuple[str, int]] = []
            while pending and len(batch) < 4 and len(visited) < self.max_nodes:
                _, endpoint = pending.pop(0)
                if endpoint not in visited:
                    visited.add(endpoint)
                    batch.append(endpoint)
            if not batch:
                continue
            replies = await asyncio.gather(
                *(
                    self._query(
                        endpoint,
                        b"get_peers",
                        {b"id": self.node_id, b"info_hash": self.info_hash},
                    )
                    for endpoint in batch
                )
            )
            for endpoint, reply in zip(batch, replies, strict=True):
                if not reply:
                    continue
                token = reply.get(b"token")
                if isinstance(token, bytes) and token:
                    announce_tokens[endpoint] = token
                peers.update(parse_compact_peers(reply.get(b"values")))
                for key in (b"nodes", b"nodes6"):
                    # This implementation intentionally uses IPv4 KRPC only;
                    # ignore nodes6 until the Android parity layer supports it.
                    if key == b"nodes":
                        for candidate in parse_compact_nodes(reply.get(key, b"")):
                            pair = (candidate.host, candidate.port)
                            if pair not in visited and not any(p == pair for _, p in pending):
                                dist = xor_distance(candidate.node_id, self.info_hash)
                                pending.append((dist, pair))
                if len(pending) > self.max_nodes * 4:
                    pending.sort(key=lambda item: item[0])
                    del pending[self.max_nodes * 4 :]

        await asyncio.gather(
            *(
                self._query(
                    endpoint,
                    b"announce_peer",
                    {
                        b"id": self.node_id,
                        b"info_hash": self.info_hash,
                        b"implied_port": 1,
                        b"port": 0,
                        b"token": token,
                    },
                )
                for endpoint, token in list(announce_tokens.items())[:_MAX_ANNOUNCES]
            ),
            return_exceptions=True,
        )
        return sorted(peers, key=lambda peer: (peer.host, peer.port))[:_MAX_RETURNED_PEERS]
