"""Human-controlled device-key pins in the existing Megas Local authority.

Pairing payloads carry public keys only. Their authenticity comes from comparing
the fingerprint on the other trusted device, not from a public Firebase UID.
No pairing operation is exposed as an ordinary model tool.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass, field
import hashlib
import hmac
import json
import re
import secrets
import time

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from megas.credential_store import WindowsDPAPICredentialStore
from megas.local.store import LocalStore, _utc_now
from .identity import PeerPairingRequired, _validate_uid

FORMAT = "megas-device-pairing"
VERSION = 2
MAX_PEERS = 8


def _public(key):
    return key.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)


def _load_public(encoded):
    if not isinstance(encoded, str) or len(encoded) > 256:
        raise ValueError("device_public_key_invalid")
    try:
        raw = base64.b64decode(encoded, validate=True)
        key = serialization.load_der_public_key(raw)
    except (ValueError, TypeError) as exc:
        raise ValueError("device_public_key_invalid") from exc
    if not isinstance(key, ec.EllipticCurvePublicKey) or not isinstance(key.curve, ec.SECP256R1):
        raise ValueError("device_public_key_invalid")
    if _public(key) != raw:
        raise ValueError("device_public_key_invalid")
    return key


def _fingerprint(key):
    return hashlib.sha256(_public(key)).hexdigest()


@dataclass(frozen=True)
class PairedDevice:
    device_id: str
    local_device_id: str
    fingerprint: str
    auth_key: bytes = field(repr=False)
    rendezvous: bytes = field(repr=False)


class DevicePairingStore:
    def __init__(self, store: LocalStore, subject: str, *, role="windows", private_store=None, now=time.time):
        self.store = store
        self.subject = _validate_uid(subject)
        if role not in {"windows", "android"}:
            raise ValueError("device_role_invalid")
        self.role, self.now = role, now
        scope = hashlib.sha256(subject.encode()).hexdigest()
        self.identity_setting = "devnet.identity.v2." + scope
        self.private_store = private_store or WindowsDPAPICredentialStore(
            store.db_path.parent / "operator" / ("device-key-" + scope + ".credential"))

    def _identity(self):
        # The existing authority transaction serializes key initialization across
        # GUI/MCP processes. A corrupt or unavailable secure store fails closed.
        with self.store._transaction() as connection:
            existing = connection.execute("SELECT value_json FROM local_settings WHERE key=?", (self.identity_setting,)).fetchone()
            if not self.private_store.exists():
                if existing is not None:
                    raise PermissionError("device_private_key_missing")
                key = ec.generate_private_key(ec.SECP256R1())
                raw = key.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
                self.private_store.write(base64.b64encode(raw).decode())
            raw = base64.b64decode(self.private_store.read(), validate=True)
            key = serialization.load_der_private_key(raw, None)
            if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(key.curve, ec.SECP256R1):
                raise ValueError("device_private_key_invalid")
            public = key.public_key()
            fingerprint = _fingerprint(public)
            identity = {"device_id": self.role + "-" + fingerprint[:32], "role": self.role,
                "public_key": base64.b64encode(_public(public)).decode(), "fingerprint": fingerprint}
            if existing is not None and json.loads(existing[0]) != identity:
                raise PermissionError("device_identity_changed")
            connection.execute("INSERT INTO local_settings(key,value_json) VALUES(?,?) ON CONFLICT(key) DO NOTHING",
                (self.identity_setting, json.dumps(identity, sort_keys=True)))
        return key, identity

    def offer(self):
        _, identity = self._identity()
        payload = {"format": FORMAT, "version": VERSION, "subject": self.subject,
            **{k: identity[k] for k in ("device_id", "role", "public_key")},
            "expires_at": int(self.now()) + 300, "nonce": secrets.token_hex(16)}
        return {"payload": json.dumps(payload, sort_keys=True, separators=(",", ":")),
            "fingerprint": identity["fingerprint"], "expires_at": payload["expires_at"]}

    def preview(self, payload: str):
        if not isinstance(payload, str) or len(payload.encode()) > 4096:
            raise ValueError("device_pairing_payload_invalid")
        try:
            row = json.loads(payload)
        except ValueError as exc:
            raise ValueError("device_pairing_payload_invalid") from exc
        fields = {"format", "version", "subject", "device_id", "role", "public_key", "expires_at", "nonce"}
        if not isinstance(row, dict) or set(row) != fields or row["format"] != FORMAT or type(row["version"]) is not int or row["version"] != VERSION:
            raise ValueError("device_pairing_payload_invalid")
        if row["subject"] != self.subject:
            raise PermissionError("device_pairing_account_mismatch")
        expected_role = "android" if self.role == "windows" else "windows"
        if row["role"] != expected_role:
            raise ValueError("device_pairing_role_invalid")
        expires = row["expires_at"]
        if type(expires) is not int or not self.now() < expires <= self.now() + 330:
            raise ValueError("device_pairing_offer_expired")
        if not isinstance(row["nonce"], str) or not re.fullmatch("[0-9a-f]{32}", row["nonce"]):
            raise ValueError("device_pairing_payload_invalid")
        key = _load_public(row["public_key"])
        fingerprint = _fingerprint(key)
        if row["device_id"] != expected_role + "-" + fingerprint[:32]:
            raise ValueError("device_pairing_identity_invalid")
        return {**row, "fingerprint": fingerprint}

    def pin(self, payload: str, *, confirm: bool, fingerprint: str):
        if confirm is not True:
            raise PermissionError("device_pairing_human_confirmation_required")
        row = self.preview(payload)
        if not isinstance(fingerprint, str) or not hmac.compare_digest(fingerprint, row["fingerprint"]):
            raise PermissionError("device_pairing_fingerprint_mismatch")
        self._identity()
        identifier = row["device_id"]
        metadata = {k: row[k] for k in ("subject", "role", "public_key", "fingerprint")}
        with self.store._transaction() as connection:
            existing = connection.execute("SELECT status,type,scopes FROM local_devices WHERE id=?", (identifier,)).fetchone()
            if existing is not None and existing[0] != "active":
                raise PermissionError("device_pairing_revoked")
            if existing is not None and (existing[1] != "devnet-" + row["role"] or "notifications" not in json.loads(existing[2] or "[]")):
                raise PermissionError("device_pairing_authority_mismatch")
            if existing is None:
                count = connection.execute("SELECT COUNT(*) FROM local_devices WHERE status='active' AND type IN ('devnet-android','devnet-windows')").fetchone()[0]
                if count >= MAX_PEERS:
                    raise ValueError("device_pairing_capacity_reached")
                connection.execute("INSERT INTO local_devices(id,name,type,scopes,created_at,status) VALUES(?,?,?,?,?,'active')",
                    (identifier, "Paired " + row["role"], "devnet-" + row["role"], '["notifications"]', _utc_now()))
            setting = "devnet.peer.v2." + identifier
            old = connection.execute("SELECT value_json FROM local_settings WHERE key=?", (setting,)).fetchone()
            if old is not None and json.loads(old[0]) != metadata:
                raise PermissionError("device_pairing_pin_changed")
            connection.execute("INSERT INTO local_settings(key,value_json) VALUES(?,?) ON CONFLICT(key) DO NOTHING", (setting, json.dumps(metadata, sort_keys=True)))
        return {"device_id": identifier, "fingerprint": row["fingerprint"], "paired": True, "scope": "notifications"}

    def credentials(self):
        active = []
        for device in self.store.list_devices():
            if device.status != "active" or device.type not in {"devnet-android", "devnet-windows"}:
                continue
            if "notifications" not in json.loads(device.scopes or "[]"):
                continue
            row = self.store.get_setting("devnet.peer.v2." + device.id)
            if not isinstance(row, dict) or row.get("subject") != self.subject:
                continue
            public = _load_public(row["public_key"])
            if row.get("fingerprint") != _fingerprint(public) or device.id != row["role"] + "-" + _fingerprint(public)[:32]:
                raise PermissionError("device_pairing_pin_invalid")
            active.append((device, row, public))
        if not active:
            raise PeerPairingRequired("secure_device_pairing_required")
        if len(active) > MAX_PEERS:
            raise PermissionError("device_pairing_capacity_reached")
        key, identity = self._identity()
        peers = []
        for device, row, public in active:
            ids = sorted((identity["device_id"], device.id))
            context = ("MEGAS-DEVICE-PAIR-v2\0" + self.subject + "\0" + "\0".join(ids)).encode()
            auth = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=context).derive(key.exchange(ec.ECDH(), public))
            rendezvous = hmac.new(auth, b"MEGAS-DEVICE-DISCOVERY-v2", hashlib.sha256).digest()[:20]
            peers.append(PairedDevice(device.id, identity["device_id"], row["fingerprint"], auth, rendezvous))
        return peers
