"""Bounded BEP-5 bencoding codec (bytes-first, duplicate keys rejected)."""

from __future__ import annotations


class BencodeError(Exception):
    pass


def encode(value: object) -> bytes:
    if isinstance(value, bytes):
        return f"{len(value)}:".encode("ascii") + value
    if isinstance(value, str):
        encoded = value.encode("utf-8")
        return f"{len(encoded)}:".encode("ascii") + encoded
    if isinstance(value, int) and not isinstance(value, bool):
        return f"i{value}e".encode("ascii")
    if isinstance(value, (list, tuple)):
        return b"l" + b"".join(encode(v) for v in value) + b"e"
    if isinstance(value, dict):
        encoded_keys: list[tuple[bytes, bytes]] = []
        for k, v in value.items():
            if isinstance(k, str):
                bk = k.encode("utf-8")
            elif isinstance(k, bytes):
                bk = k
            else:
                raise BencodeError("dict_key_must_be_bytes_or_str")
            encoded_keys.append((bk, encode(v)))
        encoded_keys.sort(key=lambda item: item[0])
        return b"d" + b"".join(f"{len(k)}:".encode("ascii") + k + v for k, v in encoded_keys) + b"e"
    raise BencodeError(f"unsupported_bencode_type_{type(value).__name__}")


def decode(packet: bytes, max_bytes: int = 65536) -> object:
    if not isinstance(packet, (bytes, bytearray)):
        raise BencodeError("packet_must_be_bytes")
    if not packet:
        raise BencodeError("packet_empty")
    if len(packet) > max_bytes:
        raise BencodeError("packet_size_invalid")

    cursor = 0

    def parse(depth: int) -> object:
        nonlocal cursor
        if depth > 16:
            raise BencodeError("max_depth_exceeded")
        if cursor >= len(packet):
            raise BencodeError("unexpected_end_of_packet")
        marker = packet[cursor]
        if marker == ord("i"):
            end = packet.find(b"e", cursor)
            if end < 0:
                raise BencodeError("integer_terminator_missing")
            raw_int = packet[cursor + 1 : end]
            if not raw_int:
                raise BencodeError("integer_empty")
            if raw_int == b"-0" or (raw_int.startswith(b"0") and len(raw_int) > 1) or (raw_int.startswith(b"-0") and len(raw_int) > 2):
                raise BencodeError("integer_invalid_format")
            try:
                val = int(raw_int)
            except ValueError as exc:
                raise BencodeError("integer_invalid") from exc
            cursor = end + 1
            return val
        if marker == ord("l"):
            cursor += 1
            items = []
            while cursor < len(packet) and packet[cursor] != ord("e"):
                items.append(parse(depth + 1))
            if cursor >= len(packet):
                raise BencodeError("list_terminator_missing")
            cursor += 1
            return items
        if marker == ord("d"):
            cursor += 1
            items_dict: dict[bytes, object] = {}
            previous: bytes | None = None
            while cursor < len(packet) and packet[cursor] != ord("e"):
                k = parse(depth + 1)
                if not isinstance(k, bytes):
                    raise BencodeError("dict_key_not_bytes")
                if previous is not None and k <= previous:
                    raise BencodeError("dict_keys_not_sorted_or_duplicate")
                previous = k
                v = parse(depth + 1)
                items_dict[k] = v
            if cursor >= len(packet):
                raise BencodeError("dict_terminator_missing")
            cursor += 1
            return items_dict
        if ord("0") <= marker <= ord("9"):
            colon = packet.find(b":", cursor)
            if colon < 0:
                raise BencodeError("string_length_terminator_missing")
            raw_len = packet[cursor:colon]
            if not raw_len or (raw_len.startswith(b"0") and len(raw_len) > 1):
                raise BencodeError("string_length_invalid")
            try:
                size = int(raw_len)
            except ValueError as exc:
                raise BencodeError("string_length_invalid") from exc
            start = colon + 1
            end = start + size
            if end > len(packet):
                raise BencodeError("string_exceeds_packet")
            cursor = end
            return packet[start:end]
        raise BencodeError("marker_invalid")

    res = parse(0)
    if cursor != len(packet):
        raise BencodeError("trailing_packet_data")
    return res
