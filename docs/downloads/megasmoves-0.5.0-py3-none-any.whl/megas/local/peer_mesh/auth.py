"""Local verification of the signed-in Firebase account token."""

from __future__ import annotations

import base64
import json
import math
import re
import threading
import time
from urllib.request import Request, urlopen

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

FIREBASE_PROJECT_ID = "amretradynamics"
MAX_LOCAL_TOKEN_BYTES = 16 * 1024
_FIREBASE_CERTS_URL = (
    "https://www.googleapis.com/robot/v1/metadata/x509/"
    "securetoken@system.gserviceaccount.com"
)
_CACHE_CONTROL_MAX_AGE_RE = re.compile(r"(?:^|,)\s*max-age=(\d+)", re.IGNORECASE)
_CERT_CACHE_LOCK = threading.Lock()
_CERT_CACHE: dict[str, str] = {}
_CERT_CACHE_EXPIRES_AT = 0.0


class PeerAuthError(ValueError):
    pass


def _decode_segment(value: str) -> bytes:
    try:
        return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (ValueError, base64.binascii.Error) as exc:
        raise PeerAuthError("firebase_local_token_encoding_invalid") from exc


def _validate_uid(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value
        or len(value.encode("utf-8")) > 128
        or any(ord(char) < 0x21 or ord(char) > 0x7E for char in value)
    ):
        raise PeerAuthError("firebase_uid_invalid")
    return value


def _firebase_signing_keys(*, force_refresh: bool = False) -> dict[str, str]:
    """Fetch and cache Firebase's public ID-token signing certificates."""
    global _CERT_CACHE, _CERT_CACHE_EXPIRES_AT
    now = time.time()
    with _CERT_CACHE_LOCK:
        if not force_refresh and _CERT_CACHE and _CERT_CACHE_EXPIRES_AT > now:
            return dict(_CERT_CACHE)

        headers = {"Accept": "application/json"}
        if force_refresh:
            headers["Cache-Control"] = "no-cache"
        request = Request(_FIREBASE_CERTS_URL, headers=headers)
        try:
            with urlopen(request, timeout=5.0) as response:
                raw = response.read(256 * 1024 + 1)
                cache_control = response.headers.get("Cache-Control", "")
        except Exception as exc:
            raise PeerAuthError("firebase_signing_keys_unavailable") from exc
        if len(raw) > 256 * 1024:
            raise PeerAuthError("firebase_signing_keys_response_too_large")
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise PeerAuthError("firebase_signing_keys_response_invalid") from exc
        if not isinstance(payload, dict) or not payload or any(
            not isinstance(kid, str)
            or not kid
            or not isinstance(pem, str)
            or "BEGIN CERTIFICATE" not in pem
            for kid, pem in payload.items()
        ):
            raise PeerAuthError("firebase_signing_keys_response_invalid")

        match = _CACHE_CONTROL_MAX_AGE_RE.search(cache_control)
        max_age = int(match.group(1)) if match else 300
        refreshed = dict(_CERT_CACHE)
        refreshed.update(payload)
        while len(refreshed) > 32:
            refreshed.pop(next(iter(refreshed)))
        _CERT_CACHE = refreshed
        _CERT_CACHE_EXPIRES_AT = now + min(max(max_age, 30), 21600)
        return dict(_CERT_CACHE)


def _verify_firebase_signature(
    *, key_id: str, signing_input: bytes, signature: bytes, allow_unknown_key: bool = False
) -> None:
    for force_refresh in (False, True):
        certificates = _firebase_signing_keys(force_refresh=force_refresh)
        pem = certificates.get(key_id)
        if pem is None:
            continue
        try:
            certificate = x509.load_pem_x509_certificate(pem.encode("ascii"))
            certificate.public_key().verify(
                signature,
                signing_input,
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
        except Exception as exc:
            raise PeerAuthError("firebase_local_token_signature_invalid") from exc
        return
    if not allow_unknown_key:
        raise PeerAuthError("firebase_local_token_signing_key_unknown")


def firebase_uid_from_local_token(
    token: str,
    *,
    project_id: str = FIREBASE_PROJECT_ID,
    require_fresh_token: bool = True,
) -> str:
    """Verify a locally stored Firebase ID token and return its UID.

    Google's rotating public signing certificates verify the signature. No
    Megas endpoint or Firebase service-account credential is required. The
    bearer token is used only with the configured relay over TLS and is never
    forwarded to another device or included in logs.
    """
    if not isinstance(token, str) or len(token.encode("utf-8")) > MAX_LOCAL_TOKEN_BYTES:
        raise PeerAuthError("firebase_local_token_size_invalid")
    parts = token.split(".")
    if len(parts) != 3 or not all(parts):
        raise PeerAuthError("firebase_local_token_format_invalid")
    try:
        header = json.loads(_decode_segment(parts[0]).decode("utf-8"))
        claims = json.loads(_decode_segment(parts[1]).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PeerAuthError("firebase_local_token_claims_invalid") from exc
    if not isinstance(header, dict) or header.get("alg") != "RS256":
        raise PeerAuthError("firebase_local_token_algorithm_invalid")
    key_id = header.get("kid")
    if not isinstance(key_id, str) or not key_id or len(key_id) > 128:
        raise PeerAuthError("firebase_local_token_key_id_invalid")
    if not isinstance(claims, dict):
        raise PeerAuthError("firebase_local_token_claims_invalid")
    if (
        claims.get("iss") != f"https://securetoken.google.com/{project_id}"
        or claims.get("aud") != project_id
    ):
        raise PeerAuthError("firebase_local_token_project_invalid")
    subject = _validate_uid(claims.get("sub"))
    expires_at = claims.get("exp")
    issued_at = claims.get("iat")
    auth_time = claims.get("auth_time")
    now = time.time()
    if (
        isinstance(expires_at, bool)
        or not isinstance(expires_at, (int, float))
        or not math.isfinite(expires_at)
        or isinstance(issued_at, bool)
        or not isinstance(issued_at, (int, float))
        or not math.isfinite(issued_at)
        or isinstance(auth_time, bool)
        or not isinstance(auth_time, (int, float))
        or expires_at <= issued_at
        or (require_fresh_token and (expires_at <= now or issued_at > now + 30 or auth_time > now + 30))
        or auth_time > issued_at
    ):
        raise PeerAuthError("firebase_local_token_time_claims_invalid")
    _verify_firebase_signature(
        key_id=key_id,
        signing_input=f"{parts[0]}.{parts[1]}".encode("ascii"),
        signature=_decode_segment(parts[2]),
        allow_unknown_key=not require_fresh_token,
    )
    return subject


# Re-export identity primitives for callers importing from auth
from .identity import account_peer_key, account_peer_proof  # noqa: E402
