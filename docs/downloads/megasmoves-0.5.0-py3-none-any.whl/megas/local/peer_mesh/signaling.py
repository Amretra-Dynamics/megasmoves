"""Account-HMAC authenticated UDP signaling frames shared with Android."""

from __future__ import annotations

import time
import hashlib
import hmac
import uuid
import zlib
from dataclasses import dataclass, field

MAGIC = b"MEGAS/1\n"
MAX_DATAGRAM_BYTES = 1200
MAX_SIGNAL_BYTES = 32 * 1024
MAX_FRAGMENTS = 32
FRAGMENT_BYTES = 1050
_HEADER_BYTES = len(MAGIC) + 1 + 16 + 1 + 1 + 1
_CHECKSUM_BYTES = 4
_MAC_BYTES = 16


class SignalFrameError(ValueError):
    pass


def pack_signal(
    kind: str,
    session_id: str,
    device_id: str,
    payload: bytes,
    *,
    auth_key: bytes,
) -> list[bytes]:
    if len(kind) != 1 or kind not in {"H", "O", "A"}:
        raise SignalFrameError("signal_kind_invalid")
    try:
        session = uuid.UUID(hex=session_id).bytes
    except (ValueError, AttributeError) as exc:
        raise SignalFrameError("signal_session_id_invalid") from exc
    source = device_id.encode("ascii", errors="strict")
    if not 1 <= len(source) <= 64 or any(value < 0x21 or value > 0x7E for value in source):
        raise SignalFrameError("signal_device_id_invalid")
    if not isinstance(payload, bytes) or not payload or len(payload) > MAX_SIGNAL_BYTES:
        raise SignalFrameError("signal_payload_size_invalid")
    if not isinstance(auth_key, bytes) or len(auth_key) != 32:
        raise SignalFrameError("signal_auth_key_invalid")
    count = (len(payload) + FRAGMENT_BYTES - 1) // FRAGMENT_BYTES
    if count > MAX_FRAGMENTS:
        raise SignalFrameError("signal_fragment_count_invalid")
    frames = []
    for index in range(count):
        chunk = payload[index * FRAGMENT_BYTES : (index + 1) * FRAGMENT_BYTES]
        unsigned = MAGIC + kind.encode("ascii") + session + bytes((count, index, len(source))) + source + chunk
        mac = hmac.new(auth_key, unsigned, hashlib.sha256).digest()[:_MAC_BYTES]
        authenticated = unsigned + mac
        frame = authenticated + zlib.crc32(authenticated).to_bytes(_CHECKSUM_BYTES, "big")
        if len(frame) > MAX_DATAGRAM_BYTES:
            raise SignalFrameError("signal_datagram_too_large")
        frames.append(frame)
    return frames


@dataclass(frozen=True, slots=True)
class DecodedFrame:
    kind: str
    session_id: str
    device_id: str
    total: int
    index: int
    payload: bytes


def unpack_signal(frame: bytes, *, auth_key: bytes) -> DecodedFrame:
    if not isinstance(auth_key, bytes) or len(auth_key) != 32:
        raise SignalFrameError("signal_auth_key_invalid")
    if not isinstance(frame, bytes) or len(frame) < _HEADER_BYTES + 1 + _MAC_BYTES + _CHECKSUM_BYTES or len(frame) > MAX_DATAGRAM_BYTES:
        raise SignalFrameError("signal_frame_size_invalid")
    if not frame.startswith(MAGIC):
        raise SignalFrameError("signal_magic_invalid")
    authenticated, supplied_checksum = frame[:-_CHECKSUM_BYTES], frame[-_CHECKSUM_BYTES:]
    expected_checksum = zlib.crc32(authenticated).to_bytes(_CHECKSUM_BYTES, "big")
    if supplied_checksum != expected_checksum:
        raise SignalFrameError("signal_checksum_invalid")
    unsigned, supplied_mac = authenticated[:-_MAC_BYTES], authenticated[-_MAC_BYTES:]
    expected_mac = hmac.new(auth_key, unsigned, hashlib.sha256).digest()[:_MAC_BYTES]
    if not hmac.compare_digest(supplied_mac, expected_mac):
        raise SignalFrameError("signal_authentication_invalid")
    offset = len(MAGIC)
    try:
        kind = frame[offset : offset + 1].decode("ascii")
        session_id = uuid.UUID(bytes=frame[offset + 1 : offset + 17]).hex
    except (UnicodeDecodeError, ValueError) as exc:
        raise SignalFrameError("signal_header_invalid") from exc
    total, index, source_len = frame[offset + 17 : offset + 20]
    source_start = offset + 20
    payload_start = source_start + source_len
    if (
        kind not in {"H", "O", "A"}
        or total < 1
        or total > MAX_FRAGMENTS
        or index >= total
        or source_len < 1
        or source_len > 64
        or payload_start >= len(unsigned)
    ):
        raise SignalFrameError("signal_header_invalid")
    try:
        device_id = frame[source_start:payload_start].decode("ascii")
    except UnicodeDecodeError as exc:
        raise SignalFrameError("signal_device_id_invalid") from exc
    if any(value < 0x21 or value > 0x7E for value in device_id.encode("ascii")):
        raise SignalFrameError("signal_device_id_invalid")
    return DecodedFrame(kind, session_id, device_id, total, index, unsigned[payload_start:])


@dataclass(slots=True)
class _Partial:
    kind: str
    device_id: str
    total: int
    created_at: float = field(default_factory=time.monotonic)
    fragments: dict[int, bytes] = field(default_factory=dict)


class SignalAssembler:
    """Reassembles bounded SDP frames only after per-frame account HMAC checks."""

    def __init__(self, *, max_messages: int = 32, ttl_seconds: float = 20.0) -> None:
        self.max_messages = max(1, min(max_messages, 128))
        self.ttl_seconds = max(1.0, min(ttl_seconds, 120.0))
        self._partial: dict[tuple[tuple[str, int], str, str], _Partial] = {}

    def push(
        self,
        address: tuple[str, int],
        raw: bytes,
        *,
        auth_key: bytes,
    ) -> tuple[str, str, str, bytes] | None:
        frame = unpack_signal(raw, auth_key=auth_key)
        now = time.monotonic()
        for key, partial in tuple(self._partial.items()):
            if now - partial.created_at > self.ttl_seconds:
                self._partial.pop(key, None)
        key = (address, frame.session_id, frame.kind)
        partial = self._partial.get(key)
        if partial is None:
            if len(self._partial) >= self.max_messages:
                oldest = min(self._partial, key=lambda item: self._partial[item].created_at)
                self._partial.pop(oldest, None)
            partial = _Partial(frame.kind, frame.device_id, frame.total)
            self._partial[key] = partial
        if partial.total != frame.total or partial.device_id != frame.device_id:
            self._partial.pop(key, None)
            raise SignalFrameError("signal_fragment_conflict")
        partial.fragments.setdefault(frame.index, frame.payload)
        if sum(map(len, partial.fragments.values())) > MAX_SIGNAL_BYTES:
            self._partial.pop(key, None)
            raise SignalFrameError("signal_reassembly_too_large")
        if len(partial.fragments) != partial.total:
            return None
        payload = b"".join(partial.fragments[index] for index in range(partial.total))
        self._partial.pop(key, None)
        return partial.kind, frame.session_id, partial.device_id, payload
