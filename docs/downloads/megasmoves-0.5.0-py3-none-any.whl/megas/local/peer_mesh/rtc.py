"""Direct-only WebRTC sessions interoperable with the Android peer client.

Public BEP-5 DHT nodes exchange only short-lived UDP endpoint announcements.
SDP and notifications are sent directly between peers; there is no TURN/data
relay and no Android VpnService. If direct ICE cannot connect, the link stays
offline instead of falling back to a cloud route.
"""

from __future__ import annotations

import asyncio
import hmac
import json
import re
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from aiortc import RTCConfiguration, RTCIceServer, RTCPeerConnection, RTCSessionDescription

from .auth import PeerAuthError, account_peer_proof
from .bep5 import Bep5PeerDiscovery, PeerAddress
from .identity import rendezvous_info_hash
from .signaling import SignalAssembler, SignalFrameError, pack_signal

STUN_SERVERS = (
    "stun:stun.l.google.com:19302",
    "stun:stun1.l.google.com:19302",
    "stun:stun.cloudflare.com:3478",
)
MAX_DATA_CHANNEL_MESSAGE_BYTES = 16 * 1024
MAX_SDP_CHARS = 32 * 1024
MAX_ACTIVE_CONNECTIONS = 2
MAX_PENDING_ACKS = 8
MAX_INBOUND_SIGNAL_TASKS = 32
MAX_SEEN_HELLOS = 64
DISCOVERY_INTERVAL_SECONDS = 8
# v1.0.546 Android emitted two UUIDs (64 hex characters). Accept that bounded
# legacy nonce as well as the common 32-hex nonce; the pair-key proof is mandatory.
_NONCE_RE = re.compile(r"(?:[0-9a-f]{32}|[0-9a-f]{64})\Z")


def _local_gateway_candidates() -> list[str]:
    candidates: set[str] = set()
    try:
        import subprocess
        from megas.adapters.base import windows_subprocess_kwargs
        out = subprocess.check_output(["netsh", "interface", "ipv4", "show", "addresses"],
                                      text=True, timeout=1.0, stdin=subprocess.DEVNULL,
                                      **windows_subprocess_kwargs())
        for line in out.splitlines():
            m = re.search(r"Default Gateway:\s+([0-9.]+)", line)
            if m and m.group(1) not in {"0.0.0.0", "127.0.0.1"}:
                candidates.add(m.group(1))
    except Exception:
        pass
    try:
        import subprocess
        from megas.adapters.base import windows_subprocess_kwargs
        out = subprocess.check_output(["arp", "-a"], text=True, timeout=1.0,
                                      stdin=subprocess.DEVNULL, **windows_subprocess_kwargs())
        for line in out.splitlines():
            m = re.search(r"^\s*([0-9.]+)\s+([0-9a-fA-F-]+)\s+dynamic", line)
            if m and not m.group(1).startswith("224.") and not m.group(1).startswith("239."):
                candidates.add(m.group(1))
    except Exception:
        pass
    return sorted(candidates)


@dataclass(slots=True)
class _Connection:
    peer: PeerAddress
    session_id: str
    pc: RTCPeerConnection
    remote_device_id: str
    remote_role: str = "android"
    channel: Any = None
    local_nonce: str = ""
    remote_nonce: str = ""
    remote_identity_verified: bool = False
    auth_ack_received: bool = False
    retry_task: asyncio.Task | None = None
    expiry_task: asyncio.Task | None = None

    def __post_init__(self) -> None:
        if not self.local_nonce:
            self.local_nonce = uuid.uuid4().hex

    @property
    def authenticated(self) -> bool:
        return (
            self.remote_identity_verified
            and self.auth_ack_received
            and self.channel is not None
            and self.channel.readyState == "open"
        )


class DirectPeerRtcMesh:
    """Windows endpoint for the Android-compatible direct peer protocol."""

    def __init__(
        self,
        account_subject: str,
        *,
        peer_auth_key: bytes,
        role: str = "windows",
        on_notification: Callable[[dict[str, Any]], None] | None = None,
        discovery: Bep5PeerDiscovery | None = None,
        local_device_id: str | None = None,
        expected_device_id: str | None = None,
        rendezvous: bytes | None = None,
        protocol_version: int = 1,
    ) -> None:
        if role != "windows":
            raise ValueError("peer_role_invalid")
        if not isinstance(peer_auth_key, bytes) or len(peer_auth_key) != 32:
            raise ValueError("peer_auth_key_invalid")
        self.role = role
        self.account_subject = account_subject
        self.peer_auth_key = peer_auth_key
        if protocol_version not in {1, 2}:
            raise ValueError("peer_protocol_invalid")
        if protocol_version == 2 and (
            not re.fullmatch(r"windows-[0-9a-f]{32}", local_device_id or "")
            or not re.fullmatch(r"android-[0-9a-f]{32}", expected_device_id or "")
            or not isinstance(rendezvous, bytes) or len(rendezvous) != 20
        ):
            raise ValueError("paired_peer_identity_required")
        self.protocol_version = protocol_version
        self.expected_device_id = expected_device_id
        self.device_id = local_device_id or f"windows-{uuid.uuid4().hex}"
        self.on_notification = on_notification
        self.discovery = discovery or Bep5PeerDiscovery(rendezvous or rendezvous_info_hash(account_subject))
        self._assembler = SignalAssembler()
        self._connections_by_session: dict[str, _Connection] = {}
        self._connections_by_peer: dict[tuple[str, int], _Connection] = {}
        self._pending_acks: dict[str, asyncio.Future[bool]] = {}
        self._started = False
        self._closed = False
        self._discovery_task: asyncio.Task | None = None
        self._seen_hellos: dict[tuple[str, int], float] = {}
        self._inbound_signal_tasks: set[asyncio.Task] = set()

    @property
    def status(self) -> dict[str, Any]:
        return {
            "started": self._started,
            "account_authenticated": self._started and not self._closed,
            "direct_peer_count": sum(
                1 for connection in self._connections_by_session.values()
                if connection.authenticated
            ),
            "route": "direct_webrtc_only",
            "relay_configured": False,
            "vpn_service": False,
        }

    async def start(self) -> None:
        if self._started:
            return
        if self._closed:
            raise RuntimeError("peer_mesh_closed")
        await self.discovery.start()
        self.discovery.set_packet_handler(self._on_direct_packet)
        self._started = True
        self._discovery_task = asyncio.create_task(
            self._discovery_loop(), name="MegasDirectPeerDiscovery"
        )

    async def _discovery_loop(self) -> None:
        failures = 0
        while not self._closed:
            try:
                self._send_hello(PeerAddress("255.255.255.255", 42100))
                for host in _local_gateway_candidates():
                    self._send_hello(PeerAddress(host, 42100))
                peers = await self.discovery.discover()
                failures = 0
                for peer in peers[:4]:
                    if 0 < peer.port <= 65535:
                        self._send_hello(peer)
            except asyncio.CancelledError:
                raise
            except Exception:
                failures = min(failures + 1, 4)
            has_authenticated = any(c.authenticated for c in self._connections_by_session.values())
            base_interval = 45 if has_authenticated else DISCOVERY_INTERVAL_SECONDS
            delay = min(base_interval * (2**failures), 300)
            await asyncio.sleep(delay)

    def _send_hello(self, peer: PeerAddress) -> None:
        body = json.dumps(
            {"device_id": self.device_id, "role": self.role, "version": self.protocol_version},
            separators=(",", ":"),
        ).encode("utf-8")
        self._send_signal(peer, "H", uuid.uuid4().hex, body, repeats=3)

    def _on_direct_packet(self, address: tuple[str, int], raw: bytes) -> None:
        if self._closed or len(raw) > 1200 or len(self._inbound_signal_tasks) >= MAX_INBOUND_SIGNAL_TASKS:
            return
        task = asyncio.create_task(self._handle_direct_packet(address, raw))
        self._inbound_signal_tasks.add(task)
        task.add_done_callback(self._inbound_signal_tasks.discard)

    async def _handle_direct_packet(self, address: tuple[str, int], raw: bytes) -> None:
        try:
            complete = self._assembler.push(address, raw, auth_key=self.peer_auth_key)
        except SignalFrameError:
            return
        if complete is None:
            return
        kind, session_id, remote_device_id, payload_bytes = complete
        if remote_device_id == self.device_id or (self.expected_device_id is not None and remote_device_id != self.expected_device_id):
            return
        try:
            payload = json.loads(payload_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict):
            return
        peer = PeerAddress(address[0], address[1])
        if kind == "H":
            await self._handle_hello(peer, remote_device_id, payload)
        elif kind == "A":
            await self._handle_answer(peer, session_id, remote_device_id, payload)

    async def _handle_hello(
        self,
        peer: PeerAddress,
        remote_device_id: str,
        payload: dict[str, Any],
    ) -> None:
        if (
            payload.get("version") != self.protocol_version
            or payload.get("role") != "android"
            or payload.get("device_id") != remote_device_id
            or not remote_device_id.startswith("android-")
            or len(remote_device_id) > 64
        ):
            return
        peer_key = (peer.host, peer.port)
        existing = self._connections_by_peer.get(peer_key)
        if existing and existing.pc.connectionState not in {"failed", "closed"}:
            return
        if existing is not None:
            await self._drop_connection(existing)
        if len(self._connections_by_session) >= MAX_ACTIVE_CONNECTIONS:
            return
        now = time.monotonic()
        if now - self._seen_hellos.get(peer_key, 0.0) < 5.0:
            return
        self._seen_hellos[peer_key] = now
        if len(self._seen_hellos) > MAX_SEEN_HELLOS:
            oldest = min(self._seen_hellos, key=self._seen_hellos.get)
            self._seen_hellos.pop(oldest, None)
        await self._create_offer(peer, remote_device_id)

    async def _handle_answer(
        self,
        peer: PeerAddress,
        session_id: str,
        remote_device_id: str,
        payload: dict[str, Any],
    ) -> None:
        connection = self._connections_by_session.get(session_id)
        if (
            connection is None
            or (connection.peer.host, connection.peer.port) != (peer.host, peer.port)
            or connection.remote_device_id != remote_device_id
            or payload.get("type") != "answer"
            or payload.get("version") != self.protocol_version
        ):
            return
        sdp = payload.get("sdp")
        if not isinstance(sdp, str) or not sdp or len(sdp) > MAX_SDP_CHARS:
            await self._drop_connection(connection)
            return
        # Inject the peer's LAN source IP as a host candidate if the SDP
        # doesn't already contain it.  Android hotspot (softap on wlan1)
        # doesn't enumerate itself as an ICE candidate, so the only way
        # aiortc can reach the phone is via the IP we received the UDP
        # signal from.
        peer_ip = connection.peer.host
        if peer_ip and not peer_ip.startswith("127.") and peer_ip not in sdp:
            # Extract the m= port from the SDP to pair with the candidate
            m_port_match = re.search(r"^m=application\s+(\d+)\s", sdp, re.MULTILINE)
            cand_port = m_port_match.group(1) if m_port_match else "42100"
            synthetic = (
                f"a=candidate:8888888 1 udp 2130706431 {peer_ip} {cand_port}"
                f" typ host generation 0\r\n"
            )
            # Insert before the last blank line or at end
            if sdp.rstrip().endswith("\r\n"):
                sdp = sdp.rstrip("\r\n") + "\r\n" + synthetic + "\r\n"
            else:
                sdp = sdp.rstrip("\n") + "\n" + synthetic
        try:
            await connection.pc.setRemoteDescription(
                RTCSessionDescription(sdp=sdp, type="answer")
            )
        except Exception:
            await self._drop_connection(connection)

    def _new_pc(self) -> RTCPeerConnection:
        configuration = RTCConfiguration(
            iceServers=[RTCIceServer(urls=list(STUN_SERVERS))]
        )
        return RTCPeerConnection(configuration=configuration)

    async def _create_offer(self, peer: PeerAddress, remote_device_id: str) -> None:
        pc = self._new_pc()
        session_id = uuid.uuid4().hex
        connection = _Connection(
            peer=peer,
            session_id=session_id,
            pc=pc,
            remote_device_id=remote_device_id,
        )
        self._connections_by_session[session_id] = connection
        self._connections_by_peer[(peer.host, peer.port)] = connection

        @pc.on("connectionstatechange")
        async def on_connection_state_change() -> None:
            if pc.connectionState in {"failed", "closed"}:
                await self._drop_connection(connection)

        self._attach_channel(connection, pc.createDataChannel("megas-direct-v1", ordered=True))
        try:
            offer = await pc.createOffer()
            await pc.setLocalDescription(offer)
            for _ in range(30):
                if pc.iceGatheringState == "complete":
                    break
                await asyncio.sleep(0.1)
            local = pc.localDescription
            if local is None or not local.sdp or len(local.sdp) > MAX_SDP_CHARS:
                raise RuntimeError("peer_offer_invalid")
            body = json.dumps(
                {"sdp": local.sdp, "type": "offer", "version": self.protocol_version},
                separators=(",", ":"),
            ).encode("utf-8")
            connection.retry_task = asyncio.create_task(
                self._repeat_signal(peer, "O", session_id, body, connection),
                name="MegasDirectPeerOfferRetry",
            )
            connection.expiry_task = asyncio.create_task(
                self._expire_connection(connection), name="MegasPeerOfferExpiry"
            )
        except Exception:
            await self._drop_connection(connection)

    async def _repeat_signal(
        self,
        peer: PeerAddress,
        kind: str,
        session_id: str,
        payload: bytes,
        connection: _Connection,
    ) -> None:
        for _ in range(4):
            if (
                self._closed
                or connection.authenticated
                or connection.pc.connectionState in {"failed", "closed"}
            ):
                return
            self._send_signal(peer, kind, session_id, payload, repeats=2)
            await asyncio.sleep(2.0)

    def _send_signal(
        self,
        peer: PeerAddress,
        kind: str,
        session_id: str,
        payload: bytes,
        *,
        repeats: int,
    ) -> None:
        try:
            frames = pack_signal(
                kind,
                session_id,
                self.device_id,
                payload,
                auth_key=self.peer_auth_key,
            )
        except (SignalFrameError, ValueError):
            return
        for _ in range(max(1, min(repeats, 3))):
            if self._closed:
                return
            for frame in frames:
                try:
                    self.discovery.send_datagram(peer, frame)
                except (OSError, RuntimeError, ValueError):
                    return

    async def _expire_connection(self, connection: _Connection) -> None:
        await asyncio.sleep(30)
        if not connection.authenticated:
            await self._drop_connection(connection)

    def _attach_channel(self, connection: _Connection, channel: Any) -> None:
        connection.channel = channel

        @channel.on("open")
        def on_open() -> None:
            self._send_auth(connection)

        @channel.on("close")
        def on_close() -> None:
            # A closed data channel can leave ICE connected. Release its slot
            # so authenticated discovery can create a fresh session.
            self._drop_connection_soon(connection)

        @channel.on("message")
        def on_message(message: str | bytes) -> None:
            if isinstance(message, bytes):
                if len(message) > MAX_DATA_CHANNEL_MESSAGE_BYTES:
                    channel.close()
                    return
                try:
                    message = message.decode("utf-8")
                except UnicodeDecodeError:
                    channel.close()
                    return
            if not isinstance(message, str) or len(message.encode("utf-8")) > MAX_DATA_CHANNEL_MESSAGE_BYTES:
                channel.close()
                return
            asyncio.create_task(self._handle_channel_message(connection, message))

    def _send_auth(self, connection: _Connection) -> None:
        if connection.channel is None or connection.channel.readyState != "open":
            return
        proof = account_peer_proof(
            self.peer_auth_key,
            "auth",
            connection.session_id,
            self.role,
            self.device_id,
            connection.local_nonce,
        )
        self._send_json(
            connection,
            {
                "type": "auth",
                "role": self.role,
                "device_id": self.device_id,
                "nonce": connection.local_nonce,
                "proof": proof,
            },
        )

    async def _handle_channel_message(self, connection: _Connection, raw: str) -> None:
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            return
        if not isinstance(payload, dict):
            return
        message_type = payload.get("type")
        if message_type == "auth":
            self._handle_auth(connection, payload)
            return
        if message_type == "auth_ack":
            self._handle_auth_ack(connection, payload)
            return
        if not connection.authenticated:
            return
        if message_type == "notification_ack":
            notification_id = payload.get("notification_id")
            future = self._pending_acks.get(notification_id) if isinstance(notification_id, str) else None
            if future is not None and not future.done():
                future.set_result(payload.get("accepted") is True)
        elif message_type == "notification" and self.on_notification is not None:
            try:
                self.on_notification(payload)
            except Exception:
                return

    def _handle_auth(self, connection: _Connection, payload: dict[str, Any]) -> None:
        remote_id = payload.get("device_id")
        nonce = payload.get("nonce")
        proof = payload.get("proof")
        if (
            payload.get("role") != "android"
            or (self.expected_device_id is not None and remote_id != self.expected_device_id)
            or remote_id != connection.remote_device_id
            or not isinstance(nonce, str)
            or not _NONCE_RE.fullmatch(nonce)
            or not isinstance(proof, str)
            or len(proof) != 64
        ):
            self._drop_connection_soon(connection)
            return
        expected = account_peer_proof(
            self.peer_auth_key,
            "auth",
            connection.session_id,
            "android",
            remote_id,
            nonce,
        )
        if not hmac.compare_digest(proof, expected):
            self._drop_connection_soon(connection)
            return
        connection.remote_nonce = nonce
        connection.remote_identity_verified = True
        ack = account_peer_proof(
            self.peer_auth_key,
            "ack",
            connection.session_id,
            self.role,
            self.device_id,
            nonce,
            connection.local_nonce,
        )
        self._send_json(
            connection,
            {
                "type": "auth_ack",
                "nonce": nonce,
                "peer_nonce": connection.local_nonce,
                "role": self.role,
                "device_id": self.device_id,
                "proof": ack,
                "accepted": True,
            },
        )

    def _handle_auth_ack(self, connection: _Connection, payload: dict[str, Any]) -> None:
        remote_id = payload.get("device_id")
        nonce = payload.get("nonce")
        peer_nonce = payload.get("peer_nonce")
        proof = payload.get("proof")
        if (
            payload.get("role") != "android"
            or (self.expected_device_id is not None and remote_id != self.expected_device_id)
            or remote_id != connection.remote_device_id
            or payload.get("accepted") is not True
            or nonce != connection.local_nonce
            or peer_nonce != connection.remote_nonce
            or not isinstance(proof, str)
            or len(proof) != 64
        ):
            self._drop_connection_soon(connection)
            return
        expected = account_peer_proof(
            self.peer_auth_key,
            "ack",
            connection.session_id,
            "android",
            remote_id,
            nonce,
            peer_nonce,
        )
        if not hmac.compare_digest(proof, expected):
            self._drop_connection_soon(connection)
            return
        connection.auth_ack_received = True

    def _drop_connection_soon(self, connection: _Connection) -> None:
        asyncio.create_task(self._drop_connection(connection))

    def _send_json(self, connection: _Connection, payload: dict[str, Any]) -> None:
        if connection.channel is None or connection.channel.readyState != "open":
            return
        raw = json.dumps(payload, separators=(",", ":"))
        if len(raw.encode("utf-8")) <= MAX_DATA_CHANNEL_MESSAGE_BYTES:
            connection.channel.send(raw)

    async def send_notification(
        self,
        *,
        title: str,
        message: str,
        level: str,
        event_type: str,
        timeout_seconds: float = 8.0,
    ) -> dict[str, Any]:
        if not self._started or self._closed:
            return {"delivered": False, "reason": "peer_mesh_not_running", "peer_acknowledged": False}
        channels = [
            connection for connection in self._connections_by_session.values()
            if connection.authenticated and connection.remote_role == "android"
        ]
        if not channels:
            return {"delivered": False, "reason": "no_authenticated_android_peer", "peer_acknowledged": False}
        if len(self._pending_acks) >= MAX_PENDING_ACKS:
            return {"delivered": False, "reason": "notification_queue_full", "peer_acknowledged": False}
        notification_id = uuid.uuid4().hex
        future: asyncio.Future[bool] = asyncio.get_running_loop().create_future()
        self._pending_acks[notification_id] = future
        payload = {
            "type": "notification",
            "notification_id": notification_id,
            "title": title[:120],
            "message": message[:2000],
            "level": level,
            "event_type": event_type,
        }
        try:
            for connection in channels:
                self._send_json(connection, payload)
            accepted = await asyncio.wait_for(
                future,
                timeout=max(1.0, min(float(timeout_seconds), 30.0)),
            )
            return {
                "delivered": accepted,
                "reason": "android_notification_posted" if accepted else "android_notification_rejected",
                "peer_acknowledged": True,
                "transport": "direct_webrtc",
            }
        except asyncio.TimeoutError:
            return {"delivered": False, "reason": "android_peer_ack_timeout", "peer_acknowledged": False}
        finally:
            self._pending_acks.pop(notification_id, None)

    async def _drop_connection(self, connection: _Connection) -> None:
        if self._connections_by_session.get(connection.session_id) is not connection:
            return
        self._connections_by_session.pop(connection.session_id, None)
        key = (connection.peer.host, connection.peer.port)
        if self._connections_by_peer.get(key) is connection:
            self._connections_by_peer.pop(key, None)
        if connection.retry_task is not None and connection.retry_task is not asyncio.current_task():
            connection.retry_task.cancel()
        if connection.expiry_task is not None and connection.expiry_task is not asyncio.current_task():
            connection.expiry_task.cancel()
        try:
            await connection.pc.close()
        except Exception:
            pass

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._discovery_task is not None:
            self._discovery_task.cancel()
            await asyncio.gather(self._discovery_task, return_exceptions=True)
        await self.discovery.close()
        for connection in tuple(self._connections_by_session.values()):
            await self._drop_connection(connection)
        for future in tuple(self._pending_acks.values()):
            if not future.done():
                future.cancel()
        self._pending_acks.clear()
        self._started = False
