"""Domain models for Megas Local."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Workspace:
    # Keep path/approved first for compatibility with the foundation API.
    path: str
    approved: bool
    id: Optional[str] = None


@dataclass(frozen=True)
class Thread:
    megas_thread_id: str
    native_thread_id: Optional[str]
    worker_id: str
    provider_id: str
    workspace_path: str
    cloud_thread_id: Optional[str] = None


@dataclass(frozen=True)
class Session:
    live_session_id: str
    megas_thread_id: str
    status: str
    pid: Optional[int] = None
    process_create_time: Optional[float] = None
    created_at: str = ""
    updated_at: str = ""
    reason: Optional[str] = None


@dataclass(frozen=True)
class LocalDevicePrincipal:
    device_id: str
    name: str
    type: str
    scopes: tuple[str, ...]


@dataclass(frozen=True)
class Device:
    id: str
    name: str
    type: str
    created_at: str
    last_used_at: Optional[str]
    status: str
    scopes: str
    credential_id: Optional[str] = None
    rotated_at: Optional[str] = None
    revoked_at: Optional[str] = None


@dataclass(frozen=True)
class DeviceAudit:
    audit_id: str
    device_id: str
    action: str
    timestamp: str
    actor_device_id: str
    reason: str
