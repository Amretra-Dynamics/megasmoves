"""Exact create-or-replay semantics for Local thread identities."""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass

from .models import Thread
from .workspace import WorkspaceService

_THREAD_ID_PATTERN = re.compile(r"^thr_[0-9a-f]{32}$")


@dataclass(frozen=True)
class ThreadCreationResult:
    outcome: str
    thread: Thread


def validate_megas_thread_id(value: object) -> str:
    thread_id = str(value or "").strip()
    if not _THREAD_ID_PATTERN.fullmatch(thread_id):
        raise ValueError("megas_thread_id must be thr_ followed by 32 lowercase hex characters")
    return thread_id


def _require_exact_binding(
    thread: Thread,
    *,
    worker_id: str,
    provider_id: str,
    workspace_path: str,
) -> None:
    if thread.worker_id != worker_id:
        raise ValueError("Thread identity conflict: Worker binding differs")
    if thread.provider_id != provider_id:
        raise ValueError("Thread identity conflict: provider binding differs")
    if thread.workspace_path != workspace_path:
        raise ValueError("Thread identity conflict: workspace binding differs")


def create_or_replay_thread(
    workspace: WorkspaceService,
    *,
    megas_thread_id: object,
    worker_id: str,
    provider_id: str,
    path: str,
) -> ThreadCreationResult:
    """Create once or return the exact existing binding for the same identity.

    SQLite's primary key resolves concurrent duplicate requests. If another
    request wins between the pre-read and insert, the losing request re-reads
    and returns that exact binding rather than surfacing a false 500.
    """

    thread_id = validate_megas_thread_id(megas_thread_id)
    canonical = workspace.register_workspace(path)
    canonical_path = str(canonical)

    existing = workspace.store.get_thread_by_id(thread_id)
    if existing is not None:
        _require_exact_binding(
            existing,
            worker_id=worker_id,
            provider_id=provider_id,
            workspace_path=canonical_path,
        )
        return ThreadCreationResult("replayed", existing)

    try:
        created = workspace.bind_thread_workspace(
            megas_thread_id=thread_id,
            native_thread_id=None,
            worker_id=worker_id,
            provider_id=provider_id,
            path=canonical_path,
        )
        return ThreadCreationResult("created", created)
    except sqlite3.IntegrityError:
        raced = workspace.store.get_thread_by_id(thread_id)
        if raced is None:
            raise
        _require_exact_binding(
            raced,
            worker_id=worker_id,
            provider_id=provider_id,
            workspace_path=canonical_path,
        )
        return ThreadCreationResult("replayed", raced)
