"""Scoped Local cancellation for process-backed and API-backed providers."""

from __future__ import annotations

import asyncio
import hashlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Literal, Optional

from megas.adapters.process_control import (
    process_create_time,
    terminate_process_tree,
    terminate_process_tree_by_pid,
)

from .broker import LocalEventBroker
from .protocol import LocalEvent
from .store import LocalStore

_TERMINAL = frozenset({"completed", "failed", "cancelled", "interrupted"})
ProviderCanceller = Callable[[], Awaitable[bool]]


@dataclass(frozen=True)
class CancellationResult:
    outcome: Literal["accepted", "already_terminal", "interrupted"]
    durable_status: str
    reason: Optional[str] = None


class ProcessRegistry:
    def __init__(self, store: LocalStore):
        self.store = store
        self._processes: dict[str, asyncio.subprocess.Process] = {}
        self._provider_cancellers: dict[str, ProviderCanceller] = {}
        self._lock = asyncio.Lock()

    async def register(
        self,
        live_session_id: str,
        process: asyncio.subprocess.Process,
    ) -> None:
        reject_status: Optional[str] = None
        create_time = process_create_time(process.pid)
        async with self._lock:
            existing = self._processes.get(live_session_id)
            if existing is not None and existing is not process and existing.returncode is None:
                raise RuntimeError(f"A process is already registered for {live_session_id}")

            with self.store._transaction("EXCLUSIVE") as conn:
                row = conn.execute(
                    "SELECT status FROM local_sessions WHERE live_session_id=?",
                    (live_session_id,),
                ).fetchone()
                if row is None:
                    raise ValueError(f"Session {live_session_id} not found")
                status = str(row["status"])
                if status in _TERMINAL:
                    reject_status = status
                elif status == "accepted":
                    conn.execute(
                        """
                        UPDATE local_sessions
                        SET status='running', pid=?, process_create_time=?,
                            updated_at=strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                        WHERE live_session_id=? AND status='accepted'
                        """,
                        (process.pid, create_time, live_session_id),
                    )
                    self._processes[live_session_id] = process
                elif status in {"running", "cancelling"}:
                    conn.execute(
                        """
                        UPDATE local_sessions
                        SET pid=?, process_create_time=?,
                            updated_at=strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                        WHERE live_session_id=?
                        """,
                        (process.pid, create_time, live_session_id),
                    )
                    self._processes[live_session_id] = process
                else:
                    reject_status = status

        if reject_status is not None:
            await terminate_process_tree(process, timeout=3.0)
            raise RuntimeError(
                f"Refusing to attach a process to {live_session_id} in {reject_status}"
            )

    async def unregister(
        self,
        live_session_id: str,
        process: asyncio.subprocess.Process,
    ) -> None:
        async with self._lock:
            if self._processes.get(live_session_id) is process:
                self._processes.pop(live_session_id, None)

    async def get(
        self,
        live_session_id: str,
    ) -> Optional[asyncio.subprocess.Process]:
        async with self._lock:
            return self._processes.get(live_session_id)

    async def register_provider_canceller(
        self,
        live_session_id: str,
        canceller: ProviderCanceller,
    ) -> None:
        async with self._lock:
            existing = self._provider_cancellers.get(live_session_id)
            if existing is not None and existing is not canceller:
                raise RuntimeError(
                    f"A provider canceller is already registered for {live_session_id}"
                )
            self._provider_cancellers[live_session_id] = canceller

    async def unregister_provider_canceller(
        self,
        live_session_id: str,
    ) -> None:
        async with self._lock:
            self._provider_cancellers.pop(live_session_id, None)

    async def cancel_provider(self, live_session_id: str) -> bool:
        async with self._lock:
            canceller = self._provider_cancellers.get(live_session_id)
        if canceller is None:
            return False
        try:
            result = bool(await canceller())
        finally:
            await self.unregister_provider_canceller(live_session_id)
        return result


class CancellationCoordinator:
    def __init__(
        self,
        store: LocalStore,
        registry: ProcessRegistry,
        broker: LocalEventBroker,
    ):
        self.store = store
        self.registry = registry
        self.broker = broker
        self._locks: dict[str, asyncio.Lock] = {}
        self._locks_guard = asyncio.Lock()

    async def _session_lock(self, live_session_id: str) -> asyncio.Lock:
        async with self._locks_guard:
            return self._locks.setdefault(live_session_id, asyncio.Lock())

    @staticmethod
    def _terminal_event(
        *,
        worker_id: str,
        megas_thread_id: str,
        native_thread_id: Optional[str],
        live_session_id: str,
        status: str,
        reason: Optional[str],
    ) -> LocalEvent:
        raw = f"{worker_id}|{megas_thread_id}|{live_session_id}|{status}"
        event_id = "evt_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]
        occurred_at = datetime.now(timezone.utc).isoformat()
        kind = "turn_completed" if status == "cancelled" else "error"
        payload = {
            "schema_version": "megas.conversation-event.v1",
            "event_id": event_id,
            "kind": kind,
            "source": "live",
            "occurred_at": occurred_at,
            "role": None,
            "native_item_id": None,
            "native_turn_id": None,
            "tool_call_id": None,
            "status": status,
            "content_text": (
                "The Worker stopped following this turn, but the provider task could not "
                "be cancelled through an authoritative provider operation. Inspect native "
                "history before starting replacement work."
                if status == "interrupted"
                else None
            ),
            "content_json": None,
            "tool_name": None,
            "file_path": None,
            "additions": None,
            "deletions": None,
            "diff_snippet": None,
            "error_code": reason if status == "interrupted" else None,
            "error_message": None,
            "unsupported_type": None,
            "is_conversation_visible": status == "interrupted",
        }
        return LocalEvent(
            event_id=event_id,
            worker_id=worker_id,
            megas_thread_id=megas_thread_id,
            native_thread_id=native_thread_id,
            live_session_id=live_session_id,
            sequence=-1,
            event_type=kind,
            created_at=occurred_at,
            payload=payload,
        )

    def _finish_if_still_cancelling(
        self,
        *,
        live_session_id: str,
        worker_id: str,
        megas_thread_id: str,
        native_thread_id: Optional[str],
        final_status: Literal["cancelled", "interrupted"],
        reason: Optional[str],
    ) -> tuple[str, Optional[LocalEvent]]:
        event = self._terminal_event(
            worker_id=worker_id,
            megas_thread_id=megas_thread_id,
            native_thread_id=native_thread_id,
            live_session_id=live_session_id,
            status=final_status,
            reason=reason,
        )
        now = datetime.now(timezone.utc).isoformat()
        with self.store._transaction("EXCLUSIVE") as conn:
            row = conn.execute(
                "SELECT status FROM local_sessions WHERE live_session_id=?",
                (live_session_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Session {live_session_id} not found")
            if row["status"] != "cancelling":
                return str(row["status"]), None
            persisted = self.store._insert_event(conn, event)
            conn.execute(
                """
                UPDATE local_sessions
                SET status=?, updated_at=?, reason=?
                WHERE live_session_id=? AND status='cancelling'
                """,
                (final_status, now, reason, live_session_id),
            )
            return final_status, persisted

    async def cancel_session(
        self,
        *,
        worker_id: str,
        megas_thread_id: str,
        live_session_id: str,
        timeout: float = 3.0,
    ) -> CancellationResult:
        lock = await self._session_lock(live_session_id)
        async with lock:
            session, thread = self.store.get_session_scope(live_session_id)
            if thread.worker_id != worker_id or thread.megas_thread_id != megas_thread_id:
                raise PermissionError("Cancellation scope does not match the durable turn")
            if session.status in _TERMINAL:
                return CancellationResult(
                    outcome="already_terminal",
                    durable_status=session.status,
                )
            if session.status != "cancelling":
                session = self.store.update_session_status(
                    live_session_id,
                    "cancelling",
                    reason="user_requested_stop",
                )

            process = await self.registry.get(live_session_id)
            terminated = False
            cancellation_reason = "user_requested_stop"
            if process is not None:
                await terminate_process_tree(process, timeout=timeout)
                terminated = process.returncode is not None
                await self.registry.unregister(live_session_id, process)
            elif session.pid is not None:
                terminated = await terminate_process_tree_by_pid(
                    session.pid,
                    expected_create_time=session.process_create_time,
                    timeout=timeout,
                )
            if not terminated:
                try:
                    terminated = await self.registry.cancel_provider(live_session_id)
                except Exception:
                    terminated = False
                if terminated:
                    cancellation_reason = "provider_cancelled"

            latest = self.store.get_session(live_session_id)
            if latest is None:
                raise ValueError(f"Session {live_session_id} not found")
            if latest.status in _TERMINAL:
                return CancellationResult(
                    outcome="already_terminal",
                    durable_status=latest.status,
                )

            if not terminated:
                durable = await self.broker.commit_and_publish(
                    lambda: self._finish_if_still_cancelling(
                        live_session_id=live_session_id,
                        worker_id=worker_id,
                        megas_thread_id=megas_thread_id,
                        native_thread_id=thread.native_thread_id,
                        final_status="interrupted",
                        reason="cancellation_provider_unavailable",
                    )
                )
                return CancellationResult(
                    outcome=(
                        "interrupted" if durable == "interrupted" else "already_terminal"
                    ),
                    durable_status=durable,
                    reason=(
                        "cancellation_provider_unavailable"
                        if durable == "interrupted"
                        else None
                    ),
                )

            durable = await self.broker.commit_and_publish(
                lambda: self._finish_if_still_cancelling(
                    live_session_id=live_session_id,
                    worker_id=worker_id,
                    megas_thread_id=megas_thread_id,
                    native_thread_id=thread.native_thread_id,
                    final_status="cancelled",
                    reason=cancellation_reason,
                )
            )
            return CancellationResult(
                outcome=("accepted" if durable == "cancelled" else "already_terminal"),
                durable_status=durable,
            )
