"""Canonical request digests for Local idempotency claims."""

from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping


def compute_request_digest(request_data: Mapping[str, Any]) -> str:
    """Return a stable SHA-256 digest without logging request content.

    Null values are preserved because omitting a field and explicitly sending null
    can have different protocol semantics. Non-JSON values fail closed.
    """
    canonical_json = json.dumps(
        request_data,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )
    return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()
