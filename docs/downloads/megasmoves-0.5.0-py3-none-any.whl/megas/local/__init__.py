"""Megas Local boundary."""
