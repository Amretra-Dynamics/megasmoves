"""Project folder registration and working-directory resolution for Megas Local."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from megas.policy import _strip_win_ext_prefix

from .models import Thread, Workspace
from .store import LocalStore


def default_sandbox_path() -> Path:
    sandbox = Path.home() / ".megas" / "sandbox"
    return sandbox


class WorkspaceService:
    def __init__(self, store: LocalStore):
        self.store = store

    @staticmethod
    def _canonical_existing_directory(path: str) -> Path:
        raw = str(path or "").strip()
        if not raw or raw in {"sandbox", "default", "default_sandbox"}:
            candidate = default_sandbox_path().resolve()
        else:
            candidate = Path(_strip_win_ext_prefix(raw)).expanduser().resolve()
        if not candidate.is_dir():
            raise ValueError("Workspace must be an existing directory")
        return candidate

    @staticmethod
    def _is_within(candidate: Path, root: Path) -> bool:
        try:
            candidate.relative_to(root)
            return True
        except ValueError:
            if os.name != "nt":
                return False
            candidate_value = os.path.normcase(str(candidate))
            root_value = os.path.normcase(str(root)).rstrip("\\/")
            return candidate_value == root_value or candidate_value.startswith(
                root_value + os.sep
            )

    def ensure_default_sandbox(self) -> Workspace:
        sandbox = default_sandbox_path().resolve()
        canonical_str = str(sandbox)
        ws = self.store.get_workspace_by_path(canonical_str)
        if ws is None:
            return self.store.create_workspace(canonical_str, approved=True)
        return ws

    def register_workspace(self, path: str) -> Path:
        canonical = self._canonical_existing_directory(path)
        # The legacy approved column records selection in this registry. The
        # owner explicitly made folder selection informational, not an ACL.
        self.store.create_workspace(str(canonical), approved=True)
        return canonical

    def approve_workspace(self, path: str) -> Workspace:
        canonical = self._canonical_existing_directory(path)
        return self.store.create_workspace(str(canonical), approved=True)

    def revoke_workspace(self, path: str) -> bool:
        # Revocation must remain possible even when a trusted folder was removed.
        canonical = Path(_strip_win_ext_prefix(path)).expanduser().resolve()
        return self.store.revoke_workspace(str(canonical))

    def get_workspace_summaries(self) -> list[dict[str, object]]:
        self.ensure_default_sandbox()
        return [
            {"id": workspace.id, "path": workspace.path, "approved": workspace.approved}
            for workspace in self.store.list_workspaces()
        ]

    def bind_thread_workspace(
        self,
        megas_thread_id: str,
        native_thread_id: Optional[str],
        worker_id: str,
        provider_id: str,
        path: str,
    ) -> Thread:
        canonical = self.register_workspace(path)
        canonical_str = str(canonical)
        return self.store.create_thread(
            megas_thread_id=megas_thread_id,
            native_thread_id=native_thread_id,
            worker_id=worker_id,
            provider_id=provider_id,
            workspace_path=canonical_str,
        )

    def resolve_thread_workspace(
        self,
        worker_id: str,
        megas_thread_id: str,
        requested_workdir: Optional[str] = None,
    ) -> Path:
        thread = self.store.get_thread(worker_id, megas_thread_id)
        if thread is None:
            raise ValueError(f"Thread {megas_thread_id} not found for Worker {worker_id}")

        root = self._canonical_existing_directory(thread.workspace_path)

        if requested_workdir is not None:
            candidate = self._canonical_existing_directory(requested_workdir)
            return candidate
        return root

