from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Literal, Optional, TypeAlias

BindingState: TypeAlias = Literal["pending", "bound", "legacy_cloud"]
RoutePreference: TypeAlias = Literal["auto", "direct", "tailscale", "cloud", None]
EffectiveRoute: TypeAlias = Literal["direct", "tailscale", "cloud", "offline", None]

_UNSET: Final = object()


@dataclass(frozen=True)
class ThreadIdentityInfo:
    worker_id: Optional[str]
    provider: str
    native_thread_id: Optional[str]
    workspace: Optional[str]


@dataclass(frozen=True)
class RouteMetadata:
    preference: RoutePreference
    effective: EffectiveRoute
    reason: Optional[str]
    live_session_id: Optional[str]


@dataclass(frozen=True)
class StorageMetadata:
    local_known: bool
    cloud_known: bool


@dataclass(frozen=True)
class ThreadIdentity:
    schema_version: str
    megas_thread_id: str
    identity: ThreadIdentityInfo
    binding_state: BindingState
    route: RouteMetadata
    storage: StorageMetadata

    @classmethod
    def from_local_thread(
        cls,
        megas_thread_id: str,
        worker_id: str,
        provider_id: str,
        native_thread_id: Optional[str],
        workspace_path: Optional[str],
        live_session_id: Optional[str] = None,
    ) -> "ThreadIdentity":
        if not worker_id:
            raise ValueError("Local thread identity requires a non-empty worker_id")
        if not provider_id:
            raise ValueError("Thread identity requires a non-empty provider_id")

        binding_state: BindingState = "bound" if native_thread_id else "pending"
        return cls(
            schema_version="megas.thread-identity.v1",
            megas_thread_id=megas_thread_id,
            identity=ThreadIdentityInfo(
                worker_id=worker_id,
                provider=provider_id,
                native_thread_id=native_thread_id,
                workspace=workspace_path,
            ),
            binding_state=binding_state,
            route=RouteMetadata(
                preference="auto",
                effective="direct" if live_session_id else None,
                reason="local_known",
                live_session_id=live_session_id,
            ),
            storage=StorageMetadata(local_known=True, cloud_known=False),
        )

    @classmethod
    def from_cloud_thread(
        cls,
        megas_thread_id: str,
        worker_id: Optional[str],
        provider_id: str,
        native_thread_id: Optional[str],
        live_session_id: Optional[str] = None,
    ) -> "ThreadIdentity":
        if not provider_id:
            raise ValueError("Thread identity requires a non-empty provider_id")

        normalized_worker_id = worker_id or None
        binding_state: BindingState = (
            "bound"
            if normalized_worker_id is not None and native_thread_id is not None
            else "legacy_cloud"
        )
        return cls(
            schema_version="megas.thread-identity.v1",
            megas_thread_id=megas_thread_id,
            identity=ThreadIdentityInfo(
                worker_id=normalized_worker_id,
                provider=provider_id,
                native_thread_id=native_thread_id,
                workspace=None,
            ),
            binding_state=binding_state,
            route=RouteMetadata(
                preference="cloud",
                effective="cloud",
                reason="cloud_known",
                live_session_id=live_session_id,
            ),
            storage=StorageMetadata(local_known=False, cloud_known=True),
        )

    def with_route(
        self,
        preference: RoutePreference,
        effective: EffectiveRoute,
        reason: Optional[str],
        live_session_id: object = _UNSET,
    ) -> "ThreadIdentity":
        """Return a route update without changing conversation identity.

        Omitting ``live_session_id`` preserves the current value. Passing ``None``
        explicitly clears it after a durable turn becomes terminal.
        """
        next_live_session_id = (
            self.route.live_session_id
            if live_session_id is _UNSET
            else live_session_id
        )
        if next_live_session_id is not None and not isinstance(next_live_session_id, str):
            raise TypeError("live_session_id must be a string, None, or omitted")

        return ThreadIdentity(
            schema_version=self.schema_version,
            megas_thread_id=self.megas_thread_id,
            identity=self.identity,
            binding_state=self.binding_state,
            route=RouteMetadata(
                preference=preference,
                effective=effective,
                reason=reason,
                live_session_id=next_live_session_id,
            ),
            storage=self.storage,
        )

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "megas_thread_id": self.megas_thread_id,
            "identity": {
                "worker_id": self.identity.worker_id,
                "provider": self.identity.provider,
                "native_thread_id": self.identity.native_thread_id,
                "workspace": self.identity.workspace,
            },
            "binding_state": self.binding_state,
            "route": {
                "preference": self.route.preference,
                "effective": self.route.effective,
                "reason": self.route.reason,
                "live_session_id": self.route.live_session_id,
            },
            "storage": {
                "local_known": self.storage.local_known,
                "cloud_known": self.storage.cloud_known,
            },
        }
