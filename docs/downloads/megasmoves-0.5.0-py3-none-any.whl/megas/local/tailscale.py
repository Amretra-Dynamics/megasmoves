"""Tailscale detection and explicit-consent private Serve for Megas Local."""

from __future__ import annotations

import json
import secrets
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any, Literal, Optional

from megas.adapters.base import subprocess_hide_window_kwargs

from .security import LocalSecurityPolicy
from .store import LocalStore


class TailscaleError(RuntimeError):
    pass


@dataclass(frozen=True)
class TailscaleCommandResult:
    returncode: int
    stdout: str
    stderr: str


class TailscaleCli:
    def __init__(self, binary: Optional[str] = None, timeout_seconds: float = 10.0):
        self.binary = binary or shutil.which("tailscale")
        self.timeout_seconds = timeout_seconds

    @property
    def installed(self) -> bool:
        return bool(self.binary)

    def run(self, args: list[str]) -> TailscaleCommandResult:
        if not self.binary:
            raise TailscaleError("tailscale_not_installed")
        try:
            completed = subprocess.run(
                [self.binary, *args],
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
                **subprocess_hide_window_kwargs(),
            )
        except subprocess.TimeoutExpired as exc:
            raise TailscaleError("tailscale_command_timeout") from exc
        except OSError as exc:
            raise TailscaleError("tailscale_command_unavailable") from exc
        return TailscaleCommandResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def status_json(self) -> dict[str, Any]:
        result = self.run(["status", "--json"])
        if result.returncode != 0:
            raise TailscaleError("tailscale_daemon_unreachable")
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise TailscaleError("tailscale_status_invalid_json") from exc
        if not isinstance(payload, dict):
            raise TailscaleError("tailscale_status_invalid_json")
        return payload

    def serve_status_json(self) -> dict[str, Any]:
        result = self.run(["serve", "status", "--json"])
        if result.returncode != 0:
            raise TailscaleError("tailscale_serve_status_unavailable")
        try:
            payload = json.loads(result.stdout or "{}")
        except json.JSONDecodeError as exc:
            raise TailscaleError("tailscale_serve_status_invalid_json") from exc
        if not isinstance(payload, dict):
            raise TailscaleError("tailscale_serve_status_invalid_json")
        return payload

    def configure_private_mapping(
        self,
        *,
        local_port: int,
        https_port: int,
        path: str,
    ) -> None:
        target = f"http://127.0.0.1:{local_port}"
        result = self.run(
            [
                "serve",
                "--bg",
                "--yes",
                f"--https={https_port}",
                f"--set-path={path}",
                target,
            ]
        )
        if result.returncode != 0:
            raise TailscaleError("tailscale_serve_apply_failed")

    def disable_private_mapping(self, *, https_port: int, path: str) -> None:
        result = self.run(
            [
                "serve",
                f"--https={https_port}",
                f"--set-path={path}",
                "off",
            ]
        )
        if result.returncode != 0:
            raise TailscaleError("tailscale_serve_disable_failed")


class TailscaleStatus:
    def __init__(self, cli: Optional[TailscaleCli] = None, cache_seconds: float = 5.0):
        self.cli = cli or TailscaleCli()
        self.cache_seconds = cache_seconds
        self._lock = threading.Lock()
        self._cached_at = 0.0
        self._cached: Optional[dict[str, Any]] = None

    def get_status(self) -> dict[str, Any]:
        now = time.monotonic()
        with self._lock:
            if self._cached is not None and now - self._cached_at < self.cache_seconds:
                return dict(self._cached)
            value = self._read_status()
            self._cached = value
            self._cached_at = now
            return dict(value)

    def _read_status(self) -> dict[str, Any]:
        if not self.cli.installed:
            return {
                "installed": False,
                "daemon_reachable": False,
                "authenticated_connected": False,
                "dns_name": None,
                "serve_mappings": None,
                "diagnostic_code": "tailscale_not_installed",
            }
        try:
            status = self.cli.status_json()
        except TailscaleError as exc:
            return {
                "installed": True,
                "daemon_reachable": False,
                "authenticated_connected": False,
                "dns_name": None,
                "serve_mappings": None,
                "diagnostic_code": str(exc),
            }

        self_status = status.get("Self") if isinstance(status.get("Self"), dict) else {}
        dns_name = self_status.get("DNSName")
        if isinstance(dns_name, str):
            dns_name = dns_name.rstrip(".") or None
        else:
            dns_name = None
        backend_state = status.get("BackendState")
        connected = backend_state == "Running" and bool(self_status.get("Online", True))

        serve_mappings: Optional[dict[str, Any]] = None
        serve_diagnostic: Optional[str] = None
        try:
            serve_mappings = self.cli.serve_status_json()
        except TailscaleError as exc:
            serve_diagnostic = str(exc)

        return {
            "installed": True,
            "daemon_reachable": True,
            "authenticated_connected": connected,
            "dns_name": dns_name,
            "serve_mappings": serve_mappings,
            "diagnostic_code": serve_diagnostic or (None if connected else "tailscale_not_connected"),
        }


class TailscaleServeService:
    SETTING_PLAN_PREFIX = "tailscale_serve_plan:"
    SETTING_STATE = "tailscale_serve_state"

    def __init__(
        self,
        store: LocalStore,
        security_policy: LocalSecurityPolicy,
        cli: Optional[TailscaleCli] = None,
        *,
        api_path: str = "/megas",
        stream_path: str = "/megas-stream",
        https_port: int = 443,
        plan_ttl_seconds: int = 300,
    ):
        for path in (api_path, stream_path):
            if not path.startswith("/") or path == "/":
                raise ValueError("Megas Serve paths must be non-root absolute paths")
        if api_path.rstrip("/") == stream_path.rstrip("/"):
            raise ValueError("REST and WebSocket Serve paths must be distinct")
        self.store = store
        self.security_policy = security_policy
        self.cli = cli or TailscaleCli()
        self.api_path = api_path.rstrip("/")
        self.stream_path = stream_path.rstrip("/")
        self.https_port = https_port
        self.plan_ttl_seconds = plan_ttl_seconds

    def _port_setting(self, key: str, error_prefix: str) -> int:
        setting = self.store.get_setting(key)
        if not isinstance(setting, dict) or not isinstance(setting.get("port"), int):
            raise TailscaleError(f"{error_prefix}_port_unavailable")
        port = setting["port"]
        if port < 1 or port > 65535:
            raise TailscaleError(f"{error_prefix}_port_invalid")
        return port

    @staticmethod
    def _mapping_state(
        serve_status: dict[str, Any],
        *,
        local_port: int,
        path: str,
    ) -> Literal["absent", "matching", "conflict"]:
        serialized = json.dumps(serve_status, sort_keys=True)
        if path not in serialized:
            return "absent"
        if f"127.0.0.1:{local_port}" in serialized:
            return "matching"
        return "conflict"

    def plan(self) -> dict[str, Any]:
        gateway_port = self._port_setting("gateway_port", "gateway")
        websocket_port = self._port_setting("websocket_port", "websocket")
        status = TailscaleStatus(self.cli, cache_seconds=0).get_status()
        hostname = status.get("dns_name")
        if not status.get("authenticated_connected") or not isinstance(hostname, str):
            raise TailscaleError(status.get("diagnostic_code") or "tailscale_not_connected")
        serve_status = status.get("serve_mappings")
        if not isinstance(serve_status, dict):
            serve_status = self.cli.serve_status_json()

        api_previous = self._mapping_state(
            serve_status,
            local_port=gateway_port,
            path=self.api_path,
        )
        stream_previous = self._mapping_state(
            serve_status,
            local_port=websocket_port,
            path=self.stream_path,
        )
        if "conflict" in {api_previous, stream_previous}:
            raise TailscaleError("tailscale_serve_path_conflict")

        nonce = secrets.token_urlsafe(24)
        now = time.time()
        plan = {
            "nonce": nonce,
            "created_at": now,
            "expires_at": now + self.plan_ttl_seconds,
            "gateway_port": gateway_port,
            "websocket_port": websocket_port,
            "https_port": self.https_port,
            "api_path": self.api_path,
            "stream_path": self.stream_path,
            "api_previous": api_previous,
            "stream_previous": stream_previous,
            "hostname": hostname,
            "expected_api_url": f"https://{hostname}{self.api_path}",
            "expected_stream_url": f"wss://{hostname}{self.stream_path}",
            "action": "configure_private_tailnet_serve",
        }
        self.store.set_setting(f"{self.SETTING_PLAN_PREFIX}{nonce}", plan)
        return {
            "plan": plan,
            "human_readable": (
                f"Allow devices in this tailnet to reach Megas REST at "
                f"https://{hostname}{self.api_path} and its private event stream at "
                f"wss://{hostname}{self.stream_path}. This does not enable Funnel."
            ),
        }

    def _verify_plan(self, plan: dict[str, Any]) -> None:
        if time.time() >= float(plan.get("expires_at", 0)):
            raise TailscaleError("tailscale_serve_plan_expired")
        if (
            plan.get("api_path") != self.api_path
            or plan.get("stream_path") != self.stream_path
            or plan.get("https_port") != self.https_port
            or not isinstance(plan.get("gateway_port"), int)
            or not isinstance(plan.get("websocket_port"), int)
            or plan.get("api_previous") not in {"absent", "matching"}
            or plan.get("stream_previous") not in {"absent", "matching"}
        ):
            raise TailscaleError("tailscale_serve_plan_mismatch")
        if plan["gateway_port"] != self._port_setting("gateway_port", "gateway"):
            raise TailscaleError("tailscale_serve_plan_stale")
        if plan["websocket_port"] != self._port_setting("websocket_port", "websocket"):
            raise TailscaleError("tailscale_serve_plan_stale")

    def apply(self, nonce: str) -> dict[str, Any]:
        key = f"{self.SETTING_PLAN_PREFIX}{nonce}"
        plan = self.store.get_setting(key)
        if not isinstance(plan, dict):
            raise TailscaleError("tailscale_serve_plan_invalid")
        self.store.delete_setting(key)
        self._verify_plan(plan)

        gateway_port = plan["gateway_port"]
        websocket_port = plan["websocket_port"]
        api_added = plan["api_previous"] == "absent"
        stream_added = plan["stream_previous"] == "absent"
        try:
            if api_added:
                self.cli.configure_private_mapping(
                    local_port=gateway_port,
                    https_port=self.https_port,
                    path=self.api_path,
                )
            if stream_added:
                self.cli.configure_private_mapping(
                    local_port=websocket_port,
                    https_port=self.https_port,
                    path=self.stream_path,
                )
            serve_status = self.cli.serve_status_json()
            if self._mapping_state(
                serve_status,
                local_port=gateway_port,
                path=self.api_path,
            ) != "matching" or self._mapping_state(
                serve_status,
                local_port=websocket_port,
                path=self.stream_path,
            ) != "matching":
                raise TailscaleError("tailscale_serve_verification_failed")
        except Exception:
            if stream_added:
                try:
                    self.cli.disable_private_mapping(
                        https_port=self.https_port,
                        path=self.stream_path,
                    )
                except TailscaleError:
                    pass
            if api_added:
                try:
                    self.cli.disable_private_mapping(
                        https_port=self.https_port,
                        path=self.api_path,
                    )
                except TailscaleError:
                    pass
            raise

        hostname = plan["hostname"]
        self.security_policy.register_tailscale_host(hostname)
        state = {
            "gateway_port": gateway_port,
            "websocket_port": websocket_port,
            "https_port": self.https_port,
            "api_path": self.api_path,
            "stream_path": self.stream_path,
            "hostname": hostname,
            "verified_api_url": plan["expected_api_url"],
            "verified_stream_url": plan["expected_stream_url"],
            "verified_at": time.time(),
        }
        self.store.set_setting(self.SETTING_STATE, state)
        return {"status": "configured", "state": state}

    def status(self) -> dict[str, Any]:
        state = self.store.get_setting(self.SETTING_STATE)
        if not isinstance(state, dict):
            return {"configured": False, "drift": False}
        try:
            serve_status = self.cli.serve_status_json()
            api_present = self._mapping_state(
                serve_status,
                local_port=state["gateway_port"],
                path=state["api_path"],
            ) == "matching"
            stream_present = self._mapping_state(
                serve_status,
                local_port=state["websocket_port"],
                path=state["stream_path"],
            ) == "matching"
        except (KeyError, TailscaleError):
            return {"configured": True, "drift": True, "state": state}
        return {
            "configured": True,
            "drift": not (api_present and stream_present),
            "state": state,
            "serve_status": serve_status,
        }

    def disable(self) -> dict[str, Any]:
        state = self.store.get_setting(self.SETTING_STATE)
        if not isinstance(state, dict):
            return {"status": "not_configured"}
        errors: list[str] = []
        for path in (state.get("stream_path"), state.get("api_path")):
            if not isinstance(path, str):
                continue
            try:
                self.cli.disable_private_mapping(
                    https_port=int(state["https_port"]),
                    path=path,
                )
            except TailscaleError as exc:
                errors.append(str(exc))
        if errors:
            raise TailscaleError("tailscale_serve_disable_incomplete")
        hostname = state.get("hostname")
        if isinstance(hostname, str):
            self.security_policy.unregister_tailscale_host(hostname)
        self.store.delete_setting(self.SETTING_STATE)
        return {"status": "disabled"}
