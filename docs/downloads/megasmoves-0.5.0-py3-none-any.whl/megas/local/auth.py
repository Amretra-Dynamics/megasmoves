"""Device credential issuance and verification for Megas Local."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from typing import Iterable, Optional

from .models import LocalDevicePrincipal
from .store import LocalStore, _utc_now

_KDF_NAME = "pbkdf2_sha256"
_KDF_ITERATIONS = 600_000


def _encode_secret(secret: str, *, salt: Optional[str] = None) -> str:
    salt_value = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        secret.encode("utf-8"),
        salt_value.encode("ascii"),
        _KDF_ITERATIONS,
    ).hex()
    return f"{_KDF_NAME}${_KDF_ITERATIONS}${salt_value}${digest}"


def _verify_secret(secret: str, encoded: str) -> bool:
    try:
        algorithm, iterations_text, salt, expected_digest = encoded.split("$", 3)
        iterations = int(iterations_text)
    except (AttributeError, TypeError, ValueError):
        return False
    if algorithm != _KDF_NAME or iterations < 100_000 or iterations > 2_000_000:
        return False
    actual_digest = hashlib.pbkdf2_hmac(
        "sha256",
        secret.encode("utf-8"),
        salt.encode("ascii"),
        iterations,
    ).hex()
    return hmac.compare_digest(actual_digest, expected_digest)


def _normalize_scopes(scopes: Iterable[str]) -> tuple[str, ...]:
    normalized = tuple(sorted({scope.strip() for scope in scopes if scope.strip()}))
    if not normalized:
        raise ValueError("At least one device scope is required")
    return normalized


def issue_device_credential(
    store: LocalStore,
    name: str,
    device_type: str,
    scopes: Iterable[str],
) -> tuple[str, str]:
    """Issue a device credential and return ``(device_id, bearer_token)`` once."""
    clean_name = name.strip()
    clean_type = device_type.strip().lower()
    if not clean_name or not clean_type:
        raise ValueError("Device name and type are required")

    normalized_scopes = _normalize_scopes(scopes)
    device_id = f"dev_{secrets.token_hex(16)}"
    credential_id = f"cred_{secrets.token_hex(16)}"
    raw_secret = secrets.token_urlsafe(32)
    secret_hash = _encode_secret(raw_secret)
    store.register_device(
        device_id=device_id,
        name=clean_name,
        device_type=clean_type,
        scopes=json.dumps(normalized_scopes, separators=(",", ":")),
        credential_id=credential_id,
        secret_hash=secret_hash,
    )
    return device_id, f"{credential_id}.{raw_secret}"


def verify_device_credential(
    store: LocalStore,
    token: str,
) -> Optional[LocalDevicePrincipal]:
    try:
        credential_id, raw_secret = token.split(".", 1)
    except (AttributeError, ValueError):
        return None
    if not credential_id.startswith("cred_") or not raw_secret:
        return None

    conn = store._get_conn()
    row = conn.execute(
        """
        SELECT id, name, type, secret_hash, scopes, status, revoked_at
        FROM local_devices
        WHERE credential_id=?
        """,
        (credential_id,),
    ).fetchone()
    if row is None:
        return None
    if row["status"] != "active" or row["revoked_at"] is not None:
        return None
    if not _verify_secret(raw_secret, row["secret_hash"]):
        return None

    try:
        scopes_value = json.loads(row["scopes"] or "[]")
        scopes = tuple(scope for scope in scopes_value if isinstance(scope, str))
    except (TypeError, json.JSONDecodeError):
        return None

    with store._transaction() as transaction:
        transaction.execute(
            "UPDATE local_devices SET last_used_at=? WHERE id=? AND status='active'",
            (_utc_now(), row["id"]),
        )
    return LocalDevicePrincipal(
        device_id=row["id"],
        name=row["name"],
        type=row["type"],
        scopes=scopes,
    )


def revoke_device_credential(
    store: LocalStore,
    device_id: str,
    *,
    actor_device_id: str,
    reason: str,
) -> bool:
    return store.revoke_device(
        device_id=device_id,
        actor_device_id=actor_device_id,
        reason=reason,
    )
