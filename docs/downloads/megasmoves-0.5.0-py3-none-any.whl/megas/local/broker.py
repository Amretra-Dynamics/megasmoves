"""Persist-before-publish event broker for Megas Local."""

from __future__ import annotations

import asyncio
import copy
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional, TypeVar

from megas.adapters.base import WorkerEvent
from megas.policy import redact

from .canonical import CanonicalEvent, normalize_worker_event
from .models import Session, Thread
from .protocol import LocalEvent
from .store import LocalStore

Normalizer = Callable[[Thread, Session, WorkerEvent], Optional[CanonicalEvent]]
OperationResult = TypeVar("OperationResult")
_TERMINAL_SESSION_STATES = frozenset(
    {"completed", "failed", "cancelled", "interrupted"}
)


@dataclass(eq=False)
class BrokerSubscription:
    subscription_id: str
    live_session_id: str
    high_watermark: int
    queue: asyncio.Queue[LocalEvent]
    overflowed: asyncio.Event = field(default_factory=asyncio.Event)
    closed: asyncio.Event = field(default_factory=asyncio.Event)


class LocalEventBroker:
    def __init__(
        self,
        store: LocalStore,
        normalizer: Optional[
            Callable[
                [Thread, Session, WorkerEvent, str],
                Optional[CanonicalEvent],
            ]
        ] = None,
    ):
        self.store = store
        self._normalizer = normalizer or self._default_normalizer
        self._subscriptions: dict[str, set[BrokerSubscription]] = {}
        self._lock = asyncio.Lock()

    @staticmethod
    def _default_normalizer(
        thread: Thread,
        session: Session,
        worker_event: WorkerEvent,
        occurred_at: str,
    ) -> Optional[CanonicalEvent]:
        return normalize_worker_event(
            thread,
            session,
            worker_event,
            occurred_at=occurred_at,
        )

    @staticmethod
    def _bounded_redacted_payload(payload: dict[str, Any]) -> dict[str, Any]:
        total_string_bytes = 0
        max_total_string_bytes = 256 * 1024

        def walk(value: Any, depth: int = 0) -> Any:
            nonlocal total_string_bytes
            if depth > 12:
                return "<nested-truncated>"
            if isinstance(value, dict):
                output: dict[str, Any] = {}
                for index, (key, child) in enumerate(value.items()):
                    if index >= 256:
                        output["<truncated>"] = True
                        break
                    output[str(key)[:256]] = walk(child, depth + 1)
                return output
            if isinstance(value, (list, tuple)):
                bounded = [walk(child, depth + 1) for child in value[:1000]]
                if len(value) > 1000:
                    bounded.append("<truncated>")
                return bounded
            if isinstance(value, str):
                remaining = max_total_string_bytes - total_string_bytes
                if remaining <= 0:
                    return "<payload-truncated>"
                encoded = value.encode("utf-8", errors="replace")
                bounded = encoded[: min(remaining, 100_000)].decode(
                    "utf-8",
                    errors="replace",
                )
                total_string_bytes += len(bounded.encode("utf-8"))
                if len(encoded) > len(bounded.encode("utf-8")):
                    bounded += "…<truncated>"
                return redact(bounded)
            if value is None or isinstance(value, (bool, int, float)):
                return value
            return redact(str(value)[:4096])

        bounded = walk(copy.deepcopy(payload))
        return bounded if isinstance(bounded, dict) else {"value": bounded}

    async def subscribe_with_watermark(
        self,
        live_session_id: str,
        *,
        max_queue_size: int = 512,
    ) -> BrokerSubscription:
        if max_queue_size < 1 or max_queue_size > 4096:
            raise ValueError("Subscription queue size must be between 1 and 4096")
        async with self._lock:
            high_watermark = self.store.next_sequence(live_session_id) - 1
            subscription = BrokerSubscription(
                subscription_id=f"sub_{secrets.token_hex(16)}",
                live_session_id=live_session_id,
                high_watermark=high_watermark,
                queue=asyncio.Queue(maxsize=max_queue_size),
            )
            self._subscriptions.setdefault(live_session_id, set()).add(subscription)
            return subscription

    async def unsubscribe(self, subscription: BrokerSubscription) -> None:
        async with self._lock:
            subscribers = self._subscriptions.get(subscription.live_session_id)
            if subscribers is not None:
                subscribers.discard(subscription)
                if not subscribers:
                    self._subscriptions.pop(subscription.live_session_id, None)
            subscription.closed.set()

    async def close_session(self, live_session_id: str) -> None:
        # Terminal event is persisted and queued before this is called.
        async with self._lock:
            subscribers = tuple(self._subscriptions.pop(live_session_id, set()))
            for subscription in subscribers:
                subscription.closed.set()

    def _publish_locked(self, event: LocalEvent) -> None:
        dead: list[BrokerSubscription] = []
        for subscription in tuple(
            self._subscriptions.get(event.live_session_id, set())
        ):
            try:
                subscription.queue.put_nowait(event)
            except asyncio.QueueFull:
                subscription.overflowed.set()
                subscription.closed.set()
                dead.append(subscription)
        if dead:
            subscribers = self._subscriptions.get(event.live_session_id)
            if subscribers is not None:
                for subscription in dead:
                    subscribers.discard(subscription)
                if not subscribers:
                    self._subscriptions.pop(event.live_session_id, None)

    async def commit_and_publish(
        self,
        operation: Callable[[], tuple[OperationResult, Optional[LocalEvent]]],
    ) -> OperationResult:
        """Serialize a caller-owned SQLite mutation with live publication.

        The operation must commit its durable state before returning. Running it
        under the same broker lock as normal adapter events prevents a later
        sequence from being delivered before this event. The returned event must
        be the exact persisted row, including its assigned sequence.
        """
        async with self._lock:
            result, persisted = operation()
            if persisted is not None:
                if persisted.sequence < 0:
                    raise ValueError("Only a persisted event may be published")
                self._publish_locked(persisted)
            return result

    async def append_and_publish(
        self,
        thread: Thread,
        session: Session,
        worker_event: WorkerEvent,
    ) -> Optional[LocalEvent]:
        if session.megas_thread_id != thread.megas_thread_id:
            raise ValueError("Session and thread identities do not match")
        authoritative_thread = self.store.get_thread(
            thread.worker_id,
            thread.megas_thread_id,
        )
        if authoritative_thread is None or authoritative_thread != thread:
            raise ValueError("Thread context does not match durable SQLite authority")
        authoritative_session = self.store.get_session(session.live_session_id)
        if authoritative_session is None:
            raise ValueError(f"Session {session.live_session_id} not found")
        if authoritative_session.status in _TERMINAL_SESSION_STATES:
            return None

        redacted_event = WorkerEvent(
            event_type=worker_event.event_type,
            payload=self._bounded_redacted_payload(worker_event.payload or {}),
        )
        occurred_at = datetime.now(timezone.utc).isoformat()
        canonical = self._normalizer(
            thread,
            authoritative_session,
            redacted_event,
            occurred_at,
        )
        if canonical is None:
            return None

        candidate = LocalEvent(
            event_id=canonical.event_id,
            worker_id=thread.worker_id,
            megas_thread_id=thread.megas_thread_id,
            native_thread_id=thread.native_thread_id,
            live_session_id=session.live_session_id,
            sequence=-1,
            event_type=canonical.kind,
            created_at=occurred_at,
            payload=canonical.to_dict(),
        )

        async with self._lock:
            latest_session = self.store.get_session(session.live_session_id)
            if latest_session is None:
                raise ValueError(f"Session {session.live_session_id} not found")
            if latest_session.status in _TERMINAL_SESSION_STATES:
                return None
            with self.store._transaction() as conn:
                existed = conn.execute(
                    "SELECT 1 FROM local_events WHERE event_id=?",
                    (candidate.event_id,),
                ).fetchone() is not None
                persisted = self.store._insert_event(conn, candidate)
            if existed:
                return None
            self._publish_locked(persisted)
            return persisted
