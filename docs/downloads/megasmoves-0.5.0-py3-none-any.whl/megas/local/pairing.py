"""One-time pairing challenge authority for Megas Local."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from typing import Any, Mapping

from .store import LocalStore


class PairingError(Exception):
    pass


class InvalidChallengeError(PairingError):
    pass


class ExpiredChallengeError(PairingError):
    pass


class ConsumedChallengeError(PairingError):
    pass


class RateLimitedError(PairingError):
    pass


class PairingChallengeStore:
    MAX_ACTIVE_PER_WORKER = 10
    MAX_FAILED_ATTEMPTS = 5
    MAX_CONTEXT_BYTES = 8 * 1024

    def __init__(self, store: LocalStore):
        self.store = store

    @staticmethod
    def _hash_secret(secret: str, salt: str) -> str:
        return hashlib.sha256(f"{salt}:{secret}".encode("utf-8")).hexdigest()

    def create_challenge(
        self,
        worker_id: str,
        context: Mapping[str, Any],
        ttl_seconds: int = 300,
        secret_bytes: int = 24,
    ) -> tuple[str, str]:
        if not worker_id:
            raise ValueError("worker_id is required")
        if ttl_seconds < 30 or ttl_seconds > 600:
            raise ValueError("Pairing challenge TTL must be between 30 and 600 seconds")
        if secret_bytes < 16 or secret_bytes > 64:
            raise ValueError("Pairing secret size must be between 16 and 64 bytes")

        context_json = json.dumps(
            dict(context),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
        if len(context_json.encode("utf-8")) > self.MAX_CONTEXT_BYTES:
            raise ValueError("Pairing context is too large")

        now = time.time()
        challenge_id = f"pair_{secrets.token_hex(16)}"
        secret = secrets.token_urlsafe(secret_bytes)
        salt = secrets.token_hex(16)
        verifier_hash = self._hash_secret(secret, salt)

        with self.store._transaction() as conn:
            active_count = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM local_pairing_challenges
                WHERE worker_id=?
                  AND expires_at>?
                  AND consumed_at IS NULL
                  AND failed_attempts<?
                """,
                (worker_id, now, self.MAX_FAILED_ATTEMPTS),
            ).fetchone()["count"]
            if active_count >= self.MAX_ACTIVE_PER_WORKER:
                raise RateLimitedError("Too many active pairing challenges")
            conn.execute(
                """
                INSERT INTO local_pairing_challenges (
                    challenge_id,
                    worker_id,
                    verifier_hash,
                    salt,
                    created_at,
                    expires_at,
                    consumed_at,
                    failed_attempts,
                    context_json
                ) VALUES (?, ?, ?, ?, ?, ?, NULL, 0, ?)
                """,
                (
                    challenge_id,
                    worker_id,
                    verifier_hash,
                    salt,
                    now,
                    now + ttl_seconds,
                    context_json,
                ),
            )
        return challenge_id, secret

    def verify_and_consume(
        self,
        challenge_id: str,
        secret: str,
    ) -> dict[str, Any]:
        now = time.time()
        invalid_secret = False
        context: dict[str, Any] | None = None
        with self.store._transaction() as conn:
            row = conn.execute(
                """
                SELECT
                    verifier_hash,
                    salt,
                    expires_at,
                    consumed_at,
                    failed_attempts,
                    context_json
                FROM local_pairing_challenges
                WHERE challenge_id=?
                """,
                (challenge_id,),
            ).fetchone()
            if row is None:
                raise InvalidChallengeError("Invalid pairing challenge")
            if row["consumed_at"] is not None:
                raise ConsumedChallengeError("Pairing challenge was already used")
            if now >= row["expires_at"]:
                raise ExpiredChallengeError("Pairing challenge expired")
            if row["failed_attempts"] >= self.MAX_FAILED_ATTEMPTS:
                raise InvalidChallengeError("Invalid pairing challenge")

            actual_hash = self._hash_secret(secret, row["salt"])
            if not hmac.compare_digest(actual_hash, row["verifier_hash"]):
                conn.execute(
                    """
                    UPDATE local_pairing_challenges
                    SET failed_attempts=failed_attempts+1
                    WHERE challenge_id=?
                    """,
                    (challenge_id,),
                )
                invalid_secret = True
            else:
                result = conn.execute(
                    """
                    UPDATE local_pairing_challenges
                    SET consumed_at=?
                    WHERE challenge_id=? AND consumed_at IS NULL
                    """,
                    (now, challenge_id),
                )
                if result.rowcount != 1:
                    raise ConsumedChallengeError("Pairing challenge was already used")
                decoded = json.loads(row["context_json"])
                if not isinstance(decoded, dict):
                    raise PairingError("Invalid pairing challenge context")
                context = decoded

        if invalid_secret:
            raise InvalidChallengeError("Invalid pairing challenge")
        assert context is not None
        return context

    def cleanup(self) -> int:
        now = time.time()
        consumed_cutoff = now - 3600
        with self.store._transaction() as conn:
            result = conn.execute(
                """
                DELETE FROM local_pairing_challenges
                WHERE expires_at<?
                   OR (consumed_at IS NOT NULL AND consumed_at<?)
                """,
                (now, consumed_cutoff),
            )
        return result.rowcount
