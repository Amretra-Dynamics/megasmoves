"""Gateway factory with stable Local thread and run-catalogue contracts."""

from __future__ import annotations

from typing import Callable, Optional
import urllib.parse

from .gateway import LocalGatewayHandler, ThreadingHTTPServer
from .runtime import LocalRuntimeServices
from .store import LocalStore
from .thread_creation import create_or_replay_thread
from .thread_runs import list_thread_runs

_THREAD_COLLECTION_PATH = "/api/local/v1/threads"
_EXECUTE_SCOPE = "conversation:execute"
_READ_SCOPE = "conversation:read"


class StableThreadGatewayHandler(LocalGatewayHandler):
    """Own exact thread creation and durable thread-run discovery."""

    def _handle_get(self) -> None:
        parsed = self._parsed_url()
        parts = self._path_parts(parsed.path.rstrip("/"))
        if not (
            len(parts) == 7
            and parts[:4] == ["api", "local", "v1", "threads"]
            and parts[6] == "runs"
        ):
            super()._handle_get()
            return

        if self._require_principal(_READ_SCOPE) is None:
            return
        worker_id, thread_id = parts[4], parts[5]
        if not self._require_worker(worker_id):
            return
        if self.services.store.get_thread(worker_id, thread_id) is None:
            self._error(404, "thread_not_found", "Thread not found")
            return

        query = urllib.parse.parse_qs(parsed.query)
        page = list_thread_runs(
            self.services.store,
            worker_id=worker_id,
            megas_thread_id=thread_id,
            limit=query.get("limit", ["100"])[0],
            before_created_at=query.get("before_created_at", [""])[0],
            before_session_id=query.get("before_session_id", [""])[0],
        )
        self._send_json(200, page)

    def _provider_can_create_thread(self, provider_id: str) -> bool:
        test_authorizer = getattr(self.server, "provider_authorizer", None)
        if callable(test_authorizer):
            return bool(test_authorizer(provider_id))
        providers = self.services.capabilities().get("providers") or []
        return any(
            isinstance(provider, dict)
            and provider.get("provider_id") == provider_id
            and provider.get("can_create_thread") is True
            for provider in providers
        )

    def _handle_post(self) -> None:
        parsed = self._parsed_url()
        path = parsed.path.rstrip("/")
        if path != _THREAD_COLLECTION_PATH:
            super()._handle_post()
            return

        if self._require_principal(_EXECUTE_SCOPE) is None:
            return
        body = self._read_json_body()
        if body is None:
            return
        worker_id = str(body.get("worker_id") or self.services.worker_id)
        if not self._require_worker(worker_id):
            return
        provider_id = str(body.get("provider_id") or "").strip()
        if not provider_id or not self._provider_can_create_thread(provider_id):
            self._error(
                409,
                "provider_not_certified",
                "This provider is not runtime-certified to create Local threads on this Worker.",
            )
            return

        result = create_or_replay_thread(
            self.services.workspace,
            megas_thread_id=body.get("megas_thread_id"),
            worker_id=worker_id,
            provider_id=provider_id,
            path=str(body.get("workspace_path") or ""),
        )
        self._send_json(
            201 if result.outcome == "created" else 200,
            {"outcome": result.outcome, "thread": result.thread},
        )


def create_server(
    store: LocalStore,
    port: int = 18765,
    *,
    services: Optional[LocalRuntimeServices] = None,
    test_authenticator=None,
    provider_authorizer: Optional[Callable[[str], bool]] = None,
) -> ThreadingHTTPServer:
    runtime_services = services or LocalRuntimeServices.build(store)
    try:
        import os
        from pathlib import Path
        host = os.environ.get("MEGAS_LOCAL_HOST", "127.0.0.1")
        if host == "0.0.0.0":
            host = "127.0.0.1"
        server = ThreadingHTTPServer(
            (host, port),
            StableThreadGatewayHandler,
            services=runtime_services,
            test_authenticator=test_authenticator,
        )
        if provider_authorizer is not None:
            server.provider_authorizer = provider_authorizer
        if os.environ.get("MEGAS_LOCAL_TLS", "0") == "1":
            cert_file = Path(__file__).resolve().parents[2] / "certs" / "megas_local.crt"
            key_file = Path(__file__).resolve().parents[2] / "certs" / "megas_local.key"
            if cert_file.is_file() and key_file.is_file():
                import ssl
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                context.minimum_version = ssl.TLSVersion.TLSv1_2
                context.load_cert_chain(str(cert_file), str(key_file))
                server.socket = context.wrap_socket(server.socket, server_side=True)
        return server
    except Exception:
        if services is None:
            runtime_services.close()
        raise
