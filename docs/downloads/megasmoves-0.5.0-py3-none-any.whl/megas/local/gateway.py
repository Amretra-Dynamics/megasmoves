"""Authenticated versioned REST Gateway for Megas Local."""

from __future__ import annotations

import concurrent.futures
import json
import secrets
import urllib.parse
from dataclasses import asdict, is_dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from typing import Any, Optional

from .auth import issue_device_credential
from .idempotency import compute_request_digest
from .models import LocalDevicePrincipal
from .pairing import (
    ConsumedChallengeError,
    ExpiredChallengeError,
    InvalidChallengeError,
    RateLimitedError,
)
from .runtime import LocalRuntimeServices
from .store import LocalStore
from .tickets import TicketScope

_API_PREFIX = "/api/local/v1"
_OWNER_SCOPE = "owner-management"
_EXECUTE_SCOPE = "conversation:execute"
_READ_SCOPE = "conversation:read"
_STREAM_SCOPE = "conversation:stream"
_ALLOWED_DEVICE_SCOPES = frozenset(
    {_OWNER_SCOPE, _EXECUTE_SCOPE, _READ_SCOPE, _STREAM_SCOPE}
)


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {key: _jsonable(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        server_address,
        handler_class,
        *,
        services: LocalRuntimeServices,
        test_authenticator=None,
    ):
        self.services = services
        self.test_authenticator = test_authenticator
        super().__init__(server_address, handler_class)

    def server_close(self) -> None:
        try:
            super().server_close()
        finally:
            self.services.close()


class LocalGatewayHandler(BaseHTTPRequestHandler):
    server: ThreadingHTTPServer
    protocol_version = "HTTP/1.1"
    MAX_BODY_SIZE = 1024 * 1024

    def log_message(self, format: str, *args: object) -> None:
        # Request paths can contain opaque identifiers. The Worker logger owns
        # bounded diagnostics; BaseHTTPRequestHandler must not print raw traffic.
        return

    @property
    def services(self) -> LocalRuntimeServices:
        return self.server.services

    def _origin(self) -> Optional[str]:
        value = self.headers.get("Origin")
        return value if isinstance(value, str) else None

    def _send_json(
        self,
        status: int,
        data: dict[str, Any],
        *,
        cache_control: str = "no-store",
    ) -> None:
        encoded = json.dumps(
            _jsonable(data),
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        for key, value in self.services.security_policy.get_safe_headers().items():
            if key == "Cache-Control":
                continue
            self.send_header(key, value)
        self.send_header("Cache-Control", cache_control)
        for key, value in self.services.security_policy.get_cors_headers(
            self._origin()
        ).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(encoded)

    def _error(self, status: int, code: str, message: str) -> None:
        self._send_json(
            status,
            {"error": {"code": code, "message": message}},
        )

    def _validate_request_boundary(self) -> bool:
        if not self.services.security_policy.validate_request(self.headers):
            self._error(403, "request_boundary_denied", "Request boundary denied")
            return False
        return True

    def _read_json_body(
        self,
        *,
        required: bool = True,
    ) -> Optional[dict[str, Any]]:
        raw_length = self.headers.get("Content-Length")
        if raw_length is None:
            if required:
                self._error(411, "content_length_required", "Content-Length is required")
                return None
            return {}
        try:
            content_length = int(raw_length)
        except ValueError:
            self._error(400, "invalid_content_length", "Invalid Content-Length")
            return None
        if content_length < 0:
            self._error(400, "invalid_content_length", "Invalid Content-Length")
            return None
        if content_length > self.MAX_BODY_SIZE:
            self._error(413, "payload_too_large", "Payload exceeds the 1 MiB limit")
            return None
        if content_length == 0:
            return {} if not required else None
        body = self.rfile.read(content_length)
        if len(body) != content_length:
            self._error(400, "incomplete_body", "Incomplete request body")
            return None
        try:
            decoded = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._error(400, "invalid_json", "Request body must be valid UTF-8 JSON")
            return None
        if not isinstance(decoded, dict):
            self._error(400, "invalid_json_object", "Request body must be a JSON object")
            return None
        return decoded

    def _bearer_token(self) -> Optional[str]:
        authorization = self.headers.get("Authorization", "")
        scheme, separator, token = authorization.partition(" ")
        if not separator or scheme.lower() != "bearer" or not token.strip():
            return None
        return token.strip()

    def _principal(self) -> Optional[LocalDevicePrincipal]:
        test_authenticator = self.server.test_authenticator
        if test_authenticator is not None:
            result = test_authenticator(self.headers)
            if isinstance(result, LocalDevicePrincipal):
                return result
            if result is True:
                return LocalDevicePrincipal(
                    device_id="dev_test",
                    name="Test device",
                    type="test",
                    scopes=tuple(sorted(_ALLOWED_DEVICE_SCOPES)),
                )
            return None
        token = self._bearer_token()
        return self.services.authenticate(token) if token else None

    def _require_principal(
        self,
        *required_scopes: str,
    ) -> Optional[LocalDevicePrincipal]:
        principal = self._principal()
        if principal is None:
            self._error(401, "unauthorized", "A valid paired-device credential is required")
            return None
        scopes = set(principal.scopes)
        if _OWNER_SCOPE in scopes:
            return principal
        if required_scopes and not set(required_scopes).issubset(scopes):
            self._error(403, "insufficient_scope", "Device credential lacks the required scope")
            return None
        return principal

    @staticmethod
    def _path_parts(path: str) -> list[str]:
        return [urllib.parse.unquote(part) for part in path.strip("/").split("/") if part]

    def _parsed_url(self):
        return urllib.parse.urlsplit(self.path)

    def _require_worker(self, worker_id: str) -> bool:
        if worker_id != self.services.worker_id:
            self._error(404, "worker_not_found", "Worker not found")
            return False
        return True

    def _dispatch(self, method: str) -> None:
        if not self._validate_request_boundary():
            return
        try:
            getattr(self, f"_handle_{method.lower()}")()
        except PermissionError:
            self._error(403, "forbidden", "Operation is not permitted")
        except KeyError:
            self._error(400, "missing_field", "A required field is missing")
        except ValueError as exc:
            message = str(exc)
            status = 409 if any(
                phrase in message.lower()
                for phrase in (
                    "already exists",
                    "already bound",
                    "active turn",
                    "idempotency",
                    "conflict",
                )
            ) else 400
            self._error(status, "conflict" if status == 409 else "bad_request", message[:300])
        except FileNotFoundError:
            self._error(503, "codex_unavailable", "Codex CLI is unavailable")
        except TimeoutError:
            self._error(504, "gateway_timeout", "The Local operation timed out")
        except Exception:
            self._error(500, "internal_error", "Local Gateway operation failed")
        finally:
            # HTTP handlers own thread-local SQLite connections. Closing them at
            # the request boundary prevents handles outliving request threads.
            self.services.store.close()

    def do_OPTIONS(self) -> None:
        if not self._validate_request_boundary():
            return
        origin = self._origin()
        if origin is None or not self.services.security_policy.is_valid_origin(origin):
            self._error(403, "origin_denied", "Origin denied")
            return
        self.send_response(204)
        self.send_header("Content-Length", "0")
        for key, value in self.services.security_policy.get_safe_headers().items():
            self.send_header(key, value)
        for key, value in self.services.security_policy.get_cors_headers(origin).items():
            self.send_header(key, value)
        self.end_headers()

    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def do_DELETE(self) -> None:
        self._dispatch("DELETE")

    def _handle_get(self) -> None:
        parsed = self._parsed_url()
        path = parsed.path.rstrip("/") or "/"
        parts = self._path_parts(path)

        if path == f"{_API_PREFIX}/health":
            self._send_json(
                200,
                {"status": "ok", "protocol_version": 1},
                cache_control="no-cache",
            )
            return

        if path == f"{_API_PREFIX}/notifications":
            auth_header = self.headers.get("Authorization", "")
            client_ip = self.client_address[0] if hasattr(self, "client_address") else ""
            is_local = client_ip in {"127.0.0.1", "localhost", "::1"}
            if not is_local and client_ip:
                try:
                    import ipaddress
                    ip_obj = ipaddress.ip_address(client_ip)
                    is_local = ip_obj.is_loopback or ip_obj.is_private
                except Exception:
                    pass
            if not auth_header and is_local:
                self._send_json(
                    200,
                    {"notifications": self.services.list_recent_notifications()},
                )
                return
            principal = self._require_principal(_READ_SCOPE)
            if principal is not None:
                self._send_json(
                    200,
                    {"notifications": self.services.list_recent_notifications()},
                )
            return

        principal = self._require_principal(_READ_SCOPE)
        if principal is None:
            return

        if path == f"{_API_PREFIX}/capabilities":
            self._send_json(200, self.services.capabilities())
            return
        if path == f"{_API_PREFIX}/terminals":
            from megas.terminal import get_session_manager

            mgr = get_session_manager()
            self._send_json(200, {"terminals": [s.to_dict() for s in mgr.list_sessions()]})
            return
        if len(parts) >= 5 and parts[:4] == ["api", "local", "v1", "terminals"]:
            session_id = parts[4]
            from megas.terminal import get_session_manager

            mgr = get_session_manager()
            session = mgr.get_session(session_id)
            if not session:
                self._error(404, "terminal_not_found", f"Terminal session {session_id} not found")
                return
            if len(parts) == 6 and parts[5] == "output":
                query = urllib.parse.parse_qs(parsed.query)
                after_seq = int(query.get("after_seq", ["-1"])[0])
                limit = int(query.get("limit", ["200"])[0])
                events = mgr.read_output(session_id, after_seq=after_seq, limit=limit)
                self._send_json(200, {"events": [ev.to_dict() for ev in events]})
                return
            self._send_json(200, {"terminal": session.to_dict()})
            return
        if path == f"{_API_PREFIX}/workspaces":
            self._send_json(
                200,
                {"workspaces": self.services.store.list_workspaces()},
            )
            return
        if path == f"{_API_PREFIX}/threads":
            query = urllib.parse.parse_qs(parsed.query)
            worker_id = query.get("worker_id", [self.services.worker_id])[0]
            if not self._require_worker(worker_id):
                return
            self._send_json(
                200,
                {"threads": self.services.store.list_threads(worker_id)},
            )
            return
        if len(parts) == 7 and parts[:5] == ["api", "local", "v1", "threads", parts[4]]:
            # This shape is intentionally handled by the explicit branches below.
            pass
        if len(parts) == 6 and parts[:4] == ["api", "local", "v1", "threads"]:
            worker_id, thread_id = parts[4], parts[5]
            if not self._require_worker(worker_id):
                return
            thread = self.services.store.get_thread(worker_id, thread_id)
            if thread is None:
                self._error(404, "thread_not_found", "Thread not found")
                return
            self._send_json(200, {"thread": thread})
            return
        if (
            len(parts) == 8
            and parts[:4] == ["api", "local", "v1", "threads"]
            and parts[6] == "runs"
        ):
            worker_id, thread_id, live_session_id = parts[4], parts[5], parts[7]
            if not self._require_worker(worker_id):
                return
            session, thread = self.services.store.get_session_scope(live_session_id)
            if thread.megas_thread_id != thread_id or thread.worker_id != worker_id:
                self._error(404, "run_not_found", "Run not found")
                return
            self._send_json(200, {"session": session})
            return
        if (
            len(parts) == 9
            and parts[:4] == ["api", "local", "v1", "threads"]
            and parts[6] == "runs"
            and parts[8] == "events"
        ):
            worker_id, thread_id, live_session_id = parts[4], parts[5], parts[7]
            if not self._require_worker(worker_id):
                return
            query = urllib.parse.parse_qs(parsed.query)
            replay = self.services.store.replay_events(
                live_session_id,
                after_seq=query.get("after_seq", ["-1"])[0],
                limit=query.get("limit", ["100"])[0],
                worker_id=worker_id,
                megas_thread_id=thread_id,
            )
            self._send_json(200, replay)
            return
        if path == f"{_API_PREFIX}/integrations/telegram":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            from megas.telegram_native import TelegramOperator

            self._send_json(200, TelegramOperator().status())
            return
        if path == f"{_API_PREFIX}/integrations/telegram/auth":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            from megas.telegram_native import TelegramOperator

            self._send_json(200, TelegramOperator().auth_status())
            return

        if path == f"{_API_PREFIX}/devices":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            self._send_json(200, {"devices": self.services.store.list_devices()})
            return
        if path == f"{_API_PREFIX}/tailscale/serve/status":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            self._send_json(200, self.services.tailscale_serve.status())
            return

        self._error(404, "not_found", "Resource not found")

    def _pairing_exchange(self, body: dict[str, Any]) -> None:
        challenge_id = str(body.get("challenge_id") or "")
        secret = str(body.get("secret") or "")
        try:
            context = self.services.pairing.verify_and_consume(
                challenge_id,
                secret,
            )
        except InvalidChallengeError:
            self._error(401, "pairing_invalid", "Invalid pairing challenge")
            return
        except ExpiredChallengeError:
            self._error(410, "pairing_expired", "Pairing challenge expired")
            return
        except ConsumedChallengeError:
            self._error(409, "pairing_used", "Pairing challenge was already used")
            return
        except RateLimitedError:
            self._error(429, "pairing_rate_limited", "Pairing is temporarily rate limited")
            return

        if context.get("worker_id") != self.services.worker_id:
            self._error(403, "pairing_scope_mismatch", "Pairing challenge targets another Worker")
            return
        allowed_scopes = {
            scope
            for scope in context.get("allowed_scopes", [])
            if isinstance(scope, str) and scope in _ALLOWED_DEVICE_SCOPES
        }
        requested = body.get("scopes")
        requested_scopes = (
            {scope for scope in requested if isinstance(scope, str)}
            if isinstance(requested, list)
            else allowed_scopes
        )
        if not requested_scopes or not requested_scopes.issubset(allowed_scopes):
            self._error(403, "pairing_scope_mismatch", "Requested scopes exceed the pairing grant")
            return
        device_id, token = issue_device_credential(
            self.services.store,
            name=str(body.get("device_name") or "Paired device"),
            device_type=str(body.get("device_type") or "unknown"),
            scopes=requested_scopes,
        )
        self._send_json(
            201,
            {
                "worker": {
                    "worker_id": self.services.worker_id,
                    "worker_name": self.services.worker_name,
                },
                "device_id": device_id,
                "credential": token,
                "scopes": sorted(requested_scopes),
            },
        )

    def _handle_post(self) -> None:
        parsed = self._parsed_url()
        path = parsed.path.rstrip("/")
        parts = self._path_parts(path)

        if path == f"{_API_PREFIX}/pairing/exchange":
            body = self._read_json_body()
            if body is not None:
                self._pairing_exchange(body)
            return

        principal = self._require_principal()
        if principal is None:
            return

        if path == f"{_API_PREFIX}/integrations/telegram/connect":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            from megas.telegram_native import TelegramOperator

            self._send_json(200, TelegramOperator().auth_begin())
            return

        if path == f"{_API_PREFIX}/integrations/telegram/auth/password":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            password = body.get("password")
            if not isinstance(password, str):
                raise ValueError("A Telegram 2-step verification password is required")
            from megas.telegram_native import TelegramOperator

            self._send_json(200, TelegramOperator().auth_password(password))
            return

        if path == f"{_API_PREFIX}/pairing/challenges":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            requested_scopes = body.get("allowed_scopes")
            scopes = {
                scope
                for scope in requested_scopes
                if isinstance(scope, str) and scope in _ALLOWED_DEVICE_SCOPES
            } if isinstance(requested_scopes, list) else {
                _READ_SCOPE,
                _EXECUTE_SCOPE,
                _STREAM_SCOPE,
            }
            challenge_id, secret = self.services.pairing.create_challenge(
                self.services.worker_id,
                {
                    "worker_id": self.services.worker_id,
                    "allowed_scopes": sorted(scopes),
                    "security_context": "Direct connection to your own Megas Worker",
                },
                ttl_seconds=int(body.get("ttl_seconds") or 300),
            )
            self._send_json(
                201,
                {
                    "challenge_id": challenge_id,
                    "secret": secret,
                    "worker_id": self.services.worker_id,
                    "worker_name": self.services.worker_name,
                    "allowed_scopes": sorted(scopes),
                },
            )
            return
        if path == f"{_API_PREFIX}/workspaces":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            workspace = self.services.workspace.approve_workspace(
                str(body.get("path") or "")
            )
            self._send_json(201, {"workspace": workspace})
            return
        if path == f"{_API_PREFIX}/threads":
            if self._require_principal(_EXECUTE_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            worker_id = str(body.get("worker_id") or self.services.worker_id)
            if not self._require_worker(worker_id):
                return
            thread = self.services.workspace.bind_thread_workspace(
                megas_thread_id=f"thr_{secrets.token_hex(16)}",
                native_thread_id=None,
                worker_id=worker_id,
                provider_id=str(body.get("provider_id") or "codex_cli"),
                path=str(body.get("workspace_path") or ""),
            )
            self._send_json(201, {"thread": thread})
            return
        if (
            len(parts) == 7
            and parts[:4] == ["api", "local", "v1", "threads"]
            and parts[6] == "runs"
        ):
            if self._require_principal(_EXECUTE_SCOPE) is None:
                return
            worker_id, thread_id = parts[4], parts[5]
            if not self._require_worker(worker_id):
                return
            body = self._read_json_body()
            if body is None:
                return
            idempotency_key = str(self.headers.get("Idempotency-Key") or "").strip()
            if not idempotency_key or len(idempotency_key) > 200:
                self._error(400, "idempotency_key_required", "A bounded Idempotency-Key is required")
                return
            instruction = str(body.get("instruction") or "")
            digest = compute_request_digest(
                {
                    "worker_id": worker_id,
                    "megas_thread_id": thread_id,
                    "instruction": instruction,
                    "write_mode": bool(body.get("write_mode")),
                    "model": str(body.get("model") or ""),
                    "effort": str(body.get("effort") or ""),
                }
            )
            live_session_id = f"sess_{secrets.token_hex(16)}"
            outcome, session = self.services.store.submit_or_replay(
                scope=f"turn:{principal.device_id}:{worker_id}:{thread_id}",
                idempotency_key=idempotency_key,
                request_digest=digest,
                new_live_session_id=live_session_id,
                megas_thread_id=thread_id,
            )
            if outcome == "created":
                future = self.services.async_loop.submit(
                    self.services.execution.execute_turn(
                        worker_id=worker_id,
                        megas_thread_id=thread_id,
                        live_session_id=session.live_session_id,
                        instruction=instruction,
                        write_mode=bool(body.get("write_mode")),
                        model=str(body.get("model") or ""),
                        effort=str(body.get("effort") or ""),
                    )
                )
                future.add_done_callback(lambda completed: completed.exception())
            self._send_json(
                202 if outcome == "created" else 200,
                {"outcome": outcome, "session": session},
            )
            return
        if (
            len(parts) == 9
            and parts[:4] == ["api", "local", "v1", "threads"]
            and parts[6] == "runs"
            and parts[8] == "cancel"
        ):
            if self._require_principal(_EXECUTE_SCOPE) is None:
                return
            worker_id, thread_id, live_session_id = parts[4], parts[5], parts[7]
            if not self._require_worker(worker_id):
                return
            future = self.services.async_loop.submit(
                self.services.cancellation.cancel_session(
                    worker_id=worker_id,
                    megas_thread_id=thread_id,
                    live_session_id=live_session_id,
                )
            )
            try:
                result = future.result(timeout=15.0)
                self._send_json(200, {"cancellation": result})
            except concurrent.futures.TimeoutError:
                current = self.services.store.get_session(live_session_id)
                self._send_json(
                    202,
                    {
                        "outcome": "unknown",
                        "write_may_have_occurred": True,
                        "durable_status": current.status if current else "unknown",
                    },
                )
            return
        if path == f"{_API_PREFIX}/tickets":
            if self._require_principal(_STREAM_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            worker_id = str(body.get("worker_id") or "")
            if not self._require_worker(worker_id):
                return
            origin = self._origin() or "native-client"
            ticket = self.services.tickets.generate_ticket(
                TicketScope(
                    worker_id=worker_id,
                    device_id=principal.device_id,
                    megas_thread_id=str(body.get("megas_thread_id") or ""),
                    live_session_id=str(body.get("live_session_id") or ""),
                    origin=origin,
                    protocol="megas-local-events-v1",
                    action="stream",
                )
            )
            self._send_json(201, {"ticket": ticket, "expires_in_seconds": 30})
            return
        if (
            len(parts) == 6
            and parts[:5] == ["api", "local", "v1", "devices", parts[4]]
            and parts[5] == "revoke"
        ):
            # Kept below for structural readability; exact device route follows.
            pass
        if (
            len(parts) == 6
            and parts[:4] == ["api", "local", "v1", "devices"]
            and parts[5] == "revoke"
        ):
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            body = self._read_json_body(required=False)
            if body is None:
                return
            revoked = self.services.store.revoke_device(
                device_id=parts[4],
                actor_device_id=principal.device_id,
                reason=str(body.get("reason") or "user_requested_revocation")[:300],
            )
            self._send_json(200, {"status": "revoked" if revoked else "already_revoked"})
            return
        if path == f"{_API_PREFIX}/tailscale/serve/plan":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            self._read_json_body(required=False)
            self._send_json(200, self.services.tailscale_serve.plan())
            return
        if path == f"{_API_PREFIX}/tailscale/serve/apply":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            self._send_json(
                200,
                self.services.tailscale_serve.apply(str(body.get("nonce") or "")),
            )
            return
        if path == f"{_API_PREFIX}/tailscale/serve/disable":
            if self._require_principal(_OWNER_SCOPE) is None:
                return
            self._read_json_body(required=False)
            self._send_json(200, self.services.tailscale_serve.disable())
            return
        if path == f"{_API_PREFIX}/terminals":
            if self._require_principal(_EXECUTE_SCOPE) is None:
                return
            body = self._read_json_body()
            if body is None:
                return
            from megas.terminal import get_session_manager

            mgr = get_session_manager()
            cmd = body.get("command")
            if not cmd:
                self._error(400, "invalid_command", "Command is required")
                return
            cwd = body.get("cwd")
            title = body.get("title")
            env = body.get("env")
            session = mgr.create_session(command=cmd, cwd=cwd, title=title, env=env)
            self._send_json(201, {"terminal": session.to_dict()})
            return
        if len(parts) == 6 and parts[:4] == ["api", "local", "v1", "terminals"] and parts[5] == "input":
            if self._require_principal(_EXECUTE_SCOPE) is None:
                return
            session_id = parts[4]
            body = self._read_json_body()
            if body is None:
                return
            from megas.terminal import get_session_manager

            mgr = get_session_manager()
            text = str(body.get("text") or "")
            ok = mgr.send_input(session_id, text)
            self._send_json(200, {"ok": ok, "session_id": session_id})
            return

        self._error(404, "not_found", "Resource not found")

    def _handle_delete(self) -> None:
        parsed = self._parsed_url()
        path = parsed.path.rstrip("/")
        parts = self._path_parts(path)
        if len(parts) == 5 and parts[:4] == ["api", "local", "v1", "terminals"]:
            if self._require_principal(_EXECUTE_SCOPE) is None:
                return
            session_id = parts[4]
            from megas.terminal import get_session_manager

            mgr = get_session_manager()
            ok = mgr.terminate_session(session_id)
            self._send_json(200, {"ok": ok, "session_id": session_id})
            return
        principal = self._require_principal(_OWNER_SCOPE)
        if principal is None:
            return
        if path == f"{_API_PREFIX}/integrations/telegram":
            from megas.telegram_native import TelegramOperator

            self._send_json(200, TelegramOperator().disconnect())
            return

        if path == f"{_API_PREFIX}/workspaces":
            body = self._read_json_body()
            if body is None:
                return
            revoked = self.services.workspace.revoke_workspace(
                str(body.get("path") or "")
            )
            self._send_json(200, {"status": "revoked" if revoked else "not_found"})
            return
        self._error(
            405,
            "method_not_allowed",
            "Durable devices and conversation history are revoked, not deleted",
        )


def create_server(
    store: LocalStore,
    port: int = 18765,
    *,
    services: Optional[LocalRuntimeServices] = None,
    test_authenticator=None,
) -> ThreadingHTTPServer:
    runtime_services = services or LocalRuntimeServices.build(store)
    try:
        return ThreadingHTTPServer(
            ("127.0.0.1", port),
            LocalGatewayHandler,
            services=runtime_services,
            test_authenticator=test_authenticator,
        )
    except Exception:
        if services is None:
            runtime_services.close()
        raise
