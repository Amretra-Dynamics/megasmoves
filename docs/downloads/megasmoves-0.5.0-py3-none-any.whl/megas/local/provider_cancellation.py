"""Authoritative cancellation factories for API-backed coding agents."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
import os

ProviderCanceller = Callable[[], Awaitable[bool]]


def build_provider_canceller(
    provider_id: str,
    native_thread_id: str,
) -> ProviderCanceller | None:
    provider = str(provider_id or "").strip().lower()
    native_id = str(native_thread_id or "").strip()
    if not native_id:
        return None

    if provider == "devin_cli":
        from megas.adapters.devin_control_plane import (
            DevinControlPlane,
            UrllibDevinTransport,
        )

        token = os.getenv("DEVIN_API_KEY", "").strip()
        org_id = os.getenv("DEVIN_ORG_ID", "").strip()
        if not token or not org_id:
            return None

        async def cancel_devin() -> bool:
            plane = DevinControlPlane(UrllibDevinTransport(token), org_id)
            response = await asyncio.to_thread(
                plane.terminate_session,
                native_id,
                archive=False,
            )
            return str(response.get("session_id") or "") == native_id

        return cancel_devin

    # Jules v1alpha currently has create/get/list/sendMessage/approvePlan only.
    # Returning None is deliberate: the caller records an interrupted/unknown
    # provider state rather than pretending Stop terminated the remote task.
    return None
