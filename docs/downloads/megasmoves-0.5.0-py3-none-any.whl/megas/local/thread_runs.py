"""Authoritative, cursor-paginated Local run catalogue for one thread."""

from __future__ import annotations

from typing import Any

from .store import LocalStore, _row_to_session


def list_thread_runs(
    store: LocalStore,
    *,
    worker_id: str,
    megas_thread_id: str,
    limit: object = 100,
    before_created_at: object = "",
    before_session_id: object = "",
) -> dict[str, Any]:
    """List durable sessions newest-first within one exact Worker/thread scope.

    The cursor is the ordered pair ``(created_at, live_session_id)``. Both parts
    are required together so pagination cannot silently jump across equal
    timestamps or become ambiguous after a restart.
    """

    try:
        bounded_limit = int(limit)
    except (TypeError, ValueError) as exc:
        raise ValueError("limit must be an integer") from exc
    if bounded_limit < 1 or bounded_limit > 200:
        raise ValueError("limit must be between 1 and 200")

    created_cursor = str(before_created_at or "").strip()
    session_cursor = str(before_session_id or "").strip()
    if bool(created_cursor) != bool(session_cursor):
        raise ValueError(
            "before_created_at and before_session_id must be supplied together"
        )
    if len(created_cursor) > 100 or len(session_cursor) > 200:
        raise ValueError("run catalogue cursor is too long")

    thread = store.get_thread(worker_id, megas_thread_id)
    if thread is None:
        raise LookupError("Local thread not found")

    sql = """
        SELECT s.*
        FROM local_sessions AS s
        JOIN local_threads AS t
          ON t.megas_thread_id = s.megas_thread_id
        WHERE t.worker_id=? AND t.megas_thread_id=?
    """
    params: list[object] = [worker_id, megas_thread_id]
    if created_cursor:
        sql += """
          AND (
            s.created_at < ?
            OR (s.created_at = ? AND s.live_session_id < ?)
          )
        """
        params.extend([created_cursor, created_cursor, session_cursor])
    sql += " ORDER BY s.created_at DESC, s.live_session_id DESC LIMIT ?"
    params.append(bounded_limit + 1)

    rows = store._get_conn().execute(sql, tuple(params)).fetchall()
    has_more = len(rows) > bounded_limit
    page_rows = rows[:bounded_limit]
    sessions = [_row_to_session(row) for row in page_rows]
    next_cursor = None
    if has_more and page_rows:
        last = page_rows[-1]
        next_cursor = {
            "created_at": str(last["created_at"]),
            "live_session_id": str(last["live_session_id"]),
        }
    return {
        "sessions": sessions,
        "has_more": has_more,
        "next_cursor": next_cursor,
    }
