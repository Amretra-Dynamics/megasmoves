"""Host, Origin, CORS, and browser-request policy for Megas Local."""

from __future__ import annotations

import ipaddress
import os
import socket
import urllib.parse
from typing import Any, Optional


CANONICAL_MEGAS_WEB_ORIGINS = frozenset({"https://megasmoves.io"})


class LocalSecurityPolicy:
    def __init__(self) -> None:
        self._allowed_hosts: set[str] = {"127.0.0.1", "localhost", "::1"}
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            lan_ip = s.getsockname()[0]
            s.close()
            if lan_ip:
                self._allowed_hosts.add(lan_ip)
        except Exception:
            pass
        extra_hosts = os.environ.get("MEGAS_LOCAL_ALLOWED_HOSTS", "").split(",")
        for h in extra_hosts:
            clean = h.strip()
            if clean:
                norm = self._normalize_host(clean)
                if norm:
                    self._allowed_hosts.add(norm)
        # The product website is the canonical browser control surface. Development
        # origins remain opt-in through local settings; no wildcard origin is used.
        self._allowed_origins: set[str] = set(CANONICAL_MEGAS_WEB_ORIGINS)
        self._tailscale_hosts: set[str] = set()

    @staticmethod
    def _normalize_host(host_header: str) -> Optional[str]:
        raw = str(host_header or "").strip()
        if not raw or any(character in raw for character in "/?#@"):
            return None
        try:
            parsed = urllib.parse.urlsplit(f"//{raw}")
        except ValueError:
            return None
        if parsed.username is not None or parsed.password is not None:
            return None
        hostname = parsed.hostname
        if hostname is None:
            return None
        normalized = hostname.rstrip(".").lower()
        try:
            return ipaddress.ip_address(normalized).compressed
        except ValueError:
            try:
                return normalized.encode("idna").decode("ascii")
            except UnicodeError:
                return None

    @classmethod
    def _normalize_origin(cls, origin: str) -> Optional[str]:
        raw = str(origin or "").strip()
        if not raw or raw.lower() == "null":
            return None
        try:
            parsed = urllib.parse.urlsplit(raw)
        except ValueError:
            return None
        if parsed.scheme not in {"http", "https"}:
            return None
        if parsed.username is not None or parsed.password is not None:
            return None
        if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            return None
        host = cls._normalize_host(parsed.netloc)
        if host is None:
            return None
        default_port = 443 if parsed.scheme == "https" else 80
        try:
            port = parsed.port or default_port
        except ValueError:
            return None
        host_text = f"[{host}]" if ":" in host else host
        port_suffix = "" if port == default_port else f":{port}"
        return f"{parsed.scheme}://{host_text}{port_suffix}"

    def register_origin(self, origin: str) -> str:
        normalized = self._normalize_origin(origin)
        if normalized is None:
            raise ValueError("Invalid browser origin")
        self._allowed_origins.add(normalized)
        return normalized

    def unregister_origin(self, origin: str) -> None:
        normalized = self._normalize_origin(origin)
        if normalized is not None and normalized not in CANONICAL_MEGAS_WEB_ORIGINS:
            self._allowed_origins.discard(normalized)

    def register_tailscale_host(self, host: str) -> str:
        normalized = self._normalize_host(host)
        if normalized is None or not normalized.endswith(".ts.net"):
            raise ValueError("Expected a verified Tailscale MagicDNS host")
        self._tailscale_hosts.add(normalized)
        self._allowed_hosts.add(normalized)
        self._allowed_origins.add(f"https://{normalized}")
        return normalized

    def unregister_tailscale_host(self, host: str) -> None:
        normalized = self._normalize_host(host)
        if normalized is None:
            return
        self._tailscale_hosts.discard(normalized)
        self._allowed_hosts.discard(normalized)
        self._allowed_origins.discard(f"https://{normalized}")

    def is_valid_host(self, host_header: str) -> bool:
        normalized = self._normalize_host(host_header)
        if normalized is None:
            return False
        if normalized in self._allowed_hosts:
            return True
        if normalized.endswith(".ts.net"):
            return True
        try:
            ip = ipaddress.ip_address(normalized)
            if ip.is_private or ip.is_loopback:
                return True
        except ValueError:
            pass
        return False

    def is_valid_origin(self, origin_header: str) -> bool:
        normalized = self._normalize_origin(origin_header)
        return normalized is not None and normalized in self._allowed_origins

    def validate_request(self, headers: Any) -> bool:
        if not self.is_valid_host(headers.get("Host", "")):
            return False
        origin = headers.get("Origin")
        return origin is None or self.is_valid_origin(origin)

    def get_cors_headers(
        self,
        request_origin: Optional[str] = None,
        *,
        allow_private_network: bool = True,
    ) -> dict[str, str]:
        headers = {
            "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": (
                "Authorization, Content-Type, Idempotency-Key, X-Megas-Protocol"
            ),
            "Access-Control-Max-Age": "600",
            "Vary": "Origin, Access-Control-Request-Private-Network",
        }
        if request_origin and self.is_valid_origin(request_origin):
            headers["Access-Control-Allow-Origin"] = request_origin
            # The Local Gateway is loopback-only for Direct web use. PNA approval
            # is still bounded by exact Origin and Host validation; no wildcard is used.
            if allow_private_network:
                headers["Access-Control-Allow-Private-Network"] = "true"
        return headers

    @staticmethod
    def get_safe_headers(*, static_ui: bool = False) -> dict[str, str]:
        headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Referrer-Policy": "no-referrer",
            "Cache-Control": "no-store",
        }
        headers["Content-Security-Policy"] = (
            "default-src 'self'; base-uri 'none'; frame-ancestors 'none'; "
            "object-src 'none'; connect-src 'self' ws: wss:"
            if static_ui
            else "default-src 'none'; frame-ancestors 'none'; base-uri 'none'"
        )
        return headers
