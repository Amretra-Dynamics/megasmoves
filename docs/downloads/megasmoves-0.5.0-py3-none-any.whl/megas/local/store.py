"""Durable store API for Megas Local SQLite authority."""

from __future__ import annotations

import datetime
import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from typing import Any, Iterator, Optional, Protocol

from .models import Device, DeviceAudit, Session, Thread, Workspace
from .protocol import LocalEvent

_TERMINAL_SESSION_STATES = frozenset(
    {"completed", "failed", "cancelled", "interrupted"}
)
_ALLOWED_SESSION_TRANSITIONS: dict[str, frozenset[str]] = {
    "accepted": frozenset(
        {
            "running",
            "cancelling",
            "completed",
            "failed",
            "cancelled",
            "interrupted",
        }
    ),
    "running": frozenset(
        {"cancelling", "completed", "failed", "interrupted"}
    ),
    # Completion may win a race after cancellation was accepted.
    "cancelling": frozenset(
        {"cancelled", "completed", "failed", "interrupted"}
    ),
}


class DeviceRevocationObserver(Protocol):
    def on_device_revoked(self, device_id: str) -> None: ...


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _row_to_workspace(row: sqlite3.Row) -> Workspace:
    return Workspace(
        path=row["path"],
        approved=bool(row["approved"]),
        id=row["id"],
    )


def _row_to_thread(row: sqlite3.Row) -> Thread:
    return Thread(
        megas_thread_id=row["megas_thread_id"],
        native_thread_id=row["native_thread_id"],
        worker_id=row["worker_id"],
        provider_id=row["provider_id"],
        workspace_path=row["workspace_path"],
        cloud_thread_id=row["cloud_thread_id"],
    )


def _row_to_session(row: sqlite3.Row) -> Session:
    return Session(
        live_session_id=row["live_session_id"],
        megas_thread_id=row["megas_thread_id"],
        status=row["status"],
        pid=row["pid"],
        process_create_time=row["process_create_time"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        reason=row["reason"],
    )


def _row_to_device(row: sqlite3.Row) -> Device:
    return Device(
        id=row["id"],
        name=row["name"],
        type=row["type"],
        created_at=row["created_at"],
        last_used_at=row["last_used_at"],
        status=row["status"],
        scopes=row["scopes"],
        credential_id=row["credential_id"],
        rotated_at=row["rotated_at"],
        revoked_at=row["revoked_at"],
    )


class LocalStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._local = threading.local()
        self._device_revocation_observers: list[DeviceRevocationObserver] = []

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn"):
            conn = sqlite3.connect(
                str(self.db_path),
                timeout=30.0,
                isolation_level=None,
            )
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=30000")
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def _transaction(self, mode: str = "IMMEDIATE") -> Iterator[sqlite3.Connection]:
        if mode not in {"DEFERRED", "IMMEDIATE", "EXCLUSIVE"}:
            raise ValueError(f"Unsupported SQLite transaction mode: {mode}")
        conn = self._get_conn()
        conn.execute(f"BEGIN {mode}")
        try:
            yield conn
            conn.execute("COMMIT")
        except Exception:
            if conn.in_transaction:
                conn.execute("ROLLBACK")
            raise

    def close(self) -> None:
        if hasattr(self._local, "conn"):
            self._local.conn.close()
            del self._local.conn

    def init_db(self) -> None:
        from .migrations import run_migrations

        run_migrations(self._get_conn())

    # Workspaces ---------------------------------------------------------
    def create_workspace(self, path: str, approved: bool = True) -> Workspace:
        if not path:
            raise ValueError("Workspace path must not be empty")
        with self._transaction() as conn:
            row = conn.execute(
                "SELECT id FROM local_workspaces WHERE path=?",
                (path,),
            ).fetchone()
            workspace_id = row["id"] if row else f"ws_{uuid.uuid4().hex}"
            if row:
                conn.execute(
                    "UPDATE local_workspaces SET approved=? WHERE path=?",
                    (1 if approved else 0, path),
                )
            else:
                conn.execute(
                    "INSERT INTO local_workspaces (id, path, approved) VALUES (?, ?, ?)",
                    (workspace_id, path, 1 if approved else 0),
                )
        return Workspace(path=path, approved=approved, id=workspace_id)

    def get_workspace_by_path(self, path: str) -> Optional[Workspace]:
        row = self._get_conn().execute(
            "SELECT id, path, approved FROM local_workspaces WHERE path=?",
            (path,),
        ).fetchone()
        return _row_to_workspace(row) if row else None

    def list_workspaces(self, approved_only: bool = False) -> list[Workspace]:
        sql = "SELECT id, path, approved FROM local_workspaces"
        params: tuple[Any, ...] = ()
        if approved_only:
            sql += " WHERE approved=1"
        sql += " ORDER BY path"
        return [
            _row_to_workspace(row)
            for row in self._get_conn().execute(sql, params).fetchall()
        ]

    def revoke_workspace(self, path: str) -> bool:
        with self._transaction() as conn:
            result = conn.execute(
                "UPDATE local_workspaces SET approved=0 WHERE path=? AND approved<>0",
                (path,),
            )
        return result.rowcount > 0

    def _require_approved_workspace(
        self,
        conn: sqlite3.Connection,
        path: str,
    ) -> sqlite3.Row:
        row = conn.execute(
            "SELECT id, path, approved FROM local_workspaces WHERE path=?",
            (path,),
        ).fetchone()
        if row is None:
            raise ValueError(f"Workspace is not registered: {path}")
        if not bool(row["approved"]):
            raise PermissionError(f"Workspace approval is revoked: {path}")
        return row

    # Threads ------------------------------------------------------------
    def create_thread(
        self,
        megas_thread_id: str,
        native_thread_id: Optional[str],
        worker_id: str,
        provider_id: str,
        workspace_path: str,
        cloud_thread_id: Optional[str] = None,
    ) -> Thread:
        if not megas_thread_id or not worker_id or not provider_id:
            raise ValueError("Thread, Worker, and provider identities are required")
        with self._transaction() as conn:
            self._require_approved_workspace(conn, workspace_path)
            conn.execute(
                """
                INSERT INTO local_threads (
                    megas_thread_id,
                    native_thread_id,
                    worker_id,
                    provider_id,
                    workspace_path,
                    cloud_thread_id
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    megas_thread_id,
                    native_thread_id,
                    worker_id,
                    provider_id,
                    workspace_path,
                    cloud_thread_id,
                ),
            )
        return Thread(
            megas_thread_id=megas_thread_id,
            native_thread_id=native_thread_id,
            worker_id=worker_id,
            provider_id=provider_id,
            workspace_path=workspace_path,
            cloud_thread_id=cloud_thread_id,
        )

    def bind_native_thread(self, megas_thread_id: str, native_thread_id: str) -> None:
        if not native_thread_id:
            raise ValueError("Native thread identity must not be empty")
        with self._transaction("EXCLUSIVE") as conn:
            row = conn.execute(
                "SELECT native_thread_id FROM local_threads WHERE megas_thread_id=?",
                (megas_thread_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Thread {megas_thread_id} not found")
            existing = row["native_thread_id"]
            if existing is not None:
                if existing == native_thread_id:
                    return
                raise ValueError(
                    f"Thread {megas_thread_id} is already bound to a different native thread"
                )
            conn.execute(
                "UPDATE local_threads SET native_thread_id=? WHERE megas_thread_id=?",
                (native_thread_id, megas_thread_id),
            )
            conn.execute(
                """
                UPDATE local_events
                SET native_thread_id=?
                WHERE megas_thread_id=? AND native_thread_id IS NULL
                """,
                (native_thread_id, megas_thread_id),
            )

    def bind_cloud_thread(self, megas_thread_id: str, cloud_thread_id: str) -> None:
        if not cloud_thread_id:
            raise ValueError("Cloud thread identity must not be empty")
        with self._transaction() as conn:
            row = conn.execute(
                "SELECT cloud_thread_id FROM local_threads WHERE megas_thread_id=?",
                (megas_thread_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Thread {megas_thread_id} not found")
            existing = row["cloud_thread_id"]
            if existing is not None:
                if existing == cloud_thread_id:
                    return
                raise ValueError(
                    f"Thread {megas_thread_id} is already linked to another cloud thread"
                )
            conn.execute(
                "UPDATE local_threads SET cloud_thread_id=? WHERE megas_thread_id=?",
                (cloud_thread_id, megas_thread_id),
            )

    # Compatibility name used by the A24 branch.
    update_thread_cloud_link = bind_cloud_thread

    def get_thread(self, worker_id: str, megas_thread_id: str) -> Optional[Thread]:
        row = self._get_conn().execute(
            """
            SELECT
                megas_thread_id,
                native_thread_id,
                worker_id,
                provider_id,
                workspace_path,
                cloud_thread_id
            FROM local_threads
            WHERE worker_id=? AND megas_thread_id=?
            """,
            (worker_id, megas_thread_id),
        ).fetchone()
        return _row_to_thread(row) if row else None

    def get_thread_by_id(self, megas_thread_id: str) -> Optional[Thread]:
        row = self._get_conn().execute(
            """
            SELECT
                megas_thread_id,
                native_thread_id,
                worker_id,
                provider_id,
                workspace_path,
                cloud_thread_id
            FROM local_threads
            WHERE megas_thread_id=?
            """,
            (megas_thread_id,),
        ).fetchone()
        return _row_to_thread(row) if row else None

    def list_threads(self, worker_id: Optional[str] = None) -> list[Thread]:
        sql = """
            SELECT
                megas_thread_id,
                native_thread_id,
                worker_id,
                provider_id,
                workspace_path,
                cloud_thread_id
            FROM local_threads
        """
        params: tuple[Any, ...] = ()
        if worker_id is not None:
            sql += " WHERE worker_id=?"
            params = (worker_id,)
        sql += " ORDER BY megas_thread_id"
        return [
            _row_to_thread(row)
            for row in self._get_conn().execute(sql, params).fetchall()
        ]

    # Sessions -----------------------------------------------------------
    def create_session(
        self,
        live_session_id: str,
        megas_thread_id: str,
        pid: Optional[int] = None,
        process_create_time: Optional[float] = None,
    ) -> Session:
        now = _utc_now()
        try:
            with self._transaction() as conn:
                thread_row = conn.execute(
                    "SELECT workspace_path FROM local_threads WHERE megas_thread_id=?",
                    (megas_thread_id,),
                ).fetchone()
                if thread_row is None:
                    raise ValueError(f"Thread {megas_thread_id} not found")
                self._require_approved_workspace(conn, thread_row["workspace_path"])
                conn.execute(
                    """
                    INSERT INTO local_sessions (
                        live_session_id,
                        megas_thread_id,
                        status,
                        pid,
                        process_create_time,
                        created_at,
                        updated_at,
                        reason
                    ) VALUES (?, ?, 'accepted', ?, ?, ?, ?, NULL)
                    """,
                    (
                        live_session_id,
                        megas_thread_id,
                        pid,
                        process_create_time,
                        now,
                        now,
                    ),
                )
        except sqlite3.IntegrityError as exc:
            message = str(exc)
            if (
                "local_sessions_one_active_turn" in message
                or "local_sessions.megas_thread_id" in message
            ):
                raise ValueError(
                    f"Active turn already exists for thread {megas_thread_id}"
                ) from exc
            raise
        return Session(
            live_session_id=live_session_id,
            megas_thread_id=megas_thread_id,
            status="accepted",
            pid=pid,
            process_create_time=process_create_time,
            created_at=now,
            updated_at=now,
        )

    def mark_session_started(
        self,
        live_session_id: str,
        pid: Optional[int],
        process_create_time: Optional[float],
    ) -> Session:
        now = _utc_now()
        with self._transaction() as conn:
            row = conn.execute(
                "SELECT * FROM local_sessions WHERE live_session_id=?",
                (live_session_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Session {live_session_id} not found")
            if row["status"] == "accepted":
                conn.execute(
                    """
                    UPDATE local_sessions
                    SET status='running', pid=?, process_create_time=?, updated_at=?
                    WHERE live_session_id=?
                    """,
                    (pid, process_create_time, now, live_session_id),
                )
            elif row["status"] != "running":
                raise ValueError(
                    f"Cannot mark session {live_session_id} started from {row['status']}"
                )
        session = self.get_session(live_session_id)
        assert session is not None
        return session

    def update_session_status(
        self,
        live_session_id: str,
        status: str,
        reason: Optional[str] = None,
    ) -> Session:
        now = _utc_now()
        with self._transaction() as conn:
            row = conn.execute(
                "SELECT * FROM local_sessions WHERE live_session_id=?",
                (live_session_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Session {live_session_id} not found")

            current_status = row["status"]
            current_reason = row["reason"]
            if current_status in _TERMINAL_SESSION_STATES:
                if status == current_status and (
                    reason is None or reason == current_reason
                ):
                    return _row_to_session(row)
                raise ValueError(
                    f"Cannot transition terminal session {live_session_id} "
                    f"from {current_status} to {status}"
                )

            if status not in _ALLOWED_SESSION_TRANSITIONS.get(
                current_status,
                frozenset(),
            ):
                raise ValueError(
                    f"Invalid transition for session {live_session_id} "
                    f"from {current_status} to {status}"
                )

            conn.execute(
                """
                UPDATE local_sessions
                SET status=?, updated_at=?, reason=?
                WHERE live_session_id=?
                """,
                (status, now, reason, live_session_id),
            )
            updated = conn.execute(
                "SELECT * FROM local_sessions WHERE live_session_id=?",
                (live_session_id,),
            ).fetchone()
            assert updated is not None
            return _row_to_session(updated)

    def get_session(self, live_session_id: str) -> Optional[Session]:
        row = self._get_conn().execute(
            "SELECT * FROM local_sessions WHERE live_session_id=?",
            (live_session_id,),
        ).fetchone()
        return _row_to_session(row) if row else None

    def get_active_session_for_thread(
        self,
        megas_thread_id: str,
    ) -> Optional[Session]:
        row = self._get_conn().execute(
            """
            SELECT *
            FROM local_sessions
            WHERE megas_thread_id=?
              AND status NOT IN ('completed', 'failed', 'cancelled', 'interrupted')
            """,
            (megas_thread_id,),
        ).fetchone()
        return _row_to_session(row) if row else None

    def get_active_sessions(self) -> list[Session]:
        rows = self._get_conn().execute(
            """
            SELECT *
            FROM local_sessions
            WHERE status NOT IN ('completed', 'failed', 'cancelled', 'interrupted')
            ORDER BY created_at, live_session_id
            """
        ).fetchall()
        return [_row_to_session(row) for row in rows]

    def get_session_scope(
        self,
        live_session_id: str,
    ) -> tuple[Session, Thread]:
        row = self._get_conn().execute(
            """
            SELECT
                s.live_session_id,
                s.megas_thread_id,
                s.status,
                s.pid,
                s.process_create_time,
                s.created_at,
                s.updated_at,
                s.reason,
                t.native_thread_id,
                t.worker_id,
                t.provider_id,
                t.workspace_path,
                t.cloud_thread_id
            FROM local_sessions AS s
            JOIN local_threads AS t
              ON t.megas_thread_id = s.megas_thread_id
            WHERE s.live_session_id=?
            """,
            (live_session_id,),
        ).fetchone()
        if row is None:
            raise ValueError(f"Session {live_session_id} not found")
        session = _row_to_session(row)
        thread = Thread(
            megas_thread_id=row["megas_thread_id"],
            native_thread_id=row["native_thread_id"],
            worker_id=row["worker_id"],
            provider_id=row["provider_id"],
            workspace_path=row["workspace_path"],
            cloud_thread_id=row["cloud_thread_id"],
        )
        return session, thread

    # Events -------------------------------------------------------------
    def next_sequence(self, live_session_id: str) -> int:
        row = self._get_conn().execute(
            "SELECT MAX(sequence) AS max_seq FROM local_events WHERE live_session_id=?",
            (live_session_id,),
        ).fetchone()
        return (row["max_seq"] if row and row["max_seq"] is not None else -1) + 1

    def _validate_event_scope(
        self,
        conn: sqlite3.Connection,
        event: LocalEvent,
    ) -> sqlite3.Row:
        scope = conn.execute(
            """
            SELECT
                s.megas_thread_id,
                t.worker_id,
                t.native_thread_id
            FROM local_sessions AS s
            JOIN local_threads AS t
              ON t.megas_thread_id = s.megas_thread_id
            WHERE s.live_session_id=?
            """,
            (event.live_session_id,),
        ).fetchone()
        if scope is None:
            raise ValueError(f"Session {event.live_session_id} not found")
        if scope["megas_thread_id"] != event.megas_thread_id:
            raise ValueError("Event thread identity does not match the durable session")
        if scope["worker_id"] != event.worker_id:
            raise ValueError("Event Worker identity does not match the durable thread")
        durable_native_id = scope["native_thread_id"]
        if durable_native_id is not None and event.native_thread_id != durable_native_id:
            raise ValueError("Event native-thread identity does not match the binding")
        if durable_native_id is None and event.native_thread_id is not None:
            raise ValueError("Bind the native thread before persisting native-scoped events")
        return scope

    def _insert_event(
        self,
        conn: sqlite3.Connection,
        event: LocalEvent,
    ) -> LocalEvent:
        self._validate_event_scope(conn, event)
        existing = conn.execute(
            "SELECT * FROM local_events WHERE event_id=?",
            (event.event_id,),
        ).fetchone()
        if existing is not None:
            existing_event = self._event_from_row(existing)
            candidate = replace(event, sequence=existing_event.sequence)
            if existing_event != candidate:
                raise ValueError(f"Event ID conflict: {event.event_id}")
            return existing_event

        sequence = event.sequence
        if sequence < 0:
            row = conn.execute(
                "SELECT MAX(sequence) AS max_seq FROM local_events WHERE live_session_id=?",
                (event.live_session_id,),
            ).fetchone()
            sequence = (
                row["max_seq"] if row and row["max_seq"] is not None else -1
            ) + 1
        persisted = replace(event, sequence=sequence)
        conn.execute(
            """
            INSERT INTO local_events (
                event_id,
                worker_id,
                megas_thread_id,
                native_thread_id,
                live_session_id,
                sequence,
                event_type,
                created_at,
                payload_json,
                schema_version,
                cloud_event_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                persisted.event_id,
                persisted.worker_id,
                persisted.megas_thread_id,
                persisted.native_thread_id,
                persisted.live_session_id,
                persisted.sequence,
                persisted.event_type,
                persisted.created_at,
                json.dumps(
                    persisted.payload,
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                persisted.schema_version,
                persisted.cloud_event_id,
            ),
        )
        return persisted

    def append_event(self, event: LocalEvent) -> LocalEvent:
        with self._transaction() as conn:
            return self._insert_event(conn, event)

    @staticmethod
    def _event_from_row(row: sqlite3.Row) -> LocalEvent:
        return LocalEvent(
            event_id=row["event_id"],
            worker_id=row["worker_id"],
            megas_thread_id=row["megas_thread_id"],
            native_thread_id=row["native_thread_id"],
            live_session_id=row["live_session_id"],
            sequence=row["sequence"],
            event_type=row["event_type"],
            created_at=row["created_at"],
            payload=json.loads(row["payload_json"]),
            schema_version=row["schema_version"],
            cloud_event_id=row["cloud_event_id"],
        )

    def replay_events(
        self,
        live_session_id: str,
        after_seq: int = -1,
        limit: int = 100,
        worker_id: Optional[str] = None,
        megas_thread_id: Optional[str] = None,
    ) -> dict[str, Any]:
        try:
            after_seq = int(after_seq)
            limit = int(limit)
        except (TypeError, ValueError) as exc:
            raise ValueError("after_seq and limit must be integers") from exc
        if after_seq < -1:
            raise ValueError("after_seq must be >= -1")
        if limit < 1 or limit > 500:
            raise ValueError("limit must be between 1 and 500")

        conn = self._get_conn()
        scope = conn.execute(
            """
            SELECT s.megas_thread_id, t.worker_id
            FROM local_sessions AS s
            JOIN local_threads AS t
              ON t.megas_thread_id = s.megas_thread_id
            WHERE s.live_session_id=?
            """,
            (live_session_id,),
        ).fetchone()
        if scope is None:
            raise ValueError(f"Session {live_session_id} not found")
        if worker_id is not None and scope["worker_id"] != worker_id:
            raise PermissionError("Cross-Worker replay access denied")
        if (
            megas_thread_id is not None
            and scope["megas_thread_id"] != megas_thread_id
        ):
            raise PermissionError("Cross-thread replay access denied")

        rows = conn.execute(
            """
            SELECT *
            FROM local_events
            WHERE live_session_id=? AND sequence>?
            ORDER BY sequence ASC
            LIMIT ?
            """,
            (live_session_id, after_seq, limit + 1),
        ).fetchall()
        has_more = len(rows) > limit
        page_rows = rows[:limit]
        expected_sequence = after_seq + 1
        events: list[LocalEvent] = []
        next_cursor = after_seq
        for row in page_rows:
            sequence = row["sequence"]
            if sequence != expected_sequence:
                raise ValueError(
                    f"Sequence gap detected: expected {expected_sequence}, got {sequence}"
                )
            events.append(self._event_from_row(row))
            next_cursor = sequence
            expected_sequence += 1
        return {
            "events": events,
            "requested_cursor": after_seq,
            "next_cursor": next_cursor,
            "has_more": has_more,
            "integrity_status": "ok",
        }

    def reconcile_interrupted_session(
        self,
        live_session_id: str,
        reason_code: str,
        event: LocalEvent,
    ) -> LocalEvent:
        now = _utc_now()
        with self._transaction("EXCLUSIVE") as conn:
            row = conn.execute(
                "SELECT * FROM local_sessions WHERE live_session_id=?",
                (live_session_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Session {live_session_id} not found")
            if row["status"] in _TERMINAL_SESSION_STATES:
                if row["status"] == "interrupted":
                    existing = conn.execute(
                        "SELECT * FROM local_events WHERE event_id=?",
                        (event.event_id,),
                    ).fetchone()
                    if existing is not None:
                        return self._event_from_row(existing)
                raise ValueError(
                    f"Cannot reconcile terminal session {live_session_id} "
                    f"from {row['status']}"
                )
            persisted = self._insert_event(conn, event)
            conn.execute(
                """
                UPDATE local_sessions
                SET status='interrupted', updated_at=?, reason=?
                WHERE live_session_id=?
                """,
                (now, reason_code, live_session_id),
            )
            return persisted

    # Idempotency --------------------------------------------------------
    def check_idempotency(self, scope: str, idempotency_key: str) -> Optional[str]:
        row = self._get_conn().execute(
            """
            SELECT result_json
            FROM local_idempotency
            WHERE scope=? AND idempotency_key=?
            """,
            (scope, idempotency_key),
        ).fetchone()
        return row["result_json"] if row else None

    def register_idempotency(
        self,
        scope: str,
        idempotency_key: str,
        result_json: str,
    ) -> None:
        try:
            with self._transaction() as conn:
                conn.execute(
                    """
                    INSERT INTO local_idempotency (
                        scope,
                        idempotency_key,
                        result_json,
                        status,
                        created_at
                    ) VALUES (?, ?, ?, 'completed', ?)
                    """,
                    (scope, idempotency_key, result_json, _utc_now()),
                )
        except sqlite3.IntegrityError as exc:
            raise ValueError(
                f"Duplicate idempotency key {idempotency_key} in scope {scope}"
            ) from exc

    def submit_or_replay(
        self,
        scope: str,
        idempotency_key: str,
        request_digest: str,
        new_live_session_id: str,
        megas_thread_id: str,
        expires_at: Optional[str] = None,
    ) -> tuple[str, Session]:
        now = _utc_now()
        try:
            with self._transaction("EXCLUSIVE") as conn:
                existing = conn.execute(
                    """
                    SELECT request_digest, live_session_id
                    FROM local_idempotency
                    WHERE scope=? AND idempotency_key=?
                    """,
                    (scope, idempotency_key),
                ).fetchone()
                if existing is not None:
                    if existing["request_digest"] != request_digest:
                        raise ValueError("Idempotency key payload conflict")
                    session_id = existing["live_session_id"]
                    session_row = conn.execute(
                        """
                        SELECT * FROM local_sessions
                        WHERE live_session_id=? AND megas_thread_id=?
                        """,
                        (session_id, megas_thread_id),
                    ).fetchone()
                    if session_row is None:
                        raise sqlite3.IntegrityError(
                            "Idempotency claim points to a missing or cross-thread session"
                        )
                    return "replayed", _row_to_session(session_row)

                thread_row = conn.execute(
                    "SELECT workspace_path FROM local_threads WHERE megas_thread_id=?",
                    (megas_thread_id,),
                ).fetchone()
                if thread_row is None:
                    raise ValueError(f"Thread {megas_thread_id} not found")
                self._require_approved_workspace(conn, thread_row["workspace_path"])
                conn.execute(
                    """
                    INSERT INTO local_sessions (
                        live_session_id,
                        megas_thread_id,
                        status,
                        pid,
                        process_create_time,
                        created_at,
                        updated_at,
                        reason
                    ) VALUES (?, ?, 'accepted', NULL, NULL, ?, ?, NULL)
                    """,
                    (new_live_session_id, megas_thread_id, now, now),
                )
                conn.execute(
                    """
                    INSERT INTO local_idempotency (
                        scope,
                        idempotency_key,
                        result_json,
                        request_digest,
                        live_session_id,
                        status,
                        created_at,
                        expires_at
                    ) VALUES (?, ?, '{}', ?, ?, 'accepted', ?, ?)
                    """,
                    (
                        scope,
                        idempotency_key,
                        request_digest,
                        new_live_session_id,
                        now,
                        expires_at,
                    ),
                )
                session_row = conn.execute(
                    "SELECT * FROM local_sessions WHERE live_session_id=?",
                    (new_live_session_id,),
                ).fetchone()
                assert session_row is not None
                return "created", _row_to_session(session_row)
        except sqlite3.IntegrityError as exc:
            message = str(exc)
            if (
                "local_sessions_one_active_turn" in message
                or "local_sessions.megas_thread_id" in message
            ):
                raise ValueError(
                    f"Active turn already exists for thread {megas_thread_id}"
                ) from exc
            raise

    def complete_idempotency(
        self,
        scope: str,
        idempotency_key: str,
        result_json: str,
        status: str,
    ) -> None:
        with self._transaction() as conn:
            result = conn.execute(
                """
                UPDATE local_idempotency
                SET result_json=?, status=?
                WHERE scope=? AND idempotency_key=?
                """,
                (result_json, status, scope, idempotency_key),
            )
            if result.rowcount != 1:
                raise ValueError("Idempotency claim not found")

    def cleanup_idempotency_keys(self, before_iso: str) -> int:
        with self._transaction() as conn:
            result = conn.execute(
                """
                DELETE FROM local_idempotency
                WHERE expires_at IS NOT NULL AND expires_at < ?
                """,
                (before_iso,),
            )
        return result.rowcount

    # Devices ------------------------------------------------------------
    def register_device_revocation_observer(
        self,
        observer: DeviceRevocationObserver,
    ) -> None:
        if observer not in self._device_revocation_observers:
            self._device_revocation_observers.append(observer)

    def register_device(
        self,
        device_id: str,
        name: str,
        device_type: str,
        scopes: str,
        credential_id: Optional[str] = None,
        secret_hash: Optional[str] = None,
    ) -> Device:
        now = _utc_now()
        with self._transaction() as conn:
            conn.execute(
                """
                INSERT INTO local_devices (
                    id,
                    name,
                    type,
                    credential_id,
                    secret_hash,
                    scopes,
                    created_at,
                    last_used_at,
                    status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')
                """,
                (
                    device_id,
                    name,
                    device_type,
                    credential_id,
                    secret_hash,
                    scopes,
                    now,
                    now,
                ),
            )
        device = self.get_device(device_id)
        assert device is not None
        return device

    def get_device(self, device_id: str) -> Optional[Device]:
        row = self._get_conn().execute(
            """
            SELECT
                id,
                name,
                type,
                credential_id,
                scopes,
                created_at,
                last_used_at,
                rotated_at,
                revoked_at,
                status
            FROM local_devices
            WHERE id=?
            """,
            (device_id,),
        ).fetchone()
        return _row_to_device(row) if row else None

    def list_devices(self) -> list[Device]:
        rows = self._get_conn().execute(
            """
            SELECT
                id,
                name,
                type,
                credential_id,
                scopes,
                created_at,
                last_used_at,
                rotated_at,
                revoked_at,
                status
            FROM local_devices
            ORDER BY created_at DESC, id
            """
        ).fetchall()
        return [_row_to_device(row) for row in rows]

    def revoke_device(
        self,
        device_id: str,
        actor_device_id: str,
        reason: str,
    ) -> bool:
        now = _utc_now()
        with self._transaction() as conn:
            target = conn.execute(
                "SELECT id, status, scopes FROM local_devices WHERE id=?",
                (device_id,),
            ).fetchone()
            if target is None:
                raise ValueError(f"Device {device_id} not found")
            if target["status"] == "revoked":
                return False

            try:
                target_scopes = set(json.loads(target["scopes"] or "[]"))
            except (TypeError, json.JSONDecodeError):
                target_scopes = set()
            if "owner-management" in target_scopes:
                active_rows = conn.execute(
                    """
                    SELECT id, scopes
                    FROM local_devices
                    WHERE status='active' AND id<>?
                    """,
                    (device_id,),
                ).fetchall()
                other_owner_exists = False
                for row in active_rows:
                    try:
                        scopes = set(json.loads(row["scopes"] or "[]"))
                    except (TypeError, json.JSONDecodeError):
                        scopes = set()
                    if "owner-management" in scopes:
                        other_owner_exists = True
                        break
                if not other_owner_exists:
                    raise ValueError(
                        "Cannot revoke the last active owner-management device"
                    )

            conn.execute(
                """
                UPDATE local_devices
                SET status='revoked', revoked_at=?
                WHERE id=?
                """,
                (now, device_id),
            )
            conn.execute(
                """
                INSERT INTO local_device_audits (
                    audit_id,
                    device_id,
                    action,
                    timestamp,
                    actor_device_id,
                    reason
                ) VALUES (?, ?, 'revoke', ?, ?, ?)
                """,
                (
                    f"aud_{uuid.uuid4().hex}",
                    device_id,
                    now,
                    actor_device_id,
                    reason,
                ),
            )

        for observer in tuple(self._device_revocation_observers):
            try:
                observer.on_device_revoked(device_id)
            except Exception:
                # Revocation is already durable. A failed in-memory listener must not
                # roll back or misreport the authoritative result.
                continue
        return True

    def list_device_audits(self, device_id: str) -> list[DeviceAudit]:
        rows = self._get_conn().execute(
            """
            SELECT audit_id, device_id, action, timestamp, actor_device_id, reason
            FROM local_device_audits
            WHERE device_id=?
            ORDER BY timestamp, audit_id
            """,
            (device_id,),
        ).fetchall()
        return [
            DeviceAudit(
                audit_id=row["audit_id"],
                device_id=row["device_id"],
                action=row["action"],
                timestamp=row["timestamp"],
                actor_device_id=row["actor_device_id"],
                reason=row["reason"],
            )
            for row in rows
        ]

    # Worker identity continuity ----------------------------------------
    def rebind_worker_identity(
        self,
        old_worker_id: str,
        new_worker_id: str,
        worker_name: str,
    ) -> dict[str, int]:
        old_worker_id = str(old_worker_id or "").strip()
        new_worker_id = str(new_worker_id or "").strip()
        worker_name = str(worker_name or "Megas Local Worker").strip()
        if not old_worker_id or not new_worker_id:
            raise ValueError("Old and new Worker identities are required")
        if old_worker_id == new_worker_id:
            self.set_setting(
                "local_worker_identity",
                {"worker_id": new_worker_id, "worker_name": worker_name},
            )
            return {}

        with self._transaction("EXCLUSIVE") as conn:
            active = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM local_sessions
                WHERE status NOT IN ('completed', 'failed', 'cancelled', 'interrupted')
                """
            ).fetchone()
            if active and int(active["count"] or 0) > 0:
                raise RuntimeError(
                    "Refusing to rebind Local Worker identity while a turn is active"
                )

            # local_events has an immediate composite FK to local_threads. Defer
            # checks until both sides have moved, then prove integrity explicitly.
            conn.execute("PRAGMA defer_foreign_keys=ON")
            counts: dict[str, int] = {}
            for table in (
                "local_threads",
                "local_events",
                "local_pairing_challenges",
                "local_tickets",
            ):
                result = conn.execute(
                    f"UPDATE {table} SET worker_id=? WHERE worker_id=?",
                    (new_worker_id, old_worker_id),
                )
                counts[table] = int(result.rowcount or 0)

            identity_json = json.dumps(
                {"worker_id": new_worker_id, "worker_name": worker_name},
                sort_keys=True,
                separators=(",", ":"),
            )
            conn.execute(
                """
                INSERT INTO local_settings (key, value_json)
                VALUES ('local_worker_identity', ?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json
                """,
                (identity_json,),
            )
            violations = conn.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise sqlite3.IntegrityError(
                    f"Worker identity rebind violated Local integrity: {violations!r}"
                )
            return counts

    # Settings -----------------------------------------------------------
    def get_setting(self, key: str) -> Optional[Any]:
        row = self._get_conn().execute(
            "SELECT value_json FROM local_settings WHERE key=?",
            (key,),
        ).fetchone()
        return json.loads(row["value_json"]) if row else None

    def set_setting(self, key: str, value: Any) -> None:
        value_json = json.dumps(value, sort_keys=True, separators=(",", ":"))
        with self._transaction() as conn:
            conn.execute(
                """
                INSERT INTO local_settings (key, value_json)
                VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json
                """,
                (key, value_json),
            )

    def delete_setting(self, key: str) -> bool:
        with self._transaction() as conn:
            result = conn.execute(
                "DELETE FROM local_settings WHERE key=?",
                (key,),
            )
        return result.rowcount > 0

    def get_status(self) -> dict[str, Any]:
        conn = self._get_conn()
        try:
            conn.execute("SELECT 1")
            violations = conn.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                return {
                    "status": "error",
                    "error": "foreign_key_check_failed",
                    "violation_count": len(violations),
                }
            return {"status": "ok"}
        except Exception as exc:
            return {"status": "error", "error": type(exc).__name__}
