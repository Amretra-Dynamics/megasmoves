"""Fail-closed Local projection of runtime-certified coding-agent providers."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from megas.runtime_manifest import _agent_inventory

_CERTIFIED_STATES = frozenset({"verified", "certified"})
_CREATE_CAPABILITIES = frozenset({"new_thread", "realtime_stream"})
_RESUME_CAPABILITIES = frozenset(
    {"new_thread", "realtime_stream", "exact_resume", "native_persistence"}
)


def project_local_provider_capabilities(
    reports: Mapping[str, Mapping[str, Any]],
    supported_provider_ids: Iterable[str],
) -> list[dict[str, Any]]:
    """Project only Local-executable providers without upgrading partial evidence."""

    projected: list[dict[str, Any]] = []
    for provider_id in sorted({str(item).strip() for item in supported_provider_ids if str(item).strip()}):
        report = reports.get(provider_id) or {}
        status = str(report.get("status") or "unavailable")
        certification_status = str(
            report.get("certification_status") or "not_verified"
        )
        verified_capabilities = sorted(
            {
                str(item).strip()
                for item in report.get("verified_capabilities") or []
                if str(item).strip()
            }
        )
        verified = set(verified_capabilities)
        is_usable = (
            status == "available"
            and certification_status in _CERTIFIED_STATES
        )
        can_create_thread = is_usable and _CREATE_CAPABILITIES.issubset(verified)
        can_resume_thread = is_usable and _RESUME_CAPABILITIES.issubset(verified)
        projected.append(
            {
                "provider_id": provider_id,
                "status": status,
                "certification_status": certification_status,
                "certification_reason": str(
                    report.get("certification_reason")
                    or report.get("reason")
                    or "runtime_certification_required"
                ),
                "version": report.get("version"),
                "verified_capabilities": verified_capabilities,
                "can_create_thread": can_create_thread,
                "can_resume_thread": can_resume_thread,
            }
        )
    return projected


def build_local_provider_capabilities(
    config: object,
    supported_provider_ids: Iterable[str],
) -> list[dict[str, Any]]:
    reports, _certified_agents = _agent_inventory(config)  # type: ignore[arg-type]
    return project_local_provider_capabilities(reports, supported_provider_ids)
