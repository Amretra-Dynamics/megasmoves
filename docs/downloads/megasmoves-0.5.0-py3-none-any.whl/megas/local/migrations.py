"""Schema migrations for Megas Local SQLite journal."""

from __future__ import annotations

import datetime
import hashlib
import sqlite3
from collections.abc import Sequence


def run_migrations(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS local_schema_migrations (
            version INTEGER PRIMARY KEY,
            checksum TEXT NOT NULL,
            applied_at TEXT NOT NULL
        )
        """
    )
    _apply_v1(conn)
    _apply_v2_nullable_native_thread(conn)
    _apply_v3_session_state(conn)
    _apply_v4_idempotency(conn)
    _apply_v5_workspace_identity(conn)
    _apply_v6_device_credentials_and_revocation(conn)
    _apply_v7_pairing_challenges(conn)
    _apply_v8_websocket_tickets(conn)
    _apply_v9_cloud_continuity(conn)


def _apply_v1(conn: sqlite3.Connection) -> None:
    v1_sql = """
        CREATE TABLE IF NOT EXISTS local_devices (
            id TEXT PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS local_workspaces (
            path TEXT PRIMARY KEY,
            approved INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS local_threads (
            megas_thread_id TEXT PRIMARY KEY,
            native_thread_id TEXT NOT NULL,
            worker_id TEXT NOT NULL,
            provider_id TEXT NOT NULL,
            workspace_path TEXT NOT NULL,
            UNIQUE(worker_id, provider_id, native_thread_id),
            UNIQUE(megas_thread_id, worker_id, native_thread_id)
        );
        CREATE TABLE IF NOT EXISTS local_sessions (
            live_session_id TEXT PRIMARY KEY,
            megas_thread_id TEXT NOT NULL,
            status TEXT NOT NULL,
            pid INTEGER,
            process_create_time REAL,
            UNIQUE(live_session_id, megas_thread_id),
            FOREIGN KEY (megas_thread_id) REFERENCES local_threads(megas_thread_id) ON DELETE RESTRICT
        );
        CREATE TABLE IF NOT EXISTS local_events (
            event_id TEXT PRIMARY KEY,
            worker_id TEXT NOT NULL,
            megas_thread_id TEXT NOT NULL,
            native_thread_id TEXT NOT NULL,
            live_session_id TEXT NOT NULL,
            sequence INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            created_at TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            schema_version INTEGER NOT NULL,
            UNIQUE(live_session_id, sequence),
            FOREIGN KEY (live_session_id, megas_thread_id) REFERENCES local_sessions(live_session_id, megas_thread_id) ON DELETE RESTRICT,
            FOREIGN KEY (megas_thread_id, worker_id, native_thread_id) REFERENCES local_threads(megas_thread_id, worker_id, native_thread_id) ON DELETE RESTRICT
        );
        CREATE TABLE IF NOT EXISTS local_idempotency (
            scope TEXT NOT NULL,
            idempotency_key TEXT NOT NULL,
            result_json TEXT NOT NULL,
            PRIMARY KEY (scope, idempotency_key)
        );
        CREATE TABLE IF NOT EXISTS local_settings (
            key TEXT PRIMARY KEY,
            value_json TEXT NOT NULL
        );
    """
    checksum = hashlib.sha256(v1_sql.encode("utf-8")).hexdigest()

    row = conn.execute(
        "SELECT checksum FROM local_schema_migrations WHERE version=1"
    ).fetchone()
    if row:
        if row["checksum"] != checksum:
            raise ValueError(
                f"Migration checksum mismatch for v1. Expected {checksum}, got {row['checksum']}"
            )
        return

    conn.executescript(v1_sql)
    conn.execute(
        "INSERT INTO local_schema_migrations (version, checksum, applied_at) VALUES (?, ?, ?)",
        (1, checksum, datetime.datetime.now(datetime.timezone.utc).isoformat()),
    )


def _canonical_sql(statements: Sequence[str]) -> str:
    return "\n".join(f"{statement.strip()};" for statement in statements)


def _assert_existing_checksum(
    conn: sqlite3.Connection,
    version: int,
    checksum: str,
) -> bool:
    row = conn.execute(
        "SELECT checksum FROM local_schema_migrations WHERE version=?",
        (version,),
    ).fetchone()
    if row is None:
        return False
    if row["checksum"] != checksum:
        raise ValueError(
            f"Migration checksum mismatch for v{version}. "
            f"Expected {checksum}, got {row['checksum']}"
        )
    return True


def _apply_statements(
    conn: sqlite3.Connection,
    version: int,
    statements: Sequence[str],
) -> None:
    checksum = hashlib.sha256(_canonical_sql(statements).encode("utf-8")).hexdigest()
    if _assert_existing_checksum(conn, version, checksum):
        return

    conn.execute("BEGIN IMMEDIATE")
    try:
        if _assert_existing_checksum(conn, version, checksum):
            conn.execute("COMMIT")
            return
        for statement in statements:
            conn.execute(statement)
        conn.execute(
            "INSERT INTO local_schema_migrations (version, checksum, applied_at) "
            "VALUES (?, ?, ?)",
            (
                version,
                checksum,
                datetime.datetime.now(datetime.timezone.utc).isoformat(),
            ),
        )
        conn.execute("COMMIT")
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise


def _apply_v2_nullable_native_thread(conn: sqlite3.Connection) -> None:
    statements = (
        """
        CREATE TABLE local_threads_v2 (
            megas_thread_id TEXT PRIMARY KEY,
            native_thread_id TEXT,
            worker_id TEXT NOT NULL,
            provider_id TEXT NOT NULL,
            workspace_path TEXT NOT NULL,
            UNIQUE(worker_id, provider_id, native_thread_id),
            UNIQUE(megas_thread_id, worker_id, native_thread_id)
        )
        """,
        """
        INSERT INTO local_threads_v2 (
            megas_thread_id,
            native_thread_id,
            worker_id,
            provider_id,
            workspace_path
        )
        SELECT
            megas_thread_id,
            native_thread_id,
            worker_id,
            provider_id,
            workspace_path
        FROM local_threads
        """,
        "DROP TABLE local_threads",
        "ALTER TABLE local_threads_v2 RENAME TO local_threads",
        """
        CREATE TABLE local_events_v2 (
            event_id TEXT PRIMARY KEY,
            worker_id TEXT NOT NULL,
            megas_thread_id TEXT NOT NULL,
            native_thread_id TEXT,
            live_session_id TEXT NOT NULL,
            sequence INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            created_at TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            schema_version INTEGER NOT NULL,
            UNIQUE(live_session_id, sequence),
            FOREIGN KEY (live_session_id, megas_thread_id)
                REFERENCES local_sessions(live_session_id, megas_thread_id)
                ON DELETE RESTRICT,
            FOREIGN KEY (megas_thread_id, worker_id, native_thread_id)
                REFERENCES local_threads(megas_thread_id, worker_id, native_thread_id)
                ON DELETE RESTRICT
        )
        """,
        """
        INSERT INTO local_events_v2 (
            event_id,
            worker_id,
            megas_thread_id,
            native_thread_id,
            live_session_id,
            sequence,
            event_type,
            created_at,
            payload_json,
            schema_version
        )
        SELECT
            event_id,
            worker_id,
            megas_thread_id,
            native_thread_id,
            live_session_id,
            sequence,
            event_type,
            created_at,
            payload_json,
            schema_version
        FROM local_events
        """,
        "DROP TABLE local_events",
        "ALTER TABLE local_events_v2 RENAME TO local_events",
    )
    version = 2
    checksum = hashlib.sha256(_canonical_sql(statements).encode("utf-8")).hexdigest()
    if _assert_existing_checksum(conn, version, checksum):
        return

    foreign_keys_enabled = bool(conn.execute("PRAGMA foreign_keys").fetchone()[0])
    if foreign_keys_enabled:
        conn.execute("PRAGMA foreign_keys=OFF")
    try:
        conn.execute("BEGIN IMMEDIATE")
        if _assert_existing_checksum(conn, version, checksum):
            conn.execute("COMMIT")
            return
        for statement in statements:
            conn.execute(statement)
        violations = conn.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise sqlite3.IntegrityError(
                f"Foreign-key violations after migration v{version}: {violations!r}"
            )
        conn.execute(
            "INSERT INTO local_schema_migrations (version, checksum, applied_at) "
            "VALUES (?, ?, ?)",
            (
                version,
                checksum,
                datetime.datetime.now(datetime.timezone.utc).isoformat(),
            ),
        )
        conn.execute("COMMIT")
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    finally:
        if foreign_keys_enabled:
            conn.execute("PRAGMA foreign_keys=ON")


def _apply_v3_session_state(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        3,
        (
            "ALTER TABLE local_sessions ADD COLUMN created_at TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE local_sessions ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE local_sessions ADD COLUMN reason TEXT",
            """
            UPDATE local_sessions
            SET created_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
            WHERE created_at = ''
            """,
            """
            UPDATE local_sessions
            SET updated_at = created_at
            WHERE updated_at = ''
            """,
            """
            CREATE UNIQUE INDEX local_sessions_one_active_turn
            ON local_sessions (megas_thread_id)
            WHERE status NOT IN ('completed', 'failed', 'cancelled', 'interrupted')
            """,
        ),
    )


def _apply_v4_idempotency(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        4,
        (
            "ALTER TABLE local_idempotency ADD COLUMN request_digest TEXT",
            "ALTER TABLE local_idempotency ADD COLUMN live_session_id TEXT",
            "ALTER TABLE local_idempotency ADD COLUMN status TEXT",
            "ALTER TABLE local_idempotency ADD COLUMN created_at TEXT",
            "ALTER TABLE local_idempotency ADD COLUMN expires_at TEXT",
            """
            UPDATE local_idempotency
            SET status = COALESCE(status, 'completed'),
                created_at = COALESCE(
                    created_at,
                    strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                )
            """,
            """
            CREATE INDEX idx_local_idempotency_expiry
            ON local_idempotency (expires_at)
            WHERE expires_at IS NOT NULL
            """,
        ),
    )


def _apply_v5_workspace_identity(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        5,
        (
            """
            CREATE TABLE local_workspaces_v5 (
                id TEXT PRIMARY KEY,
                path TEXT UNIQUE NOT NULL,
                approved INTEGER NOT NULL DEFAULT 0
            )
            """,
            """
            INSERT INTO local_workspaces_v5 (id, path, approved)
            SELECT
                'ws_' || lower(hex(randomblob(16))),
                path,
                approved
            FROM local_workspaces
            """,
            "DROP TABLE local_workspaces",
            "ALTER TABLE local_workspaces_v5 RENAME TO local_workspaces",
        ),
    )


def _apply_v6_device_credentials_and_revocation(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        6,
        (
            "ALTER TABLE local_devices ADD COLUMN name TEXT NOT NULL DEFAULT 'Unknown Device'",
            "ALTER TABLE local_devices ADD COLUMN type TEXT NOT NULL DEFAULT 'unknown'",
            "ALTER TABLE local_devices ADD COLUMN credential_id TEXT",
            "ALTER TABLE local_devices ADD COLUMN secret_hash TEXT",
            "ALTER TABLE local_devices ADD COLUMN scopes TEXT NOT NULL DEFAULT '[]'",
            "ALTER TABLE local_devices ADD COLUMN created_at TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE local_devices ADD COLUMN last_used_at TEXT",
            "ALTER TABLE local_devices ADD COLUMN rotated_at TEXT",
            "ALTER TABLE local_devices ADD COLUMN revoked_at TEXT",
            "ALTER TABLE local_devices ADD COLUMN status TEXT NOT NULL DEFAULT 'active'",
            """
            UPDATE local_devices
            SET created_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
            WHERE created_at = ''
            """,
            """
            CREATE UNIQUE INDEX idx_local_devices_credential_id
            ON local_devices (credential_id)
            WHERE credential_id IS NOT NULL
            """,
            """
            CREATE INDEX idx_local_devices_status
            ON local_devices (status)
            """,
            """
            CREATE TABLE local_device_audits (
                audit_id TEXT PRIMARY KEY,
                device_id TEXT NOT NULL,
                action TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                actor_device_id TEXT NOT NULL,
                reason TEXT NOT NULL,
                FOREIGN KEY (device_id)
                    REFERENCES local_devices(id)
                    ON DELETE RESTRICT
            )
            """,
            """
            CREATE INDEX idx_local_device_audits_device_time
            ON local_device_audits (device_id, timestamp)
            """,
        ),
    )


def _apply_v7_pairing_challenges(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        7,
        (
            """
            CREATE TABLE local_pairing_challenges (
                challenge_id TEXT PRIMARY KEY,
                worker_id TEXT NOT NULL,
                verifier_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                created_at REAL NOT NULL,
                expires_at REAL NOT NULL,
                consumed_at REAL,
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                context_json TEXT NOT NULL
            )
            """,
            """
            CREATE INDEX idx_pairing_challenges_expires
            ON local_pairing_challenges (expires_at)
            """,
            """
            CREATE INDEX idx_pairing_challenges_worker
            ON local_pairing_challenges (worker_id)
            """,
        ),
    )


def _apply_v8_websocket_tickets(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        8,
        (
            """
            CREATE TABLE local_tickets (
                ticket_hash TEXT PRIMARY KEY,
                worker_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                megas_thread_id TEXT NOT NULL,
                live_session_id TEXT NOT NULL,
                origin TEXT NOT NULL,
                protocol TEXT NOT NULL,
                action TEXT NOT NULL,
                expires_at REAL NOT NULL,
                status TEXT NOT NULL,
                FOREIGN KEY (device_id)
                    REFERENCES local_devices(id)
                    ON DELETE RESTRICT,
                FOREIGN KEY (megas_thread_id)
                    REFERENCES local_threads(megas_thread_id)
                    ON DELETE RESTRICT,
                FOREIGN KEY (live_session_id, megas_thread_id)
                    REFERENCES local_sessions(live_session_id, megas_thread_id)
                    ON DELETE RESTRICT
            )
            """,
            """
            CREATE INDEX idx_local_tickets_device_status
            ON local_tickets (device_id, status)
            """,
            """
            CREATE INDEX idx_local_tickets_expiry
            ON local_tickets (expires_at)
            """,
        ),
    )


def _apply_v9_cloud_continuity(conn: sqlite3.Connection) -> None:
    _apply_statements(
        conn,
        9,
        (
            "ALTER TABLE local_threads ADD COLUMN cloud_thread_id TEXT",
            "ALTER TABLE local_events ADD COLUMN cloud_event_id TEXT",
            """
            CREATE UNIQUE INDEX idx_local_threads_cloud_thread_id
            ON local_threads (cloud_thread_id)
            WHERE cloud_thread_id IS NOT NULL
            """,
            """
            CREATE UNIQUE INDEX idx_local_events_cloud_event_id
            ON local_events (cloud_event_id)
            WHERE cloud_event_id IS NOT NULL
            """,
        ),
    )
