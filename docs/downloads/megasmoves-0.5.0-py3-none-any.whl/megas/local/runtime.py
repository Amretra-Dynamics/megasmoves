"""Composition root for the Megas Local runtime."""

from __future__ import annotations

import asyncio
import concurrent.futures
import hashlib
import platform
import threading
import uuid
from dataclasses import dataclass
from typing import Any, Coroutine, Optional

from megas.config import load_config, resolve_machine_label
from megas.operate.gate import operate_status

from .auth import verify_device_credential
from .broker import LocalEventBroker
from .cancellation import CancellationCoordinator, ProcessRegistry
from .execution_service import LocalExecutionService
from .pairing import PairingChallengeStore
from .provider_capabilities import build_local_provider_capabilities
from .security import LocalSecurityPolicy
from .store import LocalStore
from .tailscale import TailscaleServeService, TailscaleStatus
from .tickets import TicketService
from .workspace import WorkspaceService
from .ws_registry import LocalConnectionRegistry
from .ws_stream import LocalWebSocketServer, WS_PROTOCOL


class AsyncRuntimeLoop:
    def __init__(self) -> None:
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._run,
            name="megas-local-async-runtime",
            daemon=True,
        )
        self._started = threading.Event()
        self._closed = False
        self._thread.start()
        if not self._started.wait(timeout=5.0):
            raise RuntimeError("Local async runtime failed to start")

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._started.set()
        self._loop.run_forever()
        pending = asyncio.all_tasks(self._loop)
        for task in pending:
            task.cancel()
        if pending:
            self._loop.run_until_complete(
                asyncio.gather(*pending, return_exceptions=True)
            )
        self._loop.close()

    def submit(
        self,
        coroutine: Coroutine[Any, Any, Any],
    ) -> concurrent.futures.Future[Any]:
        if self._closed:
            coroutine.close()
            raise RuntimeError("Local async runtime is closed")
        return asyncio.run_coroutine_threadsafe(coroutine, self._loop)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5.0)
        if self._thread.is_alive():
            raise RuntimeError("Local async runtime did not stop cleanly")


def resolve_local_worker_identity(store: LocalStore) -> tuple[str, str]:
    config = load_config()
    configured_worker_id = str(config.worker_id or "").strip()
    configured_name = resolve_machine_label(config.machine_name or config.worker_name)

    existing = store.get_setting("local_worker_identity")
    if isinstance(existing, dict):
        worker_id = str(existing.get("worker_id") or "").strip()
        worker_name = str(existing.get("worker_name") or configured_name).strip()
        if worker_id:
            if configured_worker_id and worker_id != configured_worker_id:
                # Auth-first is now the normal path. This migration is for older
                # installs that created Local state before cloud authorization.
                store.rebind_worker_identity(
                    worker_id,
                    configured_worker_id,
                    configured_name or worker_name,
                )
                return configured_worker_id, configured_name or worker_name
            return worker_id, worker_name or configured_name

    worker_name = configured_name
    if configured_worker_id:
        worker_id = configured_worker_id
    else:
        machine_id = str(config.machine_id or uuid.uuid4().hex)
        digest = hashlib.sha256(machine_id.encode("utf-8")).hexdigest()[:24]
        worker_id = f"wrk_local_{digest}"
    store.set_setting(
        "local_worker_identity",
        {"worker_id": worker_id, "worker_name": worker_name},
    )
    return worker_id, worker_name


@dataclass
class LocalRuntimeServices:
    store: LocalStore
    worker_id: str
    worker_name: str
    security_policy: LocalSecurityPolicy
    pairing: PairingChallengeStore
    broker: LocalEventBroker
    process_registry: ProcessRegistry
    execution: LocalExecutionService
    cancellation: CancellationCoordinator
    tickets: TicketService
    workspace: WorkspaceService
    tailscale_status: TailscaleStatus
    tailscale_serve: TailscaleServeService
    async_loop: AsyncRuntimeLoop
    connection_registry: LocalConnectionRegistry
    websocket_server: LocalWebSocketServer
    websocket_port: Optional[int] = None

    @classmethod
    def build(cls, store: LocalStore) -> "LocalRuntimeServices":
        worker_id, worker_name = resolve_local_worker_identity(store)
        security_policy = LocalSecurityPolicy()
        configured_origins = store.get_setting("allowed_origins")
        if isinstance(configured_origins, list):
            for origin in configured_origins:
                if isinstance(origin, str):
                    try:
                        security_policy.register_origin(origin)
                    except ValueError:
                        continue
        existing_serve = store.get_setting("tailscale_serve_state")
        if isinstance(existing_serve, dict) and isinstance(
            existing_serve.get("hostname"),
            str,
        ):
            try:
                security_policy.register_tailscale_host(
                    existing_serve["hostname"]
                )
            except ValueError:
                pass

        broker = LocalEventBroker(store)
        process_registry = ProcessRegistry(store)
        execution = LocalExecutionService(store, broker, process_registry)
        async_loop = AsyncRuntimeLoop()
        tickets = TicketService(store)
        connection_registry = LocalConnectionRegistry(async_loop.submit)
        store.register_device_revocation_observer(connection_registry)
        websocket_server = LocalWebSocketServer(
            store=store,
            broker=broker,
            tickets=tickets,
            security_policy=security_policy,
            registry=connection_registry,
        )
        return cls(
            store=store,
            worker_id=worker_id,
            worker_name=worker_name,
            security_policy=security_policy,
            pairing=PairingChallengeStore(store),
            broker=broker,
            process_registry=process_registry,
            execution=execution,
            cancellation=CancellationCoordinator(store, process_registry, broker),
            tickets=tickets,
            workspace=WorkspaceService(store),
            tailscale_status=TailscaleStatus(),
            tailscale_serve=TailscaleServeService(store, security_policy),
            async_loop=async_loop,
            connection_registry=connection_registry,
            websocket_server=websocket_server,
        )

    def start_websocket(self, port: int = 0) -> int:
        if self.websocket_port is not None:
            return self.websocket_port
        import os
        host = os.environ.get("MEGAS_LOCAL_HOST", "127.0.0.1")
        if host == "0.0.0.0":
            host = "127.0.0.1"
        future = self.async_loop.submit(
            self.websocket_server.start(host, port)
        )
        websocket_port = int(future.result(timeout=15.0))
        self.websocket_port = websocket_port
        self.store.set_setting(
            "websocket_port",
            {"port": websocket_port, "protocol": WS_PROTOCOL},
        )
        return websocket_port

    def stop_websocket(self) -> None:
        if self.websocket_port is None:
            return
        self.async_loop.submit(self.websocket_server.stop()).result(timeout=15.0)
        self.websocket_port = None
        self.store.delete_setting("websocket_port")

    def authenticate(self, bearer_token: str):
        return verify_device_credential(self.store, bearer_token)

    def capabilities(self) -> dict[str, Any]:
        config = load_config()
        providers = build_local_provider_capabilities(
            config,
            self.execution.adapter_factories.keys(),
        )
        launchable_providers = [
            row for row in providers if bool(row.get("can_create_thread"))
        ]
        resumable_providers = [
            row for row in providers if bool(row.get("can_resume_thread"))
        ]
        codex = next(
            (row for row in providers if row["provider_id"] == "codex_cli"),
            None,
        )
        codex_state = str(codex["status"]) if codex is not None else "unavailable"

        tailscale = self.tailscale_status.get_status()
        tailscale_serve = self.tailscale_serve.status()
        operate = operate_status()
        cloud_configured = bool(config.is_paired)
        cloud_identity_matches = bool(
            cloud_configured and config.worker_id == self.worker_id
        )

        return {
            "protocol_version": 1,
            "worker_id": self.worker_id,
            "worker_name": self.worker_name,
            "platform": platform.system().lower(),
            "sqlite_health": self.store.get_status()["status"],
            "codex_state": codex_state,
            "providers": providers,
            "products": {
                "moves": {
                    "availability": "available",
                    "operational": bool(launchable_providers),
                },
                "operate": {
                    **operate,
                    "availability": "available",
                    "operational": bool(operate["enabled"]),
                    "enable_command": "megas operate enable",
                    "disable_command": "megas operate disable",
                },
                "security": {
                    "availability": "waitlist",
                    "operational": False,
                    "audits_enabled": False,
                    "findings_enabled": False,
                    "remediation_enabled": False,
                },
            },
            "routes": {
                "direct": {
                    "available": True,
                    "gateway_bound": True,
                    "requires_cloud": False,
                },
                "tailscale": {
                    "available": bool(
                        tailscale.get("authenticated_connected")
                        and tailscale_serve.get("configured")
                        and not tailscale_serve.get("drift")
                    ),
                    "installed": bool(tailscale.get("installed")),
                    "connected": bool(tailscale.get("authenticated_connected")),
                    "serve_configured": bool(tailscale_serve.get("configured")),
                    "serve_drift": bool(tailscale_serve.get("drift")),
                    "dns_name": tailscale.get("dns_name"),
                    "diagnostic_code": tailscale.get("diagnostic_code"),
                },
                "cloud": {
                    "configured": cloud_configured,
                    "identity_matches_local": cloud_identity_matches,
                    "worker_id": config.worker_id if cloud_configured else None,
                    "connected": None,
                    "connection_state_source": "cloud_worker_heartbeat",
                },
            },
            "tailscale": tailscale,
            "tailscale_serve": tailscale_serve,
            "websocket": {
                "available": self.websocket_port is not None,
                "port": self.websocket_port,
                "subprotocol": WS_PROTOCOL,
                "path_template": (
                    "/api/local/v1/threads/{worker_id}/{megas_thread_id}/"
                    "runs/{live_session_id}/stream"
                ),
            },
            "capabilities": {
                "pairing": True,
                "direct_turns": bool(launchable_providers),
                "strict_native_resume": bool(resumable_providers),
                "ordered_replay": True,
                "cancellation": True,
                "websocket_tickets": True,
                "websocket_streaming": self.websocket_port is not None,
                "private_tailscale_serve": True,
                "direct_write_mode": False,
                "operate_enabled": bool(operate["enabled"]),
                "security_operational": False,
            },
        }

    def list_recent_notifications(self, limit: int = 50) -> list[dict[str, Any]]:
        import json
        from pathlib import Path
        notif_file = Path.home() / ".megas" / "notifications.jsonl"
        if not notif_file.is_file():
            return []
        items = []
        try:
            with open(notif_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            items.append(json.loads(line))
                        except Exception:
                            pass
        except Exception:
            return []
        return items[-limit:]

    def close(self) -> None:
        try:
            self.stop_websocket()
        finally:
            self.async_loop.close()
