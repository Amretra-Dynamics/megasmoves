"""Worker-local canonical conversation events.

This mirrors the shared conversation contract without importing the cloud backend.
The Worker remains independently runnable when Megas cloud is unavailable.
"""

from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass
from typing import Any, Optional

from megas.adapters.base import WorkerEvent

from .models import Session, Thread

_VISIBLE_KINDS = frozenset(
    {
        "user_message",
        "assistant_delta",
        "assistant_final",
        "approval_request",
        "question",
        "error",
    }
)

_KIND_BY_WORKER_EVENT = {
    "user_message": "user_message",
    "assistant_delta": "assistant_delta",
    "assistant_message": "assistant_final",
    "assistant_final": "assistant_final",
    "agent_reasoning": "reasoning",
    "reasoning": "reasoning",
    "tool_started": "tool_call",
    "tool_call": "tool_call",
    "tool_output": "tool_result",
    "tool_finished": "tool_result",
    "tool_result": "tool_result",
    "approval_request": "approval_request",
    "approval_response": "approval_response",
    "file_change": "file_change",
    "plan_update": "plan",
    "plan": "plan",
    "question": "question",
    "agent_error": "error",
    "error": "error",
    "agent_turn_started": "turn_started",
    "turn_started": "turn_started",
    "agent_turn_completed": "turn_completed",
    "turn_completed": "turn_completed",
    "command_finished": "command_finished",
    "session_completed": "session_completed",
    "session_failed": "session_failed",
    "session_cancelled": "session_cancelled",
    "session_interrupted": "session_interrupted",
}


@dataclass(frozen=True)
class CanonicalEvent:
    event_id: str
    kind: str
    source: str
    occurred_at: str
    role: Optional[str]
    native_item_id: Optional[str]
    native_turn_id: Optional[str]
    tool_call_id: Optional[str]
    status: Optional[str]
    content_text: Optional[str]
    content_json: Any
    tool_name: Optional[str]
    file_path: Optional[str]
    additions: Optional[int]
    deletions: Optional[int]
    diff_snippet: Optional[str]
    error_code: Optional[str]
    error_message: Optional[str]
    unsupported_type: Optional[str]
    is_conversation_visible: bool

    @property
    def kind_value(self) -> str:
        return self.kind

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "megas.conversation-event.v1",
            "event_id": self.event_id,
            "kind": self.kind,
            "source": self.source,
            "occurred_at": self.occurred_at,
            "role": self.role,
            "native_item_id": self.native_item_id,
            "native_turn_id": self.native_turn_id,
            "tool_call_id": self.tool_call_id,
            "status": self.status,
            "content_text": self.content_text,
            "content_json": self.content_json,
            "tool_name": self.tool_name,
            "file_path": self.file_path,
            "additions": self.additions,
            "deletions": self.deletions,
            "diff_snippet": self.diff_snippet,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "unsupported_type": self.unsupported_type,
            "is_conversation_visible": self.is_conversation_visible,
        }


def _text(payload: dict[str, Any], *keys: str) -> Optional[str]:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return None


def _string_id(payload: dict[str, Any], *keys: str) -> Optional[str]:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, (str, int)) and str(value):
            return str(value)
    return None


def _optional_int(payload: dict[str, Any], key: str) -> Optional[int]:
    value = payload.get(key)
    if value is None or isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _event_id(
    thread: Thread,
    session: Session,
    event_type: str,
    payload: dict[str, Any],
) -> str:
    source_id = _string_id(
        payload,
        "event_id",
        "native_item_id",
        "item_id",
        "call_id",
        "tool_call_id",
    )
    if source_id is None:
        # Identical deltas may be legitimate repeats, so never deduplicate them by
        # payload text alone. Native provider IDs are deterministic; otherwise use
        # a fresh opaque Local event identity.
        return f"evt_{secrets.token_hex(16)}"
    raw = "|".join(
        (
            thread.worker_id,
            thread.megas_thread_id,
            session.live_session_id,
            event_type,
            source_id,
        )
    )
    return "evt_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def normalize_worker_event(
    thread: Thread,
    session: Session,
    worker_event: WorkerEvent,
    *,
    occurred_at: str,
) -> Optional[CanonicalEvent]:
    payload = dict(worker_event.payload or {})
    event_type = str(worker_event.event_type or "unsupported_event")
    kind = _KIND_BY_WORKER_EVENT.get(event_type, "unsupported_event")

    native_item_id = _string_id(payload, "native_item_id", "item_id", "event_id")
    native_turn_id = _string_id(payload, "native_turn_id", "turn_id")
    tool_call_id = _string_id(payload, "tool_call_id", "call_id", "item_id")
    tool_name = _text(payload, "tool_name", "title", "tool_type", "name")
    status = _text(payload, "status")
    content_text: Optional[str]

    if kind in {"assistant_delta", "assistant_final", "user_message", "reasoning", "question"}:
        content_text = _text(payload, "content_text", "text", "message", "content")
    elif kind == "tool_call":
        content_text = _text(payload, "input", "command", "content_text", "text")
        status = status or "streaming"
    elif kind == "tool_result":
        content_text = _text(payload, "output", "content_text", "text", "result")
        status = status or "completed"
    elif kind == "error":
        content_text = _text(payload, "message", "error_message", "text")
        status = status or "failed"
    else:
        content_text = _text(payload, "content_text", "text", "message")

    if kind in {"assistant_delta", "assistant_final", "user_message"} and not content_text:
        return None

    role: Optional[str] = None
    if kind == "user_message":
        role = "user"
    elif kind in {"assistant_delta", "assistant_final", "reasoning"}:
        role = "assistant"

    unsupported_type = event_type if kind == "unsupported_event" else None
    content_json = payload.get("content_json")
    if content_json is None and kind in {
        "tool_call",
        "tool_result",
        "file_change",
        "plan",
        "approval_request",
        "approval_response",
        "unsupported_event",
    }:
        content_json = payload

    return CanonicalEvent(
        event_id=_event_id(thread, session, event_type, payload),
        kind=kind,
        source="live",
        occurred_at=occurred_at,
        role=role,
        native_item_id=native_item_id,
        native_turn_id=native_turn_id,
        tool_call_id=tool_call_id if kind in {"tool_call", "tool_result"} else None,
        status=status or ("completed" if kind not in {"assistant_delta", "tool_call"} else None),
        content_text=content_text,
        content_json=content_json,
        tool_name=tool_name,
        file_path=_text(payload, "file_path", "path"),
        additions=_optional_int(payload, "additions"),
        deletions=_optional_int(payload, "deletions"),
        diff_snippet=_text(payload, "diff_snippet", "diff"),
        error_code=_text(payload, "error_code", "code"),
        error_message=_text(payload, "error_message", "message") if kind == "error" else None,
        unsupported_type=unsupported_type,
        is_conversation_visible=kind in _VISIBLE_KINDS,
    )


def canonical_payload_digest(payload: dict[str, Any]) -> str:
    serialized = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()
