"""Protocol contracts for Megas Local."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass(frozen=True)
class LocalEvent:
    event_id: str
    worker_id: str
    megas_thread_id: str
    native_thread_id: Optional[str]
    live_session_id: str
    sequence: int
    event_type: str
    created_at: str
    payload: dict[str, Any]
    schema_version: int = 1
    cloud_event_id: Optional[str] = None
