"""Authenticated replay-then-live WebSocket server for Megas Local."""

from __future__ import annotations

import asyncio
import dataclasses
import http
import json
import os
from pathlib import Path
import ssl
import time
import urllib.parse
from dataclasses import dataclass
from typing import Any, Optional

from websockets.asyncio.server import Server, ServerConnection, serve
from websockets.exceptions import ConnectionClosed
from websockets.http11 import Request, Response

from .broker import BrokerSubscription, LocalEventBroker
from .errors import AuthenticationError
from .security import LocalSecurityPolicy
from .store import LocalStore
from .tickets import TicketScope, TicketService
from .ws_registry import LocalConnectionRegistry

WS_PROTOCOL = "megas-local-events-v1"
WS_CLOSE_REPLAY_REQUIRED = 4409
WS_CLOSE_POLICY_VIOLATION = 1008
_REPLAY_PAGE_SIZE = 100
_HEARTBEAT_SECONDS = 20.0


@dataclass(frozen=True)
class AcceptedStream:
    scope: TicketScope
    after_sequence: int


class LocalWebSocketServer:
    def __init__(
        self,
        *,
        store: LocalStore,
        broker: LocalEventBroker,
        tickets: TicketService,
        security_policy: LocalSecurityPolicy,
        registry: LocalConnectionRegistry,
        max_queue_size: int = 512,
    ):
        self.store = store
        self.broker = broker
        self.tickets = tickets
        self.security_policy = security_policy
        self.registry = registry
        self.max_queue_size = max_queue_size
        self._accepted: dict[int, AcceptedStream] = {}
        self._server: Optional[Server] = None
        self.host = "127.0.0.1"
        self.port: Optional[int] = None

    @staticmethod
    def _parse_stream_path(path: str) -> tuple[str, str, str, str, int]:
        parsed = urllib.parse.urlsplit(path)
        parts = [
            urllib.parse.unquote(part)
            for part in parsed.path.strip("/").split("/")
            if part
        ]
        expected_prefix = ["api", "local", "v1", "threads"]
        if (
            len(parts) != 9
            or parts[:4] != expected_prefix
            or parts[6] != "runs"
            or parts[8] != "stream"
        ):
            raise ValueError("Invalid stream path")
        worker_id, thread_id, live_session_id = parts[4], parts[5], parts[7]
        query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        ticket = query.get("ticket", [""])[0]
        try:
            after_sequence = int(query.get("after_seq", ["-1"])[0])
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid replay cursor") from exc
        if after_sequence < -1:
            raise ValueError("Invalid replay cursor")
        if not ticket or len(ticket) > 512:
            raise AuthenticationError("Invalid ticket")
        return worker_id, thread_id, live_session_id, ticket, after_sequence

    @staticmethod
    def _request_origin(request: Request) -> str:
        origin = request.headers.get("Origin")
        return origin if origin else "native-client"

    @staticmethod
    def _offered_protocols(request: Request) -> set[str]:
        raw = request.headers.get("Sec-WebSocket-Protocol", "")
        return {value.strip() for value in raw.split(",") if value.strip()}

    async def process_request(
        self,
        connection: ServerConnection,
        request: Request,
    ) -> Optional[Response]:
        if not self.security_policy.validate_request(request.headers):
            return connection.respond(http.HTTPStatus.FORBIDDEN, "Request boundary denied\n")
        if WS_PROTOCOL not in self._offered_protocols(request):
            return connection.respond(
                http.HTTPStatus.BAD_REQUEST,
                "Required WebSocket subprotocol is missing\n",
            )
        try:
            worker_id, thread_id, live_session_id, ticket, after_sequence = (
                self._parse_stream_path(request.path)
            )
            scope = self.tickets.consume_for_stream_request(
                ticket,
                worker_id=worker_id,
                megas_thread_id=thread_id,
                live_session_id=live_session_id,
                origin=self._request_origin(request),
                protocol=WS_PROTOCOL,
            )
        except AuthenticationError:
            return connection.respond(http.HTTPStatus.UNAUTHORIZED, "Invalid stream ticket\n")
        except ValueError:
            return connection.respond(http.HTTPStatus.BAD_REQUEST, "Invalid stream request\n")

        self._accepted[id(connection)] = AcceptedStream(
            scope=scope,
            after_sequence=after_sequence,
        )
        return None

    def process_response(
        self,
        connection: ServerConnection,
        request: Request,
        response: Response,
    ) -> Response:
        for key, value in self.security_policy.get_safe_headers().items():
            response.headers[key] = value
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Megas-Protocol"] = WS_PROTOCOL
        return response

    @staticmethod
    def _event_message(event) -> str:
        return json.dumps(
            {
                "type": "session_event",
                "protocol_version": 1,
                "event": dataclasses.asdict(event),
            },
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )

    async def _send_replay(
        self,
        connection: ServerConnection,
        accepted: AcceptedStream,
        subscription: BrokerSubscription,
    ) -> int:
        scope = accepted.scope
        watermark = subscription.high_watermark
        cursor = accepted.after_sequence
        if cursor > watermark:
            await connection.close(
                code=WS_CLOSE_REPLAY_REQUIRED,
                reason="Replay cursor is ahead of durable history",
            )
            raise ValueError("Replay cursor is ahead of durable history")

        await connection.send(
            json.dumps(
                {
                    "type": "connected",
                    "protocol_version": 1,
                    "worker_id": scope.worker_id,
                    "megas_thread_id": scope.megas_thread_id,
                    "live_session_id": scope.live_session_id,
                    "requested_after_seq": cursor,
                    "watermark": watermark,
                },
                separators=(",", ":"),
            )
        )

        while cursor < watermark:
            page = self.store.replay_events(
                scope.live_session_id,
                after_seq=cursor,
                limit=_REPLAY_PAGE_SIZE,
                worker_id=scope.worker_id,
                megas_thread_id=scope.megas_thread_id,
            )
            events = [
                event
                for event in page["events"]
                if cursor < event.sequence <= watermark
            ]
            if not events:
                await connection.close(
                    code=WS_CLOSE_REPLAY_REQUIRED,
                    reason="Durable history is incomplete",
                )
                raise ValueError("Durable replay did not reach the watermark")
            for event in events:
                if event.sequence != cursor + 1:
                    await connection.close(
                        code=WS_CLOSE_REPLAY_REQUIRED,
                        reason="Sequence gap in durable history",
                    )
                    raise ValueError("Sequence gap in durable history")
                await connection.send(self._event_message(event))
                cursor = event.sequence
            if not page["has_more"] and cursor < watermark:
                await connection.close(
                    code=WS_CLOSE_REPLAY_REQUIRED,
                    reason="Durable history ended before the watermark",
                )
                raise ValueError("Durable replay ended before the watermark")

        await connection.send(
            json.dumps(
                {
                    "type": "replay_complete",
                    "protocol_version": 1,
                    "watermark": watermark,
                    "next_sequence": watermark + 1,
                },
                separators=(",", ":"),
            )
        )
        return watermark + 1

    async def _send_live(
        self,
        connection: ServerConnection,
        subscription: BrokerSubscription,
        expected_sequence: int,
    ) -> None:
        while True:
            queue_task = asyncio.create_task(subscription.queue.get())
            overflow_task = asyncio.create_task(subscription.overflowed.wait())
            closed_task = asyncio.create_task(subscription.closed.wait())
            done, pending = await asyncio.wait(
                {queue_task, overflow_task, closed_task},
                timeout=_HEARTBEAT_SECONDS,
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
            if not done:
                await connection.send(
                    json.dumps(
                        {
                            "type": "heartbeat",
                            "protocol_version": 1,
                            "sent_at": time.time(),
                        },
                        separators=(",", ":"),
                    )
                )
                continue
            if overflow_task in done and overflow_task.result():
                await connection.close(
                    code=WS_CLOSE_REPLAY_REQUIRED,
                    reason="Client fell behind; replay is required",
                )
                return
            if queue_task in done:
                event = queue_task.result()
                if event.sequence < expected_sequence:
                    continue
                if event.sequence != expected_sequence:
                    await connection.close(
                        code=WS_CLOSE_REPLAY_REQUIRED,
                        reason="Live sequence gap; replay is required",
                    )
                    return
                await connection.send(self._event_message(event))
                expected_sequence += 1
                continue
            if closed_task in done and closed_task.result():
                return

    async def handle(self, connection: ServerConnection) -> None:
        accepted = self._accepted.pop(id(connection), None)
        if accepted is None or connection.subprotocol != WS_PROTOCOL:
            await connection.close(
                code=WS_CLOSE_POLICY_VIOLATION,
                reason="WebSocket authorization was not completed",
            )
            return

        registration = await self.registry.register(
            accepted.scope.device_id,
            connection,
        )
        subscription: Optional[BrokerSubscription] = None
        try:
            subscription = await self.broker.subscribe_with_watermark(
                accepted.scope.live_session_id,
                max_queue_size=self.max_queue_size,
            )
            expected_sequence = await self._send_replay(
                connection,
                accepted,
                subscription,
            )
            durable_session = self.store.get_session(accepted.scope.live_session_id)
            if durable_session is not None and durable_session.status in {
                "completed",
                "failed",
                "cancelled",
                "interrupted",
            }:
                return
            await self._send_live(
                connection,
                subscription,
                expected_sequence,
            )
        except ConnectionClosed:
            return
        except ValueError:
            return
        finally:
            if subscription is not None:
                await self.broker.unsubscribe(subscription)
            await registration.unregister()

    async def start(self, host: str = "127.0.0.1", port: int = 0) -> int:
        if self._server is not None:
            raise RuntimeError("Local WebSocket server is already running")
        self.host = host
        ssl_context = None
        if os.environ.get("MEGAS_LOCAL_TLS", "0") == "1":
            cert_file = Path(__file__).resolve().parents[2] / "certs" / "megas_local.crt"
            key_file = Path(__file__).resolve().parents[2] / "certs" / "megas_local.key"
            if cert_file.is_file() and key_file.is_file():
                ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                ssl_context.minimum_version = ssl.TLSVersion.TLSv1_2
                ssl_context.load_cert_chain(str(cert_file), str(key_file))

        self._server = await serve(
            self.handle,
            host,
            port,
            ssl=ssl_context,
            process_request=self.process_request,
            process_response=self.process_response,
            subprotocols=[WS_PROTOCOL],
            compression=None,
            server_header=None,
            open_timeout=10,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=5,
            max_size=64 * 1024,
            max_queue=8,
            write_limit=64 * 1024,
        )
        sockets = self._server.sockets or []
        if not sockets:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
            raise RuntimeError("Local WebSocket server did not bind a socket")
        self.port = int(sockets[0].getsockname()[1])
        return self.port

    async def stop(self) -> None:
        if self._server is None:
            return
        await self.registry.close_all_for_shutdown()
        self._server.close()
        await self._server.wait_closed()
        self._server = None
        self.port = None
        self._accepted.clear()
