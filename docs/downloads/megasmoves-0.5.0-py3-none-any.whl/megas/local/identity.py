"""Stable secret-free identity helpers for Local and provider ownership.

This facade preserves the installation fingerprint already used by native-thread
sync. Keeping one identity source prevents pairing, Local routes, and provider
installations from inventing incompatible machine identities.
"""

from __future__ import annotations


def worker_installation_id() -> str:
    # Import lazily to avoid pulling provider parsers into Local runtime startup.
    from megas.thread_sync import _worker_installation_id

    return _worker_installation_id()


__all__ = ["worker_installation_id"]
