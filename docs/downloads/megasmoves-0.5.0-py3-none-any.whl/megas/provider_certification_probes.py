"""Runtime-safe negative probes used before issuing adapter certificates."""

from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Any, Iterator
from unittest.mock import patch

from . import certified_thread_sync as certified
from . import thread_sync_legacy as legacy
from .cursor_cli_history import index_cursor_cli_threads


_UUIDISH = re.compile(
    r"^(?:[0-9a-f]{8}-[0-9a-f-]{20,}|(?:ses|sess|session|task|chat|cline)[_-][a-z0-9._-]{4,})$",
    re.IGNORECASE,
)

# Explicit provider data roots bypass Path.home(). Negative probes must clear
# them or an installed runner can leak real history into an isolated trap test.
_ISOLATED_DATA_ENVIRONMENTS = (
    "CURSOR_DATA_DIR",
    "CLINE_DATA_DIR",
    "OPENCODE_DATA_DIR",
    "OPENCODE_CONFIG_DIR",
    "KILO_DATA_DIR",
    "KILOCODE_DATA_DIR",
    "ANTIGRAVITY_DATA_DIR",
    "AGY_DATA_DIR",
)


@contextmanager
def _isolated_home() -> Iterator[Path]:
    with tempfile.TemporaryDirectory(prefix="megas-cert-negative-") as raw:
        home = Path(raw).resolve()
        previous_environment = {
            name: os.environ.pop(name, None)
            for name in _ISOLATED_DATA_ENVIRONMENTS
        }
        try:
            with patch.object(Path, "home", return_value=home):
                yield home
        finally:
            for name, value in previous_environment.items():
                if value is not None:
                    os.environ[name] = value


def _write(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")


def _trap_jsonl() -> str:
    return json.dumps(
        {
            "type": "telemetry",
            "role": "assistant",
            "content": "This is cache telemetry, never a conversation.",
            "session_id": "telemetry-cache-id",
        }
    ) + "\n"


def _strict_cline_file(path: Path) -> dict[str, Any] | None:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(raw, dict):
        return None
    internal = str(
        raw.get("session_id")
        or raw.get("sessionId")
        or raw.get("taskId")
        or raw.get("id")
        or ""
    ).strip()
    if internal:
        if internal != path.stem:
            return None
    elif not _UUIDISH.fullmatch(path.stem):
        # Official Cline snapshot filenames are session ids. Arbitrary names
        # such as cache.json, telemetry.json, or settings.json are not accepted.
        return None
    return certified._parse_cline_file(path)


def strict_cline_index(limit: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in certified._cline_session_files():
        if len(rows) >= limit:
            break
        thread = _strict_cline_file(path)
        if not thread:
            continue
        rows.append(
            legacy._index_row(
                native_id=str(thread["native_id"]),
                agent_type="cline",
                title=str(thread.get("title") or "Cline session")[:80],
                project_path=thread.get("project_path"),
                sync_cursor=legacy._cursor_with_epoch(
                    str(thread.get("sync_cursor") or "")
                ),
            )
        )
    return rows


def strict_cline_read(native_id: str) -> dict[str, Any] | None:
    wanted = str(native_id or "").strip()
    if not wanted or not _UUIDISH.fullmatch(wanted):
        return None
    path = certified._cline_root() / "sessions" / f"{wanted}.json"
    thread = _strict_cline_file(path) if path.is_file() else None
    return thread if thread and thread.get("native_id") == wanted else None


def install_strict_readers() -> None:
    certified._READERS["cline"] = certified.ProviderReader(
        strict_cline_index,
        strict_cline_read,
    )


def _sqlite_nonconversation(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    try:
        conn.execute("CREATE TABLE telemetry(id TEXT PRIMARY KEY, payload TEXT)")
        conn.execute(
            "INSERT INTO telemetry(id, payload) VALUES(?, ?)",
            ("fake-session", '{"role":"assistant","content":"not chat"}'),
        )
        conn.commit()
    finally:
        conn.close()


def negative_nonconversation_sources_rejected(provider_id: str) -> tuple[bool, str]:
    """Exercise the provider's real trap class without touching user stores."""
    provider = str(provider_id or "").strip().lower()
    install_strict_readers()
    with _isolated_home() as home:
        try:
            if provider == "codex_cli":
                _write(home / ".codex" / "history.jsonl", _trap_jsonl())
                rows = legacy.index_codex_threads(20)
            elif provider == "antigravity":
                _write(
                    home
                    / ".gemini"
                    / "antigravity-cli"
                    / "cache"
                    / "last_conversations.json",
                    json.dumps({"conversations": [{"id": "cache-id"}]}),
                )
                rows = legacy.index_agy_threads(20)
            elif provider == "grok_build":
                _write(home / ".grok" / "sessions" / "telemetry.jsonl", _trap_jsonl())
                rows = legacy.index_grok_threads(20)
            elif provider == "opencode":
                root = home / ".local" / "share" / "opencode"
                _write(root / "telemetry.jsonl", _trap_jsonl())
                _sqlite_nonconversation(root / "opencode.db")
                rows = legacy.index_sqlite_agent_stores(
                    [root],
                    agent_type="opencode",
                    db_names=("opencode.db",),
                    limit=20,
                )
            elif provider == "kilo_code":
                root = home / ".kilocode"
                _write(root / "cache.jsonl", _trap_jsonl())
                _sqlite_nonconversation(root / "kilo.db")
                rows = legacy.index_sqlite_agent_stores(
                    [root],
                    agent_type="kilo_code",
                    db_names=("kilo.db",),
                    limit=20,
                )
            elif provider == "cline":
                _write(
                    home / ".cline" / "data" / "sessions" / "cache.json",
                    json.dumps(
                        {
                            "messages": [
                                {"role": "assistant", "content": "cache telemetry"}
                            ]
                        }
                    ),
                )
                rows = strict_cline_index(20)
            elif provider == "cursor_cli":
                _write(
                    home
                    / ".cursor"
                    / "projects"
                    / "demo"
                    / "agent-transcripts"
                    / "telemetry.jsonl",
                    _trap_jsonl(),
                )
                # The authoritative Cursor CLI reader requires an exact UUID
                # to exist in the CLI chat store before any transcript is read.
                rows = index_cursor_cli_threads(20)
            elif provider in {"devin_cli", "jules_cli"}:
                # Their certified readers call only explicit sessions/messages
                # or sessions/activities API resources; there is no filesystem
                # wildcard or generic JSON ingestion surface.
                return True, "api_resource_allowlist"
            elif provider == "claude_code":
                _write(home / ".claude" / "stats-cache.jsonl", _trap_jsonl())
                rows = legacy.index_claude_threads(20)
            elif provider == "aider":
                return False, "authoritative_native_history_reader_not_implemented"
            else:
                return False, "provider_negative_probe_not_implemented"
        except Exception as exc:
            return False, f"negative_probe_error:{type(exc).__name__}"
    return (not rows, "negative_sources_rejected" if not rows else "negative_source_was_indexed")


def secret_redaction_proved(adapter: object) -> tuple[bool, str]:
    """Verify the adapter's normal output boundary removes common secrets."""
    secret = "sk-megas-certification-0123456789abcdef0123456789abcdef"
    sample = (
        f"Authorization: Bearer {secret}\n"
        f"OPENAI_API_KEY={secret}\n"
        "normal user-visible text"
    )
    redact = getattr(adapter, "redact_output", None)
    if not callable(redact):
        return False, "adapter_redaction_boundary_missing"
    try:
        output = str(redact(sample))
    except Exception as exc:
        return False, f"adapter_redaction_failed:{type(exc).__name__}"
    if secret in output:
        return False, "secret_survived_redaction"
    if "normal user-visible text" not in output:
        return False, "redaction_destroyed_safe_content"
    return True, "secret_redaction_proved"
