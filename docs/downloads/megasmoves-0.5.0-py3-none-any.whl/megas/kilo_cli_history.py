"""Authoritative Kilo Code 1.x history reader through the provider CLI."""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from typing import Any

from .adapters.base import (
    prefer_console_free_tool_path,
    resolve_cli_argv,
    subprocess_hide_window_kwargs,
)
from . import thread_sync_legacy as legacy


_SESSION_ID = re.compile(r"^ses_[A-Za-z0-9._-]{4,200}$")


def _binary() -> Path | None:
    for candidate in (
        os.getenv("MEGAS_KILO_BINARY", "").strip(),
        "kilo",
        "kilocode",
    ):
        if not candidate:
            continue
        found = shutil.which(candidate)
        if found:
            return Path(found)
        path = Path(candidate).expanduser()
        if path.is_file():
            return path
    return None


def _run_kilo_json(*args: str, timeout: float = 15.0) -> Any:
    binary = _binary()
    if binary is None:
        return None
    try:
        result = subprocess.run(
            resolve_cli_argv(str(binary), *args),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            env=prefer_console_free_tool_path(dict(os.environ)),
            **subprocess_hide_window_kwargs(),
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    payload = result.stdout.strip()
    if not payload or len(payload.encode("utf-8")) > 32 * 1024 * 1024:
        return None
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return None


def _text(value: object, limit: int = 64_000) -> str:
    cleaned = legacy._sanitize_provider_text(str(value or ""))
    return cleaned if len(cleaned) <= limit else cleaned[:limit] + "\n…[truncated]"


def _nested(mapping: dict[str, Any], *path: str) -> object:
    current: object = mapping
    for key in path:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def _session_id(value: object) -> str:
    text = str(value or "").strip()
    return text if _SESSION_ID.fullmatch(text) else ""


def _project_path(row: dict[str, Any]) -> str | None:
    for value in (
        row.get("directory"),
        row.get("projectPath"),
        row.get("project_path"),
        _nested(row, "project", "worktree"),
        _nested(row, "project", "path"),
    ):
        text = str(value or "").strip()
        if text and "\x00" not in text:
            return text[:4_096]
    return None


def _updated(row: dict[str, Any]) -> str:
    for value in (
        row.get("updated"),
        row.get("updatedAt"),
        row.get("updateTime"),
        _nested(row, "time", "updated"),
        _nested(row, "time", "created"),
    ):
        text = str(value or "").strip()
        if text:
            return text[:200]
    return "0"


def index_kilo_cli_threads(limit: int) -> list[dict[str, Any]]:
    count = min(max(int(limit), 1), 5_000)
    payload = _run_kilo_json(
        "session",
        "list",
        "--all",
        "--max-count",
        str(count),
        "--format",
        "json",
    )
    if not isinstance(payload, list):
        return []

    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in payload:
        if not isinstance(item, dict):
            continue
        native_id = _session_id(
            item.get("id")
            or item.get("sessionID")
            or item.get("session_id")
        )
        if not native_id or native_id in seen:
            continue
        seen.add(native_id)
        title = _text(
            item.get("title") or item.get("name") or "Kilo session",
            80,
        )
        rows.append(
            legacy._index_row(
                native_id=native_id,
                agent_type="kilo_code",
                title=title or "Kilo session",
                project_path=_project_path(item),
                sync_cursor=legacy._cursor_with_epoch(_updated(item)),
            )
        )
        if len(rows) >= count:
            break
    return rows


def _message_text(message: dict[str, Any]) -> str:
    direct = message.get("content") or message.get("text")
    if isinstance(direct, str):
        return _text(direct)
    parts = message.get("parts")
    if not isinstance(parts, list):
        return ""

    values: list[str] = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        if str(part.get("type") or "").lower() not in {
            "text",
            "reasoning",
        }:
            continue
        value = part.get("text") or part.get("content")
        if isinstance(value, str) and value:
            values.append(_text(value))
    return "\n".join(values)


def _canonical_messages(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw_messages = payload.get("messages")
    if not isinstance(raw_messages, list):
        return []

    result: list[dict[str, Any]] = []
    for item in raw_messages:
        if not isinstance(item, dict):
            continue
        info = item.get("info") if isinstance(item.get("info"), dict) else item
        role = str(
            info.get("role") or item.get("role") or ""
        ).strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = _message_text(item)
        if not content:
            continue
        native_item_id = str(
            info.get("id")
            or item.get("id")
            or f"message-{len(result)}"
        ).strip()[:300]
        created = str(
            info.get("createdAt")
            or info.get("created_at")
            or _nested(info, "time", "created")
            or ""
        )[:200]
        result.append(
            {
                "seq": len(result),
                "role": role,
                "kind": (
                    "user_message" if role == "user" else "assistant_final"
                ),
                "content": content,
                "created_at": created,
                "native_item_id": native_item_id,
            }
        )
    return result


def read_kilo_cli_thread(native_id: str) -> dict[str, Any] | None:
    wanted = _session_id(native_id)
    if not wanted:
        return None
    payload = _run_kilo_json("export", wanted, timeout=30.0)
    if not isinstance(payload, dict):
        return None

    info = payload.get("info") if isinstance(payload.get("info"), dict) else payload
    observed = _session_id(
        info.get("id")
        or info.get("sessionID")
        or info.get("session_id")
    )
    if observed != wanted:
        return None
    messages = _canonical_messages(payload)
    if not messages:
        return None

    title = _text(info.get("title") or "Kilo session", 80) or "Kilo session"
    thread = {
        "native_id": wanted,
        "agent_type": "kilo_code",
        "project_path": _project_path(info),
        "title": title,
        "status": str(info.get("status") or "active").lower()[:40],
        "sync_cursor": legacy._cursor_with_epoch(_updated(info)),
        "messages": messages,
    }
    finalized = legacy.finalize_native_thread(
        thread,
        provider_id="kilo_code",
        data_roots=[Path.home() / ".local" / "share" / "kilo"],
        source_hint=f"kilo-cli-export:{wanted}",
        extra_meta={
            "identity_source": "kilo_session_id",
            "source_format": "kilo_cli_export_v1",
            "history_authority": "kilo_cli",
        },
    )
    raw_metadata = finalized.get("metadata_json")
    if isinstance(raw_metadata, str):
        try:
            parsed_metadata = json.loads(raw_metadata)
        except json.JSONDecodeError:
            parsed_metadata = None
        if isinstance(parsed_metadata, dict):
            finalized["metadata_json"] = parsed_metadata
    return finalized
