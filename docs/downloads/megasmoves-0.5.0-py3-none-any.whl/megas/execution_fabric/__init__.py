"""MegasMoves Execution Fabric.

Capability-driven execution engine that discovers local and connected execution
providers across Windows, macOS, Linux, Android, and Web, enforcing platform
policy and legal boundaries before resolving the optimal execution plan.
"""

from .models import (
    ExecutionPlan,
    HostEnvironment,
    PlatformPolicyViolation,
    ProviderCapability,
    ProviderType,
    TargetArchitecture,
    TargetOS,
    TestRequirement,
)
from .policy_gate import PolicyGate
from .registry import ProviderRegistry
from .resolver import CapabilityResolver

__all__ = [
    "CapabilityResolver",
    "ExecutionPlan",
    "HostEnvironment",
    "PlatformPolicyViolation",
    "PolicyGate",
    "ProviderCapability",
    "ProviderRegistry",
    "ProviderType",
    "TargetArchitecture",
    "TargetOS",
    "TestRequirement",
]
