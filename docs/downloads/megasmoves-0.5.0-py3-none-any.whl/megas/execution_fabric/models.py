"""Data models for the MegasMoves Execution Fabric."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TargetOS(str, Enum):
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"
    ANDROID = "android"
    IOS = "ios"
    WEB = "web"


class TargetArchitecture(str, Enum):
    X64 = "x64"
    ARM64 = "arm64"
    UNIVERSAL = "universal"
    ANY = "any"


class ProviderType(str, Enum):
    NATIVE_HOST = "native_host"
    WSL2 = "wsl2"
    APPLE_VIRTUALIZATION = "apple_virtualization"
    DOCKER = "docker"
    PODMAN = "podman"
    QEMU = "qemu"
    WINE = "wine"
    REMOTE_BRIDGE = "remote_bridge"
    ADB = "adb"
    SIMULATOR = "simulator"
    WEBVIEW = "webview"


class PlatformPolicyViolation(Exception):
    """Raised when an execution request violates platform legal or policy rules."""

    def __init__(self, message: str, *, rule_code: str, suggested_action: str) -> None:
        super().__init__(message)
        self.rule_code = rule_code
        self.suggested_action = suggested_action


@dataclass(frozen=True)
class HostEnvironment:
    """Current host machine operating system, architecture, and hardware characteristics."""

    os: TargetOS
    architecture: TargetArchitecture
    is_apple_silicon: bool = False
    is_genuine_apple_hardware: bool = False
    has_wsl2: bool = False
    wsl_distros: list[str] = field(default_factory=list)
    has_docker: bool = False
    has_podman: bool = False
    has_wine: bool = False
    has_kvm: bool = False
    has_adb: bool = False
    hostname: str = "localhost"


@dataclass(frozen=True)
class TestRequirement:
    """Specific requirements of the test or application to be executed."""

    __test__ = False

    target_os: TargetOS
    target_arch: TargetArchitecture = TargetArchitecture.ANY
    requires_gui: bool = False
    requires_kernel_isolation: bool = True
    requires_notarization_or_signing: bool = False
    required_distro: str | None = None
    project_root: str | None = None
    target_id: str | None = None


@dataclass(frozen=True)
class ProviderCapability:
    """A registered provider capable of satisfying execution requests."""

    provider_id: str
    provider_type: ProviderType
    supported_os: list[TargetOS]
    supported_arch: list[TargetArchitecture]
    supports_gui: bool = False
    is_local: bool = True
    is_available: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ExecutionPlan:
    """The resolved execution path for running and testing a target."""

    target_os: TargetOS
    provider_type: ProviderType
    provider_id: str
    is_local: bool
    requires_second_device: bool
    runner_command: list[str]
    environment_variables: dict[str, str] = field(default_factory=dict)
    rationale: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
