"""Policy and legal compliance gate for the MegasMoves Execution Fabric.

Enforces critical invariants:
1. NEVER automate, provision, or facilitate unauthorized macOS virtualization
   or Hackintosh environments on non-Apple hardware.
2. Genuine Apple hardware is strictly required for macOS execution and testing.
3. Safe execution boundaries and loopback requirements.
"""

from __future__ import annotations

from .models import HostEnvironment, PlatformPolicyViolation, ProviderType, TargetOS, TestRequirement


class PolicyGate:
    """Evaluates execution requests and provider candidates against legal and platform rules."""

    @staticmethod
    def validate_request(host: HostEnvironment, req: TestRequirement) -> None:
        """Validate whether the test request is legally and technically permissible on the host.

        Raises:
            PlatformPolicyViolation: If the request requires an unauthorized workaround.
        """
        # INVARIANT: macOS execution requires genuine Apple hardware
        if req.target_os == TargetOS.MACOS:
            if not host.is_genuine_apple_hardware and host.os != TargetOS.MACOS:
                # We permit this request ONLY IF it will be routed to a genuine connected Mac
                # (via ProviderType.REMOTE_BRIDGE) or an authorized service.
                # Attempting to satisfy macOS locally on Windows or Linux is prohibited.
                pass

    @staticmethod
    def is_provider_permitted(
        host: HostEnvironment,
        req: TestRequirement,
        provider_type: ProviderType,
    ) -> tuple[bool, str]:
        """Check if a specific provider is legally and technically allowed to satisfy the requirement.

        Returns:
            (allowed: bool, reason: str)
        """
        # Rule 1: No macOS virtualization on non-Apple host hardware
        if req.target_os == TargetOS.MACOS:
            if provider_type in {
                ProviderType.QEMU,
                ProviderType.DOCKER,
                ProviderType.PODMAN,
                ProviderType.WINE,
            } and not host.is_genuine_apple_hardware:
                return (
                    False,
                    "Policy Invariant: macOS virtualization/emulation is prohibited on non-Apple hardware. "
                    "A genuine connected Mac via Megas Platform Bridge is required.",
                )

            if provider_type == ProviderType.NATIVE_HOST and host.os != TargetOS.MACOS:
                return (
                    False,
                    "Host OS cannot run macOS binaries natively.",
                )

        # Rule 2: iOS Simulator requires genuine macOS host
        if req.target_os == TargetOS.IOS:
            if provider_type != ProviderType.SIMULATOR or host.os != TargetOS.MACOS:
                return (
                    False,
                    "iOS Simulator is supported only on a genuine macOS host environment.",
                )

        # Rule 3: WSL2 is available only on Windows hosts
        if provider_type == ProviderType.WSL2 and host.os != TargetOS.WINDOWS:
            return (False, "WSL 2 is supported only on Windows.")

        # Rule 4: Apple Virtualization is available only on macOS hosts
        if provider_type == ProviderType.APPLE_VIRTUALIZATION and host.os != TargetOS.MACOS:
            return (False, "Apple Virtualization.framework is supported only on macOS.")

        return (True, "Permitted by platform policy")
