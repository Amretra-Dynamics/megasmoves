"""Provider registry and hardware capability discovery for MegasMoves."""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from typing import Any
from megas.adapters.base import windows_subprocess_kwargs

from .models import (
    HostEnvironment,
    ProviderCapability,
    ProviderType,
    TargetArchitecture,
    TargetOS,
)


class ProviderRegistry:
    """Discovers host capabilities and maintains the active provider registry."""

    def __init__(self, host: HostEnvironment | None = None) -> None:
        self.host = host or self.discover_host()
        self._connected_bridges: list[ProviderCapability] = []

    @classmethod
    def discover_host(cls) -> HostEnvironment:
        """Probe the current host machine for installed subsystems and hardware."""
        sys_name = platform.system().lower()
        machine = platform.machine().lower()

        is_arm = machine in {"arm64", "aarch64"}
        arch = TargetArchitecture.ARM64 if is_arm else TargetArchitecture.X64

        if "windows" in sys_name:
            host_os = TargetOS.WINDOWS
            is_apple = False
        elif "darwin" in sys_name:
            host_os = TargetOS.MACOS
            is_apple = True
        else:
            host_os = TargetOS.LINUX
            is_apple = False

        # Probe Windows Subsystem for Linux (WSL 2)
        has_wsl2 = False
        wsl_distros: list[str] = []
        if host_os == TargetOS.WINDOWS:
            wsl_bin = shutil.which("wsl") or shutil.which("wsl.exe")
            if wsl_bin:
                try:
                    res = subprocess.run(
                        [wsl_bin, "-l", "-q"],
                        capture_output=True,
                        text=False,
                        timeout=3,
                        check=False,
                        stdin=subprocess.DEVNULL,
                        **windows_subprocess_kwargs(),
                    )
                    if res.returncode == 0:
                        # Parse UTF-16LE or UTF-8 output from wsl -l -q
                        raw = res.stdout
                        try:
                            text = raw.decode("utf-16le")
                        except UnicodeDecodeError:
                            text = raw.decode("utf-8", errors="replace")
                        distros = [line.strip().replace("\x00", "") for line in text.splitlines() if line.strip()]
                        if distros:
                            has_wsl2 = True
                            wsl_distros = distros
                except Exception:
                    pass

        has_docker = shutil.which("docker") is not None
        has_podman = shutil.which("podman") is not None
        has_wine = shutil.which("wine") is not None
        has_adb = shutil.which("adb") is not None or shutil.which("adb.exe") is not None
        has_kvm = os.path.exists("/dev/kvm") if host_os == TargetOS.LINUX else False

        return HostEnvironment(
            os=host_os,
            architecture=arch,
            is_apple_silicon=is_apple and is_arm,
            is_genuine_apple_hardware=is_apple,
            has_wsl2=has_wsl2,
            wsl_distros=wsl_distros,
            has_docker=has_docker,
            has_podman=has_podman,
            has_wine=has_wine,
            has_kvm=has_kvm,
            has_adb=has_adb,
            hostname=platform.node() or "localhost",
        )

    def register_connected_bridge(
        self,
        node_id: str,
        target_os: TargetOS,
        target_arch: TargetArchitecture,
        *,
        hostname: str,
        port: int = 50052,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Register an authorized remote machine connected via megas_platform_bridge."""
        cap = ProviderCapability(
            provider_id=f"bridge:{node_id}",
            provider_type=ProviderType.REMOTE_BRIDGE,
            supported_os=[target_os],
            supported_arch=[target_arch],
            supports_gui=True,
            is_local=False,
            is_available=True,
            metadata={
                "hostname": hostname,
                "port": port,
                "node_id": node_id,
                **(metadata or {}),
            },
        )
        self._connected_bridges.append(cap)

    def unregister_connected_bridge(self, node_id: str) -> None:
        """Remove a disconnected remote bridge."""
        self._connected_bridges = [
            b for b in self._connected_bridges if b.metadata.get("node_id") != node_id
        ]

    def get_available_providers(self) -> list[ProviderCapability]:
        """List all discovered local and connected providers."""
        providers: list[ProviderCapability] = []

        # 1. Native host provider
        providers.append(
            ProviderCapability(
                provider_id=f"native:{self.host.os.value}",
                provider_type=ProviderType.NATIVE_HOST,
                supported_os=[self.host.os],
                supported_arch=[self.host.architecture],
                supports_gui=True,
                is_local=True,
                is_available=True,
                metadata={"os": self.host.os.value, "arch": self.host.architecture.value},
            )
        )

        # 2. Windows Subsystem for Linux (WSL2)
        if self.host.os == TargetOS.WINDOWS and self.host.has_wsl2:
            providers.append(
                ProviderCapability(
                    provider_id="wsl2:default",
                    provider_type=ProviderType.WSL2,
                    supported_os=[TargetOS.LINUX],
                    supported_arch=[self.host.architecture],
                    supports_gui=True,  # WSLg
                    is_local=True,
                    is_available=True,
                    metadata={"distros": self.host.wsl_distros},
                )
            )

        # 3. Apple Virtualization (macOS)
        if self.host.os == TargetOS.MACOS:
            providers.append(
                ProviderCapability(
                    provider_id="apple:virtualization",
                    provider_type=ProviderType.APPLE_VIRTUALIZATION,
                    supported_os=[TargetOS.LINUX],
                    supported_arch=[self.host.architecture],
                    supports_gui=True,
                    is_local=True,
                    is_available=True,
                )
            )
            providers.append(
                ProviderCapability(
                    provider_id="apple:simctl",
                    provider_type=ProviderType.SIMULATOR,
                    supported_os=[TargetOS.IOS],
                    supported_arch=[self.host.architecture],
                    supports_gui=True,
                    is_local=True,
                    is_available=True,
                )
            )

        # 4. Wine (on Linux or macOS)
        if self.host.has_wine:
            providers.append(
                ProviderCapability(
                    provider_id="wine:local",
                    provider_type=ProviderType.WINE,
                    supported_os=[TargetOS.WINDOWS],
                    supported_arch=[TargetArchitecture.X64],
                    supports_gui=True,
                    is_local=True,
                    is_available=True,
                )
            )

        # 5. Docker / Containers
        if self.host.has_docker:
            providers.append(
                ProviderCapability(
                    provider_id="docker:local",
                    provider_type=ProviderType.DOCKER,
                    supported_os=[TargetOS.LINUX],
                    supported_arch=[self.host.architecture],
                    supports_gui=False,
                    is_local=True,
                    is_available=True,
                )
            )

        # 6. Android Debug Bridge (ADB)
        if self.host.has_adb:
            providers.append(
                ProviderCapability(
                    provider_id="adb:local",
                    provider_type=ProviderType.ADB,
                    supported_os=[TargetOS.ANDROID],
                    supported_arch=[TargetArchitecture.ANY, TargetArchitecture.ARM64, TargetArchitecture.X64],
                    supports_gui=True,
                    is_local=True,
                    is_available=True,
                )
            )

        # 7. Connected peer bridges
        providers.extend(self._connected_bridges)

        return providers
