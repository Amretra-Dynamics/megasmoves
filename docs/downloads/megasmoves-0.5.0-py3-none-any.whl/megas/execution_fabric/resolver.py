"""Capability Resolver for the MegasMoves Execution Fabric."""

from __future__ import annotations

from typing import Any

from .models import (
    ExecutionPlan,
    HostEnvironment,
    PlatformPolicyViolation,
    ProviderCapability,
    ProviderType,
    TargetArchitecture,
    TargetOS,
    TestRequirement,
)
from .policy_gate import PolicyGate
from .registry import ProviderRegistry


class CapabilityResolver:
    """Matches test requirements against available providers and returns the optimal execution plan."""

    def __init__(self, registry: ProviderRegistry | None = None) -> None:
        self.registry = registry or ProviderRegistry()
        self.policy_gate = PolicyGate()

    @property
    def host(self) -> HostEnvironment:
        return self.registry.host

    def resolve(self, req: TestRequirement) -> ExecutionPlan:
        """Resolve the optimal execution plan for a test request."""
        # 1. Validate against platform policy
        self.policy_gate.validate_request(self.host, req)

        # 2. Get available providers
        candidates = self.registry.get_available_providers()

        # 3. Filter candidates by OS, Arch, and Policy
        matching: list[tuple[int, ProviderCapability]] = []

        for p in candidates:
            if not p.is_available:
                continue
            if req.target_os not in p.supported_os:
                continue
            if req.target_arch != TargetArchitecture.ANY:
                if req.target_arch not in p.supported_arch and TargetArchitecture.ANY not in p.supported_arch:
                    continue

            # Check Policy Gate
            allowed, reason = self.policy_gate.is_provider_permitted(self.host, req, p.provider_type)
            if not allowed:
                continue

            # Prioritize:
            # Rank 1: Native host (score 100)
            # Rank 2: Native OS Subsystem (WSL2, Apple Virtualization) (score 80)
            # Rank 3: Local Container / Compatibility (Wine, Docker) (score 60)
            # Rank 4: Connected remote bridge (score 40)
            score = 0
            if p.provider_type == ProviderType.NATIVE_HOST:
                score = 100
            elif p.provider_type in {ProviderType.WSL2, ProviderType.APPLE_VIRTUALIZATION, ProviderType.SIMULATOR}:
                score = 80
            elif p.provider_type in {ProviderType.WINE, ProviderType.DOCKER, ProviderType.PODMAN}:
                score = 60
            elif p.provider_type == ProviderType.REMOTE_BRIDGE:
                score = 40
            elif p.provider_type == ProviderType.ADB:
                score = 90  # Highest for Android

            matching.append((score, p))

        if not matching:
            # Handle special policy-informed error messaging
            if req.target_os == TargetOS.MACOS and not self.host.is_genuine_apple_hardware:
                raise PlatformPolicyViolation(
                    message="macOS testing requires genuine Apple hardware under Apple platform licensing.",
                    rule_code="MACOS_GENUINE_HARDWARE_REQUIRED",
                    suggested_action="Connect a Mac on your local network to test, build, and debug without leaving your Windows desk.",
                )
            if req.target_os == TargetOS.LINUX and self.host.os == TargetOS.WINDOWS and not self.host.has_wsl2:
                raise RuntimeError(
                    "Linux testing on Windows requires Windows Subsystem for Linux (WSL 2). "
                    "Run 'wsl --install' to enable native Linux testing directly on your Windows PC."
                )

            raise RuntimeError(f"No available execution provider found for target {req.target_os.value}.")

        # Sort by score descending
        matching.sort(key=lambda x: x[0], reverse=True)
        best_provider = matching[0][1]

        return self._build_plan(req, best_provider)

    def _build_plan(self, req: TestRequirement, provider: ProviderCapability) -> ExecutionPlan:
        """Construct the concrete execution plan based on the resolved provider."""
        if provider.provider_type == ProviderType.NATIVE_HOST:
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=True,
                requires_second_device=False,
                runner_command=["native_exec"],
                rationale="Running natively on host OS with 0 overhead and direct kernel process supervision.",
            )

        if provider.provider_type == ProviderType.WSL2:
            distro = req.required_distro or (
                self.host.wsl_distros[0] if self.host.wsl_distros else "Ubuntu"
            )
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=True,
                requires_second_device=False,
                runner_command=["wsl.exe", "-d", distro, "--exec"],
                rationale=f"Executing locally on Windows via WSL 2 ({distro}) with WSLg GUI and process isolation.",
                metadata={"distro": distro},
            )

        if provider.provider_type == ProviderType.APPLE_VIRTUALIZATION:
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=True,
                requires_second_device=False,
                runner_command=["vz_run"],
                rationale="Executing in native Apple Virtualization.framework microVM with VirtioFS and VirtioSocket.",
            )

        if provider.provider_type == ProviderType.SIMULATOR:
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=True,
                requires_second_device=False,
                runner_command=["xcrun", "simctl"],
                rationale="Executing in native macOS CoreSimulator.",
            )

        if provider.provider_type == ProviderType.ADB:
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=True,
                requires_second_device=False,
                runner_command=["adb"],
                rationale="Deploying and debugging on attached Android device via ADB protocol.",
            )

        if provider.provider_type == ProviderType.WINE:
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=True,
                requires_second_device=False,
                runner_command=["wine"],
                rationale="Executing locally via isolated Wine prefix with DXVK translation.",
            )

        if provider.provider_type == ProviderType.REMOTE_BRIDGE:
            node = provider.metadata.get("hostname", "remote-mac")
            return ExecutionPlan(
                target_os=req.target_os,
                provider_type=provider.provider_type,
                provider_id=provider.provider_id,
                is_local=False,
                requires_second_device=True,
                runner_command=["megas_bridge", "dispatch", f"--node={node}"],
                rationale=f"Routing execution to authorized genuine Apple node '{node}' via Megas Platform Bridge over LAN.",
                metadata=dict(provider.metadata),
            )

        return ExecutionPlan(
            target_os=req.target_os,
            provider_type=provider.provider_type,
            provider_id=provider.provider_id,
            is_local=provider.is_local,
            requires_second_device=not provider.is_local,
            runner_command=["custom_exec"],
            rationale="Executing via specialized provider.",
        )
