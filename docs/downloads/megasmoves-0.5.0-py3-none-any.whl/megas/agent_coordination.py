"""Accountable coordination over the existing action/task authority.

Coordination changes records only. Starting an agent remains a separate typed
execution operation; handoff text is context, never an executable command.
"""
from __future__ import annotations

import json
from jsonschema import validate
from megas.agent_tasks import AgentTaskStore, _now

TASK = {"type": "string", "pattern": "^task_[a-f0-9]{32}$"}
CLIENT = {"type": "string", "pattern": "^[a-z0-9._-]{1,64}$"}
TEXT = {"type": "string", "minLength": 1, "maxLength": 4000}


def tools():
    common = {"task_id": TASK, "client": CLIENT,
              "expected_generation": {"type": "integer", "minimum": 0}}
    specs = [
        ("board", {"limit": {"type": "integer", "minimum": 1, "maximum": 100},
                   "offset": {"type": "integer", "minimum": 0, "maximum": 2000},
                   "include_terminal": {"type": "boolean"}}, [],
         "Read a bounded page of tasks, owners, dependencies and handoffs. Start here before claiming work; use development_checkpoint_read for full continuation."),
        ("claim", common, list(common), "Claim an available task using its current generation. Rejects competing owners and incomplete dependencies. Does not start execution."),
        ("handoff", {**common, "summary": TEXT, "next_action": TEXT},
         [*common, "summary", "next_action"], "Pause owned work with a durable summary and exact next action. A later claim retains context; no work is silently replayed."),
        ("complete", {**common, "evidence": {"type": "array", "items": TEXT, "minItems": 1, "maxItems": 32}},
         [*common, "evidence"], "Complete owned work with supplied evidence and completed dependencies. Evidence is recorded as agent-reported, not independently verified."),
    ]
    return [{"name": "agent_coordination_"+name, "description": description,
             "inputSchema": {"type": "object", "properties": fields, "required": required, "additionalProperties": False},
             "annotations": {"readOnlyHint": name == "board", "destructiveHint": False, "openWorldHint": False}}
            for name, fields, required, description in specs]


class AgentCoordination:
    def __init__(self, home=None, *, authorize=None):
        self.store = AgentTaskStore(home)
        self.authorize = authorize

    def _authorize(self, task):
        if task.project_authority_scope:
            if self.authorize is None:
                raise PermissionError("linked account authorization required")
            self.authorize(task)

    @staticmethod
    def _result(value):
        return {"content": [{"type": "text", "text": json.dumps(value, sort_keys=True)}],
                "structuredContent": value, "isError": False}

    def call(self, name, arguments):
        definition = next((tool for tool in tools() if tool['name'] == name), None)
        if definition is None:
            raise ValueError("unknown coordination operation")
        validate(arguments, definition['inputSchema'])
        with self.store._lock():
            tasks = self.store._load_unlocked()
            if name == 'agent_coordination_board':
                visible = []
                for task in tasks:
                    try:
                        self._authorize(task)
                    except PermissionError:
                        continue
                    if task.state in {'completed', 'cancelled'} and not arguments.get('include_terminal', False):
                        continue
                    visible.append(task)
                visible.sort(key=lambda task: task.id)
                offset, limit = arguments.get('offset', 0), arguments.get('limit', 25)
                rows = []
                size = 0
                for task in visible[offset:offset+limit]:
                    handoff = task.shared_context.get('coordination') or {}
                    row = {'id': task.id, 'title': task.title[:256], 'action_id': task.action_id,
                           'state': task.state, 'owner': task.assigned_client,
                           'generation': task.assignment_generation, 'depends_on': task.depends_on,
                           'has_checkpoint': bool(task.continuity),
                           'handoff': {key: str(handoff.get(key) or '')[:1000] for key in ['summary', 'next_action', 'reported_by']}}
                    size += len(json.dumps(row).encode('utf-8'))
                    if size > 96*1024:
                        break
                    rows.append(row)
                next_offset = offset+len(rows)
                return self._result({'tasks': rows, 'execution_started': False,
                                     'next_offset': next_offset if next_offset < len(visible) else None,
                                     'workflow': ['inspect', 'claim', 'execute', 'checkpoint', 'handoff or complete']})
            task = next((task for task in tasks if task.id == arguments['task_id']), None)
            if task is None:
                raise KeyError('unknown task')
            self._authorize(task)
            if task.assignment_generation != arguments['expected_generation']:
                raise RuntimeError('stale task generation; read the coordination board again')
            if task.state in {'completed', 'cancelled'}:
                raise RuntimeError('terminal task cannot be changed')
            if task.assigned_client and task.assigned_client != arguments['client']:
                raise RuntimeError('task is owned by another agent; explicit human reassignment is required')
            for dependency in task.depends_on:
                required = next((item for item in tasks if item.id == dependency), None)
                if required is None:
                    raise RuntimeError('task dependency is unavailable')
                self._authorize(required)
                if required.state != 'completed' and name != 'agent_coordination_handoff':
                    raise RuntimeError('task dependencies are incomplete')
            if name != 'agent_coordination_claim' and task.assigned_client != arguments['client']:
                raise RuntimeError('claim the task before reporting work')
            task.assignment_generation += 1
            task.updated_at = _now()
            if name == 'agent_coordination_claim':
                task.assigned_client = arguments['client']
                task.state = 'assigned'
            elif name == 'agent_coordination_handoff':
                task.state = 'paused'
                task.assigned_client = None
                task.shared_context['coordination'] = {'summary': arguments['summary'],
                    'next_action': arguments['next_action'], 'reported_by': arguments['client'], 'at': task.updated_at}
            else:
                task.state = 'completed'
                task.completion_note = '\n'.join(arguments['evidence'])[:4000]
                task.shared_context['completion_evidence'] = {'items': arguments['evidence'],
                    'reported_by': arguments['client'], 'independently_verified': False, 'at': task.updated_at}
            task.assignment_history.append({'at': task.updated_at, 'generation': task.assignment_generation,
                                           'to': task.assigned_client, 'event': name})
            task.validate()
            self.store._save_unlocked(tasks)
            return self._result({'task': task.to_dict(), 'execution_started': False})
