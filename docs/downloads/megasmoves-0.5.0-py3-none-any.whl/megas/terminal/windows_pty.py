"""Windows TTY adapter for human CLI sessions, using pinned pywinpty."""
from __future__ import annotations

import time
import shutil
import subprocess
from pathlib import Path


class _Input:
    def __init__(self, process):
        self.process = process

    def write(self, text):
        return self.process.write(text.replace('\r\n', '\r').replace('\n', '\r'))

    def flush(self):
        pass


class _Output:
    def __init__(self, process):
        self.process = process

    def readline(self, limit=8192):
        # Read chunks, not complete lines: interactive CLI prompts need not
        # contain a newline, and a single long line must stay bounded.
        try:
            return self.process.read(limit)
        except EOFError:
            return ''

    def close(self):
        pass


class WindowsPtyProcess:
    def __init__(self, argv, *, cwd, env):
        from winpty import Backend, PTY, PtyProcess
        executable = shutil.which(argv[0], path=env.get('PATH'))
        if executable is None:
            raise FileNotFoundError('Terminal program was not found')
        if Path(executable).suffix.lower() in {'.cmd', '.bat', '.ps1'}:
            from megas.adapters.base import resolve_cli_argv
            resolved = resolve_cli_argv(executable, *argv[1:])
            if Path(resolved[0]).name.lower() in {'cmd.exe', 'powershell.exe', 'pwsh.exe'}:
                raise ValueError('This script shim cannot be launched without a shell; choose its native executable')
            executable, argv = resolved[0], resolved
        terminal = PTY(100, 30, backend=Backend.ConPTY)
        # ConPTY requires quoting the executable when its path contains
        # spaces. Keep the argument vector separate; never invoke a shell.
        terminal.spawn('"'+executable+'"', cmdline=' '+subprocess.list2cmdline(argv[1:]),
                       cwd=cwd, env='\0'.join(key+'='+value for key, value in env.items())+'\0')
        self.process = PtyProcess(terminal)
        self.pid = self.process.pid
        self.stdin = _Input(self.process)
        self.stdout = _Output(self.process)
        self.stderr = None  # TTY combines stdout/stderr into one ordered stream.

    def poll(self):
        return None if self.process.isalive() else self.process.exitstatus

    def wait(self):
        while self.process.isalive():
            time.sleep(.1)
        return self.process.exitstatus or 0

    def terminate(self):
        if not self.process.terminate(force=True):
            raise RuntimeError('TTY process did not terminate')

    def kill(self):
        self.terminate()
