"""Data models for multi-terminal session multiplexing in MegasMoves."""

from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Literal, Optional

TerminalState = Literal["running", "completed", "failed", "needs_input", "waiting_capacity", "terminated", "detached"]
StreamChannel = Literal["stdout", "stderr", "system", "needs_input"]


@dataclass
class TerminalEvent:
    seq: int
    session_id: str
    timestamp: float
    channel: StreamChannel
    text: str
    exit_code: Optional[int] = None
    needs_input: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class TerminalSession:
    session_id: str
    title: str
    command: list[str]
    cwd: str
    state: TerminalState = "running"
    started_at: float = field(default_factory=time.time)
    ended_at: Optional[float] = None
    exit_code: Optional[int] = None
    pid: Optional[int] = None
    sequence_head: int = 0
    needs_input: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def new(
        cls,
        command: list[str],
        cwd: str,
        title: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> TerminalSession:
        sid = f"term_{uuid.uuid4().hex[:12]}"
        default_title = (
            title or (command[0] if command else "Terminal")
        )
        return cls(
            session_id=sid,
            title=default_title,
            command=command,
            cwd=cwd,
            metadata=metadata or {},
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
