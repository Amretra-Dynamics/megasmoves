"""Multi-terminal session multiplexer and process supervisor for MegasMoves."""

from __future__ import annotations

import collections
import json
import logging
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from megas.adapters.base import subprocess_hide_window_kwargs
from megas.terminal_parse import detect_completion_in_text
from megas.policy import redact

from .models import TerminalEvent, TerminalSession, TerminalState

logger = logging.getLogger(__name__)

# Max output event history retained per session
DEFAULT_RING_CAPACITY = 5000


class TerminalSessionManager:
    """Supervises and multiplexes any number of concurrent terminal sessions."""

    def __init__(
        self,
        ring_capacity: int = DEFAULT_RING_CAPACITY,
        db_path: Optional[Path] = None,
    ):
        self.ring_capacity = ring_capacity
        self.db_path = db_path
        self._sessions: dict[str, TerminalSession] = {}
        self._buffers: dict[str, collections.deque[TerminalEvent]] = {}
        self._processes: dict[str, subprocess.Popen] = {}
        self._stdin_writers: dict[str, Any] = {}
        self._secret_values: dict[str, tuple[str, ...]] = {}
        self._lock = threading.RLock()
        self._notification_listeners: list[Callable[[TerminalSession, str], None]] = []

        if self.db_path:
            self._init_db()
            self._load_persisted_sessions()

        # Wire default decentralized notification listener
        self.register_notification_listener(self._default_decentralized_notify)

    def _init_db(self) -> None:
        if not self.db_path:
            return
        try:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(str(self.db_path), timeout=15.0) as conn:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS local_terminal_sessions (
                        session_id TEXT PRIMARY KEY,
                        command_json TEXT NOT NULL,
                        cwd TEXT NOT NULL,
                        title TEXT NOT NULL,
                        state TEXT NOT NULL,
                        pid INTEGER,
                        started_at REAL NOT NULL,
                        ended_at REAL,
                        exit_code INTEGER,
                        sequence_head INTEGER NOT NULL DEFAULT -1,
                        metadata_json TEXT NOT NULL DEFAULT '{}'
                    )
                    """
                )
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS local_terminal_events (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        session_id TEXT NOT NULL,
                        seq INTEGER NOT NULL,
                        timestamp REAL NOT NULL,
                        channel TEXT NOT NULL,
                        text TEXT NOT NULL,
                        exit_code INTEGER,
                        needs_input INTEGER NOT NULL DEFAULT 0,
                        UNIQUE(session_id, seq)
                    )
                    """
                )
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_term_events_sess_seq ON local_terminal_events(session_id, seq)"
                )
        except Exception as exc:
            logger.debug("Terminal DB initialization error: %s", exc)

    def _load_persisted_sessions(self) -> None:
        if not self.db_path:
            return
        try:
            with sqlite3.connect(str(self.db_path), timeout=15.0) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    "SELECT * FROM local_terminal_sessions ORDER BY started_at DESC LIMIT 50"
                ).fetchall()
                for row in rows:
                    sess = TerminalSession(
                        session_id=row["session_id"],
                        command=json.loads(row["command_json"]),
                        cwd=row["cwd"],
                        title=row["title"],
                        state=row["state"],
                        pid=row["pid"],
                        started_at=row["started_at"],
                        ended_at=row["ended_at"],
                        exit_code=row["exit_code"],
                        sequence_head=row["sequence_head"],
                        metadata=json.loads(row["metadata_json"] or "{}"),
                    )
                    if sess.state in {"running", "needs_input"}:
                        # A saved PID is not proof that this manager owns the
                        # process after restart. Preserve context without ever
                        # attaching to or killing an unrelated reused PID.
                        sess.state = "detached"
                        sess.metadata["recovery_reason"] = "supervisor_not_attached_after_restart"
                        sess.pid = None
                    with self._lock:
                        if sess.session_id not in self._sessions:
                            self._sessions[sess.session_id] = sess
                            self._buffers[sess.session_id] = collections.deque(
                                maxlen=self.ring_capacity
                            )
        except Exception as exc:
            logger.debug("Terminal DB load error: %s", exc)

    def _persist_session(self, session: TerminalSession) -> None:
        if not self.db_path:
            return
        try:
            with sqlite3.connect(str(self.db_path), timeout=15.0) as conn:
                conn.execute(
                    """
                    INSERT INTO local_terminal_sessions (
                        session_id, command_json, cwd, title, state, pid, started_at, ended_at, exit_code, sequence_head, metadata_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(session_id) DO UPDATE SET
                        state=excluded.state,
                        pid=excluded.pid,
                        ended_at=excluded.ended_at,
                        exit_code=excluded.exit_code,
                        sequence_head=excluded.sequence_head,
                        metadata_json=excluded.metadata_json
                    """,
                    (
                        session.session_id,
                        json.dumps(session.command),
                        session.cwd,
                        session.title,
                        session.state,
                        session.pid,
                        session.started_at,
                        session.ended_at,
                        session.exit_code,
                        session.sequence_head,
                        json.dumps(session.metadata or {}),
                    ),
                )
        except Exception as exc:
            logger.debug("Terminal DB session persist error: %s", exc)

    def _persist_event(self, event: TerminalEvent) -> None:
        if not self.db_path:
            return
        try:
            with sqlite3.connect(str(self.db_path), timeout=15.0) as conn:
                conn.execute(
                    """
                    INSERT OR IGNORE INTO local_terminal_events (
                        session_id, seq, timestamp, channel, text, exit_code, needs_input
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        event.session_id,
                        event.seq,
                        event.timestamp,
                        event.channel,
                        event.text,
                        event.exit_code,
                        1 if event.needs_input else 0,
                    ),
                )
                conn.execute(
                    "UPDATE local_terminal_sessions SET sequence_head=? WHERE session_id=?",
                    (event.seq, event.session_id),
                )
        except Exception as exc:
            logger.debug("Terminal DB event persist error: %s", exc)

    def register_notification_listener(
        self, callback: Callable[[TerminalSession, str], None]
    ) -> None:
        with self._lock:
            if callback not in self._notification_listeners:
                self._notification_listeners.append(callback)

    def _default_decentralized_notify(
        self, session: TerminalSession, event_kind: str
    ) -> None:
        """Dispatch high-signal lifecycle events to decentralized direct channels."""
        title = f"Megas: {session.title}"
        msg = f"Session '{session.title}' {event_kind.replace('_', ' ')}."
        if session.exit_code is not None:
            msg += f" (Exit code: {session.exit_code})"

        try:
            # Append to decentralized notification ledger (~/.megas/notifications.jsonl)
            # which is served by Local Gateway (/api/local/v1/notifications) to Android APK
            from pathlib import Path
            import json
            import time

            notif_dir = Path.home() / ".megas"
            notif_dir.mkdir(parents=True, exist_ok=True)
            notif_log = notif_dir / "notifications.jsonl"
            record = {
                "timestamp": time.time(),
                "title": title,
                "message": msg,
                "level": "error" if event_kind == "task_failed" else "info",
                "event_type": event_kind,
                "session_id": session.session_id,
                "channels": ["local_history"],
            }
            with open(notif_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

            # Attempt relay delivery as a separate best-effort path; local history is not delivery proof.
            try:
                from megas.local.peer_mesh.controller import current_peer_mesh
                mesh = current_peer_mesh()
                if mesh is not None:
                    mesh.send_notification(
                        title=title,
                        message=msg,
                        level="error" if event_kind == "task_failed" else "info",
                        event_type=event_kind,
                    )
            except Exception as mesh_err:
                logger.debug("P2P mesh notification send skipped: %s", mesh_err)
        except Exception as exc:
            logger.debug("Notification ledger write skipped: %s", exc)

    def create_session(
        self,
        command: list[str] | str,
        cwd: Optional[str] = None,
        title: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> TerminalSession:
        """Spawn a new concurrent terminal session."""
        if isinstance(command, str):
            raise ValueError("terminal commands require an explicit executable/argument list")
        else:
            cmd_list = list(command)
        if not cmd_list or len(cmd_list) > 64 or any(not isinstance(value, str) or not value or len(value) > 4096 or '\0' in value for value in cmd_list):
            raise ValueError("invalid or oversized terminal argument list")

        work_dir = cwd or os.getcwd()
        session = TerminalSession.new(
            command=cmd_list,
            cwd=work_dir,
            title=title,
            metadata=metadata,
        )

        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        self._secret_values[session.session_id] = tuple(value for key, value in merged_env.items()
            if any(marker in key.upper() for marker in ('TOKEN', 'SECRET', 'PASSWORD', 'API_KEY'))
            and isinstance(value, str) and 8 <= len(value) <= 16384)[:128]

        with self._lock:
            self._sessions[session.session_id] = session
            self._buffers[session.session_id] = collections.deque(
                maxlen=self.ring_capacity
            )

        kwargs = subprocess_hide_window_kwargs()
        if sys.platform == "win32":
            kwargs["creationflags"] = (
                kwargs.get("creationflags", 0) | subprocess.CREATE_NEW_PROCESS_GROUP
            )

        try:
            # Spawn process
            if sys.platform == "win32" and session.metadata.get("interactive") is True:
                from .windows_pty import WindowsPtyProcess
                proc = WindowsPtyProcess(cmd_list, cwd=work_dir, env=merged_env)
            else:
                proc = subprocess.Popen(
                cmd_list,
                cwd=work_dir,
                env=merged_env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                **kwargs,
                )
        except Exception as exc:
            session.state = "failed"
            session.ended_at = time.time()
            self._append_event(
                session.session_id,
                channel="system",
                text=f"Failed to start process: {exc}\n",
                exit_code=-1,
            )
            return session

        session.pid = proc.pid
        with self._lock:
            self._processes[session.session_id] = proc
            self._stdin_writers[session.session_id] = proc.stdin

        self._persist_session(session)

        # Start background reader threads for stdout and stderr
        t_out = threading.Thread(
            target=self._read_pipe,
            args=(session.session_id, proc.stdout, "stdout"),
            daemon=True,
            name=f"term-stdout-{session.session_id}",
        )
        t_err = threading.Thread(
            target=self._read_pipe,
            args=(session.session_id, proc.stderr, "stderr"),
            daemon=True,
            name=f"term-stderr-{session.session_id}",
        )
        t_wait = threading.Thread(
            target=self._wait_process,
            args=(session.session_id, proc),
            daemon=True,
            name=f"term-wait-{session.session_id}",
        )

        t_out.start()
        t_err.start()
        t_wait.start()

        return session

    def _append_event(
        self,
        session_id: str,
        channel: str,
        text: str,
        exit_code: Optional[int] = None,
        needs_input: bool = False,
    ) -> TerminalEvent:
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                raise KeyError(f"Session {session_id} not found")
            session.sequence_head += 1
            text = text[:8192]
            for secret in self._secret_values.get(session_id, ()):
                text = text.replace(secret, '[REDACTED]')
            event = TerminalEvent(
                seq=session.sequence_head,
                session_id=session_id,
                timestamp=time.time(),
                channel=channel,  # type: ignore
                text=redact(re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text[:8192])),
                exit_code=exit_code,
                needs_input=needs_input,
            )
            buf = self._buffers.get(session_id)
            if buf is not None:
                buf.append(event)
        self._persist_event(event)
        return event

    def _read_pipe(self, session_id: str, pipe: Any, channel: str) -> None:
        if not pipe:
            return
        try:
            for chunk in iter(lambda: pipe.readline(8192), ""):
                if not chunk:
                    break
                lines = [chunk]
                for line in lines:
                    self._observe_agent_output(session_id, line)
                    # Check for completion or input prompts
                    hit = detect_completion_in_text(line)
                    needs_in = False
                    if "?" in line or "([y]/n)" in line.lower() or "continue?" in line.lower():
                        needs_in = True
                    self._append_event(
                        session_id,
                        channel=channel,
                        text=line,
                        exit_code=hit.exit_code if hit else None,
                        needs_input=needs_in,
                    )
        except Exception as exc:
            logger.debug("Pipe reading error for session %s: %s", session_id, exc)
        finally:
            try:
                pipe.close()
            except Exception:
                pass

    def _wait_process(self, session_id: str, proc: subprocess.Popen) -> None:
        retcode = proc.wait()
        with self._lock:
            session = self._sessions.get(session_id)
            if session:
                session.exit_code = retcode
                session.ended_at = time.time()
                if session.state not in {"waiting_capacity", "terminated"}:
                    session.state = "completed" if retcode == 0 else "failed"
                self._persist_session(session)

        self._append_event(
            session_id,
            channel="system",
            text=f"\n[Process exited with code {retcode}]\n",
            exit_code=retcode,
        )

        if session:
            self._persist_session(session)
            event_kind = "task_completed" if retcode == 0 else "task_failed"
            for listener in list(self._notification_listeners):
                try:
                    listener(session, event_kind)
                except Exception as exc:
                    logger.debug("Notification listener error: %s", exc)

    def list_sessions(self) -> list[TerminalSession]:
        with self._lock:
            return [TerminalSession(**session.to_dict()) for session in self._sessions.values()]

    def _observe_agent_output(self, session_id: str, text: str) -> None:
        """Preserve supported structured identity and observed capacity loss.

        Output is evidence, not authority to launch or resume another process.
        A provider must independently verify identity before a native resume.
        """
        native_id = None
        capacity = text.strip().lower().startswith(('quota exceeded', 'rate limit exceeded',
                                                   'error: quota exceeded', 'error: rate limit exceeded'))
        try:
            message = json.loads(text)
            if isinstance(message, dict) and message.get('type') == 'thread.started':
                native_id = message.get('thread_id')
            elif isinstance(message, dict) and message.get('type') == 'system' and message.get('subtype') == 'init':
                native_id = message.get('session_id')
            elif isinstance(message, dict) and message.get('type') == 'error':
                error = message.get('error') or message
                if isinstance(error, dict):
                    capacity = error.get('code') in {'rate_limit_exceeded', 'usage_limit_exceeded', 'quota_exceeded'}
        except ValueError:
            pass
        if native_id is None and not capacity:
            return
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return
            if isinstance(native_id, str) and 0 < len(native_id) <= 200 and '\n' not in native_id:
                session.metadata['native_thread_id'] = native_id
                session.metadata['native_resume_verified'] = False
            if capacity:
                session.state = 'waiting_capacity'
                session.metadata['interruption'] = 'capacity_reported_by_process'
            metadata = dict(session.metadata)
            self._persist_session(session)
        if not capacity or not metadata.get('task_id'):
            return
        from megas.agent_tasks import AgentTaskStore, _now
        store = AgentTaskStore()
        with store._lock():
            tasks = store._load_unlocked()
            task = next((item for item in tasks if item.id == metadata['task_id']), None)
            if task is None or task.state in {'completed', 'cancelled'} or task.assignment_generation != metadata.get('assignment_generation'):
                return
            task.state = 'waiting_capacity'
            task.updated_at = _now()
            task.shared_context['terminal_interruption'] = {
                'session_id': session_id, 'native_thread_id': metadata.get('native_thread_id'),
                'native_resume_verified': False, 'reason': 'capacity_reported_by_process',
                'reset_at': None, 'at': task.updated_at}
            store._save_unlocked(tasks)

    def get_session(self, session_id: str) -> Optional[TerminalSession]:
        with self._lock:
            s = self._sessions.get(session_id)
            return TerminalSession(**s.to_dict()) if s else None

    def read_output(
        self, session_id: str, after_seq: int = -1, limit: int = 200
    ) -> list[TerminalEvent]:
        with self._lock:
            buf = self._buffers.get(session_id)
            if buf:
                events: list[TerminalEvent] = []
                for ev in buf:
                    if ev.seq > after_seq:
                        events.append(ev)
                        if len(events) >= limit:
                            break
                if events:
                    return events

        # Fallback to reading from SQLite local.db
        if self.db_path:
            try:
                with sqlite3.connect(str(self.db_path), timeout=15.0) as conn:
                    conn.row_factory = sqlite3.Row
                    rows = conn.execute(
                        """
                        SELECT seq, session_id, timestamp, channel, text, exit_code, needs_input
                        FROM local_terminal_events
                        WHERE session_id=? AND seq > ?
                        ORDER BY seq ASC
                        LIMIT ?
                        """,
                        (session_id, after_seq, limit),
                    ).fetchall()
                    return [
                        TerminalEvent(
                            seq=r["seq"],
                            session_id=r["session_id"],
                            timestamp=r["timestamp"],
                            channel=r["channel"],
                            text=r["text"],
                            exit_code=r["exit_code"],
                            needs_input=bool(r["needs_input"]),
                        )
                        for r in rows
                    ]
            except Exception as exc:
                logger.debug("Read output from DB error: %s", exc)
        return []

    def send_input(self, session_id: str, text: str) -> bool:
        """Send stdin to the active terminal process."""
        with self._lock:
            writer = self._stdin_writers.get(session_id)
            proc = self._processes.get(session_id)
            if not writer or not proc or proc.poll() is not None:
                return False

        try:
            writer.write(text if text.endswith("\n") else text + "\n")
            writer.flush()
            # Interactive input can be a password/token. Never echo it into
            # durable terminal history; process output is redacted separately.
            self._append_event(session_id, channel="system", text="[Input sent]\n")
            return True
        except Exception as exc:
            logger.debug("Failed to write to terminal stdin: %s", exc)
            return False

    def terminate_session(self, session_id: str, force: bool = False) -> bool:
        """Terminate or kill a running terminal session."""
        with self._lock:
            proc = self._processes.get(session_id)
            session = self._sessions.get(session_id)
            if not proc or not session:
                return False

        try:
            if force:
                proc.kill()
            else:
                proc.terminate()
            session.state = "terminated"
            session.ended_at = time.time()
            self._persist_session(session)
            return True
        except Exception as exc:
            logger.debug("Failed to terminate session %s: %s", session_id, exc)
            return False


# Global singleton instance
_GLOBAL_MANAGER: Optional[TerminalSessionManager] = None
_GLOBAL_LOCK = threading.Lock()


def get_session_manager(db_path: Optional[Path] = None) -> TerminalSessionManager:
    global _GLOBAL_MANAGER
    with _GLOBAL_LOCK:
        if _GLOBAL_MANAGER is None:
            resolved = db_path
            if resolved is None:
                try:
                    from megas.unified_runtime import local_database_path

                    resolved = local_database_path()
                except Exception:
                    resolved = None
            _GLOBAL_MANAGER = TerminalSessionManager(db_path=resolved)
        return _GLOBAL_MANAGER
