"""Operational todos attached to authorized Chitraagni project identities."""
from __future__ import annotations

import hashlib
import json
from datetime import date
from uuid import UUID

from jsonschema import validate
from megas.agent_tasks import AgentTaskStore, TaskRecord, TASK_STATES, MAX_TASKS, _now

TEXT = {"type": "string", "minLength": 1, "maxLength": 256}
PROJECT_ID = {"type": "string", "pattern": "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"}
TASK_FIELDS = {
    "title": {"type": "string", "minLength": 1, "maxLength": 4000},
    "description": {"type": "string", "maxLength": 16000},
    "priority": {"type": "string", "enum": ["low", "medium", "high", "urgent"]},
    "due_date": {"type": ["string", "null"], "pattern": "^\\d{4}-\\d{2}-\\d{2}$"},
    "depends_on": {"type": "array", "items": TEXT, "uniqueItems": True, "maxItems": 32},
}


def _schema(properties, required=()):
    return {"type": "object", "properties": properties, "required": list(required), "additionalProperties": False}


def tools():
    specs = [
        ("project_list", "List projects from the linked user's authorized Chitraagni ecosystem with local Megas execution progress. Chitraagni owns project identity; no separate Megas project registry.", _schema({}), True, False),
        ("project_board", "Read an authorized Chitraagni project and its Megas operational todos, dependencies and next actions.", _schema({"project_id": PROJECT_ID}, ["project_id"]), True, False),
        ("project_sync_owned", "Synchronize explicitly registered Megas local software workspaces into an authorized Chitraagni workspace. Creates or adopts missing Projects, persists only scoped source-to-Project bindings locally, reports drift, and never deletes Projects.", _schema({"workspace_id": PROJECT_ID}), False, False),
        ("project_link", "Attach a preserved legacy Megas plan and its todos to an existing authorized Chitraagni project. Explicit migration preserves task IDs and history; creates no project or folder trust.", _schema({"project_id": PROJECT_ID, "legacy_project_id": TEXT}, ["project_id", "legacy_project_id"]), False, True),
        ("todo_create", "Save an operational todo against an existing authorized Chitraagni project. Use its returned project ID; planning does not execute work.", _schema({"project_id": PROJECT_ID, **TASK_FIELDS}, ["project_id", "title"]), False, False),
        ("todo_update", "Update an operational todo after verifying access to its Chitraagni project. Completion requires evidence and completed dependencies.", _schema({"task_id": TEXT, **TASK_FIELDS, "state": {"type": "string", "enum": sorted(TASK_STATES)}, "completion_note": {"type": "string", "maxLength": 4000}}, ["task_id"]), False, False),
    ]
    return [{"name": "megas_" + name, "description": description, "inputSchema": schema,
             "annotations": {"readOnlyHint": read, "destructiveHint": destructive, "openWorldHint": True}}
            for name, description, schema, read, destructive in specs]


class WorkPlanning:
    def __init__(self, home=None, *, chitraagni_call=None, authority_scope=None, owned_projects_call=None):
        self.store = AgentTaskStore(home)
        self.chitraagni_call = chitraagni_call
        self.authority_scope = authority_scope
        self.owned_projects_call = owned_projects_call
        self.owned_sync_path = self.store.root / "owned-project-sync.json"

    def _remote(self, name, arguments):
        if self.chitraagni_call is None or not self.authority_scope:
            raise PermissionError("Link Chitraagni and grant the reviewed project tools before using ecosystem planning")
        response = self.chitraagni_call(name, arguments)
        if response.get("isError") is not False or "structuredContent" not in response:
            raise RuntimeError("Chitraagni project operation failed")
        return response["structuredContent"]

    @staticmethod
    def _project_id(value):
        try:
            return str(UUID(value))
        except (ValueError, TypeError, AttributeError) as exc:
            raise ValueError("project_id must be a Chitraagni UUID") from exc

    def _project(self, project_id):
        identifier = self._project_id(project_id)
        project = self._remote("chitraagni_project_get", {"project_id": identifier})
        if not isinstance(project, dict) or self._project_id(project.get("id")) != identifier:
            raise RuntimeError("Chitraagni returned a different or invalid project")
        return project

    @staticmethod
    def _workspace_id(value):
        try:
            return str(UUID(value))
        except (ValueError, TypeError, AttributeError) as exc:
            raise ValueError("workspace_id must be a Chitraagni UUID") from exc

    def _owned_sources(self):
        if self.owned_projects_call is None:
            raise RuntimeError("Megas owned-project discovery is unavailable")
        rows = self.owned_projects_call()
        if isinstance(rows, dict):
            rows = rows.get("projects")
        if not isinstance(rows, list) or len(rows) > 1000:
            raise RuntimeError("Megas owned-project inventory is invalid or exceeds the supported limit")
        result = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                raise RuntimeError("Megas owned-project inventory contains an invalid row")
            name = str(row.get("name") or "").strip()
            if not name or len(name) > 256:
                raise RuntimeError("Megas owned-project inventory contains an invalid project name")
            seed = row.get("source_id") or row.get("manifest") or row.get("root") or ("name:" + name.casefold())
            normalized_seed = str(seed).strip().replace("\\", "/").casefold()
            source_id = hashlib.sha256(("megas-owned-project:v1:" + normalized_seed).encode("utf-8")).hexdigest()
            if source_id in seen:
                raise RuntimeError("Megas owned-project inventory contains a duplicate source identity")
            seen.add(source_id)
            services = row.get("services")
            if isinstance(services, dict):
                services = sorted(str(key) for key in services)[:64]
            elif isinstance(services, list):
                services = [str(value)[:128] for value in services[:64]]
            else:
                services = []
            result.append({
                "source_id": source_id,
                "name": name,
                "product_type": str(row.get("product_type") or "software")[:256],
                "domain": str(row.get("domain") or "")[:256],
                "services": services,
                "local_status": str(row.get("status") or "")[:128],
            })
        return result

    def _load_owned_sync_unlocked(self):
        if not self.owned_sync_path.exists():
            return {"version": 1, "scopes": {}}
        try:
            value = json.loads(self.owned_sync_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError("Megas owned-project sync state is unreadable") from exc
        if not isinstance(value, dict) or value.get("version") != 1 or not isinstance(value.get("scopes"), dict):
            raise RuntimeError("Megas owned-project sync state has an unsupported format")
        return value

    def _select_sync_workspace(self, requested_id=None):
        workspaces = self._remote("chitraagni_workspaces_list", {})
        if not isinstance(workspaces, list) or len(workspaces) > 1000:
            raise RuntimeError("Chitraagni workspace list is invalid or exceeds the supported limit")
        normalized = []
        for row in workspaces:
            if not isinstance(row, dict):
                raise RuntimeError("Chitraagni workspace list contains an invalid row")
            identifier = self._workspace_id(row.get("id"))
            normalized.append({**row, "id": identifier})
        if requested_id:
            identifier = self._workspace_id(requested_id)
            match = next((row for row in normalized if row["id"] == identifier), None)
            if match is None:
                raise PermissionError("Requested Chitraagni workspace is not authorized for the linked account")
            return match
        if len(normalized) == 1:
            return normalized[0]
        if not normalized:
            raise RuntimeError("Linked Chitraagni account has no authorized workspaces")
        raise ValueError("workspace_id is required when more than one Chitraagni workspace is authorized")

    @staticmethod
    def _project_name_key(value):
        return " ".join(str(value or "").split()).casefold()

    def sync_owned_projects(self, workspace_id=None):
        sources = self._owned_sources()
        workspace = self._select_sync_workspace(workspace_id)
        workspace_id = self._workspace_id(workspace["id"])
        remote_projects = self._remote("chitraagni_workspace_projects_list", {"workspace_id": workspace_id})
        if not isinstance(remote_projects, list) or len(remote_projects) > 1000:
            raise RuntimeError("Chitraagni workspace project list is invalid or exceeds the supported limit")
        by_id = {}
        by_name = {}
        for row in remote_projects:
            if not isinstance(row, dict):
                raise RuntimeError("Chitraagni project list contains an invalid row")
            identifier = self._project_id(row.get("id"))
            project = {**row, "id": identifier}
            by_id[identifier] = project
            by_name.setdefault(self._project_name_key(project.get("name")), []).append(project)

        with self.store._lock():
            document = self._load_owned_sync_unlocked()
            scopes = document.setdefault("scopes", {})
            bindings = scopes.setdefault(self.authority_scope, {})
            if not isinstance(bindings, dict):
                raise RuntimeError("Megas owned-project sync scope is invalid")

            rows = []
            created_ids = []
            active_source_ids = {source["source_id"] for source in sources}
            for source in sources:
                source_id = source["source_id"]
                binding = bindings.get(source_id)
                if binding is not None and not isinstance(binding, dict):
                    raise RuntimeError("Megas owned-project sync binding is invalid")

                project = None
                state = "linked"
                if binding:
                    bound_workspace = str(binding.get("workspace_id") or "")
                    if bound_workspace and bound_workspace != workspace_id:
                        rows.append({
                            **source,
                            "sync_state": "workspace_conflict",
                            "project_id": binding.get("project_id"),
                            "bound_workspace_id": bound_workspace,
                        })
                        continue
                    try:
                        bound_project_id = self._project_id(binding.get("project_id"))
                    except ValueError:
                        bound_project_id = ""
                    project = by_id.get(bound_project_id)
                    if project is None:
                        state = "recovered"
                else:
                    state = "adopted"

                if project is None:
                    matches = by_name.get(self._project_name_key(source["name"]), [])
                    if len(matches) > 1:
                        rows.append({
                            **source,
                            "sync_state": "ambiguous_remote_name",
                            "matching_project_ids": [row["id"] for row in matches],
                        })
                        continue
                    if len(matches) == 1:
                        project = matches[0]
                    else:
                        payload = {
                            "workspace_id": workspace_id,
                            "name": source["name"],
                            "description": "Owned software project synchronized by Megas Moves.",
                            "product_type": source["product_type"],
                            "domain": source["domain"],
                        }
                        created = self._remote("chitraagni_project_create", payload)
                        if not isinstance(created, dict):
                            raise RuntimeError("Chitraagni project creation returned an invalid response")
                        project_id = self._project_id(created.get("id"))
                        project = {**created, "id": project_id, "name": str(created.get("name") or source["name"])}
                        by_id[project_id] = project
                        by_name.setdefault(self._project_name_key(project["name"]), []).append(project)
                        created_ids.append(project_id)
                        state = "created"

                project_id = self._project_id(project["id"])
                remote_name = str(project.get("name") or "")
                if binding and state == "linked" and self._project_name_key(remote_name) != self._project_name_key(source["name"]):
                    state = "name_drift"
                bindings[source_id] = {
                    "project_id": project_id,
                    "workspace_id": workspace_id,
                    "source_name": source["name"],
                    "remote_name": remote_name,
                    "last_seen_at": _now(),
                }
                rows.append({
                    **source,
                    "sync_state": state,
                    "project_id": project_id,
                    "remote_name": remote_name,
                })

            inactive = [
                {
                    "source_id": source_id,
                    "project_id": binding.get("project_id"),
                    "workspace_id": binding.get("workspace_id"),
                    "source_name": binding.get("source_name"),
                }
                for source_id, binding in bindings.items()
                if source_id not in active_source_ids and isinstance(binding, dict)
            ]
            document["updated_at"] = _now()
            self.store._atomic(self.owned_sync_path, document)

        return {
            "project_source": "chitraagni",
            "owned_source": "megas_workspace_projects",
            "workspace": {"id": workspace_id, "name": workspace.get("name")},
            "projects": rows,
            "created_project_ids": created_ids,
            "inactive_sources": inactive,
            "remote_deletes_performed": 0,
        }

    def _owned_binding_by_project(self):
        if not self.authority_scope:
            return {}
        with self.store._lock():
            document = self._load_owned_sync_unlocked()
        bindings = document.get("scopes", {}).get(self.authority_scope, {})
        if not isinstance(bindings, dict):
            return {}
        return {
            str(row.get("project_id")): {"source_id": source_id, **row}
            for source_id, row in bindings.items()
            if isinstance(row, dict) and row.get("project_id")
        }

    @staticmethod
    def _dependencies(tasks):
        by_id = {task.id: task for task in tasks}
        visiting, visited = set(), set()
        def visit(task):
            if task.id in visiting:
                raise ValueError("todo dependencies contain a cycle")
            if task.id in visited:
                return
            visiting.add(task.id)
            for identifier in task.depends_on:
                dependency = by_id.get(identifier)
                if dependency is None or (dependency.project, dependency.project_authority_scope) != (task.project, task.project_authority_scope):
                    raise ValueError("dependency must be an existing todo in the same project and account scope")
                visit(dependency)
            visiting.remove(task.id)
            visited.add(task.id)
        for task in tasks:
            visit(task)

    def _board(self, project, records):
        identifier = self._project_id(project["id"])
        tasks = [x.to_dict() for x in records if x.project == identifier and x.project_authority_scope == self.authority_scope]
        by_id = {x["id"]: x for x in tasks}
        for task in tasks:
            task["blocked_by"] = [x for x in task["depends_on"] if by_id.get(x, {}).get("state") != "completed"]
            task["overdue"] = bool(task["due_date"] and task["due_date"] < date.today().isoformat() and task["state"] not in {"completed", "cancelled"})
        ranks = {"urgent": 0, "high": 1, "medium": 2, "low": 3}
        ready = [x for x in tasks if not x["blocked_by"] and x["state"] in {"open", "assigned"}]
        ready.sort(key=lambda x: (not x["overdue"], ranks[x["priority"]], x["due_date"] or "9999-12-31", x["created_at"]))
        return {"project": project, "project_source": "chitraagni", "todos": tasks, "next_actions": ready[:20],
                "progress": {"total": len(tasks), "completed": sum(x["state"] == "completed" for x in tasks), "blocked": sum(bool(x["blocked_by"]) for x in tasks)}}

    def board(self, project_id):
        project = self._project(project_id)
        return self._board(project, self.store._load_unlocked())

    def call(self, name, arguments):
        tool = next((x for x in tools() if x["name"] == name), None)
        if tool is None:
            raise KeyError(name)
        try:
            validate(arguments, tool["inputSchema"])
        except Exception as exc:
            raise ValueError("invalid planning tool arguments") from exc
        if name == "megas_project_board":
            result = self.board(arguments["project_id"])
        elif name == "megas_project_sync_owned":
            result = self.sync_owned_projects(arguments.get("workspace_id"))
        elif name == "megas_project_list":
            projects = self._remote("chitraagni_projects_list", {})
            if not isinstance(projects, list) or len(projects) > 1000:
                raise RuntimeError("Chitraagni project list is invalid or exceeds the supported limit")
            records = self.store._load_unlocked()
            owned = self._owned_binding_by_project()
            result = {
                "project_source": "chitraagni",
                "projects": [
                    {
                        **x,
                        "progress": self._board(x, records)["progress"],
                        **({"owned_sync": owned[str(x.get("id"))]} if str(x.get("id")) in owned else {}),
                    }
                    for x in projects
                ],
            }
        else:
            original = self.store.get(arguments["task_id"]) if name == "megas_todo_update" else None
            if original is not None and original.project_authority_scope != self.authority_scope:
                raise PermissionError("Todo is not attached to the linked Chitraagni account; explicitly link its legacy plan first")
            project = self._project(original.project if original else arguments["project_id"])
            project_id = self._project_id(project["id"])
            with self.store._lock():
                tasks = self.store._load_unlocked()
                if name == "megas_project_link":
                    document = json.loads(self.store.path.read_text(encoding="utf-8")) if self.store.path.exists() else {"projects": []}
                    legacy = next((x for x in document.get("projects", []) if x.get("id") == arguments["legacy_project_id"]), None)
                    if legacy is None:
                        raise KeyError("unknown preserved legacy plan")
                    if legacy.get("linked_project_id") and (legacy["linked_project_id"], legacy.get("authority_scope")) != (project_id, self.authority_scope):
                        raise PermissionError("Legacy plan is already linked to a different project or identity")
                    moved = [x for x in tasks if x.project == arguments["legacy_project_id"] and x.project_authority_scope is None]
                    if any(x.assigned_client or x.state in {"assigned", "running", "waiting_approval"} for x in moved):
                        raise ValueError("Stop or unassign active legacy tasks before linking their project")
                    for task in moved:
                        task.project = project_id
                        task.project_authority_scope = self.authority_scope
                        task.updated_at = _now()
                    self._dependencies(tasks)
                    legacy.update(linked_project_id=project_id, authority_scope=self.authority_scope)
                    document.update(version=1, tasks=[x.to_dict() for x in tasks])
                    self.store._atomic(self.store.path, document)
                    result = {"project": project, "project_source": "chitraagni", "migrated_task_ids": [x.id for x in moved]}
                else:
                    if name == "megas_todo_create":
                        if len(tasks) >= MAX_TASKS:
                            raise ValueError("todo capacity reached")
                        task = TaskRecord(project=project_id, project_authority_scope=self.authority_scope, **{k: v for k, v in arguments.items() if k in TASK_FIELDS})
                        tasks.append(task)
                    else:
                        task = next((x for x in tasks if x.id == arguments["task_id"]), None)
                        if task is None:
                            raise KeyError("unknown todo")
                        if (task.project, task.project_authority_scope) != (project_id, self.authority_scope):
                            raise PermissionError("Todo project binding changed during the operation")
                        for key, value in arguments.items():
                            if key != "task_id":
                                setattr(task, key, value)
                        task.updated_at = _now()
                    task.validate()
                    self._dependencies(tasks)
                    if task.state == "completed" and (not task.completion_note.strip() or any(x.state != "completed" for x in tasks if x.id in task.depends_on)):
                        raise ValueError("completion requires a note and completed dependencies")
                    self.store._save_unlocked(tasks)
                    result = task.to_dict()
        return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}], "structuredContent": result, "isError": False}
