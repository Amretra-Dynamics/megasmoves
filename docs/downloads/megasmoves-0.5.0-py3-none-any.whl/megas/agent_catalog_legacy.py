"""Coding-agent catalog: discovery, install, setup, and Worker registration.

Single product surface for operators:

    megas agents list
    megas agents discover
    megas agents install codex
    megas agents setup claude

Design:
- One catalog entry per certified (or planned) agent with aliases.
- Discovery checks PATH, env overrides, config-stored paths, and common
  install locations (npm global, pipx, LocalAppData, Homebrew, ~/.local/bin).
- Install picks the best available strategy for the host OS (npm / pipx / brew
  / official scripts) without hard-coding a single fragile command.
- Setup writes binary path + enabled flag into worker.json so the next
  heartbeat advertises the agent as a routing capability.
"""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InstallStrategy:
    """One way to install an agent binary on the host."""

    id: str
    kind: str  # npm | pip | pipx | brew | winget | script | manual
    # argv for subprocess when kind is not "script"/"manual"
    argv: tuple[str, ...] = ()
    # platforms: windows | darwin | linux | * 
    platforms: tuple[str, ...] = ("*",)
    # executable names that must exist before this strategy can run
    requires: tuple[str, ...] = ()
    # human summary shown before install
    summary: str = ""
    # for kind=script: powerShell/bash one-liners (never run without confirm)
    script_windows: str = ""
    script_unix: str = ""
    # when kind=manual: URL/docs only
    manual_url: str = ""


@dataclass(frozen=True)
class AgentSpec:
    agent_id: str
    display_name: str
    aliases: tuple[str, ...]
    binary_names: tuple[str, ...]
    binary_env: str
    certified: bool
    installers: tuple[InstallStrategy, ...]
    auth_hint: str = ""
    package_hints: tuple[str, ...] = ()  # npm package names, pip names, etc.


@dataclass
class AgentStatus:
    agent_id: str
    display_name: str
    certified: bool
    enabled: bool
    status: str  # ready | detected | missing | disabled | quarantined
    binary_path: str | None = None
    version: str | None = None
    install_methods: list[str] = field(default_factory=list)
    auth_hint: str = ""
    aliases: list[str] = field(default_factory=list)
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Dynamic catalog (local store + live web merge)
# ---------------------------------------------------------------------------


def _strategy_from_dict(raw: dict) -> InstallStrategy:
    argv = raw.get("argv") or raw.get("command") or []
    if isinstance(argv, str):
        argv = argv.split()
    platforms = raw.get("platforms") or ["*"]
    if isinstance(platforms, str):
        platforms = [platforms]
    requires = raw.get("requires") or []
    if isinstance(requires, str):
        requires = [requires]
    return InstallStrategy(
        id=str(raw.get("id") or raw.get("kind") or "manual"),
        kind=str(raw.get("kind") or "manual"),
        argv=tuple(str(x) for x in argv),
        platforms=tuple(str(x) for x in platforms),
        requires=tuple(str(x) for x in requires),
        summary=str(raw.get("summary") or ""),
        script_windows=str(raw.get("script_windows") or ""),
        script_unix=str(raw.get("script_unix") or ""),
        manual_url=str(raw.get("manual_url") or raw.get("docs_url") or ""),
    )


def _spec_from_record(agent_id: str, rec: dict) -> AgentSpec:
    aliases = rec.get("aliases") or [agent_id]
    binaries = rec.get("binary_names") or [agent_id]
    installers = []
    for item in rec.get("installers") or []:
        if isinstance(item, dict):
            try:
                installers.append(_strategy_from_dict(item))
            except Exception:
                continue
    if not installers:
        installers.append(
            InstallStrategy(
                id="manual",
                kind="manual",
                summary="No automatic installer yet — run megas agents refresh",
                manual_url=str(rec.get("docs_url") or ""),
            )
        )
    return AgentSpec(
        agent_id=agent_id,
        display_name=str(rec.get("display_name") or agent_id),
        aliases=tuple(str(a) for a in aliases),
        binary_names=tuple(str(b) for b in binaries),
        binary_env=str(rec.get("binary_env") or f"MEGAS_{agent_id.upper()}_BINARY"),
        certified=bool(rec.get("certified", False)),
        installers=tuple(installers),
        auth_hint=str(rec.get("auth_hint") or ""),
        package_hints=tuple(str(p) for p in (rec.get("package_hints") or [])),
    )


# Mutable catalog filled from local store (+ live). Prefer get_catalog().
AGENT_CATALOG: dict[str, AgentSpec] = {}
ALIAS_TO_ID: dict[str, str] = {}
_CATALOG_LOADED = False


def _rebuild_alias_index() -> None:
    global ALIAS_TO_ID
    ALIAS_TO_ID = {}
    for agent_id, spec in AGENT_CATALOG.items():
        ALIAS_TO_ID[agent_id.lower()] = agent_id
        for alias in spec.aliases:
            key = str(alias).lower().replace("-", "_").replace(" ", "_")
            ALIAS_TO_ID.setdefault(key, agent_id)
            ALIAS_TO_ID.setdefault(key.replace("_", ""), agent_id)
        for token in spec.display_name.lower().replace("(", " ").replace(")", " ").split():
            if len(token) >= 3 and token not in {"the", "and", "for", "cli", "code"}:
                ALIAS_TO_ID.setdefault(token.replace("-", "_"), agent_id)
        for pkg in spec.package_hints:
            slug = re.sub(r"[^a-z0-9]+", "_", pkg.lower()).strip("_")
            if slug:
                ALIAS_TO_ID.setdefault(slug, agent_id)


def sync_catalog_from_store(*, force_refresh: bool = False, query: str | None = None) -> dict[str, AgentSpec]:
    """Load local agents DB (fast), optionally merge live web, rebuild AGENT_CATALOG."""
    global AGENT_CATALOG, _CATALOG_LOADED
    from megas.agents_store import agents_dict, ensure_store

    store = ensure_store(force_refresh=force_refresh, query=query)
    specs: dict[str, AgentSpec] = {}
    for agent_id, rec in agents_dict(store).items():
        try:
            specs[agent_id] = _spec_from_record(agent_id, rec)
        except Exception:
            continue
    AGENT_CATALOG = specs
    _rebuild_alias_index()
    _CATALOG_LOADED = True
    return AGENT_CATALOG


def get_catalog(*, ensure: bool = True, force_refresh: bool = False, query: str | None = None) -> dict[str, AgentSpec]:
    if ensure and (not _CATALOG_LOADED or force_refresh or query or not AGENT_CATALOG):
        sync_catalog_from_store(force_refresh=force_refresh, query=query)
    elif not AGENT_CATALOG:
        sync_catalog_from_store(force_refresh=False)
    return AGENT_CATALOG


def _normalize_agent_query(name: str) -> str:
    text = (name or "").strip().lower()
    for noise in (
        "the", "a", "an", "please", "coding", "agent", "cli", "code", "tool",
        "ai", "my", "me", "for", "install", "setup", "get", "bulk",
    ):
        text = re.sub(rf"\b{noise}\b", " ", text)
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return re.sub(r"_+", "_", text).strip("_")


def _all_match_labels() -> list[tuple[str, str]]:
    labels: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    catalog = get_catalog()
    for agent_id, spec in catalog.items():
        candidates = {
            agent_id,
            *spec.aliases,
            spec.display_name.lower(),
            re.sub(r"[^a-z0-9]+", "", agent_id),
            re.sub(r"[^a-z0-9]+", "", spec.display_name.lower()),
            *spec.binary_names,
            *spec.package_hints,
        }
        for raw in candidates:
            label = _normalize_agent_query(str(raw))
            if not label:
                continue
            for form in (label, label.replace("_", "")):
                pair = (form, agent_id)
                if pair not in seen:
                    seen.add(pair)
                    labels.append(pair)
    return labels


def resolve_agent_id(name: str, *, live_on_miss: bool = True) -> str:
    """Resolve half-baked names against local store; live-refresh on miss."""
    raw = (name or "").strip()
    if not raw:
        raise ValueError("Agent name is required. Try: megas install codex")

    get_catalog()
    key = _normalize_agent_query(raw)
    solid = key.replace("_", "")

    def _try_resolve() -> str | None:
        for candidate in (key, solid, raw.lower().replace("-", "_").replace(" ", "_")):
            if candidate in ALIAS_TO_ID:
                return ALIAS_TO_ID[candidate]
        labels = _all_match_labels()
        prefix_hits: dict[str, str] = {}
        for label, agent_id in labels:
            if key and label.startswith(key):
                prefix_hits[agent_id] = label
            elif solid and label.startswith(solid):
                prefix_hits[agent_id] = label
        if len(prefix_hits) == 1:
            return next(iter(prefix_hits))
        if len(prefix_hits) > 1:
            certified = [a for a in prefix_hits if AGENT_CATALOG.get(a) and AGENT_CATALOG[a].certified]
            if len(certified) == 1:
                return certified[0]
        sub_hits: dict[str, str] = {}
        for label, agent_id in labels:
            if key and len(key) >= 2 and key in label:
                sub_hits[agent_id] = label
            elif solid and len(solid) >= 3 and solid in label:
                sub_hits[agent_id] = label
        if len(sub_hits) == 1:
            return next(iter(sub_hits))
        if len(sub_hits) > 1:
            certified = [a for a in sub_hits if AGENT_CATALOG.get(a) and AGENT_CATALOG[a].certified]
            if len(certified) == 1:
                return certified[0]
        try:
            import difflib
            pool = sorted({label for label, _ in labels if len(label) >= 2})
            close = difflib.get_close_matches(solid or key, pool, n=5, cutoff=0.55)
            agent_ids: list[str] = []
            for match in close:
                for label, agent_id in labels:
                    if label == match and agent_id not in agent_ids:
                        agent_ids.append(agent_id)
            if len(agent_ids) == 1:
                return agent_ids[0]
            if len(agent_ids) > 1:
                certified = [a for a in agent_ids if AGENT_CATALOG.get(a) and AGENT_CATALOG[a].certified]
                if len(certified) == 1:
                    return certified[0]
                raise ValueError(
                    f"Ambiguous coding agent '{raw}'. Did you mean: {', '.join(agent_ids[:5])}?"
                )
            if close:
                best = close[0]
                for label, agent_id in labels:
                    if label == best:
                        return agent_id
        except ValueError:
            raise
        except Exception:
            pass
        return None

    def _product_canonicalize(agent_id: str) -> str:
        # Gemini CLI abandoned — Antigravity is the Google coding path for install/run.
        # Config ops (enable/disable) use exact catalog ids via _resolve_config_agent_id.
        if agent_id in {"gemini_cli", "gemini", "google_gemini"}:
            return "antigravity"
        return agent_id

    hit = _try_resolve()
    if hit:
        return _product_canonicalize(hit)
    if live_on_miss:
        sync_catalog_from_store(force_refresh=True, query=raw)
        hit = _try_resolve()
        if hit:
            return _product_canonicalize(hit)
    examples = ", ".join(sorted(AGENT_CATALOG.keys())[:8]) or "codex, claude, antigravity"
    raise ValueError(
        f"Unknown coding agent '{raw}'. Run: megas agents refresh  then try again. "
        f"Known examples: {examples}"
    )


def get_spec(name: str) -> AgentSpec:
    catalog = get_catalog()
    agent_id = resolve_agent_id(name)
    if agent_id not in catalog:
        sync_catalog_from_store(force_refresh=True, query=name)
        catalog = get_catalog(ensure=False)
    if agent_id not in catalog:
        raise ValueError(f"Agent '{name}' not in catalog after refresh.")
    return catalog[agent_id]


def host_platform() -> str:
    system = platform.system().lower()
    if system.startswith("win"):
        return "windows"
    if system == "darwin":
        return "darwin"
    return "linux"


def _strategy_matches_platform(strategy: InstallStrategy, plat: str | None = None) -> bool:
    plat = plat or host_platform()
    return "*" in strategy.platforms or plat in strategy.platforms


_NPM_EXISTS_CACHE: dict[str, bool] = {}


def _npm_package_exists(package: str, *, timeout: float = 4.0) -> bool:
    """Best-effort npm view — avoids advertising install for unpublished packages."""
    pkg = (package or "").strip()
    if not pkg:
        return False
    if pkg in _NPM_EXISTS_CACHE:
        return _NPM_EXISTS_CACHE[pkg]
    # Unit tests must stay offline/fast; assume package ok unless explicitly cached.
    if os.getenv("PYTEST_CURRENT_TEST") and os.getenv("MEGAS_TEST_NPM_VIEW", "").lower() not in {
        "1",
        "true",
        "yes",
    }:
        _NPM_EXISTS_CACHE[pkg] = True
        return True
    npm = shutil.which("npm")
    if not npm:
        _NPM_EXISTS_CACHE[pkg] = False
        return False
    try:
        res = subprocess.run(
            [npm, "view", pkg, "version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            **_hide_kwargs(),
        )
        ok = res.returncode == 0 and bool((res.stdout or "").strip())
    except Exception:
        ok = False
    _NPM_EXISTS_CACHE[pkg] = ok
    return ok


def available_install_strategies(spec: AgentSpec, *, plat: str | None = None) -> list[InstallStrategy]:
    plat = plat or host_platform()
    out: list[InstallStrategy] = []
    for strategy in spec.installers:
        if not _strategy_matches_platform(strategy, plat):
            continue
        if strategy.kind == "manual":
            out.append(strategy)
            continue
        if strategy.kind == "script":
            out.append(strategy)
            continue
        if strategy.requires and not all(shutil.which(req) for req in strategy.requires):
            continue
        # Fix pip argv to use current interpreter (seed may have wrong "python")
        if strategy.kind == "pip":
            argv = list(strategy.argv)
            if len(argv) >= 3 and argv[1] == "-m" and argv[2] == "pip":
                argv[0] = sys.executable
                strategy = InstallStrategy(
                    id=strategy.id,
                    kind=strategy.kind,
                    argv=tuple(argv),
                    platforms=strategy.platforms,
                    requires=strategy.requires,
                    summary=strategy.summary,
                    script_windows=strategy.script_windows,
                    script_unix=strategy.script_unix,
                    manual_url=strategy.manual_url,
                )
            out.append(strategy)
            continue
        if strategy.kind in {"npm", "pipx", "brew", "winget"} and strategy.requires:
            if all(shutil.which(req) for req in strategy.requires):
                out.append(strategy)
            continue
        out.append(strategy)
    return out


def pick_install_strategy(
    spec: AgentSpec,
    *,
    method: str | None = None,
    plat: str | None = None,
) -> InstallStrategy:
    strategies = available_install_strategies(spec, plat=plat)
    if not strategies:
        raise RuntimeError(
            f"No install method available for {spec.display_name} on this machine. "
            f"Install Node.js (npm) or see docs for a manual install."
        )
    if method and method not in {"auto", "", "default"}:
        wanted = method.lower().strip()
        for strategy in strategies:
            if strategy.id == wanted or strategy.kind == wanted:
                return strategy
        raise RuntimeError(
            f"Install method '{method}' is not available for {spec.display_name}. "
            f"Available: {', '.join(s.id for s in strategies)}"
        )
    # Prefer package managers over remote scripts; scripts last (need network trust).
    priority = {"npm": 0, "pipx": 1, "pip": 2, "brew": 3, "winget": 4, "script": 5, "manual": 9}
    strategies_sorted = sorted(strategies, key=lambda s: priority.get(s.kind, 8))
    # Prefer non-manual
    for strategy in strategies_sorted:
        if strategy.kind != "manual":
            return strategy
    return strategies_sorted[0]


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def _candidate_search_dirs() -> list[Path]:
    """Directories where coding CLIs commonly land outside default PATH."""
    home = Path.home()
    dirs: list[Path] = []
    env_path = os.environ.get("PATH") or os.environ.get("Path") or ""
    for part in env_path.split(os.pathsep):
        if part:
            dirs.append(Path(part))

    extras: list[Path] = [
        home / ".local" / "bin",
        home / ".npm-global" / "bin",
        home / "bin",
        home / ".cargo" / "bin",
        home / ".pyenv" / "shims",
        home / ".nvm" / "current" / "bin",
        Path("/usr/local/bin"),
        Path("/opt/homebrew/bin"),
        Path("/home/linuxbrew/.linuxbrew/bin"),
    ]
    if host_platform() == "windows":
        appdata = Path(os.environ.get("APPDATA", home / "AppData" / "Roaming"))
        local = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
        pf = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
        extras.extend(
            [
                appdata / "npm",
                local / "Programs" / "nodejs",
                local / "Microsoft" / "WindowsApps",
                local / "Antigravity",
                local / "Antigravity" / "bin",
                local / "Programs" / "Python" / "Python312" / "Scripts",
                local / "Programs" / "Python" / "Python313" / "Scripts",
                local / "pipx" / "venvs" / "aider-chat" / "Scripts",
                home / "scoop" / "shims",
                Path(os.environ.get("ChocolateyInstall", r"C:\ProgramData\chocolatey")) / "bin",
                pf / "nodejs",
                pf / "Git" / "cmd",
            ]
        )
        # npm global prefix from npm config (best-effort, short timeout)
        npm = shutil.which("npm")
        if npm:
            try:
                res = subprocess.run(
                    [npm, "config", "get", "prefix"],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=5,
                    check=False,
                    **_hide_kwargs(),
                )
                prefix = (res.stdout or "").strip()
                if prefix:
                    extras.append(Path(prefix))
                    extras.append(Path(prefix) / "bin")  # unix-style
            except Exception:
                pass
    else:
        extras.extend(
            [
                home / ".claude" / "bin",
                home / ".gemini" / "bin",
            ]
        )

    seen: set[str] = set()
    ordered: list[Path] = []
    for path in dirs + extras:
        try:
            key = str(path.resolve()).lower()
        except OSError:
            key = str(path).lower()
        if key in seen:
            continue
        seen.add(key)
        ordered.append(path)
    return ordered


def _hide_kwargs() -> dict[str, Any]:
    from megas.adapters.base import subprocess_hide_window_kwargs

    # Never fail open to a visible Windows console if the shared launch policy
    # cannot be imported. In that case installation/probing must stop instead.
    return subprocess_hide_window_kwargs()


def _is_executable_file(path: Path) -> bool:
    try:
        if not path.is_file():
            return False
        if host_platform() == "windows":
            return path.suffix.lower() in {".exe", ".cmd", ".bat", ".ps1", ""} or path.name.lower() in {
                "codex",
                "claude",
                "gemini",
                "aider",
                "agy",
            }
        return os.access(path, os.X_OK)
    except OSError:
        return False


def _find_binary_on_disk(names: Iterable[str]) -> Path | None:
    names = [n for n in names if n]
    # 1) env PATH via which
    for name in names:
        found = shutil.which(name)
        if found:
            return Path(found)
    # 2) common dirs
    suffixes = [""]
    if host_platform() == "windows":
        suffixes = [".exe", ".cmd", ".bat", ""]
    for directory in _candidate_search_dirs():
        try:
            if not directory.is_dir():
                continue
        except OSError:
            continue
        for name in names:
            for suffix in suffixes:
                candidate = directory / f"{name}{suffix}"
                if _is_executable_file(candidate):
                    return candidate.resolve()
    return None


def _probe_version(binary: Path, *, version_args: list[str] | None = None) -> str | None:
    args = version_args or ["--version"]
    try:
        res = subprocess.run(
            [str(binary), *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
            check=False,
            **_hide_kwargs(),
        )
        output = ((res.stdout or "") + "\n" + (res.stderr or "")).strip()
        match = re.search(r"(\d+\.\d+(?:\.\d+)?)", output)
        if match:
            return match.group(1)
        if output:
            first = output.splitlines()[0].strip()
            return first[:80] if first else None
    except Exception:
        return None
    return None


def _config_agent_entry(config: Any, agent_id: str) -> dict[str, Any]:
    agents = getattr(config, "agents", None) or {}
    entry = agents.get(agent_id) if isinstance(agents, dict) else None
    return entry if isinstance(entry, dict) else {}


def _is_enabled(config: Any, agent_id: str) -> bool:
    entry = _config_agent_entry(config, agent_id)
    if "enabled" not in entry:
        return True  # default-on when present on machine
    return bool(entry.get("enabled"))


def discover_binary(
    spec: AgentSpec,
    *,
    config: Any | None = None,
) -> Path | None:
    """Robust binary discovery for one agent."""
    # 1) explicit env
    env_val = (os.getenv(spec.binary_env) or "").strip()
    if env_val:
        env_path = Path(env_val).expanduser()
        if env_path.is_file() or shutil.which(env_val):
            which = shutil.which(env_val)
            return Path(which).resolve() if which else env_path.resolve()

    # 2) stored path in worker config
    if config is not None:
        entry = _config_agent_entry(config, spec.agent_id)
        stored = str(entry.get("binary") or entry.get("binary_path") or "").strip()
        if stored:
            p = Path(stored).expanduser()
            if p.is_file():
                return p.resolve()
            which = shutil.which(stored)
            if which:
                return Path(which).resolve()

    # 3) PATH + common locations
    return _find_binary_on_disk(spec.binary_names)


def _adapter_health(agent_id: str) -> tuple[str, str | None, str | None]:
    """Use certified adapter health when available: (status, version, binary)."""
    try:
        from megas.runtime_manifest import _agent_adapter_classes

        classes = _agent_adapter_classes()
        cls = classes.get(agent_id)
        if not cls:
            return "unavailable", None, None
        adapter = cls([])
        status = str(adapter.health_status())
        exe = adapter.discover_executable()
        version = adapter.detect_version() if exe else None
        return status, version, str(exe) if exe else None
    except Exception as exc:
        return "quarantined", None, None


def inspect_agent(name: str, *, config: Any | None = None) -> AgentStatus:
    spec = get_spec(name)
    strategies = available_install_strategies(spec)
    enabled = _is_enabled(config, spec.agent_id) if config is not None else True
    path = discover_binary(spec, config=config)

    # Prefer adapter certification for certified agents
    version: str | None = None
    adapter_status: str | None = None
    if spec.certified:
        adapter_status, version, adapter_path = _adapter_health(spec.agent_id)
        if adapter_path and not path:
            path = Path(adapter_path)
    if path and not version:
        version = _probe_version(path)

    if not enabled:
        status = "disabled"
        detail = "Disabled in Megas config (`megas agents enable` to use)."
    elif path and (adapter_status == "available" or (not spec.certified and path)):
        status = "ready" if spec.certified else "detected"
        detail = "Certified and available for phone sessions." if spec.certified else "Detected; adapter not certified yet."
    elif path and adapter_status == "quarantined":
        status = "quarantined"
        detail = "Binary found but version/health check failed."
    elif path:
        status = "detected"
        detail = "Binary found; health not fully verified."
    else:
        status = "missing"
        detail = "Not found on this machine."

    return AgentStatus(
        agent_id=spec.agent_id,
        display_name=spec.display_name,
        certified=spec.certified,
        enabled=enabled,
        status=status,
        binary_path=str(path) if path else None,
        version=version,
        install_methods=[s.id for s in strategies if s.kind != "manual"]
        + ([s.id for s in strategies if s.kind == "manual"] or []),
        auth_hint=spec.auth_hint,
        aliases=list(spec.aliases),
        detail=detail,
    )


def auto_register_detected_agents(
    rows: list[AgentStatus],
    *,
    config: Any | None = None,
) -> list[str]:
    """Write detected/ready agents into worker.json so Megas remembers them.

    Returns agent_ids newly or freshly registered.
    """
    from megas.config import load_config, save_config

    cfg = config if config is not None else load_config()
    if not isinstance(cfg.agents, dict):
        cfg.agents = {}
    registered: list[str] = []
    changed = False
    for row in rows:
        if row.status not in {"ready", "detected"} or not row.binary_path:
            continue
        if row.agent_id in {"gemini_cli"}:
            # Abandoned product agent — do not re-register for routing.
            continue
        # Respect explicit disable
        existing = cfg.agents.get(row.agent_id) if isinstance(cfg.agents.get(row.agent_id), dict) else {}
        if existing.get("enabled") is False:
            continue
        path = str(row.binary_path)
        prev = str(existing.get("binary") or existing.get("binary_path") or "")
        if prev == path and existing.get("enabled") is True:
            continue
        entry = dict(existing)
        entry["enabled"] = True
        entry["binary"] = path
        entry["binary_path"] = path
        entry["display_name"] = row.display_name
        entry["certified"] = row.certified
        entry["version"] = row.version
        entry["auto_registered"] = True
        entry["updated_at"] = __import__("datetime").datetime.now(
            __import__("datetime").timezone.utc
        ).isoformat()
        cfg.agents[row.agent_id] = entry
        if row.agent_id in get_catalog() and get_catalog()[row.agent_id].binary_env:
            os.environ.setdefault(get_catalog()[row.agent_id].binary_env, path)
        registered.append(row.agent_id)
        changed = True
    if changed:
        try:
            from megas.runtime_manifest import build_runtime_manifest, runtime_capabilities_from_manifest

            caps = runtime_capabilities_from_manifest(build_runtime_manifest(cfg))
            if caps:
                cfg.capabilities = caps
        except Exception:
            pass
        save_config(cfg)
        if config is not None:
            config.agents = cfg.agents
            config.capabilities = cfg.capabilities
    return registered


def list_agents(
    *,
    config: Any | None = None,
    certified_only: bool = False,
    auto_register: bool = True,
) -> list[AgentStatus]:
    rows: list[AgentStatus] = []
    catalog = get_catalog()
    store_dirty = False
    store = None
    try:
        from megas.agents_store import load_store, record_machine_detection, save_store

        store = load_store()
    except Exception:
        store = None

    abandoned_ids: set[str] = set()
    try:
        from megas.agents_store import agents_dict, load_store as _load_agents_store

        for aid, rec in agents_dict(_load_agents_store() or {}).items():
            if isinstance(rec, dict) and rec.get("abandoned"):
                abandoned_ids.add(str(aid))
    except Exception:
        abandoned_ids = {"gemini_cli"}

    for agent_id in sorted(catalog.keys()):
        if agent_id in abandoned_ids:
            # Never list abandoned peers (gemini_cli → use antigravity).
            continue
        if certified_only and not catalog[agent_id].certified:
            continue
        status = inspect_agent(agent_id, config=config)
        # Persist on-machine detections into the growing local store.
        if store is not None and status.binary_path and status.status in {
            "ready",
            "detected",
            "quarantined",
        }:
            try:
                record_machine_detection(
                    store,
                    agent_id,
                    binary_path=status.binary_path,
                    version=status.version,
                )
                store_dirty = True
            except Exception:
                pass
        rows.append(status)

    if store is not None and store_dirty:
        try:
            save_store(store)
        except Exception:
            pass

    if auto_register:
        try:
            auto_register_detected_agents(rows, config=config)
        except Exception:
            pass
    return rows


def list_installable_missing(*, config: Any | None = None) -> list[dict[str, Any]]:
    """Agents not installed on this machine that have an install path available here.

    Ordered: certified first, then auto-installable (npm/pip/…), then manual-only.
    """
    plat = host_platform()
    missing: list[dict[str, Any]] = []
    for row in list_agents(config=config):
        if row.status not in {"missing", "disabled"}:
            continue
        if row.status == "disabled":
            continue
        try:
            spec = get_spec(row.agent_id)
        except Exception:
            continue
        strategies = available_install_strategies(spec, plat=plat)
        # Only count auto strategies whose package/tool is actually usable here.
        auto: list[InstallStrategy] = []
        for s in strategies:
            if s.kind == "manual":
                continue
            if s.kind == "npm":
                pkg = ""
                for a in reversed(list(s.argv)):
                    if a in {"npm", "install", "-g", "--global", "--"}:
                        continue
                    if a.startswith("-"):
                        continue
                    pkg = a
                    break
                if pkg and not _npm_package_exists(pkg):
                    continue
            auto.append(s)
        can_auto = bool(auto)
        # Skip if no strategy at all
        if not strategies:
            continue
        # Prefer entries we can actually attempt on this PC
        if not can_auto and not any(s.kind == "manual" for s in strategies):
            continue
        method = auto[0].id if auto else (strategies[0].id if strategies else "manual")
        missing.append(
            {
                "agent_id": row.agent_id,
                "display_name": row.display_name,
                "certified": row.certified,
                "aliases": row.aliases,
                "install_methods": [s.id for s in (auto if auto else strategies)],
                "recommended_method": method,
                "can_auto_install": can_auto,
                "auth_hint": row.auth_hint,
                "detail": row.detail,
            }
        )
    # Order: certified+auto, auto, certified manual, rest
    def sort_key(item: dict[str, Any]) -> tuple:
        return (
            0 if item.get("certified") and item.get("can_auto_install") else 1,
            0 if item.get("can_auto_install") else 1,
            0 if item.get("certified") else 1,
            str(item.get("agent_id") or ""),
        )

    missing.sort(key=sort_key)
    return missing


def discover_system_agents(*, config: Any | None = None) -> dict[str, Any]:
    """Deep scan: every catalog agent + any extra PATH hits that look like agents."""
    catalog = [s.to_dict() for s in list_agents(config=config)]
    ready = [r for r in catalog if r["status"] in {"ready", "detected"}]
    missing = [r for r in catalog if r["status"] == "missing"]
    installable = list_installable_missing(config=config)
    return {
        "platform": host_platform(),
        "agents": catalog,
        "ready_count": len(ready),
        "missing_count": len(missing),
        "ready_agent_ids": [r["agent_id"] for r in ready],
        "installable_missing": installable,
        "installable_missing_ids": [r["agent_id"] for r in installable],
        "path_sample": [str(p) for p in _candidate_search_dirs()[:12]],
    }


# ---------------------------------------------------------------------------
# Install + setup + register
# ---------------------------------------------------------------------------


class AgentInstallError(RuntimeError):
    pass


def _run_command(argv: list[str], *, timeout: int = 600) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        argv,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
        **_hide_kwargs(),
    )


def _run_shell_script(script: str, *, windows: bool, timeout: int = 900) -> subprocess.CompletedProcess[str]:
    if windows:
        # Prefer PowerShell for official Windows installers.
        return subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                script,
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            **_hide_kwargs(),
        )
    return subprocess.run(
        ["bash", "-lc", script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
        **_hide_kwargs(),
    )


def install_agent(
    name: str,
    *,
    method: str | None = "auto",
    yes: bool = False,
    dry_run: bool = False,
    config: Any | None = None,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Install a coding agent binary, then setup/register with Megas."""
    def log(msg: str) -> None:
        if progress:
            progress(msg)

    spec = get_spec(name)
    strategy = pick_install_strategy(spec, method=method)
    log(f"Selected install method: {strategy.id} ({strategy.summary or strategy.kind})")

    if dry_run:
        preview = {
            "agent_id": spec.agent_id,
            "method": strategy.id,
            "kind": strategy.kind,
            "argv": list(strategy.argv) if strategy.argv else None,
            "script": strategy.script_windows if host_platform() == "windows" else strategy.script_unix,
            "summary": strategy.summary,
        }
        return {"agent_id": spec.agent_id, "action": "dry_run", "plan": preview}

    # Fail closed early if npm package is not published (bad seed / stale live entry).
    if strategy.kind == "npm" and strategy.argv:
        pkg = next(
            (a for a in strategy.argv if a not in {"npm", "install", "-g", "--global"}),
            "",
        )
        if pkg and not _npm_package_exists(pkg):
            raise AgentInstallError(
                f"npm package '{pkg}' was not found on the registry for {spec.display_name}. "
                f"Run: megas agents refresh  or install manually, then: megas agents setup {spec.agent_id}"
            )

    before = inspect_agent(spec.agent_id, config=config)
    if before.status in {"ready", "detected"} and before.binary_path:
        log(f"{spec.display_name} already present at {before.binary_path}")
        setup = setup_agent(spec.agent_id, config=config, binary=before.binary_path)
        return {
            "agent_id": spec.agent_id,
            "action": "already_installed",
            "binary_path": before.binary_path,
            "version": before.version,
            "setup": setup,
        }

    if strategy.kind == "manual":
        raise AgentInstallError(
            f"Automatic install is not available for {spec.display_name}. "
            f"Install manually{(' from ' + strategy.manual_url) if strategy.manual_url else ''} "
            f"then run: megas agents setup {spec.agent_id}"
        )

    if strategy.kind == "script" and not yes:
        raise AgentInstallError(
            f"Install method '{strategy.id}' downloads and runs an official vendor script. "
            f"Re-run with --yes to confirm:\n  {strategy.script_windows or strategy.script_unix}"
        )

    # Ensure npm tools have node
    if strategy.kind == "npm" and not shutil.which("npm"):
        raise AgentInstallError(
            "npm is required to install this agent. Install Node.js 18+ from https://nodejs.org "
            "then re-run `megas agents install`."
        )

    log(f"Installing {spec.display_name}…")
    try:
        if strategy.kind == "script":
            script = (
                strategy.script_windows
                if host_platform() == "windows"
                else strategy.script_unix
            )
            if not script:
                raise AgentInstallError(f"No script defined for platform {host_platform()}.")
            result = _run_shell_script(script, windows=host_platform() == "windows")
        else:
            result = _run_command(list(strategy.argv))
    except subprocess.TimeoutExpired as exc:
        raise AgentInstallError(f"Install timed out for {spec.display_name}.") from exc
    except FileNotFoundError as exc:
        raise AgentInstallError(f"Installer tool missing: {exc}") from exc

    if result.returncode != 0:
        tail = ((result.stderr or "") + "\n" + (result.stdout or "")).strip()[-1500:]
        raise AgentInstallError(
            f"Install failed for {spec.display_name} via {strategy.id} (exit {result.returncode}).\n{tail}"
        )

    # Refresh PATH for current process (npm global may not be in parent PATH yet)
    _refresh_path_after_install()
    path = discover_binary(spec, config=config)
    if not path:
        # one more aggressive search
        path = _find_binary_on_disk(spec.binary_names)
    if not path:
        raise AgentInstallError(
            f"{spec.display_name} install finished but binary was not found on PATH. "
            f"Open a new terminal or add the install directory to PATH, then run: "
            f"megas agents setup {spec.agent_id}"
        )

    setup = setup_agent(spec.agent_id, config=config, binary=str(path))
    version = _probe_version(path)
    try:
        from megas.agents_store import load_store, record_install_success, save_store

        store = load_store()
        record_install_success(
            store,
            spec.agent_id,
            binary_path=str(path),
            version=version,
            method=strategy.id,
        )
        save_store(store)
    except Exception:
        pass
    log(f"Installed {spec.display_name} → {path}" + (f" (v{version})" if version else ""))
    return {
        "agent_id": spec.agent_id,
        "action": "installed",
        "method": strategy.id,
        "binary_path": str(path),
        "version": version,
        "setup": setup,
        "auth_hint": spec.auth_hint,
    }


def install_agents(
    names: list[str],
    *,
    method: str | None = "auto",
    yes: bool = False,
    dry_run: bool = False,
    config: Any | None = None,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Bulk install one or more agents (fuzzy names OK)."""
    results: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    for name in names:
        name = str(name).strip()
        if not name:
            continue
        try:
            results.append(
                install_agent(
                    name,
                    method=method,
                    yes=yes,
                    dry_run=dry_run,
                    config=config,
                    progress=progress,
                )
            )
        except Exception as exc:
            errors.append({"name": name, "error": str(exc)})
            if progress:
                progress(f"FAILED {name}: {exc}")
    return {
        "ok": len(errors) == 0,
        "installed": results,
        "errors": errors,
        "count_ok": len(results),
        "count_failed": len(errors),
    }


def install_menu(*, config: Any | None = None, refresh: bool = False) -> dict[str, Any]:
    """What `megas install` shows: missing-but-installable agents in order."""
    if refresh:
        sync_catalog_from_store(force_refresh=True)
    else:
        get_catalog()
    installable = list_installable_missing(config=config)
    installed = [
        s.to_dict()
        for s in list_agents(config=config)
        if s.status in {"ready", "detected"}
    ]
    return {
        "platform": host_platform(),
        "installed": installed,
        "installable_missing": installable,
        "installable_missing_ids": [r["agent_id"] for r in installable],
        "bulk_hint": "megas install "
        + " ".join(r["agent_id"] for r in installable if r.get("can_auto_install"))
        if any(r.get("can_auto_install") for r in installable)
        else "megas install codex claude gemini",
        "all_auto_ids": [r["agent_id"] for r in installable if r.get("can_auto_install")],
    }


def _refresh_path_after_install() -> None:
    """Best-effort: append common post-install dirs to process PATH."""
    parts = [p for p in (os.environ.get("PATH") or "").split(os.pathsep) if p]
    lower = {p.lower() for p in parts}
    for directory in _candidate_search_dirs():
        try:
            key = str(directory).lower()
            if key not in lower and directory.is_dir():
                parts.insert(0, str(directory))
                lower.add(key)
        except OSError:
            continue
    os.environ["PATH"] = os.pathsep.join(parts)


def setup_agent(
    name: str,
    *,
    config: Any | None = None,
    binary: str | Path | None = None,
    enable: bool = True,
) -> dict[str, Any]:
    """Register a discovered/installed agent into Worker config + env."""
    from megas.config import load_config, save_config
    from megas.runtime_manifest import build_runtime_manifest, runtime_capabilities_from_manifest

    spec = get_spec(name)
    cfg = config if config is not None else load_config()
    path = Path(binary).expanduser() if binary else discover_binary(spec, config=cfg)
    if path is None:
        raise AgentInstallError(
            f"{spec.display_name} is not installed. Run: megas agents install {spec.agent_id}"
        )
    path = path.resolve()
    if not path.exists() and not shutil.which(str(path)):
        # allow which-style names
        which = shutil.which(str(binary) if binary else spec.binary_names[0])
        if not which:
            raise AgentInstallError(f"Binary not found: {path}")
        path = Path(which).resolve()

    if not isinstance(cfg.agents, dict):
        cfg.agents = {}
    entry = dict(cfg.agents.get(spec.agent_id) or {})
    entry["enabled"] = bool(enable)
    entry["binary"] = str(path)
    entry["binary_path"] = str(path)
    entry["display_name"] = spec.display_name
    entry["certified"] = spec.certified
    entry["updated_at"] = __import__("datetime").datetime.now(
        __import__("datetime").timezone.utc
    ).isoformat()
    cfg.agents[spec.agent_id] = entry

    # Process env so this CLI process + child worker restarts pick it up immediately.
    if spec.binary_env:
        os.environ[spec.binary_env] = str(path)

    # Refresh advertised capabilities from live inventory.
    try:
        manifest = build_runtime_manifest(cfg)
        caps = runtime_capabilities_from_manifest(manifest)
        if caps:
            cfg.capabilities = caps
    except Exception:
        # Still save agent registration even if inventory fails mid-setup.
        pass

    save_config(cfg)
    status = inspect_agent(spec.agent_id, config=cfg)
    return {
        "agent_id": spec.agent_id,
        "enabled": enable,
        "binary_path": str(path),
        "status": status.status,
        "version": status.version,
        "capabilities_include_agent": spec.agent_id in (cfg.capabilities or []),
        "auth_hint": spec.auth_hint,
        "note": (
            "Agent registered. If the Worker is already running, restart it "
            "(`megas stop` then `megas start`) so the next heartbeat advertises new capabilities."
            if status.status == "ready"
            else "Agent registered; health still incomplete — check auth / binary version."
        ),
    }


def enable_agent(name: str, *, workspaces: list[str] | None = None) -> dict[str, Any]:
    from megas.config import load_config, save_config

    # Exact catalog id first (same rule as disable) so enable antigravity /
    # gemini_cli never cross-wires via abandoned product aliases.
    try:
        agent_id = _resolve_config_agent_id(name)
        spec = get_spec(agent_id)
    except Exception:
        spec = get_spec(name)
        agent_id = spec.agent_id
    config = load_config()
    if not isinstance(config.agents, dict):
        config.agents = {}
    entry = dict(config.agents.get(agent_id) or {})
    entry["enabled"] = True
    if workspaces:
        roots = [str(Path(p).expanduser().resolve()) for p in workspaces]
        entry["supported_workspace_roots"] = roots
    # If binary known, keep it; else discover.
    if not entry.get("binary"):
        path = discover_binary(spec, config=config)
        if path:
            entry["binary"] = str(path)
            entry["binary_path"] = str(path)
            if spec.binary_env:
                os.environ[spec.binary_env] = str(path)
    config.agents[agent_id] = entry
    save_config(config)
    return setup_agent(agent_id, config=config, enable=True)


def _resolve_config_agent_id(name: str) -> str:
    """Resolve agent id for enable/disable without product alias rewrite.

    Exact catalog keys (e.g. abandoned ``gemini_cli``) win so
    ``megas agents disable gemini_cli`` never disables ``antigravity``.
    """
    raw = (name or "").strip()
    if not raw:
        raise ValueError("Agent name is required.")
    catalog = get_catalog()
    solid = raw.lower().replace("-", "_").replace(" ", "_")
    if solid in catalog:
        return solid
    if raw in catalog:
        return raw
    return resolve_agent_id(raw, live_on_miss=False)


def disable_agent(name: str) -> dict[str, Any]:
    from megas.config import load_config, save_config
    from megas.runtime_manifest import build_runtime_manifest, runtime_capabilities_from_manifest

    agent_id = _resolve_config_agent_id(name)
    config = load_config()
    if not isinstance(config.agents, dict):
        config.agents = {}
    entry = dict(config.agents.get(agent_id) or {})
    entry["enabled"] = False
    config.agents[agent_id] = entry
    try:
        manifest = build_runtime_manifest(config)
        config.capabilities = runtime_capabilities_from_manifest(manifest)
    except Exception:
        pass
    save_config(config)
    return {"agent_id": agent_id, "enabled": False}


def apply_agent_env_from_config(config: Any) -> None:
    """Call at Worker start so stored binary paths override PATH."""
    agents = getattr(config, "agents", None) or {}
    if not isinstance(agents, dict):
        return
    catalog = get_catalog(ensure=True)
    for agent_id, entry in agents.items():
        if not isinstance(entry, dict):
            continue
        if entry.get("enabled") is False:
            continue
        spec = catalog.get(agent_id)
        env_key = (spec.binary_env if spec else "") or str(entry.get("binary_env") or "")
        if not env_key:
            env_key = f"MEGAS_{agent_id.upper()}_BINARY"
        binary = str(entry.get("binary") or entry.get("binary_path") or "").strip()
        if binary:
            os.environ.setdefault(env_key, binary)


def catalog_summary_json() -> str:
    catalog = get_catalog()
    return json.dumps(
        {
            agent_id: {
                "display_name": spec.display_name,
                "aliases": list(spec.aliases),
                "certified": spec.certified,
                "binaries": list(spec.binary_names),
                "installers": [s.id for s in spec.installers],
            }
            for agent_id, spec in catalog.items()
        },
        indent=2,
    )


def refresh_agents_catalog(*, force: bool = True) -> dict[str, Any]:
    """Force live web merge into local store; return summary."""
    from megas.agents_store import default_store_path, ensure_store

    store = ensure_store(force_refresh=force)
    sync_catalog_from_store(force_refresh=False)
    meta = store.get("_refresh") or {}
    return {
        "store_path": str(default_store_path()),
        "agent_count": len(AGENT_CATALOG),
        "agent_ids": sorted(AGENT_CATALOG.keys()),
        "refresh": meta,
        "last_live_sources": store.get("last_live_sources") or [],
    }
