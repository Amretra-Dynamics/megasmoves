"""Authoritative Cursor CLI history reader.

Cursor CLI and Cursor IDE have separate session identities.  A transcript is
eligible for ``cursor_cli`` only when its exact UUID also exists in the CLI chat
store.  This prevents IDE composer ids from being offered to ``--resume``.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
from typing import Any

from . import thread_sync_legacy as legacy


_SESSION_ID = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


def _home_roots() -> list[Path]:
    explicit = os.getenv("CURSOR_DATA_DIR", "").strip()
    roots: list[Path] = []
    if explicit:
        roots.append(Path(explicit).expanduser())
    roots.extend([Path.home() / ".cursor", Path.home() / ".config" / "cursor"])
    unique: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        key = str(root)
        if key not in seen:
            seen.add(key)
            unique.append(root)
    return unique


def _cli_chat_ids() -> dict[str, list[Path]]:
    result: dict[str, list[Path]] = {}
    for root in _home_roots():
        for base in (root / "chats", root / "acp-sessions"):
            if not base.is_dir():
                continue
            try:
                stores = list(base.glob("**/store.db"))
            except OSError:
                continue
            for store in stores:
                session_id = store.parent.name
                if not _SESSION_ID.fullmatch(session_id):
                    continue
                result.setdefault(session_id, []).append(store)
    return result


def _transcript_candidates(session_id: str) -> list[Path]:
    result: list[Path] = []
    for root in _home_roots():
        projects = root / "projects"
        if not projects.is_dir():
            continue
        patterns = (
            f"*/agent-transcripts/{session_id}/{session_id}.jsonl",
            f"*/agent-transcripts/{session_id}.jsonl",
        )
        for pattern in patterns:
            try:
                result.extend(path for path in projects.glob(pattern) if path.is_file())
            except OSError:
                continue
    result.sort(key=lambda path: path.stat().st_mtime_ns, reverse=True)
    return result


def _block_text(value: object) -> str:
    if isinstance(value, str):
        return legacy._sanitize_provider_text(value)
    if isinstance(value, dict):
        for key in ("text", "content", "message"):
            if value.get(key) is not None:
                return _block_text(value.get(key))
    return ""


def _parse_transcript(path: Path, session_id: str) -> dict[str, Any] | None:
    if not _SESSION_ID.fullmatch(session_id):
        return None
    messages: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    for line_number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(record, dict):
            continue
        declared_id = str(
            record.get("session_id")
            or record.get("sessionId")
            or record.get("conversation_id")
            or ""
        ).strip()
        if declared_id and declared_id != session_id:
            return None
        message = record.get("message") if isinstance(record.get("message"), dict) else record
        role_raw = str(message.get("role") or record.get("role") or "").lower()
        if role_raw not in {"user", "assistant"}:
            continue
        role = role_raw
        content = message.get("content")
        blocks = content if isinstance(content, list) else [content]
        for block_number, block in enumerate(blocks):
            if isinstance(block, str):
                text = legacy._sanitize_provider_text(block)
                block_type = "text"
                body: dict[str, Any] = {}
            elif isinstance(block, dict):
                block_type = str(block.get("type") or "text").lower()
                text = _block_text(block)
                body = block
            else:
                continue
            native_item_id = str(
                body.get("id")
                or body.get("tool_use_id")
                or record.get("uuid")
                or record.get("id")
                or f"{session_id}:{line_number}:{block_number}"
            )[:300]
            if block_type in {"tool_use", "tool_call"}:
                messages.append(
                    {
                        "seq": len(messages),
                        "role": "assistant",
                        "kind": "tool_call",
                        "content": None,
                        "tool_name": str(body.get("name") or "tool")[:120],
                        "tool_input": legacy._sanitize_provider_text(
                            json.dumps(body.get("input") or {}, ensure_ascii=False, sort_keys=True)
                        )[:12_000],
                        "native_item_id": native_item_id,
                        "created_at": str(record.get("timestamp") or ""),
                    }
                )
                continue
            if block_type in {"tool_result", "tool_output"}:
                messages.append(
                    {
                        "seq": len(messages),
                        "role": "assistant",
                        "kind": "tool_result",
                        "content": text or None,
                        "tool_output": text[:12_000],
                        "native_item_id": native_item_id,
                        "created_at": str(record.get("timestamp") or ""),
                    }
                )
                continue
            if not text:
                continue
            messages.append(
                {
                    "seq": len(messages),
                    "role": role,
                    "kind": "user_message" if role == "user" else "assistant_final",
                    "content": text[:50_000],
                    "native_item_id": native_item_id,
                    "created_at": str(record.get("timestamp") or ""),
                }
            )
    if not messages:
        return None
    title = "Cursor CLI session"
    for message in messages:
        if message.get("role") == "user" and message.get("content"):
            title = str(message["content"])[:80]
            break
    stat = path.stat()
    thread = {
        "native_id": session_id,
        "agent_type": "cursor_cli",
        "project_path": None,
        "title": title,
        "status": "active",
        "sync_cursor": f"{stat.st_mtime_ns}|{stat.st_size}",
        "messages": messages,
    }
    return legacy.finalize_native_thread(
        thread,
        provider_id="cursor_cli",
        data_roots=_home_roots(),
        source_hint=str(path),
        extra_meta={
            "identity_source": "cursor_cli_chat_store_plus_matching_transcript",
            "source_format": "cursor_cli_transcript_jsonl",
            "resume_surface": "cursor-agent --resume <chat-id>",
        },
    )


def read_cursor_cli_thread(native_id: str) -> dict[str, Any] | None:
    session_id = str(native_id or "").strip()
    stores = _cli_chat_ids()
    if session_id not in stores:
        return None
    for transcript in _transcript_candidates(session_id):
        parsed = _parse_transcript(transcript, session_id)
        if parsed:
            return parsed
    return None


def index_cursor_cli_threads(limit: int = 200) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    stores = _cli_chat_ids()
    ordered = sorted(
        stores,
        key=lambda item: max(path.stat().st_mtime_ns for path in stores[item]),
        reverse=True,
    )
    for session_id in ordered:
        if len(result) >= limit:
            break
        thread = read_cursor_cli_thread(session_id)
        if not thread:
            continue
        result.append(
            legacy._index_row(
                native_id=session_id,
                agent_type="cursor_cli",
                title=str(thread.get("title") or "Cursor CLI session")[:80],
                project_path=None,
                sync_cursor=legacy._cursor_with_epoch(
                    str(thread.get("sync_cursor") or "")
                ),
            )
        )
    return result
