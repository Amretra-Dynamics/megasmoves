"""Public native-thread sync API backed by proof-gated provider readers.

All mature parser helpers remain available from ``thread_sync_legacy`` for
compatibility. Product index/read selection uses granular installation
certificates; execution certification remains a separate, stricter gate.
"""

from __future__ import annotations

from . import thread_sync_legacy as _legacy
from . import certified_thread_sync as _readers
from .cursor_cli_history import index_cursor_cli_threads, read_cursor_cli_thread
from .kilo_cli_history import index_kilo_cli_threads, read_kilo_cli_thread
from .provider_certification_probes import install_strict_readers

for _name, _value in vars(_legacy).items():
    if not _name.startswith("__"):
        globals()[_name] = _value


def _strict_opencode_index(limit: int):
    return _legacy.index_sqlite_agent_stores(
        _legacy._opencode_roots(),
        agent_type="opencode",
        db_names=("opencode.db", "store.db", "data.db"),
        limit=limit,
    )


# Certified product sync never uses the legacy generic-JSONL fallback for
# OpenCode. Telemetry/cache JSONL must remain invisible.
_readers._READERS["opencode"] = _readers.ProviderReader(
    _strict_opencode_index,
    _legacy.read_opencode_thread,
)
# Kilo 1.x exposes authoritative session list/export commands. Do not infer
# conversation authority from guessed SQLite filenames or OpenCode internals.
_readers._READERS["kilo_code"] = _readers.ProviderReader(
    index_kilo_cli_threads,
    read_kilo_cli_thread,
)
# Cursor IDE composer transcripts are not Cursor CLI resume targets. Require
# the same id in the CLI chat store and matching transcript before sync.
_readers._READERS["cursor_cli"] = _readers.ProviderReader(
    index_cursor_cli_threads,
    read_cursor_cli_thread,
)
install_strict_readers()

# Import after the strict reader registry is installed. This module evaluates
# certificate capabilities but consumes the same explicit reader objects.
from . import capability_gated_thread_sync as _gated  # noqa: E402

CERTIFIABLE_SYNC_PROVIDERS = _readers.CERTIFIABLE_SYNC_PROVIDERS
MINIMUM_SYNC_PROVIDERS = _readers.MINIMUM_SYNC_PROVIDERS
certified_sync_providers = _gated.history_capable_providers
list_native_thread_index = _gated.list_native_thread_index
read_all_native_threads = _gated.read_all_native_threads
read_native_thread = _gated.read_native_thread
threads_needing_full_sync = _gated.threads_needing_full_sync
CORE_SYNC_AGENTS = CERTIFIABLE_SYNC_PROVIDERS
