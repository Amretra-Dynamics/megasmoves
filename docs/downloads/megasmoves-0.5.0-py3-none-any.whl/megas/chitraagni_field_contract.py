from __future__ import annotations

import copy
import re
from typing import Any, Iterable


# Current Chitraagni main used to audit deterministic router request models.
# This is evidence, not a runtime dependency: Megas never fetches source to build
# its tool surface at runtime.
AUDITED_CHITRAAGNI_MAIN_SHA = "af868bba9fe199d9bf4ecdf21ef7b8b7d3c8842d"
FIELD_CONTRACT_VERSION = 2
_PATH_FIELD_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")

# Fields accepted by the authoritative Chitraagni request/query contracts at the
# audited revision. Path identifiers are derived from ROUTES instead of repeated
# here. Megas may add stricter local-only safety fields such as confirm=true.
SERVER_FIELDS: dict[str, dict[str, Any]] = {
    "chitraagni_project_create": {
        "body": {"name", "description", "product_type", "domain"},
        "required_body": {"name"},
    },
    "chitraagni_product_create": {
        "body": {
            "name", "product_type", "platform", "goal", "description",
            "imported_source_type", "imported_source_details_json", "product_memory_json",
        },
        "required_body": {"name"},
    },
    "chitraagni_product_update": {
        "body": {
            "name", "product_type", "platform", "goal", "description",
            "imported_source_type", "imported_source_details_json", "product_memory_json",
            "workflow_status",
        },
    },
    "chitraagni_screen_create": {
        "body": {
            "page_key", "purpose", "primary_action", "secondary_actions_json",
            "required_regions_json", "components_json", "data_requirements_json",
            "required_states_json", "related_features_json", "related_entities_json",
            "page_priority",
        },
        "required_body": {"page_key"},
    },
    "chitraagni_screen_update": {
        "body": {
            "page_key", "purpose", "primary_action", "secondary_actions_json",
            "required_regions_json", "components_json", "data_requirements_json",
            "required_states_json", "related_features_json", "related_entities_json",
            "page_priority",
        },
    },
    "chitraagni_schema_create": {
        "body": {
            "name", "entity_type", "description", "attributes_json",
            "relationships_json", "related_features_json",
        },
        "required_body": {"name"},
    },
    "chitraagni_schema_update": {
        "body": {
            "name", "entity_type", "description", "attributes_json",
            "relationships_json", "related_features_json",
        },
    },
    "chitraagni_workflow_create": {
        "body": {
            "name", "trigger", "action", "result", "side_effects_json",
            "related_features_json", "related_entities_json", "related_pages_json",
        },
        "required_body": {"name"},
    },
    "chitraagni_workflow_update": {
        "body": {
            "name", "trigger", "action", "result", "side_effects_json",
            "related_features_json", "related_entities_json", "related_pages_json",
        },
    },
    "chitraagni_version_snapshot": {"body": {"label", "source_type", "status"}},
    "chitraagni_version_update": {"body": {"label", "status"}},
    "chitraagni_design_token_set_create": {
        "body": {
            "token_set_key", "name", "description", "tokens_json", "modes_json", "metadata_json",
        },
        "required_body": {"token_set_key", "name"},
    },
    "chitraagni_design_token_set_update": {
        "body": {
            "token_set_key", "name", "description", "tokens_json", "modes_json", "metadata_json",
        },
    },
    "chitraagni_component_definition_create": {
        "body": {
            "component_key", "name", "kind", "description", "props_schema_json",
            "slots_json", "variants_json", "states_json", "default_props_json",
            "token_bindings_json", "constraints_json", "responsive_json", "metadata_json",
        },
        "required_body": {"component_key", "name"},
    },
    "chitraagni_component_definition_update": {
        "body": {
            "component_key", "name", "kind", "description", "props_schema_json",
            "slots_json", "variants_json", "states_json", "default_props_json",
            "token_bindings_json", "constraints_json", "responsive_json", "metadata_json",
        },
    },
    "chitraagni_product_screen_create": {
        "body": {
            "page_key", "purpose", "primary_action", "secondary_actions_json",
            "required_regions_json", "components_json", "data_requirements_json",
            "required_states_json", "related_features_json", "related_entities_json",
            "page_priority",
        },
        "required_body": {"page_key"},
    },
    "chitraagni_product_screen_update": {
        "body": {
            "page_key", "purpose", "primary_action", "secondary_actions_json",
            "required_regions_json", "components_json", "data_requirements_json",
            "required_states_json", "related_features_json", "related_entities_json",
            "page_priority",
        },
    },
    "chitraagni_product_screen_delete": {
        "query": {"confirm"},
        "required_query": {"confirm"},
    },
    "chitraagni_project_quality": {"query": {"version_id"}},
    "chitraagni_project_codegen_react_next": {"query": {"version_id"}},
    "chitraagni_r5_command": {
        "body": {
            "action", "correlation_id", "base_review_updated_at", "base_library_updated_at",
            "review_bundle", "library_bundle", "metadata",
        },
        "required_body": {"action"},
    },
}

# Current Chitraagni fields that the older Megas schema omitted. Keep this tiny
# and explicit. It changes the production typed contract and therefore naturally
# changes the fingerprint used by local Chitraagni tool authority.
PRODUCTION_SCHEMA_OVERLAYS: dict[str, dict[str, dict[str, Any]]] = {
    "chitraagni_product_create": {
        "imported_source_type": {"type": "string", "default": "manual"},
        "imported_source_details_json": {"type": "object"},
    },
    "chitraagni_product_update": {
        "imported_source_type": {"type": "string"},
        "imported_source_details_json": {"type": "object"},
    },
    "chitraagni_version_snapshot": {
        "source_type": {"type": "string", "default": "manual_snapshot"},
    },
}


def apply_production_field_overlays(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = copy.deepcopy(tools)
    by_name = {str(row.get("name") or ""): row for row in result}
    for name, additions in PRODUCTION_SCHEMA_OVERLAYS.items():
        tool = by_name.get(name)
        if tool is None:
            raise ValueError(f"production Chitraagni catalog is missing {name}")
        schema = tool.get("inputSchema")
        if not isinstance(schema, dict):
            raise ValueError(f"{name} is missing inputSchema")
        properties = schema.get("properties")
        if not isinstance(properties, dict):
            raise ValueError(f"{name} inputSchema is missing properties")
        for field, definition in additions.items():
            properties[field] = copy.deepcopy(definition)
    return result


def installed_production_tools() -> list[dict[str, Any]]:
    """Return the static production tool contract without account/network access."""

    from .chitraagni_operator import TOOLS
    from .chitraagni_operator_complete import COMPLETE_TOOLS
    from .chitraagni_operator_context import CONTEXT_TOOLS
    from .chitraagni_operator_extended import EXTENDED_TOOLS
    from .chitraagni_r5_contract import harden_runtime_tools

    tools = [
        copy.deepcopy(tool)
        for group in (TOOLS, EXTENDED_TOOLS, COMPLETE_TOOLS, CONTEXT_TOOLS)
        for tool in group
    ]
    return apply_production_field_overlays(harden_runtime_tools(tools))


def _path_fields(path: str) -> set[str]:
    return set(_PATH_FIELD_RE.findall(path.split("?", 1)[0]))


def _string_schema(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    kind = value.get("type")
    return kind == "string" or (isinstance(kind, list) and "string" in kind)


def field_parity(
    routes: Iterable[dict[str, str]],
    tools: Iterable[dict[str, Any]],
) -> dict[str, Any]:
    by_name = {
        str(tool.get("name") or ""): tool
        for tool in tools
        if isinstance(tool, dict) and str(tool.get("name") or "")
    }
    rows: list[dict[str, Any]] = []
    issues: list[dict[str, str]] = []

    for route in routes:
        tool_name = str(route.get("tool") or "")
        method = str(route.get("method") or "").upper()
        path = str(route.get("path") or "")
        route_issues: list[str] = []
        tool = by_name.get(tool_name)
        if tool is None:
            route_issues.append("tool missing")
        else:
            schema = tool.get("inputSchema")
            annotations = tool.get("annotations")
            if not isinstance(schema, dict) or schema.get("type") != "object":
                route_issues.append("inputSchema must be an object schema")
                properties: dict[str, Any] = {}
                required: set[str] = set()
            else:
                raw_properties = schema.get("properties")
                properties = raw_properties if isinstance(raw_properties, dict) else {}
                raw_required = schema.get("required")
                required_values = raw_required if isinstance(raw_required, list) else []
                required = {str(value) for value in required_values if str(value)}
                if schema.get("additionalProperties") is not False:
                    route_issues.append("inputSchema must set additionalProperties=false")

            for field in sorted(_path_fields(path)):
                if field not in properties:
                    route_issues.append(f"path field {field} missing from inputSchema")
                elif not _string_schema(properties[field]):
                    route_issues.append(f"path field {field} must accept string")
                if field not in required:
                    route_issues.append(f"path field {field} must be required")

            field_contract = SERVER_FIELDS.get(tool_name, {})
            server_fields = set(field_contract.get("body") or set()) | set(
                field_contract.get("query") or set()
            )
            required_server = set(field_contract.get("required_body") or set()) | set(
                field_contract.get("required_query") or set()
            )
            for field in sorted(server_fields):
                if field not in properties:
                    route_issues.append(f"server field {field} missing from inputSchema")
            for field in sorted(required_server):
                if field not in required:
                    route_issues.append(f"server-required field {field} must be required")

            if method == "DELETE":
                confirm = properties.get("confirm")
                if not isinstance(confirm, dict) or confirm.get("const") is not True:
                    route_issues.append("DELETE requires local confirm const=true")
                if "confirm" not in required:
                    route_issues.append("DELETE requires confirm")

            if not isinstance(annotations, dict):
                route_issues.append("annotations must be an object")
            else:
                if method == "GET" and annotations.get("readOnlyHint") is not True:
                    route_issues.append("GET tool must advertise readOnlyHint=true")
                if method != "GET" and annotations.get("readOnlyHint") is not False:
                    route_issues.append("mutating tool must advertise readOnlyHint=false")
                if method == "DELETE" and annotations.get("destructiveHint") is not True:
                    route_issues.append("DELETE tool must advertise destructiveHint=true")
                if annotations.get("openWorldHint") is not False:
                    route_issues.append("mounted deterministic tool must advertise openWorldHint=false")

        for issue in route_issues:
            issues.append(
                {"tool": tool_name, "method": method, "path": path, "issue": issue}
            )
        rows.append(
            {
                "tool": tool_name,
                "method": method,
                "path": path,
                "complete": not route_issues,
                "issues": route_issues,
            }
        )

    return {
        "version": FIELD_CONTRACT_VERSION,
        "audited_chitraagni_main_sha": AUDITED_CHITRAAGNI_MAIN_SHA,
        "complete": not issues,
        "route_count": len(rows),
        "complete_route_count": sum(1 for row in rows if row["complete"]),
        "issues": issues,
        "routes": rows,
    }


def assert_field_parity(
    routes: Iterable[dict[str, str]],
    tools: Iterable[dict[str, Any]],
) -> dict[str, Any]:
    report = field_parity(routes, tools)
    if report["issues"]:
        preview = "; ".join(
            f"{row['tool']}: {row['issue']}" for row in report["issues"][:12]
        )
        raise RuntimeError("Megas MCP Chitraagni field contract is incomplete: " + preview)
    return report


__all__ = [
    "AUDITED_CHITRAAGNI_MAIN_SHA",
    "FIELD_CONTRACT_VERSION",
    "PRODUCTION_SCHEMA_OVERLAYS",
    "SERVER_FIELDS",
    "apply_production_field_overlays",
    "assert_field_parity",
    "field_parity",
    "installed_production_tools",
]
