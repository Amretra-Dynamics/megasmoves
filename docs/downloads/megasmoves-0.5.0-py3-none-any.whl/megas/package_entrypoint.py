"""Cross-platform consumer entrypoint over the existing Megas Moves capability core."""
from __future__ import annotations
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import subprocess
import sys


def main(argv: list[str] | None = None) -> None:
    actual = list(sys.argv[1:] if argv is None else argv)
    if actual in (["--version"], ["version"]):
        for distribution in ("megasmoves", "megas"):
            try:
                print(version(distribution))
                return
            except PackageNotFoundError:
                pass
        raise SystemExit("Megas Moves package metadata is missing. Reinstall the package.")
    if actual in (["--help"], ["-h"], ["help"]):
        print("Megas Moves\nmegas: open the installed Windows app or show local commands\n"
              "megas gui: open the native app\nmegas connect / megas serve: use Megas MCP\n"
              "megas --version: show package version")
        return
    if actual == ["connect"]:
        actual = ["serve"]
    if sys.platform == "win32":
        from .windows_launcher import main as installed_main
        if actual == ["gui"]:
            actual = []
        installed_main(actual)
        return
    if actual == ["gui"]:
        if sys.platform == "darwin":
            candidates = [Path.home() / "Applications/MegasMoves.app", Path("/Applications/MegasMoves.app")]
            target = next((path for path in candidates if path.is_dir()), None)
            if target:
                from .adapters.base import subprocess_hide_window_kwargs
                subprocess.run(["/usr/bin/open", str(target)], check=True, timeout=20, shell=False, **subprocess_hide_window_kwargs())
                return
        elif sys.platform.startswith("linux"):
            target = Path("/usr/local/bin/megasmoves_gtk")
            if target.is_file():
                from .adapters.base import subprocess_hide_window_kwargs
                subprocess.Popen([str(target)], shell=False, close_fds=True, **subprocess_hide_window_kwargs())
                return
        raise SystemExit("Native desktop app is not installed. Use the matching app download.")
    from .installed_entrypoint import main as core_main
    core_main(actual)


if __name__ == "__main__":
    main()
