from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
from typing import Any, Callable
import urllib.error
import urllib.request

from ..execution_fabric.models import PlatformPolicyViolation
from ..adapters.base import windows_subprocess_kwargs

MAX_BRIDGE_PAYLOAD_BYTES = 256 * 1024
DEFAULT_BRIDGE_PORT = 9876
GENUINE_APPLE_MODEL_PREFIXES = (
    "Mac",
    "iMac",
    "MacBook",
    "Macmini",
    "MacPro",
    "VirtualMac",
)


def verify_genuine_apple_hardware() -> dict[str, Any]:
    """Verify that the current host is genuine Apple hardware.

    Enforces Apple macOS EULA and MegasMoves policy: macOS operations
    must never be executed on unauthorized PC virtualization or Hackintosh nodes.
    """
    if platform.system() != "Darwin":
        raise PlatformPolicyViolation(
            f"Megas Platform Bridge requires genuine macOS host; detected '{platform.system()}'",
            rule_code="LEGAL_EULA_NON_APPLE_HOST",
            suggested_action="Run Megas Platform Bridge on genuine Apple hardware.",
        )

    try:
        model = subprocess.check_output(["sysctl", "-n", "hw.model"], text=True, timeout=5,
                                        **windows_subprocess_kwargs()).strip()
    except Exception as exc:
        raise PlatformPolicyViolation(
            f"Unable to verify Apple hardware authenticity via sysctl: {exc}",
            rule_code="HARDWARE_AUTHENTICITY_INDETERMINATE",
            suggested_action="Ensure sysctl hw.model is accessible on macOS.",
        ) from exc

    if not any(model.startswith(prefix) for prefix in GENUINE_APPLE_MODEL_PREFIXES):
        raise PlatformPolicyViolation(
            f"Unauthorized hardware identifier '{model}'; macOS operations require genuine Apple hardware",
            rule_code="LEGAL_EULA_UNAUTHORIZED_HARDWARE",
            suggested_action="macOS test operations must be routed to genuine Apple hardware via LAN.",
        )

    return {"hw_model": model, "genuine_apple": True}


def discover_mac_capabilities() -> dict[str, Any]:
    """Discover installed macOS development tools, Xcode, and iOS Simulators."""
    verification = verify_genuine_apple_hardware()

    xcode_path = None
    if shutil.which("xcode-select"):
        try:
            xcode_path = subprocess.check_output(
                ["xcode-select", "-p"], text=True, timeout=5, **windows_subprocess_kwargs()
            ).strip()
        except Exception:
            pass

    xcode_version = None
    if shutil.which("xcodebuild"):
        try:
            xcode_version = subprocess.check_output(
                ["xcodebuild", "-version"], text=True, timeout=5, **windows_subprocess_kwargs()
            ).splitlines()[0].strip()
        except Exception:
            pass

    swift_version = None
    if shutil.which("swift"):
        try:
            swift_version = subprocess.check_output(
                ["swift", "--version"], text=True, timeout=5, **windows_subprocess_kwargs()
            ).splitlines()[0].strip()
        except Exception:
            pass

    simulators: list[dict[str, Any]] = []
    if shutil.which("xcrun"):
        try:
            simctl_out = subprocess.check_output(
                ["xcrun", "simctl", "list", "devices", "available", "-j"],
                text=True,
                timeout=10,
                **windows_subprocess_kwargs(),
            )
            data = json.loads(simctl_out)
            for runtime_id, devices in (data.get("devices") or {}).items():
                for dev in devices:
                    if dev.get("isAvailable"):
                        simulators.append({
                            "name": dev.get("name"),
                            "udid": dev.get("udid"),
                            "state": dev.get("state"),
                            "runtime": runtime_id,
                        })
        except Exception:
            pass

    return {
        "status": "ready",
        "genuine_apple": True,
        "hw_model": verification["hw_model"],
        "xcode_path": xcode_path,
        "xcode_version": xcode_version,
        "swift_version": swift_version,
        "simulators_count": len(simulators),
        "simulators": simulators[:20],
    }


def execute_mac_action(
    target_path: str,
    action: str,
    *,
    build_tool: str = "swift",
    timeout_seconds: int = 60,
) -> dict[str, Any]:
    """Execute a validated build, test, run, or stop action on this genuine Mac node."""
    verify_genuine_apple_hardware()

    path = Path(target_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Target path does not exist: {target_path}")

    cwd = path if path.is_dir() else path.parent

    if action == "build":
        if build_tool == "swift" or (cwd / "Package.swift").is_file():
            argv = ["swift", "build"]
        elif (cwd / "CMakeLists.txt").is_file():
            argv = ["cmake", "--build", "build"]
        else:
            argv = ["xcodebuild", "-scheme", cwd.name, "build"]
        result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=timeout_seconds,
                                **windows_subprocess_kwargs())
        return {
            "ok": result.returncode == 0,
            "stage": "build",
            "returncode": result.returncode,
            "stdout": result.stdout[-4000:],
            "stderr": result.stderr[-4000:],
        }

    if action == "test":
        if build_tool == "swift" or (cwd / "Package.swift").is_file():
            argv = ["swift", "test"]
        else:
            argv = ["xcodebuild", "test"]
        result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=timeout_seconds,
                                **windows_subprocess_kwargs())
        return {
            "ok": result.returncode == 0,
            "stage": "test",
            "returncode": result.returncode,
            "stdout": result.stdout[-4000:],
            "stderr": result.stderr[-4000:],
        }

    if action == "open":
        if build_tool == "swift" or (cwd / "Package.swift").is_file():
            proc = subprocess.Popen(["swift", "run"], cwd=cwd, **windows_subprocess_kwargs(hide_window=False))
            return {"ok": True, "stage": "open", "pid": proc.pid}
        raise ValueError("Unsupported open configuration for macOS target")

    if action == "stop":
        name = cwd.name
        subprocess.run(["pkill", "-f", name], check=False, timeout=10, **windows_subprocess_kwargs())
        return {"ok": True, "stage": "stop", "target": name}

    raise ValueError(f"Unsupported macOS bridge action: {action}")


class MacPlatformBridgeHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the authenticated macOS platform bridge."""

    server_token: str = ""

    def _authenticate(self) -> bool:
        if not self.server_token:
            return True
        header = self.headers.get("Authorization") or ""
        expected = f"Bearer {self.server_token}"
        return header.strip() == expected

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:  # noqa: N802
        if not self._authenticate():
            self._send_json(401, {"error": "unauthorized"})
            return

        if self.path in ("/health", "/"):
            try:
                hw = verify_genuine_apple_hardware()
                self._send_json(200, {"status": "ok", "host": "macos", "model": hw["hw_model"]})
            except PlatformPolicyViolation as exc:
                self._send_json(403, {"status": "policy_violation", "error": str(exc)})
            return

        if self.path == "/capabilities":
            try:
                caps = discover_mac_capabilities()
                self._send_json(200, caps)
            except PlatformPolicyViolation as exc:
                self._send_json(403, {"status": "policy_violation", "error": str(exc)})
            return

        self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self._authenticate():
            self._send_json(401, {"error": "unauthorized"})
            return

        if self.path == "/action":
            length = int(self.headers.get("Content-Length") or 0)
            if length > MAX_BRIDGE_PAYLOAD_BYTES:
                self._send_json(413, {"error": "payload too large"})
                return
            body = self.rfile.read(length)
            try:
                data = json.loads(body.decode("utf-8"))
                target_path = str(data.get("target_path") or "")
                action = str(data.get("action") or "")
                build_tool = str(data.get("build_tool") or "swift")
                result = execute_mac_action(target_path, action, build_tool=build_tool)
                self._send_json(200, result)
            except PlatformPolicyViolation as exc:
                self._send_json(403, {"ok": False, "error": str(exc)})
            except Exception as exc:
                self._send_json(400, {"ok": False, "error": str(exc)})
            return

        self._send_json(404, {"error": "not found"})


class MacPlatformBridgeServer:
    """Zero-desk-switch bridge server running on a genuine Mac."""

    def __init__(self, host: str = "0.0.0.0", port: int = DEFAULT_BRIDGE_PORT, token: str = "") -> None:
        self.host = host
        self.port = port
        self.token = token
        self._server: ThreadingHTTPServer | None = None

    def start(self) -> None:
        verify_genuine_apple_hardware()
        handler_cls = type("ConfiguredHandler", (MacPlatformBridgeHandler,), {"server_token": self.token})
        self._server = ThreadingHTTPServer((self.host, self.port), handler_cls)
        self._server.serve_forever()

    def shutdown(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None


class MacPlatformBridgeClient:
    """Client used by Windows or Linux MegasMoves operator to dispatch tests to a genuine Mac."""

    def __init__(self, base_url: str, token: str = "", timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _request(self, method: str, endpoint: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        url = f"{self.base_url}{endpoint}"
        body = json.dumps(data).encode("utf-8") if data is not None else None
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        req = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as err:
            try:
                err_payload = json.loads(err.read().decode("utf-8"))
            except Exception:
                err_payload = {"error": f"HTTP {err.code}"}
            return {"ok": False, "status_code": err.code, **err_payload}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def check_health(self) -> dict[str, Any]:
        return self._request("GET", "/health")

    def get_capabilities(self) -> dict[str, Any]:
        return self._request("GET", "/capabilities")

    def dispatch_action(self, target: dict[str, Any], action: str) -> dict[str, Any]:
        target_path = str(target.get("project_path") or target.get("root") or "")
        return self._request(
            "POST",
            "/action",
            {
                "target_path": target_path,
                "action": action,
                "target_id": str(target.get("id") or ""),
                "kind": str(target.get("kind") or "macos"),
            },
        )
