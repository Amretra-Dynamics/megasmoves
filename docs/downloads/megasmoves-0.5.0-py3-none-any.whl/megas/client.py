"""Compatibility wrapper for the certified multi-provider Worker runtime."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any

from . import client_legacy as _legacy
from .adapters.base import WorkerEvent
from .adapters.cursor import CursorCliAdapter
from .adapters.jules import JulesCliAdapter
from .codex_rate_limits import read_codex_rate_limits
from .mcp.agent_presence import summarize_agent_presence
from .mcp.remote_relay import RemoteMCPRelay
from .mcp.store import MCPStore
from .provider_limit_state import (
    EvidenceBoundLimitStateStore,
    heartbeat_snapshot_after_durable_event,
    heartbeat_snapshot_for_transition,
    project_limit_snapshots_into_health,
)
from .runtime_dispatch_gate import (
    EXECUTABLE_AGENT_TYPES,
    evaluate_dispatch_report,
    required_capabilities,
)


_MINIMUM_AGENT_TYPES = {
    "codex_cli",
    "antigravity",
    "grok_build",
    "devin_cli",
    "cursor_cli",
    "jules_cli",
    "kilo_code",
    "kiro_code",
    "opencode",
    "cline",
}
_OPTIONAL_AGENT_TYPES = {"claude_code", "aider"}

# These legacy sets are compatibility catalogues only. Runtime dispatch and UI
# readiness are both re-checked against the installation-bound manifest below.
_legacy.AGENT_BINARIES.pop("gemini_cli", None)
_legacy.AGENT_BINARY_ENVIRONMENTS.pop("gemini_cli", None)
_legacy.AGENT_BINARIES.update(
    {
        "cursor_cli": "cursor-agent",
        "jules_cli": "jules",
        "kiro_code": "kiro-cli",
    }
)
_legacy.AGENT_BINARY_ENVIRONMENTS.update(
    {
        "cursor_cli": "MEGAS_CURSOR_BINARY",
        "jules_cli": "MEGAS_JULES_BINARY",
    }
)
_legacy.CERTIFIED_AGENT_TYPES.clear()
_legacy.CERTIFIED_AGENT_TYPES.update(_MINIMUM_AGENT_TYPES | _OPTIONAL_AGENT_TYPES)


def _report_is_execution_verified(report: dict[str, Any]) -> bool:
    return bool(
        report.get("status") == "available"
        and str(report.get("certification_status") or "").lower()
        in {"verified", "certified"}
    )


def _mcp_agent_activity_for_heartbeat() -> dict[str, Any]:
    """Return bounded local Megas MCP usage evidence for the linked account.

    This is deliberately a projection of the canonical local MCP activity store.
    It contains no request bodies, credentials, prompts, tool arguments, or
    Chitraagni payloads. Client name/version remain attribution metadata only.
    """

    try:
        value = summarize_agent_presence(MCPStore())
    except Exception as exc:
        return {
            "available": False,
            "error_type": type(exc).__name__,
        }
    agents = value.get("agents") if isinstance(value.get("agents"), list) else []
    # The mobile/backend heartbeat projection is intentionally smaller than the
    # local operator resource. Full local evidence remains in Megas MCP itself.
    visible = []
    for row in agents[:16]:
        if not isinstance(row, dict):
            continue
        visible.append(
            {
                "name": str(row.get("name") or "")[:128],
                "version": str(row.get("version") or "")[:128] or None,
                "transport": str(row.get("transport") or "mcp")[:32],
                "state": "active" if row.get("state") == "active" else "inactive",
                "transport_state": str(row.get("transport_state") or "unknown")[:32],
                "last_seen": row.get("last_seen"),
                "age_seconds": max(0, int(row.get("age_seconds") or 0)),
            }
        )
    counts = value.get("counts") if isinstance(value.get("counts"), dict) else {}
    return {
        "available": True,
        "generated_at": value.get("generated_at"),
        "activity_window_seconds": int(value.get("activity_window_seconds") or 120),
        "active": max(0, int(counts.get("active") or 0)),
        "observed": max(0, int(counts.get("observed") or 0)),
        "agents": visible,
        "truncated": bool(value.get("truncated")) or len(agents) > len(visible),
        "identity_semantics": "client-supplied-attribution",
        "active_semantics": "recent-protocol-or-tool-activity",
    }


class _HeartbeatProxy:
    def __init__(
        self,
        target: Any,
        *,
        worker_id: str,
        limit_snapshots: dict[str, dict[str, Any]],
    ) -> None:
        self._target = target
        self._worker_id = str(worker_id or "")
        self._limit_snapshots = limit_snapshots

    def __getattr__(self, name: str) -> Any:
        return getattr(self._target, name)

    async def send(self, raw: str) -> Any:
        try:
            payload = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            return await self._target.send(raw)
        if isinstance(payload, dict) and payload.get("type") == "heartbeat":
            health = payload.get("agents_health")
            if not isinstance(health, dict):
                health = {}
                payload["agents_health"] = health

            manifest = payload.get("runtime_manifest")
            if isinstance(manifest, dict):
                manifest_agents = manifest.get("agents")
                if isinstance(manifest_agents, dict) and manifest_agents:
                    # A deep manifest is the authority. Remove legacy catalog-only
                    # peers and deprecated Gemini rather than showing fake readiness.
                    for stale in list(health):
                        if stale == "gemini_cli" or stale not in manifest_agents:
                            health.pop(stale, None)
                    for provider_id, report in manifest_agents.items():
                        if not isinstance(report, dict):
                            continue
                        certified = _report_is_execution_verified(report)
                        detected = bool(report.get("binary"))
                        existing = health.get(provider_id)
                        if not isinstance(existing, dict):
                            existing = {}
                        existing.update(
                            {
                                "agent_id": f"{provider_id}_w-{self._worker_id}",
                                "agent_type": provider_id,
                                "display_name": str(provider_id).replace("_", " ").title(),
                                "detected": detected,
                                "installed": detected,
                                "enabled": certified,
                                "logged_in": report.get("auth_mode")
                                not in {None, "", "unauthenticated"},
                                "authentication_state": report.get("auth_mode")
                                or "unknown",
                                "executable_version": report.get("version") or "",
                                "capabilities": list(
                                    report.get("verified_capabilities") or []
                                ),
                                "health_state": (
                                    "healthy"
                                    if certified
                                    else "degraded"
                                    if detected
                                    else "unhealthy"
                                ),
                                "health_reason": report.get(
                                    "certification_reason"
                                )
                                or report.get("reason"),
                                "certification_status": report.get(
                                    "certification_status"
                                )
                                or "not_verified",
                                "certification_reason": report.get(
                                    "certification_reason"
                                )
                                or report.get("reason"),
                                "installation_fingerprint": report.get(
                                    "installation_fingerprint"
                                ),
                                "dispatch_enabled": certified,
                            }
                        )
                        health[provider_id] = existing

            project_limit_snapshots_into_health(
                health,
                self._limit_snapshots,
            )
            health_payload = payload.get("health_payload")
            if not isinstance(health_payload, dict):
                health_payload = {}
            health_payload["mcp_agent_activity"] = _mcp_agent_activity_for_heartbeat()
            payload["health_payload"] = health_payload
            return await self._target.send(
                json.dumps(payload, separators=(",", ":"))
            )
        return await self._target.send(raw)


for _name, _value in vars(_legacy).items():
    if not _name.startswith("__"):
        globals()[_name] = _value


class WorkerRuntime(_legacy.WorkerRuntime):
    def __init__(self, config) -> None:
        super().__init__(config)
        previous_limits = getattr(self, "_agent_limit_states", {})
        evidence_bound = EvidenceBoundLimitStateStore()
        if isinstance(previous_limits, dict):
            for agent_type, payload in previous_limits.items():
                if isinstance(payload, dict):
                    evidence_bound[str(agent_type)] = payload
        self._agent_limit_states = evidence_bound
        self._provider_limit_snapshots: dict[str, dict[str, Any]] = {}
        self._remote_mcp_relay: RemoteMCPRelay | None = None

        present = {
            str(getattr(adapter, "name", "")) for adapter in self.adapters
        }
        if "cursor_cli" not in present:
            self.adapters.append(CursorCliAdapter(config.allowed_folders))
        if "jules_cli" not in present:
            self.adapters.append(JulesCliAdapter(config.allowed_folders))

    async def _handle_message(self, ws, message: dict[str, Any]) -> None:
        """Handle MCP relay traffic without creating a second Worker/operator path."""

        if isinstance(message, dict) and message.get("type") == "mcp_remote_request":
            if self._remote_mcp_relay is None:
                self._remote_mcp_relay = RemoteMCPRelay(self.config)
            task = asyncio.create_task(self._remote_mcp_relay.handle(message))
            self._track_control_task(task)
            return
        await super()._handle_message(ws, message)

    async def _verify_agent_readiness(self, command: dict[str, Any]) -> None:
        """Require the exact runtime certificate before legacy readiness checks."""

        from .agent_router import canonicalize_agent_id

        context_pack = (
            command.get("context_pack")
            if isinstance(command.get("context_pack"), dict)
            else {}
        )
        raw_agent = str(
            context_pack.get("agent_type")
            or command.get("agent_type")
            or command.get("command_type")
            or ""
        ).strip()
        base_agent = raw_agent
        for suffix in ("_w-", "_w_", "_worker_"):
            if suffix in base_agent:
                base_agent = base_agent.split(suffix, 1)[0]
                break
        base_agent = canonicalize_agent_id(base_agent) or base_agent

        if base_agent in EXECUTABLE_AGENT_TYPES:
            manifest = await self._certified_runtime_manifest()
            agents = manifest.get("agents") if isinstance(manifest, dict) else None
            report = agents.get(base_agent) if isinstance(agents, dict) else None
            decision = evaluate_dispatch_report(
                report if isinstance(report, dict) else None,
                required=required_capabilities(command),
            )
            if not decision.allowed:
                raise PermissionError(
                    f"Agent '{base_agent}' dispatch blocked: {decision.reason}."
                )

        await super()._verify_agent_readiness(command)

    async def _refresh_codex_limit_snapshot(self) -> None:
        binary = str(os.getenv("MEGAS_CODEX_BINARY") or "codex").strip()
        roots = list(getattr(self.config, "allowed_folders", []) or [])
        cwd = Path(roots[0]).expanduser() if roots else Path.home()
        snapshot = await read_codex_rate_limits(
            binary=binary,
            cwd=cwd,
            timeout_seconds=8.0,
        )
        if not isinstance(snapshot, dict):
            return
        transition = self._agent_limit_states.observe_provider_snapshot(
            "codex_cli",
            snapshot,
        )
        self._provider_limit_snapshots["codex_cli"] = (
            heartbeat_snapshot_for_transition(transition)
        )

    async def _send_event(
        self,
        ws,
        session_id: str,
        command_id: str,
        lease_id: str,
        event: WorkerEvent,
        event_index: int,
    ) -> None:
        if event.event_type == "provider_limit_snapshot":
            agent_type = str(
                event.payload.get("agent_type") or "codex_cli"
            ).strip()
            transition = self._agent_limit_states.observe_provider_snapshot(
                agent_type,
                event.payload,
            )
            self._provider_limit_snapshots[agent_type] = (
                heartbeat_snapshot_after_durable_event(transition)
            )
            if transition.event_type is None:
                # Heartbeats carry the latest provider-observed snapshot; avoid
                # polluting the durable chat with unchanged quota telemetry.
                return
            event = WorkerEvent(transition.event_type, transition.payload)
        elif event.event_type == "agent_limit_recovered" and not bool(
            event.payload.get("provider_observed")
        ):
            # Defense in depth for legacy code: successful task completion is
            # not evidence that a quota window reset.
            return

        await super()._send_event(
            ws,
            session_id,
            command_id,
            lease_id,
            event,
            event_index,
        )

    async def _send_heartbeat(self, ws, *, deep_health: bool = True) -> None:
        if deep_health:
            try:
                await self._refresh_codex_limit_snapshot()
            except Exception:
                # Quota telemetry is advisory and must never take down the
                # control socket or delay dispatch after its bounded timeout.
                pass
        await super()._send_heartbeat(
            _HeartbeatProxy(
                ws,
                worker_id=self.config.worker_id,
                limit_snapshots=self._provider_limit_snapshots,
            ),
            deep_health=deep_health,
        )


CERTIFIED_AGENT_TYPES = _legacy.CERTIFIED_AGENT_TYPES
AGENT_BINARIES = _legacy.AGENT_BINARIES
AGENT_BINARY_ENVIRONMENTS = _legacy.AGENT_BINARY_ENVIRONMENTS
