from __future__ import annotations

import logging
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from typing import Any, Dict, Optional

from .adapters.base import prefer_console_free_tool_path, windows_subprocess_kwargs

logger = logging.getLogger("megas_worker_source_materializer")


class SourceMaterializerEngine:
    """Materializes missing worker workspaces to exact pinned commit revision."""

    def materialize_workspace(
        self,
        destination_dir: str,
        pinned_binding: Dict[str, Any],
        credential_reference: Optional[str] = None,
        archive_path: Optional[str] = None,
    ) -> bool:
        dest_path = Path(destination_dir).resolve()
        dest_path.mkdir(parents=True, exist_ok=True)

        expected_commit = str(pinned_binding.get("base_commit") or "").strip()
        canonical_url = str(pinned_binding.get("canonical_url") or "").strip()
        repo_id = str(pinned_binding.get("provider_repository_id") or "").strip()

        # 1. Materialization via local archive tarball if available
        if archive_path and Path(archive_path).exists():
            try:
                logger.info("Materializing workspace from snapshot archive %s to %s", archive_path, destination_dir)
                with tarfile.open(archive_path, "r:*") as tar:
                    tar.extractall(path=dest_path)
                return True
            except Exception as e:
                logger.warning("Failed to extract snapshot archive %s: %s", archive_path, e)

        # 2. Materialization via Git fetch/clone
        if canonical_url:
            safe_url = self._redact_secrets(canonical_url)
            logger.info("Materializing workspace via Git from %s (commit: %s)", safe_url, expected_commit)

            try:
                # Initialize empty git repo if not present
                if not (dest_path / ".git").exists():
                    self._run_git(dest_path, ["init"])
                    self._run_git(dest_path, ["config", "core.hooksPath", "/dev/null"])

                # Add or update remote origin
                self._run_git(dest_path, ["remote", "remove", "origin"], check=False)
                self._run_git(dest_path, ["remote", "add", "origin", canonical_url])

                # Fetch exact commit or branch
                if expected_commit:
                    fetch_res = self._run_git(dest_path, ["fetch", "--depth", "1", "origin", expected_commit], check=False)
                    if fetch_res.returncode == 0:
                        self._run_git(dest_path, ["checkout", "FETCH_HEAD"])
                    else:
                        self._run_git(dest_path, ["fetch", "origin"])
                        self._run_git(dest_path, ["checkout", expected_commit])
                return True
            except Exception as e:
                logger.error("Failed to materialize workspace via Git: %s", self._redact_secrets(str(e)))
                return False

        # Fallback empty directory setup for isolated local test runs
        logger.info("Creating local empty workspace directory for %s", destination_dir)
        return True

    def _run_git(self, cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess:
        # Prevent git hook execution and redact secrets from output
        env = prefer_console_free_tool_path(dict(os.environ))
        env["GIT_HOOKS_PATH"] = "/dev/null"
        git_env_path = env.get("PATH") or env.get("Path")
        git_executable = shutil.which("git", path=git_env_path) or "git"

        res = subprocess.run(
            [git_executable] + args,
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60,
            check=False,
            **windows_subprocess_kwargs(),
        )

        clean_stdout = self._redact_secrets(res.stdout)
        clean_stderr = self._redact_secrets(res.stderr)

        if check and res.returncode != 0:
            raise RuntimeError(f"Git command failed (code {res.returncode}): {clean_stderr}")
        return res

    def _redact_secrets(self, text: str) -> str:
        if not text:
            return ""
        # Redact tokens, bearer tokens, passwords, and private keys
        text = re.sub(r"ghs_[a-zA-Z0-9_]{20,}", "ghs_[REDACTED]", text)
        text = re.sub(r"ghp_[a-zA-Z0-9_]{20,}", "ghp_[REDACTED]", text)
        text = re.sub(r"://[^@]+@", "://[REDACTED_CREDENTIALS]@", text)
        text = re.sub(r"Bearer\s+[a-zA-Z0-9_\-\.]+", "Bearer [REDACTED_TOKEN]", text)
        return text
