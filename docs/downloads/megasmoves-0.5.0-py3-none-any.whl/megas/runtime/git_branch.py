from __future__ import annotations

import asyncio
import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

from ..adapters.base import WorkerEvent
from ..evidence.git import get_head_commit, get_repo_state
from megas.adapters.base import prefer_console_free_tool_path, windows_subprocess_kwargs


async def prepare_session_branch(workdir: Path, session_id: str, working_branch: str | None = None) -> AsyncIterator[WorkerEvent]:
    # 1. Sanitize session_id to form deterministic and safe branch name if not provided
    if not working_branch:
        clean_id = re.sub(r"[^a-zA-Z0-9_\-]", "", session_id.replace("sess_", ""))
        if not clean_id:
            raise ValueError(f"Invalid session_id for branch name: {session_id}")
        working_branch = f"megas/session-{clean_id}"

    # Verify this is a git repo
    if not (workdir / ".git").exists():
        raise ValueError("Not a git repository")

    # Get current state
    repo_state = await get_repo_state(workdir)
    current_branch = repo_state["branch"]
    base_commit = await get_head_commit(workdir)

    # Check if metadata path exists
    meta_dir = Path.home() / ".megasmoves" / "sessions" / session_id
    meta_file = meta_dir / "branch.json"

    # Case A: already on the safe branch
    if current_branch == working_branch:
        original_branch = "main"
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text(encoding="utf-8"))
                original_branch = meta.get("original_branch") or "main"
            except Exception:
                pass
        
        # Yield the events
        yield WorkerEvent("evidence", {
            "evidence_type": "evidence_branch_prepared",
            "summary": f"Branch prepared: {original_branch} -> {working_branch}",
            "payload": {
                "kind": "branch_prepared",
                "original_branch": original_branch,
                "working_branch": working_branch,
                "base_commit": base_commit,
                "created": False,
                "session_id": session_id
            }
        })
        yield WorkerEvent("branch_prepared", {
            "session_id": session_id,
            "original_branch": original_branch,
            "working_branch": working_branch,
            "base_commit": base_commit,
            "created": False
        })
        return

    # Case B: not on the safe branch. Switch is required.
    # Check if workspace is dirty
    if repo_state["dirty"]:
        raise PermissionError(f"Workspace is dirty. Branch switching to '{working_branch}' requires a clean workspace.")

    # Check if branch already exists in local references
    check_branch_proc = await asyncio.create_subprocess_exec(
        "git", "show-ref", "--verify", f"refs/heads/{working_branch}",
        cwd=str(workdir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=prefer_console_free_tool_path(),
        **windows_subprocess_kwargs(new_group=False),
    )
    await check_branch_proc.communicate()
    branch_exists = check_branch_proc.returncode == 0

    created = False
    original_branch = current_branch

    if branch_exists:
        # Verify metadata matches
        if not meta_file.exists():
            raise ValueError(f"Safe branch '{working_branch}' exists but metadata file is missing. Aborting.")
        
        try:
            meta = json.loads(meta_file.read_text(encoding="utf-8"))
        except Exception as exc:
            raise ValueError(f"Failed to read metadata for branch '{working_branch}': {exc}. Aborting.")

        if meta.get("session_id") != session_id or meta.get("base_commit") != base_commit:
            raise ValueError(f"Metadata mismatch for branch '{working_branch}': base_commit or session_id does not match current workspace. Aborting.")

        # Switch to existing branch
        checkout_proc = await asyncio.create_subprocess_exec(
            "git", "checkout", working_branch,
            cwd=str(workdir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=prefer_console_free_tool_path(),
            **windows_subprocess_kwargs(new_group=False),
        )
        _, stderr_c = await checkout_proc.communicate()
        if checkout_proc.returncode != 0:
            raise ValueError(f"Failed to checkout safe branch '{working_branch}': {stderr_c.decode(errors='replace')}")
    else:
        # Create safe branch from current HEAD
        checkout_proc = await asyncio.create_subprocess_exec(
            "git", "checkout", "-b", working_branch,
            cwd=str(workdir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=prefer_console_free_tool_path(),
            **windows_subprocess_kwargs(new_group=False),
        )
        _, stderr_c = await checkout_proc.communicate()
        if checkout_proc.returncode != 0:
            raise ValueError(f"Failed to create safe branch '{working_branch}': {stderr_c.decode(errors='replace')}")
        
        created = True

        # Write metadata
        meta_dir.mkdir(parents=True, exist_ok=True)
        meta_data = {
            "session_id": session_id,
            "repo_root": str(workdir.resolve()),
            "original_branch": original_branch,
            "working_branch": working_branch,
            "base_commit": base_commit,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        meta_file.write_text(json.dumps(meta_data, indent=2), encoding="utf-8")

    yield WorkerEvent("evidence", {
        "evidence_type": "evidence_branch_prepared",
        "summary": f"Branch prepared: {original_branch} -> {working_branch}",
        "payload": {
            "kind": "branch_prepared",
            "original_branch": original_branch,
            "working_branch": working_branch,
            "base_commit": base_commit,
            "created": created,
            "session_id": session_id
        }
    })

    yield WorkerEvent("branch_prepared", {
        "session_id": session_id,
        "original_branch": original_branch,
        "working_branch": working_branch,
        "base_commit": base_commit,
        "created": created
    })
