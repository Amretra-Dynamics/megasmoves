"""Megas Worker evidence collectors."""

