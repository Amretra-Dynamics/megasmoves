from __future__ import annotations

import asyncio
import re
from pathlib import Path, PurePosixPath

from megas.policy import redact


FORBIDDEN_PATH_PATTERNS = [
    re.compile(r"^\.git(/|$)"),
    re.compile(r"^\.github/workflows(/|$)"),
    re.compile(r"(^|/)ops/nginx/env(/|$)"),
    re.compile(r"(^|/)\.env$"),
    re.compile(r"\.pem$"),
    re.compile(r"\.key$"),
    re.compile(r"(^|/)secrets\."),
    re.compile(r"(^|/)keystores/"),
    re.compile(r"(^|/)signing-"),
    re.compile(r"(^|/)credentials\."),
]


async def collect_git_snapshot(workdir: Path) -> dict:
    if not (workdir / ".git").exists():
        return {"is_git_repo": False}
    status = await _run_capture(["git", "status", "--short"], workdir)
    diff_stat = await _run_capture(["git", "diff", "--stat"], workdir)
    branch = await _run_capture(["git", "branch", "--show-current"], workdir)
    return {
        "is_git_repo": True,
        "branch": branch.strip(),
        "status_short": status,
        "diff_stat": diff_stat,
    }


async def get_head_commit(workdir: Path) -> str:
    return (await _run_capture(["git", "rev-parse", "HEAD"], workdir)).strip()


async def collect_git_diff(workdir: Path, max_bytes: int = 50_000) -> str:
    raw = await _run_capture(["git", "diff"], workdir)
    return raw[:max_bytes]


async def collect_changed_files(workdir: Path) -> list[dict]:
    name_status_raw = await _run_capture(
        ["git", "diff", "--name-status", "-z"], workdir
    )
    numstat_raw = await _run_capture(
        ["git", "diff", "--numstat", "-z"], workdir
    )
    # Parse --name-status -z: "M\0path\0D\0path2\0..."
    ns_parts = name_status_raw.split("\0")
    status_map: dict[str, str] = {}
    i = 0
    while i < len(ns_parts) - 1:
        status_code = ns_parts[i].strip()
        if not status_code:
            i += 1
            continue
        filepath = ns_parts[i + 1].strip()
        if filepath:
            status_map[filepath] = status_code[0]
        i += 2

    # Parse --numstat -z: "adds\tdels\tpath\0..."
    additions_map: dict[str, int] = {}
    deletions_map: dict[str, int] = {}
    for entry in numstat_raw.split("\0"):
        entry = entry.strip()
        if not entry:
            continue
        parts = entry.split("\t", 2)
        if len(parts) == 3:
            try:
                additions_map[parts[2]] = int(parts[0]) if parts[0] != "-" else 0
                deletions_map[parts[2]] = int(parts[1]) if parts[1] != "-" else 0
            except ValueError:
                pass

    result = []
    for filepath, status in status_map.items():
        result.append({
            "path": filepath,
            "status": status,
            "additions": additions_map.get(filepath, 0),
            "deletions": deletions_map.get(filepath, 0),
        })
    return result


async def generate_patch(workdir: Path) -> str:
    """Capture raw patch for git apply — no redaction, higher cap."""
    return await _run_capture_raw(["git", "diff"], workdir, max_bytes=100_000)


def validate_changed_paths(changed_files: list[dict], workdir: Path) -> None:
    for entry in changed_files:
        filepath = entry.get("path", "")
        # Reject absolute paths
        if PurePosixPath(filepath).is_absolute() or (len(filepath) > 1 and filepath[1] == ":"):
            raise PermissionError(f"Absolute path in diff is forbidden: {filepath}")
        # Reject path traversal
        if ".." in filepath.split("/"):
            raise PermissionError(f"Path traversal in diff is forbidden: {filepath}")
        # Reject forbidden patterns
        for pattern in FORBIDDEN_PATH_PATTERNS:
            if pattern.search(filepath):
                raise PermissionError(f"Protected path in diff is forbidden: {filepath}")
        # Reject symlink targets
        resolved = (workdir / filepath).resolve()
        try:
            resolved.relative_to(workdir.resolve())
        except ValueError:
            raise PermissionError(f"Path escapes workspace: {filepath}")
        # Reject deletions
        if entry.get("status") == "D":
            raise PermissionError(f"File deletion is not allowed in controlled edit mode: {filepath}")


async def _run_capture(args: list[str], workdir: Path) -> str:
    try:
        from megas.adapters.base import prefer_console_free_tool_path, windows_subprocess_kwargs

        process = await asyncio.create_subprocess_exec(
            *args,
            cwd=str(workdir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=prefer_console_free_tool_path(),
            **windows_subprocess_kwargs(new_group=False),
        )
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
        text = stdout.decode(errors="replace") if stdout else stderr.decode(errors="replace")
        return redact(text.strip())[:8000]
    except Exception as exc:
        return f"unavailable: {exc}"


async def _run_capture_raw(args: list[str], workdir: Path, max_bytes: int = 100_000) -> str:
    """Capture raw output without redaction — for patch content passed to git apply."""
    try:
        from megas.adapters.base import prefer_console_free_tool_path, windows_subprocess_kwargs

        process = await asyncio.create_subprocess_exec(
            *args,
            cwd=str(workdir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=prefer_console_free_tool_path(),
            **windows_subprocess_kwargs(new_group=False),
        )
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
        text = stdout.decode(errors="replace") if stdout else stderr.decode(errors="replace")
        return text[:max_bytes]
    except Exception as exc:
        return f"unavailable: {exc}"


async def get_repo_state(workdir: Path) -> dict:
    if not (workdir / ".git").exists():
        return {
            "branch": "main",
            "head_commit": "unknown",
            "head_subject": "Not a git repository",
            "dirty": False,
            "modified_files": [],
            "untracked_files": []
        }
    
    branch = (await _run_capture(["git", "branch", "--show-current"], workdir)).strip() or "HEAD detached"
    head_commit = (await _run_capture(["git", "rev-parse", "--short", "HEAD"], workdir)).strip()
    head_subject = (await _run_capture(["git", "log", "-1", "--format=%s"], workdir)).strip()
    
    modified_raw = await _run_capture(["git", "diff", "--name-only"], workdir)
    modified_staged = await _run_capture(["git", "diff", "--cached", "--name-only"], workdir)
    modified_files = list(set([f.strip() for f in (modified_raw + "\n" + modified_staged).split("\n") if f.strip()]))
    
    status_raw = await _run_capture(["git", "status", "--porcelain"], workdir)
    untracked_files = []
    for line in status_raw.split("\n"):
        if line.startswith("??"):
            file_path = line[2:].strip()
            untracked_files.append(file_path)
            
    dirty = len(modified_files) > 0 or len(untracked_files) > 0
    
    return {
        "branch": branch,
        "head_commit": head_commit,
        "head_subject": head_subject,
        "dirty": dirty,
        "modified_files": modified_files,
        "untracked_files": untracked_files
    }
