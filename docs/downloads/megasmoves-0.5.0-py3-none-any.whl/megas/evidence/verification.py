from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path
from typing import Any, AsyncIterator

from megas.adapters.base import prefer_console_free_tool_path, windows_subprocess_kwargs, WorkerEvent
from megas.policy import redact

# Allowlist of commands and their OS-specific variants
ALLOWLISTED_COMMAND_IDS = {
    "android_compile_debug_kotlin",
    "android_unit_tests",
    "backend_pytest"
}

def get_gradlew_cmd(repo_root: Path) -> str:
    if sys.platform == "win32":
        return str(repo_root / "gradlew.bat")
    return str(repo_root / "gradlew")

def is_docs_only(changed_files: list[dict]) -> bool:
    if not changed_files:
        return True
    for f in changed_files:
        path = f.get("path", "")
        if not path:
            continue
        # Check if the path belongs to docs/, playstore/, README.md, or ends with .md
        is_doc = (
            path.startswith("docs/") or
            path.startswith("playstore/") or
            path.endswith(".md") or
            path == "README.md"
        )
        if not is_doc:
            return False
    return True

def build_verification_plan(changed_files: list[dict], repo_root: Path) -> dict:
    has_android = False
    has_python = False
    
    for f in changed_files:
        path = f.get("path", "")
        if path.startswith("app/") or path.endswith((".kt", ".java", ".gradle", ".xml")):
            has_android = True
        if path.startswith("backend/") or path.startswith("worker/") or path.endswith(".py"):
            has_python = True
            
    required_evidence = ["terminal_result"]
    commands = []
    
    gradlew_bin = get_gradlew_cmd(repo_root)
    
    if has_android:
        required_evidence.append("evidence_build_result")
        required_evidence.append("evidence_test_result")
        commands.append({
            "id": "android_compile_debug_kotlin",
            "kind": "build",
            "label": "Android compileDebugKotlin",
            "args": [gradlew_bin, ":app:compileDebugKotlin"]
        })
        commands.append({
            "id": "android_unit_tests",
            "kind": "test",
            "label": "Android unit tests",
            "args": [gradlew_bin, ":app:testDebugUnitTest"]
        })
        
    if has_python:
        if "evidence_test_result" not in required_evidence:
            required_evidence.append("evidence_test_result")
        commands.append({
            "id": "backend_pytest",
            "kind": "test",
            "label": "Backend pytest",
            "args": ["python", "-m", "pytest", "backend/tests", "-q"]
        })
        
    return {
        "changed_files": [f.get("path", "") for f in changed_files],
        "required_evidence": required_evidence,
        "commands": commands
    }

async def run_verification_pipeline(
    plan: dict, repo_root: Path
) -> AsyncIterator[WorkerEvent]:
    for cmd_info in plan.get("commands", []):
        cmd_id = cmd_info["id"]
        cmd_kind = cmd_info["kind"]
        cmd_label = cmd_info["label"]
        cmd_args = cmd_info["args"]
        
        # Enforce allowlist check
        if cmd_id not in ALLOWLISTED_COMMAND_IDS:
            raise PermissionError(f"Verification command {cmd_id} is not allowlisted.")
            
        cmd_str = " ".join(cmd_args)
        
        yield WorkerEvent("evidence", {
            "evidence_type": "evidence_verification_command",
            "summary": f"Starting verification: {cmd_label}",
            "payload": {
                "command_id": cmd_id,
                "command": cmd_str,
                "status": "started"
            }
        })
        
        started_time = time.time()
        try:
            # Prevent shell execution
            proc = await asyncio.create_subprocess_exec(
                *cmd_args,
                cwd=str(repo_root),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=prefer_console_free_tool_path(),
                **windows_subprocess_kwargs(new_group=False),
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=180)
            exit_code = proc.returncode
            output = (stdout.decode(errors="replace") + "\n" + stderr.decode(errors="replace")).strip()
        except Exception as e:
            exit_code = -1
            output = f"Execution failed: {e}"
            
        duration = int((time.time() - started_time) * 1000)
        success = (exit_code == 0)
        
        # Capping and redacting output
        redacted_output = redact(output)[:10000]
        
        evidence_type = "evidence_build_result" if cmd_kind == "build" else "evidence_test_result"
        
        # Target determination
        target = "android" if "android" in cmd_id else "backend"
        
        yield WorkerEvent("evidence", {
            "evidence_type": evidence_type,
            "summary": f"{cmd_label} {'succeeded' if success else 'failed'} (exit code {exit_code})",
            "payload": {
                "kind": f"{cmd_kind}_result",
                "command_id": cmd_id,
                "target": target,
                "exit_code": exit_code,
                "success": success,
                "duration_ms": duration,
                "output": redacted_output
            }
        })
        
        if not success:
            # Abort subsequent verification commands immediately on failure
            break
