"""Certificate-gated provider-native history registry.

The mature parsers live in :mod:`megas.thread_sync_legacy`.  This module adds
installation certification and authoritative readers for the launch providers
without weakening the existing Codex/Antigravity/Grok/OpenCode/Kilo logic.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import time
from typing import Any, Callable, Iterable

from . import thread_sync_legacy as legacy
from .runtime_manifest import (
    _agent_adapter_classes,
    _auth_mode,
    _certification_for,
)


MINIMUM_SYNC_PROVIDERS = frozenset(
    {
        "codex_cli",
        "antigravity",
        "grok_build",
        "devin_cli",
        "cursor_cli",
        "jules_cli",
        "kilo_code",
        "opencode",
        "cline",
    }
)
OPTIONAL_SYNC_PROVIDERS = frozenset({"claude_code", "aider"})
CERTIFIABLE_SYNC_PROVIDERS = MINIMUM_SYNC_PROVIDERS | OPTIONAL_SYNC_PROVIDERS
_CERT_CACHE_TTL_SECONDS = 60.0
_cert_cache: tuple[float, frozenset[str]] | None = None


@dataclass(frozen=True)
class ProviderReader:
    index: Callable[[int], list[dict[str, Any]]]
    read: Callable[[str], dict[str, Any] | None]


def _safe_text(value: object, limit: int = 8_000) -> str:
    text = legacy._sanitize_provider_text(str(value or ""))
    return text if len(text) <= limit else text[:limit] + "\n…[truncated]"


def _authoritative_id(value: object, *, prefixes: tuple[str, ...] = ()) -> str:
    text = str(value or "").strip()
    if not text or len(text) > 300 or any(ch in text for ch in "?#\\"):
        return ""
    if prefixes and not text.startswith(prefixes):
        return ""
    return text


def _certified_provider_ids(*, force: bool = False) -> frozenset[str]:
    global _cert_cache
    now = time.monotonic()
    if (
        not force
        and _cert_cache is not None
        and now - _cert_cache[0] < _CERT_CACHE_TTL_SECONDS
    ):
        return _cert_cache[1]

    certified: set[str] = set()
    classes = _agent_adapter_classes()
    for provider_id in sorted(CERTIFIABLE_SYNC_PROVIDERS):
        adapter_class = classes.get(provider_id)
        if adapter_class is None:
            continue
        try:
            adapter = adapter_class([])
            executable = adapter.discover_executable()
            version = adapter.detect_version() if executable else None
            if not executable or not version or str(adapter.health_status()) != "available":
                continue
            decision = _certification_for(
                agent_id=provider_id,
                adapter=adapter,
                executable=Path(executable),
                version=str(version),
                auth_mode=_auth_mode(provider_id, adapter),
                execution_mode="inspect",
            )
            capabilities = set(getattr(decision, "verified_capabilities", ()) or ())
            if not bool(getattr(decision, "certified", False)):
                continue
            if not {"thread_list", "thread_read", "native_persistence", "reconciliation"}.issubset(capabilities):
                continue
            certified.add(provider_id)
        except Exception:
            continue
    result = frozenset(certified)
    _cert_cache = (now, result)
    return result


def certified_sync_providers(*, force: bool = False) -> frozenset[str]:
    """Return providers allowed to expose native history on this installation."""
    return _certified_provider_ids(force=force)


def _legacy_index(
    provider_id: str,
    fn: Callable[..., list[dict[str, Any]]],
    limit: int,
    *args: object,
    **kwargs: object,
) -> list[dict[str, Any]]:
    rows = fn(*args, limit=limit, **kwargs) if kwargs else fn(*args, limit)
    return [
        row
        for row in rows or []
        if isinstance(row, dict)
        and str(row.get("agent_type") or "") == provider_id
        and str(row.get("native_id") or "").strip()
    ][:limit]


def _index_codex(limit: int) -> list[dict[str, Any]]:
    return legacy.index_codex_threads(limit)


def _index_antigravity(limit: int) -> list[dict[str, Any]]:
    return legacy.index_agy_threads(limit)


def _index_grok(limit: int) -> list[dict[str, Any]]:
    return legacy.index_grok_threads(limit)


def _index_opencode(limit: int) -> list[dict[str, Any]]:
    rows = legacy.index_sqlite_agent_stores(
        legacy._opencode_roots(),
        agent_type="opencode",
        db_names=("opencode.db", "store.db", "data.db"),
        limit=limit,
    )
    rows.extend(
        legacy.index_jsonl_agent_roots(
            legacy._opencode_roots(),
            agent_type="opencode",
            limit=limit,
        )
    )
    return rows[: max(limit * 2, limit)]


def _index_kilo(limit: int) -> list[dict[str, Any]]:
    rows = legacy.index_sqlite_agent_stores(
        legacy._kilo_roots(),
        agent_type="kilo_code",
        db_names=("kilo.db", "store.db", "data.db", "opencode.db"),
        limit=limit,
    )
    rows.extend(
        legacy.index_jsonl_agent_roots(
            legacy._kilo_roots(),
            agent_type="kilo_code",
            limit=limit,
        )
    )
    return rows[: max(limit * 2, limit)]


def _index_claude(limit: int) -> list[dict[str, Any]]:
    return legacy.index_claude_threads(limit)


def _read_devin_thread(native_id: str) -> dict[str, Any] | None:
    from .adapters.devin_control_plane import (
        DevinControlPlane,
        UrllibDevinTransport,
        normalize_devin_id,
    )

    token = os.getenv("DEVIN_API_KEY", "").strip()
    org_id = os.getenv("DEVIN_ORG_ID", "").strip()
    if not token or not org_id:
        return None
    try:
        session_id = normalize_devin_id(native_id)
        plane = DevinControlPlane(UrllibDevinTransport(token), org_id)
        session = plane.get_session(session_id)
        messages = plane.list_messages(session_id)
    except Exception:
        return None

    canonical: list[dict[str, Any]] = []
    title = _safe_text(session.get("title") or "Devin session", 80)
    for item in messages:
        if not isinstance(item, dict):
            continue
        item_id = _authoritative_id(item.get("event_id") or item.get("id"))
        source = str(item.get("source") or "").strip().lower()
        text = _safe_text(item.get("message"))
        if not item_id or not text:
            continue
        role = "user" if source in {"user", "human", "service_user"} else "assistant"
        if role == "user" and (not title or title == "Devin session"):
            title = text[:80]
        canonical.append(
            {
                "seq": len(canonical),
                "role": role,
                "kind": "user_message" if role == "user" else "assistant_final",
                "content": text,
                "created_at": str(item.get("created_at") or ""),
                "native_item_id": item_id,
            }
        )
    if not canonical:
        return None
    thread = {
        "native_id": session_id,
        "agent_type": "devin_cli",
        "project_path": None,
        "title": title[:80],
        "status": str(session.get("status") or "active").lower(),
        "sync_cursor": str(session.get("updated_at") or len(canonical)),
        "messages": canonical,
    }
    return legacy.finalize_native_thread(
        thread,
        provider_id="devin_cli",
        data_roots=[Path.home() / ".megas" / "api" / "devin"],
        source_hint=f"devin-api:{session_id}",
        extra_meta={
            "identity_source": "devin_v3_session_id",
            "source_format": "devin_v3_messages",
            "provider_status_detail": session.get("status_detail"),
        },
    )


def _index_devin(limit: int) -> list[dict[str, Any]]:
    from .adapters.devin_control_plane import DevinControlPlane, UrllibDevinTransport

    token = os.getenv("DEVIN_API_KEY", "").strip()
    org_id = os.getenv("DEVIN_ORG_ID", "").strip()
    if not token or not org_id:
        return []
    try:
        rows = DevinControlPlane(UrllibDevinTransport(token), org_id).list_sessions(limit=limit)
    except Exception:
        return []
    result: list[dict[str, Any]] = []
    for session in rows:
        if not isinstance(session, dict):
            continue
        native_id = _authoritative_id(session.get("session_id"), prefixes=("devin-",))
        if not native_id:
            continue
        result.append(
            legacy._index_row(
                native_id=native_id,
                agent_type="devin_cli",
                title=_safe_text(session.get("title") or "Devin session", 80),
                project_path=None,
                sync_cursor=legacy._cursor_with_epoch(
                    str(session.get("updated_at") or session.get("created_at") or native_id)
                ),
            )
        )
    return result[:limit]


def _jules_activity_rows(activities: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for activity in activities:
        if not isinstance(activity, dict):
            continue
        item_id = _authoritative_id(activity.get("name") or activity.get("id"))
        if not item_id:
            continue
        role = "assistant"
        kind = "agent_activity"
        content = ""
        tool_name = None
        if isinstance(activity.get("userMessaged"), dict):
            role = "user"
            kind = "user_message"
            content = _safe_text(activity["userMessaged"].get("userMessage"))
        elif isinstance(activity.get("agentMessaged"), dict):
            kind = "assistant_final"
            content = _safe_text(activity["agentMessaged"].get("agentMessage"))
        elif isinstance(activity.get("planGenerated"), dict):
            kind = "assistant_message"
            plan = activity["planGenerated"].get("plan") or {}
            content = _safe_text(json.dumps(plan, ensure_ascii=False, sort_keys=True))
        elif isinstance(activity.get("progressUpdated"), dict):
            progress = activity["progressUpdated"]
            content = _safe_text(
                progress.get("title") or progress.get("description") or activity.get("description")
            )
        elif isinstance(activity.get("sessionFailed"), dict):
            kind = "error"
            content = _safe_text(activity["sessionFailed"].get("reason") or "Jules failed")
        elif isinstance(activity.get("sessionCompleted"), dict):
            kind = "assistant_message"
            content = "Jules session completed."
        if not content:
            continue
        row = {
            "seq": len(result),
            "role": role,
            "kind": kind,
            "content": content,
            "created_at": str(activity.get("createTime") or ""),
            "native_item_id": item_id,
        }
        if tool_name:
            row["tool_name"] = tool_name
        result.append(row)
    return result


def _read_jules_thread(native_id: str) -> dict[str, Any] | None:
    from .adapters.jules_control_plane import (
        JulesControlPlane,
        UrllibJulesTransport,
        normalize_session_name,
    )

    key = os.getenv("JULES_API_KEY", "").strip()
    if not key:
        return None
    try:
        name = normalize_session_name(native_id)
        plane = JulesControlPlane(UrllibJulesTransport(key))
        session = plane.get_session(name)
        activities = plane.list_activities(name)
    except Exception:
        return None
    messages = _jules_activity_rows(activities)
    if not messages:
        return None
    title = _safe_text(session.get("title") or "Jules session", 80)
    for message in messages:
        if message.get("role") == "user":
            title = str(message.get("content") or title)[:80]
            break
    thread = {
        "native_id": name,
        "agent_type": "jules_cli",
        "project_path": None,
        "title": title,
        "status": str(session.get("state") or "active").lower(),
        "sync_cursor": str(session.get("updateTime") or len(messages)),
        "messages": messages,
    }
    return legacy.finalize_native_thread(
        thread,
        provider_id="jules_cli",
        data_roots=[Path.home() / ".megas" / "api" / "jules"],
        source_hint=f"jules-api:{name}",
        extra_meta={
            "identity_source": "jules_session_name",
            "source_format": "jules_v1alpha_activities",
        },
    )


def _index_jules(limit: int) -> list[dict[str, Any]]:
    from .adapters.jules_control_plane import JulesControlPlane, UrllibJulesTransport

    key = os.getenv("JULES_API_KEY", "").strip()
    if not key:
        return []
    try:
        sessions = JulesControlPlane(UrllibJulesTransport(key)).list_sessions(page_size=min(limit, 100))
    except Exception:
        return []
    result: list[dict[str, Any]] = []
    for session in sessions[:limit]:
        if not isinstance(session, dict):
            continue
        native_id = _authoritative_id(session.get("name") or session.get("id"), prefixes=("sessions/",))
        if not native_id:
            continue
        result.append(
            legacy._index_row(
                native_id=native_id,
                agent_type="jules_cli",
                title=_safe_text(session.get("title") or "Jules session", 80),
                project_path=None,
                sync_cursor=legacy._cursor_with_epoch(
                    str(session.get("updateTime") or session.get("createTime") or native_id)
                ),
            )
        )
    return result


def _extract_message_content(value: object) -> str:
    if isinstance(value, str):
        return _safe_text(value)
    if isinstance(value, dict):
        for key in ("text", "content", "message", "value"):
            if value.get(key) is not None:
                return _extract_message_content(value.get(key))
        return ""
    if isinstance(value, list):
        return "\n".join(filter(None, (_extract_message_content(item) for item in value)))
    return ""


def _cline_root() -> Path:
    explicit = os.getenv("CLINE_DATA_DIR", "").strip()
    return Path(explicit).expanduser() if explicit else Path.home() / ".cline" / "data"


def _cline_session_files() -> list[Path]:
    root = _cline_root() / "sessions"
    if not root.is_dir():
        return []
    try:
        files = [path for path in root.glob("*.json") if path.is_file()]
    except OSError:
        return []
    files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return files


def _parse_cline_file(path: Path) -> dict[str, Any] | None:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(raw, dict):
        return None
    internal_id = _authoritative_id(
        raw.get("session_id") or raw.get("sessionId") or raw.get("taskId") or raw.get("id")
    )
    # Current Cline's documented snapshot name is the session id.  When an
    # internal id exists it must agree; disagreement is quarantined.
    if internal_id and internal_id != path.stem:
        return None
    native_id = internal_id or _authoritative_id(path.stem)
    if not native_id:
        return None
    candidates = (
        raw.get("messages")
        or raw.get("apiConversationHistory")
        or raw.get("conversation")
        or raw.get("history")
        or []
    )
    if not isinstance(candidates, list):
        return None
    messages: list[dict[str, Any]] = []
    for item in candidates:
        if not isinstance(item, dict):
            continue
        role_raw = str(item.get("role") or item.get("type") or "").lower()
        if role_raw in {"user", "human", "user_message", "ask"}:
            role, kind = "user", "user_message"
        elif role_raw in {"assistant", "ai", "model", "assistant_message", "say"}:
            role, kind = "assistant", "assistant_final"
        elif role_raw in {"tool", "tool_use", "tool_call"}:
            role, kind = "assistant", "tool_call"
        elif role_raw in {"tool_result", "tool_output"}:
            role, kind = "assistant", "tool_result"
        else:
            continue
        content = _extract_message_content(
            item.get("content") or item.get("text") or item.get("message") or item.get("say") or item.get("ask")
        )
        if not content and kind not in {"tool_call", "tool_result"}:
            continue
        native_item_id = _authoritative_id(
            item.get("id") or item.get("uuid") or item.get("message_id") or item.get("messageId")
        ) or f"{native_id}:{len(messages)}"
        row: dict[str, Any] = {
            "seq": len(messages),
            "role": role,
            "kind": kind,
            "content": content or None,
            "created_at": str(item.get("timestamp") or item.get("created_at") or item.get("createdAt") or ""),
            "native_item_id": native_item_id,
        }
        if kind == "tool_call":
            row["tool_name"] = str(item.get("name") or item.get("tool") or "tool")[:120]
            row["tool_input"] = _safe_text(item.get("input") or content)
        elif kind == "tool_result":
            row["tool_output"] = _safe_text(item.get("output") or content)
        messages.append(row)
    if not messages:
        return None
    title = _safe_text(raw.get("title") or raw.get("task") or "Cline session", 80)
    for row in messages:
        if row.get("role") == "user" and row.get("content"):
            title = str(row["content"])[:80]
            break
    project_path = raw.get("cwd") or raw.get("workspace") or raw.get("project_path")
    thread = {
        "native_id": native_id,
        "agent_type": "cline",
        "project_path": legacy._normalize_project_path(str(project_path)) if project_path else None,
        "title": title,
        "status": str(raw.get("status") or "active").lower(),
        "sync_cursor": f"{int(path.stat().st_mtime_ns)}|{path.stat().st_size}",
        "messages": messages,
    }
    return legacy.finalize_native_thread(
        thread,
        provider_id="cline",
        data_roots=[_cline_root()],
        source_hint=str(path),
        extra_meta={
            "identity_source": "cline_session_snapshot",
            "source_format": "cline_session_json",
        },
    )


def _read_cline_thread(native_id: str) -> dict[str, Any] | None:
    wanted = _authoritative_id(native_id)
    if not wanted:
        return None
    target = _cline_root() / "sessions" / f"{wanted}.json"
    if not target.is_file():
        return None
    parsed = _parse_cline_file(target)
    return parsed if parsed and parsed.get("native_id") == wanted else None


def _index_cline(limit: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in _cline_session_files():
        if len(rows) >= limit:
            break
        parsed = _parse_cline_file(path)
        if not parsed:
            continue
        rows.append(
            legacy._index_row(
                native_id=str(parsed["native_id"]),
                agent_type="cline",
                title=str(parsed.get("title") or "Cline session")[:80],
                project_path=parsed.get("project_path"),
                sync_cursor=legacy._cursor_with_epoch(str(parsed.get("sync_cursor") or "")),
            )
        )
    return rows


def _cursor_roots() -> list[Path]:
    home = Path.home()
    roots = [home / ".cursor" / "projects", home / ".cursor" / "chats"]
    explicit = os.getenv("CURSOR_DATA_DIR", "").strip()
    if explicit:
        roots.insert(0, Path(explicit).expanduser())
    return roots


def _cursor_jsonl_files() -> list[Path]:
    files: list[Path] = []
    for root in _cursor_roots():
        if not root.exists():
            continue
        patterns = ("**/agent-transcripts/**/*.jsonl", "**/*.jsonl")
        for pattern in patterns:
            try:
                files.extend(path for path in root.glob(pattern) if path.is_file())
            except OSError:
                continue
    unique = {str(path.resolve()): path for path in files}
    rows = list(unique.values())
    rows.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return rows


def _parse_cursor_jsonl(path: Path) -> dict[str, Any] | None:
    ids: set[str] = set()
    messages: list[dict[str, Any]] = []
    project_path: str | None = None
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    for line in lines:
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(item, dict):
            continue
        candidate = _authoritative_id(
            item.get("session_id")
            or item.get("sessionId")
            or item.get("chat_id")
            or item.get("chatId")
            or item.get("composerId")
            or item.get("conversation_id")
        )
        if candidate:
            ids.add(candidate)
        if not project_path:
            raw_path = item.get("cwd") or item.get("workspace") or item.get("project_path")
            if raw_path:
                project_path = legacy._normalize_project_path(str(raw_path))
        role_raw = str(item.get("role") or item.get("type") or "").lower()
        if role_raw in {"user", "human", "user_message"}:
            role, kind = "user", "user_message"
        elif role_raw in {"assistant", "model", "assistant_message"}:
            role, kind = "assistant", "assistant_final"
        elif role_raw in {"tool_call", "tool", "tool_use"}:
            role, kind = "assistant", "tool_call"
        elif role_raw in {"tool_result", "tool_output"}:
            role, kind = "assistant", "tool_result"
        else:
            continue
        content = _extract_message_content(
            item.get("content") or item.get("text") or item.get("message")
        )
        if not content and kind not in {"tool_call", "tool_result"}:
            continue
        row: dict[str, Any] = {
            "seq": len(messages),
            "role": role,
            "kind": kind,
            "content": content or None,
            "created_at": str(item.get("timestamp") or item.get("created_at") or ""),
            "native_item_id": _authoritative_id(
                item.get("id") or item.get("message_id") or item.get("call_id")
            ) or None,
        }
        if kind == "tool_call":
            row["tool_name"] = str(item.get("name") or item.get("tool") or "tool")[:120]
            row["tool_input"] = _safe_text(item.get("input") or content)
        elif kind == "tool_result":
            row["tool_output"] = _safe_text(item.get("output") or content)
        messages.append(row)
    # A filename is only a hint. At least one provider record must state the id,
    # and every stated id must agree.
    if len(ids) != 1 or not messages:
        return None
    native_id = next(iter(ids))
    title = "Cursor session"
    for row in messages:
        if row.get("role") == "user" and row.get("content"):
            title = str(row["content"])[:80]
            break
    thread = {
        "native_id": native_id,
        "agent_type": "cursor_cli",
        "project_path": project_path,
        "title": title,
        "status": "active",
        "sync_cursor": f"{int(path.stat().st_mtime_ns)}|{path.stat().st_size}",
        "messages": messages,
    }
    return legacy.finalize_native_thread(
        thread,
        provider_id="cursor_cli",
        data_roots=_cursor_roots(),
        source_hint=str(path),
        extra_meta={
            "identity_source": "cursor_record_session_id",
            "source_format": "cursor_transcript_jsonl",
        },
    )


def _cursor_threads(limit: int) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for path in _cursor_jsonl_files():
        if len(result) >= limit:
            break
        thread = _parse_cursor_jsonl(path)
        native_id = str((thread or {}).get("native_id") or "")
        if not thread or not native_id or native_id in seen:
            continue
        seen.add(native_id)
        result.append(thread)
    return result


def _read_cursor_thread(native_id: str) -> dict[str, Any] | None:
    wanted = _authoritative_id(native_id)
    if not wanted:
        return None
    for thread in _cursor_threads(5_000):
        if thread.get("native_id") == wanted:
            return thread
    return None


def _index_cursor(limit: int) -> list[dict[str, Any]]:
    return [
        legacy._index_row(
            native_id=str(thread["native_id"]),
            agent_type="cursor_cli",
            title=str(thread.get("title") or "Cursor session")[:80],
            project_path=thread.get("project_path"),
            sync_cursor=legacy._cursor_with_epoch(str(thread.get("sync_cursor") or "")),
        )
        for thread in _cursor_threads(limit)
    ]


_READERS: dict[str, ProviderReader] = {
    "codex_cli": ProviderReader(_index_codex, legacy.read_codex_thread),
    "antigravity": ProviderReader(_index_antigravity, legacy.read_agy_thread),
    "grok_build": ProviderReader(_index_grok, legacy.read_grok_thread),
    "opencode": ProviderReader(_index_opencode, legacy.read_opencode_thread),
    "kilo_code": ProviderReader(_index_kilo, legacy.read_kilo_thread),
    "claude_code": ProviderReader(_index_claude, legacy.read_claude_thread),
    "devin_cli": ProviderReader(_index_devin, _read_devin_thread),
    "jules_cli": ProviderReader(_index_jules, _read_jules_thread),
    "cline": ProviderReader(_index_cline, _read_cline_thread),
    "cursor_cli": ProviderReader(_index_cursor, _read_cursor_thread),
}


def list_native_thread_index(
    limit_per_agent: int = legacy._DEFAULT_LIMIT_PER_AGENT,
) -> list[dict[str, Any]]:
    certified = certified_sync_providers()
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for provider_id in sorted(certified):
        reader = _READERS.get(provider_id)
        if reader is None:
            continue
        try:
            rows = reader.index(limit_per_agent)
        except Exception as exc:
            print(
                f"[THREAD_SYNC] certified index {provider_id} failed: {type(exc).__name__}",
                flush=True,
            )
            continue
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            native_id = str(row.get("native_id") or "").strip()
            if not native_id or str(row.get("agent_type") or "") != provider_id:
                continue
            if legacy.is_megas_internal_session(
                row.get("title"),
                row.get("preview"),
                row.get("first_user_message"),
            ):
                continue
            key = f"{provider_id}:{native_id}"
            if key in seen:
                continue
            seen.add(key)
            result.append(row)
    return result


def read_native_thread(
    agent_type: str,
    native_id: str,
) -> dict[str, Any] | None:
    provider_id = str(agent_type or "").strip().lower()
    aliases = {
        "codex": "codex_cli",
        "agy": "antigravity",
        "grok": "grok_build",
        "open_code": "opencode",
        "kilo": "kilo_code",
        "kilocode": "kilo_code",
        "cursor": "cursor_cli",
        "jules": "jules_cli",
        "devin": "devin_cli",
    }
    provider_id = aliases.get(provider_id, provider_id)
    if provider_id not in certified_sync_providers():
        return None
    reader = _READERS.get(provider_id)
    if reader is None:
        return None
    thread = reader.read(str(native_id or "").strip())
    if not thread:
        return None
    if str(thread.get("agent_type") or "") != provider_id:
        return None
    if str(thread.get("native_id") or "") != str(native_id or "").strip():
        return None
    return thread


def read_all_native_threads(
    limit_per_agent: int = legacy._DEFAULT_LIMIT_PER_AGENT,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for row in list_native_thread_index(limit_per_agent):
        thread = read_native_thread(
            str(row.get("agent_type") or ""),
            str(row.get("native_id") or ""),
        )
        if thread:
            result.append(thread)
    return result


def threads_needing_full_sync(
    index_rows: list[dict[str, Any]],
    known_cursors: dict[str, str],
    *,
    max_full: int = legacy._MAX_FULL_SYNCS_PER_CYCLE,
) -> list[dict[str, Any]]:
    certified = certified_sync_providers()
    need: list[dict[str, Any]] = []
    for row in index_rows or []:
        provider_id = str(row.get("agent_type") or "")
        native_id = str(row.get("native_id") or "")
        if provider_id not in certified or not native_id:
            continue
        key = f"{provider_id}:{native_id}"
        cursor = str(row.get("sync_cursor") or "")
        if cursor and known_cursors.get(key) == cursor:
            continue
        need.append(row)
        if len(need) >= max_full:
            break
    return need
