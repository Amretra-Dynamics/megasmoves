from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

from jsonschema import Draft202012Validator

from .operator_account import ChitraagniBinding, request_json


READ_PREFIXES = (
    "/workspaces",
    "/projects",
    "/products",
    "/screens",
    "/schemas",
    "/workflows",
    "/versions",
    "/health",
    "/me",
)


def _uuid(value: Any, label: str) -> str:
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, TypeError, AttributeError) as exc:
        raise ValueError(f"{label} must be a UUID") from exc


def _required_text(arguments: dict[str, Any], key: str) -> str:
    value = str(arguments.get(key) or "").strip()
    if not value:
        raise ValueError(f"{key} is required")
    return value


def _safe_read_path(value: Any) -> str:
    path = str(value or "").strip()
    if not path.startswith("/"):
        raise ValueError("path must begin with /")
    parsed = urlsplit(path)
    if parsed.scheme or parsed.netloc:
        raise ValueError("path must be relative to the linked Chitraagni API")
    if any(segment == ".." for segment in parsed.path.split("/")):
        raise ValueError("path traversal is not allowed")
    if not any(
        parsed.path == prefix or parsed.path.startswith(prefix + "/")
        for prefix in READ_PREFIXES
    ):
        raise ValueError("read path is outside the structured Chitraagni operator surface")
    return path


def _compact(source: dict[str, Any], allowed: tuple[str, ...]) -> dict[str, Any]:
    return {key: source[key] for key in allowed if key in source}


def _tool(
    name: str,
    description: str,
    properties: dict[str, Any],
    required: list[str],
    *,
    read_only: bool = False,
    destructive: bool = False,
) -> dict[str, Any]:
    return {
        "name": name,
        "title": name.replace("chitraagni_", "Chitraagni ").replace("_", " ").title(),
        "description": description,
        "inputSchema": {
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": read_only,
            "destructiveHint": destructive,
            "openWorldHint": False,
        },
    }


TOOLS: list[dict[str, Any]] = [
    _tool(
        "chitraagni_read",
        "Read structured state from the linked user's Chitraagni account through an allowlisted relative API path.",
        {
            "path": {
                "type": "string",
                "description": "Relative path under workspaces, projects, products, screens, schemas, workflows, versions, health, or me.",
            }
        },
        ["path"],
        read_only=True,
    ),
    _tool(
        "chitraagni_product_create",
        "Create one Product surface inside an existing Project owned by the linked Chitraagni account.",
        {
            "project_id": {"type": "string"},
            "name": {"type": "string"},
            "product_type": {"type": "string", "default": "web_app"},
            "platform": {"type": ["string", "null"]},
            "goal": {"type": "string"},
            "description": {"type": "string"},
            "product_memory_json": {"type": "object"},
        },
        ["project_id", "name"],
    ),
    _tool(
        "chitraagni_screen_create",
        "Create a structured screen blueprint in an existing Project owned by the linked account.",
        {
            "project_id": {"type": "string"},
            "page_key": {"type": "string"},
            "purpose": {"type": "string"},
            "primary_action": {"type": "string"},
            "secondary_actions_json": {"type": "array"},
            "required_regions_json": {"type": "array"},
            "components_json": {"type": "array"},
            "data_requirements_json": {"type": "array"},
            "required_states_json": {"type": "array"},
            "related_features_json": {"type": "array"},
            "related_entities_json": {"type": "array"},
            "page_priority": {"type": "integer"},
        },
        ["project_id", "page_key"],
    ),
    _tool(
        "chitraagni_screen_update",
        "Update explicit fields on one structured screen in the linked account.",
        {
            "screen_id": {"type": "string"},
            "page_key": {"type": "string"},
            "purpose": {"type": "string"},
            "primary_action": {"type": "string"},
            "secondary_actions_json": {"type": "array"},
            "required_regions_json": {"type": "array"},
            "components_json": {"type": "array"},
            "data_requirements_json": {"type": "array"},
            "required_states_json": {"type": "array"},
            "related_features_json": {"type": "array"},
            "related_entities_json": {"type": "array"},
            "page_priority": {"type": "integer"},
        },
        ["screen_id"],
    ),
    _tool(
        "chitraagni_screen_delete",
        "Permanently delete one authorized structured screen. Requires explicit confirm=true.",
        {
            "screen_id": {"type": "string"},
            "confirm": {"type": "boolean", "const": True},
        },
        ["screen_id", "confirm"],
        destructive=True,
    ),
    _tool(
        "chitraagni_schema_create",
        "Create one deterministic data/schema entity in the linked account's current Project version.",
        {
            "project_id": {"type": "string"},
            "name": {"type": "string"},
            "entity_type": {"type": "string", "default": "object"},
            "description": {"type": "string"},
            "attributes_json": {"type": "array"},
            "relationships_json": {"type": "array"},
            "related_features_json": {"type": "array"},
        },
        ["project_id", "name"],
    ),
    _tool(
        "chitraagni_schema_update",
        "Update explicit fields on one schema in the linked account's current Project version.",
        {
            "schema_id": {"type": "string"},
            "name": {"type": "string"},
            "entity_type": {"type": "string"},
            "description": {"type": "string"},
            "attributes_json": {"type": "array"},
            "relationships_json": {"type": "array"},
            "related_features_json": {"type": "array"},
        },
        ["schema_id"],
    ),
    _tool(
        "chitraagni_workflow_create",
        "Create one trigger-action-result workflow in the linked account's current Project version.",
        {
            "project_id": {"type": "string"},
            "name": {"type": "string"},
            "trigger": {"type": "string"},
            "action": {"type": "string"},
            "result": {"type": "string"},
            "side_effects_json": {"type": "array"},
            "related_features_json": {"type": "array"},
            "related_entities_json": {"type": "array"},
            "related_pages_json": {"type": "array"},
        },
        ["project_id", "name"],
    ),
    _tool(
        "chitraagni_workflow_update",
        "Update explicit fields on one workflow in the linked account's current Project version.",
        {
            "workflow_id": {"type": "string"},
            "name": {"type": "string"},
            "trigger": {"type": "string"},
            "action": {"type": "string"},
            "result": {"type": "string"},
            "side_effects_json": {"type": "array"},
            "related_features_json": {"type": "array"},
            "related_entities_json": {"type": "array"},
            "related_pages_json": {"type": "array"},
        },
        ["workflow_id"],
    ),
    _tool(
        "chitraagni_version_snapshot",
        "Clone the current screens, schemas, and workflows into a new non-active Project version snapshot.",
        {
            "project_id": {"type": "string"},
            "label": {"type": ["string", "null"]},
            "status": {"type": "string", "default": "saved"},
        },
        ["project_id"],
    ),
    _tool(
        "chitraagni_version_activate",
        "Explicitly make one existing Project version the current editable version.",
        {"version_id": {"type": "string"}},
        ["version_id"],
    ),
]


@dataclass(slots=True)
class ChitraagniOperatorCatalog:
    binding: ChitraagniBinding
    timeout_seconds: float = 15.0

    def __post_init__(self) -> None:
        self.binding.validate()
        self.timeout_seconds = float(self.timeout_seconds)
        if not (0 < self.timeout_seconds <= 120):
            raise ValueError("Chitraagni operator timeout must be between 0 and 120 seconds")

    def tools(self) -> list[dict[str, Any]]:
        return [json.loads(json.dumps(tool)) for tool in TOOLS]

    def _api(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        # Verify the machine-local token still represents the same user that was
        # explicitly linked. A changed environment token cannot silently switch
        # MegasMCP to another Chitraagni account.
        self.binding.verify_current_identity(timeout=self.timeout_seconds)
        token = self.binding.token()
        try:
            return request_json(
                method,
                self.binding.api_base + path,
                token=token,
                body=body,
                timeout=self.timeout_seconds,
            )
        except Exception as exc:
            message = str(exc).replace(token, "[REDACTED]")
            if isinstance(exc, PermissionError):
                raise PermissionError(message) from exc
            if isinstance(exc, ValueError):
                raise ValueError(message) from exc
            raise RuntimeError(message) from exc

    def _product_create(self, a: dict[str, Any]) -> Any:
        project_id = _uuid(a.get("project_id"), "project_id")
        return self._api(
            "POST",
            f"/projects/{project_id}/products",
            {
                "name": _required_text(a, "name"),
                "product_type": a.get("product_type", "web_app"),
                "platform": a.get("platform"),
                "goal": a.get("goal", ""),
                "description": a.get("description", ""),
                "imported_source_type": "manual",
                "imported_source_details_json": {},
                "product_memory_json": a.get("product_memory_json", {}),
            },
        )

    def _screen_create(self, a: dict[str, Any]) -> Any:
        project_id = _uuid(a.get("project_id"), "project_id")
        return self._api(
            "POST",
            f"/projects/{project_id}/screens",
            {
                "page_key": _required_text(a, "page_key"),
                "purpose": a.get("purpose", ""),
                "primary_action": a.get("primary_action", ""),
                "secondary_actions_json": a.get("secondary_actions_json", []),
                "required_regions_json": a.get("required_regions_json", []),
                "components_json": a.get("components_json", []),
                "data_requirements_json": a.get("data_requirements_json", []),
                "required_states_json": a.get("required_states_json", []),
                "related_features_json": a.get("related_features_json", []),
                "related_entities_json": a.get("related_entities_json", []),
                "page_priority": a.get("page_priority", 0),
            },
        )

    def _screen_update(self, a: dict[str, Any]) -> Any:
        screen_id = _uuid(a.get("screen_id"), "screen_id")
        body = _compact(
            a,
            (
                "page_key",
                "purpose",
                "primary_action",
                "secondary_actions_json",
                "required_regions_json",
                "components_json",
                "data_requirements_json",
                "required_states_json",
                "related_features_json",
                "related_entities_json",
                "page_priority",
            ),
        )
        if not body:
            raise ValueError("at least one screen field must be supplied")
        return self._api("PUT", f"/screens/{screen_id}", body)

    def _screen_delete(self, a: dict[str, Any]) -> Any:
        screen_id = _uuid(a.get("screen_id"), "screen_id")
        if a.get("confirm") is not True:
            raise ValueError("confirm must be true to delete a screen")
        return self._api("DELETE", f"/screens/{screen_id}?confirm=true")

    def _schema_create(self, a: dict[str, Any]) -> Any:
        project_id = _uuid(a.get("project_id"), "project_id")
        return self._api(
            "POST",
            f"/projects/{project_id}/schemas",
            {
                "name": _required_text(a, "name"),
                "entity_type": a.get("entity_type", "object"),
                "description": a.get("description", ""),
                "attributes_json": a.get("attributes_json", []),
                "relationships_json": a.get("relationships_json", []),
                "related_features_json": a.get("related_features_json", []),
            },
        )

    def _schema_update(self, a: dict[str, Any]) -> Any:
        schema_id = _uuid(a.get("schema_id"), "schema_id")
        body = _compact(
            a,
            (
                "name",
                "entity_type",
                "description",
                "attributes_json",
                "relationships_json",
                "related_features_json",
            ),
        )
        if not body:
            raise ValueError("at least one schema field must be supplied")
        return self._api("PUT", f"/schemas/{schema_id}", body)

    def _workflow_create(self, a: dict[str, Any]) -> Any:
        project_id = _uuid(a.get("project_id"), "project_id")
        return self._api(
            "POST",
            f"/projects/{project_id}/workflows",
            {
                "name": _required_text(a, "name"),
                "trigger": a.get("trigger", ""),
                "action": a.get("action", ""),
                "result": a.get("result", ""),
                "side_effects_json": a.get("side_effects_json", []),
                "related_features_json": a.get("related_features_json", []),
                "related_entities_json": a.get("related_entities_json", []),
                "related_pages_json": a.get("related_pages_json", []),
            },
        )

    def _workflow_update(self, a: dict[str, Any]) -> Any:
        workflow_id = _uuid(a.get("workflow_id"), "workflow_id")
        body = _compact(
            a,
            (
                "name",
                "trigger",
                "action",
                "result",
                "side_effects_json",
                "related_features_json",
                "related_entities_json",
                "related_pages_json",
            ),
        )
        if not body:
            raise ValueError("at least one workflow field must be supplied")
        return self._api("PUT", f"/workflows/{workflow_id}", body)

    def _version_snapshot(self, a: dict[str, Any]) -> Any:
        project_id = _uuid(a.get("project_id"), "project_id")
        return self._api(
            "POST",
            f"/projects/{project_id}/versions",
            {
                "label": a.get("label"),
                "source_type": "manual_snapshot",
                "status": a.get("status", "saved"),
            },
        )

    def _version_activate(self, a: dict[str, Any]) -> Any:
        version_id = _uuid(a.get("version_id"), "version_id")
        return self._api("POST", f"/versions/{version_id}/activate")

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        tool = next((row for row in TOOLS if row["name"] == name), None)
        if tool is None:
            raise KeyError(name)
        if not isinstance(arguments, dict):
            raise ValueError("Chitraagni tool arguments must be a JSON object")
        validator = Draft202012Validator(tool["inputSchema"])
        errors = sorted(validator.iter_errors(arguments), key=lambda row: list(row.path))
        if errors:
            raise ValueError("invalid Chitraagni tool input: " + errors[0].message)

        if name == "chitraagni_read":
            value = self._api("GET", _safe_read_path(arguments.get("path")))
        elif name == "chitraagni_product_create":
            value = self._product_create(arguments)
        elif name == "chitraagni_screen_create":
            value = self._screen_create(arguments)
        elif name == "chitraagni_screen_update":
            value = self._screen_update(arguments)
        elif name == "chitraagni_screen_delete":
            value = self._screen_delete(arguments)
        elif name == "chitraagni_schema_create":
            value = self._schema_create(arguments)
        elif name == "chitraagni_schema_update":
            value = self._schema_update(arguments)
        elif name == "chitraagni_workflow_create":
            value = self._workflow_create(arguments)
        elif name == "chitraagni_workflow_update":
            value = self._workflow_update(arguments)
        elif name == "chitraagni_version_snapshot":
            value = self._version_snapshot(arguments)
        elif name == "chitraagni_version_activate":
            value = self._version_activate(arguments)
        else:
            raise KeyError(name)

        text = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str)
        return {
            "content": [{"type": "text", "text": text}],
            "structuredContent": value,
            "isError": False,
        }


__all__ = ["ChitraagniOperatorCatalog", "READ_PREFIXES", "TOOLS"]
