from __future__ import annotations

import asyncio
import hashlib
import json
import os
import platform
import random
import socket
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import httpx
import websockets

from .adapters.base import (
    AgentAdapter,
    WorkerEvent,
    prefer_console_free_tool_path,
    subprocess_hide_window_kwargs,
)
from .adapters.aider import AiderAdapter
from .adapters.antigravity import AntigravityAdapter
from .adapters.claude import ClaudeCodeAdapter
from .adapters.cline import ClineAdapter
from .adapters.codex import CodexCliAdapter
from .adapters.devin import DevinCliAdapter
from .adapters.custom_native import CustomNativeAgentAdapter
from .adapters.grok_build import GrokBuildAdapter
from .adapters.kilo import KiloCodeAdapter
from .adapters.kiro import KiroCodeAdapter
from .adapters.opencode import OpenCodeAdapter
from .adapters.commit_gate import CommitGateAdapter
from .adapters.pr_gate import PrGateAdapter
from .adapters.refresh import RuntimeRefreshAdapter
from .adapters.windows_cua import WindowsCuaAdapter
from .adapters.ssh_exec import SshExecAdapter
from .adapters.shell import CustomShellAdapter
from .adapters.browser import BrowserAdapter
from .operate.browser.runtime import BrowserSessionManager
from .agent_router import (
    agent_display_name,
    available_coding_agents,
    build_agent_chain,
    looks_like_limit_failure,
    parse_limit_failure,
    with_agent_type,
)
from .config import WorkerConfig, save_config
from .context_binding import verify_worker_context
from .policy import redact, resolve_allowed_workdir
from .runtime_manifest import (
    BUILTIN_ROUTING_CAPABILITIES,
    build_runtime_manifest,
    runtime_capabilities_from_manifest,
)

from .config import WorkerConfig, save_config
from .context_binding import verify_worker_context
from .policy import redact, resolve_allowed_workdir
from .runtime_manifest import (
    BUILTIN_ROUTING_CAPABILITIES,
    build_runtime_manifest,
    runtime_capabilities_from_manifest,
)


import shutil

AGENT_BINARIES = {
    "claude_code": "claude",
    "codex_cli": "codex",
    "aider": "aider",
    "gemini_cli": "agy",
    "antigravity": "agy",
    "grok_build": "grok",
    "kilo_code": "kilocode",
    "kiro_code": "kiro-cli",
    "opencode": "opencode",
    "cline": "cline",
    "devin_cli": "devin",
    "kimi_code": "kimi",
    "glm_code": "glm",
}
AGENT_BINARY_ENVIRONMENTS = {
    "claude_code": "MEGAS_CLAUDE_BINARY",
    "codex_cli": "MEGAS_CODEX_BINARY",
    "aider": "MEGAS_AIDER_BINARY",
    "gemini_cli": "MEGAS_GEMINI_BINARY",
    "antigravity": "MEGAS_ANTIGRAVITY_BINARY",
    "grok_build": "MEGAS_GROK_BINARY",
    "kilo_code": "MEGAS_KILO_BINARY",
    "kiro_code": "MEGAS_KIRO_BINARY",
    "opencode": "MEGAS_OPENCODE_BINARY",
    "cline": "MEGAS_CLINE_BINARY",
    "devin_cli": "MEGAS_DEVIN_BINARY",
}
CERTIFIED_AGENT_TYPES = {
    "codex_cli",
    "claude_code",
    # gemini_cli abandoned — antigravity is the certified Google path
    "aider",
    "antigravity",
    "kilo_code",
    "kiro_code",
    "grok_build",
    "opencode",
    "cline",
    "devin_cli",
}
BUILTIN_COMMAND_CAPABILITIES = BUILTIN_ROUTING_CAPABILITIES


def _is_transport_error(exc: BaseException) -> bool:
    """True when the failure is the control socket dying, not the agent failing.

    WebSocket presence is transport state, not execution truth. A dropped socket used to
    be reported as ``session_failed``, which threw away replies the user was waiting for
    (observed as "no close frame received or sent" on live chats).
    """
    if isinstance(exc, (ConnectionError, TimeoutError, asyncio.IncompleteReadError)):
        return True
    ws_errors = getattr(websockets, "exceptions", None)
    if ws_errors is not None:
        candidates = tuple(
            cls
            for cls in (
                getattr(ws_errors, "ConnectionClosed", None),
                getattr(ws_errors, "ConnectionClosedError", None),
                getattr(ws_errors, "ConnectionClosedOK", None),
                getattr(ws_errors, "WebSocketException", None),
            )
            if isinstance(cls, type)
        )
        if candidates and isinstance(exc, candidates):
            return True
    text = str(exc).lower()
    markers = (
        "no close frame received or sent",
        "connection closed",
        "connection reset",
        "broken pipe",
        "websocket",
        "socket is closed",
        "sent 1011",
        "keepalive ping timeout",
    )
    return any(marker in text for marker in markers)


def detect_agent_binaries() -> dict[str, str]:
    """Discover coding-agent binaries (PATH + common install dirs + config)."""
    try:
        from .agent_catalog import list_agents
        from .config import load_config

        config = load_config()
        result: dict[str, str] = {}
        # Runtime detection is observational. It must never auto-register probe
        # results into worker.json (tests and failed probes previously polluted
        # the canonical config with temporary binary paths).
        for row in list_agents(config=config, auto_register=False):
            if row.binary_path and row.status in {"ready", "detected", "quarantined"}:
                result[row.agent_id] = row.binary_path
        if result:
            return result
    except Exception:
        pass

    from .adapters.aider import AiderAdapter
    from .adapters.antigravity import AntigravityAdapter
    from .adapters.claude import ClaudeCodeAdapter
    from .adapters.codex import CodexCliAdapter
    mapping = {
        "aider": AiderAdapter,
        "antigravity": AntigravityAdapter,
        "claude_code": ClaudeCodeAdapter,
        "codex_cli": CodexCliAdapter,
    }

    result = {}
    for agent_id, adapter_cls in mapping.items():
        try:
            adapter = adapter_cls([])
            status = adapter.health_status()
            if status == "available":
                binary_name = os.getenv(adapter.binary_env, adapter.default_binary) if adapter.binary_env else adapter.default_binary
                path = shutil.which(binary_name)
                if path:
                    result[agent_id] = path
        except Exception:
            pass
    # PATH / env fallback for agents not in the adapter-health map above.
    for agent_id, default_binary in AGENT_BINARIES.items():
        if agent_id in result:
            continue
        env_name = AGENT_BINARY_ENVIRONMENTS.get(agent_id)
        binary_name = os.getenv(env_name, default_binary) if env_name else default_binary
        path = shutil.which(str(binary_name))
        if not path and agent_id == "grok_build":
            # Official Grok Build user-local install.
            for candidate in (
                Path.home() / ".grok" / "bin" / "grok.exe",
                Path.home() / ".grok" / "bin" / "grok",
            ):
                if candidate.is_file():
                    path = str(candidate)
                    break
        if path:
            result[agent_id] = path
    return result


def get_installed_agent_binaries() -> dict[str, str]:
    detected = detect_agent_binaries()
    return {agent_id: path for agent_id, path in detected.items() if agent_id in CERTIFIED_AGENT_TYPES}


def runtime_capabilities(config: WorkerConfig) -> list[str]:
    return runtime_capabilities_from_manifest(build_runtime_manifest(config))


def _register_payload(config: WorkerConfig, pairing_code: str) -> dict[str, Any]:
    from .config import get_or_create_persistent_machine_id

    manifest = build_runtime_manifest(config)
    mach_id = str(getattr(config, "machine_id", "") or get_or_create_persistent_machine_id()).strip()
    return {
        "pairing_code": pairing_code,
        "worker_name": config.worker_name,
        "machine_name": config.machine_name or socket.gethostname(),
        "platform": platform.platform(),
        "capabilities": runtime_capabilities_from_manifest(manifest),
        "agent_binaries": {},
        "runtime_manifest": manifest,
        "machine_identity": mach_id,
    }


async def pair_worker(config: WorkerConfig, pairing_code: str) -> WorkerConfig:
    payload = _register_payload(config, pairing_code)
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.post(
            f"{config.rest_base_url}/api/v1/workers/register", json=payload
        )
        response.raise_for_status()
        data = response.json()
    config.worker_id = data["worker_id"]
    config.worker_token = data["worker_token"]
    config.machine_id = data.get("machine_id", "")
    config.capabilities = list(payload["capabilities"])
    save_config(config)
    return config


class WorkerRuntime:
    def __init__(self, config: WorkerConfig) -> None:
        if not config.is_paired:
            raise RuntimeError("Megas Worker is not paired. Run pair first.")
        self.config = config
        self.browser_manager = BrowserSessionManager(config.allowed_folders)
        self.browser_adapter = BrowserAdapter(self.browser_manager)
        self.adapters: list[AgentAdapter] = [
            RuntimeRefreshAdapter(config.allowed_folders),
            self.browser_adapter,
            CodexCliAdapter(config.allowed_folders),
            AntigravityAdapter(config.allowed_folders),
            ClaudeCodeAdapter(config.allowed_folders),
            AiderAdapter(config.allowed_folders),
            KiloCodeAdapter(config.allowed_folders),
            KiroCodeAdapter(config.allowed_folders),
            GrokBuildAdapter(config.allowed_folders),
            OpenCodeAdapter(config.allowed_folders),
            ClineAdapter(config.allowed_folders),
            DevinCliAdapter(config.allowed_folders),
            CustomNativeAgentAdapter(config.allowed_folders),
            WindowsCuaAdapter(config.allowed_folders),
            SshExecAdapter(config.allowed_folders),
            CustomShellAdapter(config.allowed_folders),
            CommitGateAdapter(config.allowed_folders),
            PrGateAdapter(config.allowed_folders),
        ]
        self.running_sessions: dict[str, asyncio.Task] = {}
        self.control_tasks: set[asyncio.Task] = set()
        self.active_leases: dict[str, dict[str, str]] = {}
        # First-message solidity: never re-run a command after finish/reconnect
        # re-dispatch (backend may re-send active lease after WS restart).
        self._inflight_command_ids: set[str] = set()
        self._completed_command_ids: dict[str, float] = {}
        self._runtime_manifest: dict[str, Any] | None = None
        self._runtime_manifest_built_at = 0.0
        # Live control socket. Command tasks must not hold a stale ws across reconnect.
        # Only publish after the initial connect heartbeat (backend closes 4400 otherwise).
        self._ws = None
        self._ws_ready = False
        self._last_dispatch_agent: str | None = None
        self._codex_health_cache: tuple[float, tuple[str, str | None, dict[str, Any]]] | None = None
        self._agent_binaries_cache: dict[str, str] = {}
        # Ephemeral provider-limit state. It is advertised in every heartbeat;
        # credentials and provider output are never persisted here.
        self._agent_limit_states: dict[str, dict[str, Any]] = {}
        # Windows: rewrite PATH so bare `git` (and agent children) never hit Git\cmd
        # wrappers that flash a console on every invocation.
        fixed = prefer_console_free_tool_path(dict(os.environ))
        if fixed.get("PATH"):
            os.environ["PATH"] = fixed["PATH"]
        for key in ("NO_COLOR", "CI", "TERM", "GIT_TERMINAL_PROMPT", "GCM_INTERACTIVE"):
            if fixed.get(key):
                os.environ.setdefault(key, fixed[key])
        # Operator-registered agent binaries (megas agents install/setup).
        try:
            from .agent_catalog import apply_agent_env_from_config

            apply_agent_env_from_config(config)
        except Exception:
            pass

    async def start_forever(self) -> None:
        retry_delay = 1.0
        # Do NOT warm full agent inventory here. Probing every coding CLI before
        # open made install/update sit on "connecting" for tens of seconds and
        # sometimes blew the backend's first-heartbeat window after a slow open.
        # Connect first (shallow heartbeat), inventory after CONNECTED.
        while True:
            try:
                await self._connect_once()
                retry_delay = 1.0
            except asyncio.CancelledError:
                await self._cancel_running_sessions()
                raise
            except Exception as exc:
                jitter = random.uniform(0, min(1.0, retry_delay / 4))
                print(f"worker connection lost: {redact(str(exc))}; reconnecting in {retry_delay + jitter:.1f}s")
                await asyncio.sleep(retry_delay + jitter)
                retry_delay = min(retry_delay * 2, 30.0)

    async def _connect_once(self) -> None:
        uri = f"{self.config.ws_base_url}/api/v1/workers/{self.config.worker_id}/connect"
        heartbeat_task: asyncio.Task | None = None
        inventory_task: asyncio.Task | None = None
        try:
            async with websockets.connect(
                uri,
                additional_headers={"X-Megas-Worker-Token": self.config.worker_token},
                ping_interval=20,
                ping_timeout=20,
                open_timeout=20,
                close_timeout=10,
                max_size=2 * 1024 * 1024,
            ) as ws:
                self._ws = ws
                self._ws_ready = False
                # First frame must be a heartbeat within backend's 10s window.
                # Keep it shallow — agent inventory is built in the background.
                await self._send_heartbeat(ws, deep_health=False)
                self._ws_ready = True
                try:
                    from .service import mark_worker_connected

                    mark_worker_connected()
                except Exception:
                    pass
                print(">>> Connection established successfully! Listening for coding tasks...", flush=True)
                # Background: build full inventory and push a richer heartbeat
                # without delaying the CONNECTED pulse used by install-service.
                inventory_task = asyncio.create_task(self._refresh_inventory_after_connect(ws))
                heartbeat_task = asyncio.create_task(self._heartbeat_loop(ws))
                async for raw in ws:
                    if len(raw) > 2 * 1024 * 1024:
                        raise RuntimeError("Megas Backend sent an oversized worker message.")
                    message = json.loads(raw)
                    await self._handle_message(ws, message)
        finally:
            self._ws_ready = False
            try:
                from .service import mark_worker_disconnected

                mark_worker_disconnected()
            except Exception:
                pass
            for task in (inventory_task, heartbeat_task):
                if task:
                    task.cancel()
            await asyncio.gather(
                *(task for task in (inventory_task, heartbeat_task) if task),
                return_exceptions=True,
            )
            self._ws = None
            # Do NOT cancel running sessions on socket drop. Brief reconnects (deploy,
            # 502, network blip) used to abort mid-failover (Codex limit → Antigravity)
            # and leave sessions stuck "running" with no final events. Explicit cancel
            # messages and process shutdown still cancel via other paths.

    async def _refresh_inventory_after_connect(self, ws) -> None:
        """Build certified inventory after CONNECTED so install UX is snappy."""
        try:
            await asyncio.sleep(0.05)
            # Existing signed-in CLIs must not require one manual
            # ``megas agents setup`` invocation each.  The bootstrap runs off
            # the keepalive path, is bounded per provider, and still uses the
            # normal fail-closed certificate evaluator.
            from .certification_bootstrap import certify_authenticated_agents

            await asyncio.to_thread(certify_authenticated_agents, self.config)
            # Force rebuild after connect so first deep beat is not empty.
            self._runtime_manifest = None
            self._runtime_manifest_built_at = 0.0
            await self._certified_runtime_manifest()
            if self._ws is ws and self._ws_ready:
                # Deep vendor probes run in this separate task. The heartbeat
                # loop keeps sending shallow beats while slow CLIs respond.
                await self._send_heartbeat(ws, deep_health=True)
            # Product: push local CLI chat folders to cloud immediately on connect
            # so Android/web agent history is full without waiting for the 15s loop.
            self._last_thread_sync = 0.0
            asyncio.create_task(self._sync_agent_threads_to_backend())
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"worker inventory refresh deferred: {redact(str(exc))}", flush=True)

    async def _codex_health_for_heartbeat(self, *, deep: bool) -> tuple[str, str | None, dict[str, Any]]:
        """Codex health for heartbeat. Deep probe is expensive; cache ~90s."""
        import os
        import shutil
        from datetime import datetime, timezone

        now = time.monotonic()
        if self._codex_health_cache and now - self._codex_health_cache[0] < 90:
            return self._codex_health_cache[1]

        codex_binary = os.getenv("MEGAS_CODEX_BINARY", "codex")
        path = shutil.which(codex_binary) or ""
        if not path and Path(codex_binary).is_file():
            path = str(Path(codex_binary).resolve())

        if deep:
            try:
                from megas.core.agent_health import check_codex_health

                result = await asyncio.wait_for(check_codex_health(codex_binary), timeout=8.0)
                self._codex_health_cache = (now, result)
                return result
            except Exception as exc:
                details = {
                    "detected": bool(path),
                    "executable_path": path,
                    "version": "",
                    "capabilities": ["code_editing", "read_only"] if path else [],
                    "authentication_state": "unknown",
                }
                result = (
                    "healthy" if path else "unhealthy",
                    None if path else f"Executable '{codex_binary}' not found.",
                    details,
                )
                # Fall through to light path if deep probe fails/times out.
                if path:
                    result = ("healthy", f"deep_health_skipped:{type(exc).__name__}", details)

        details = {
            "detected": bool(path),
            "executable_path": path,
            "version": "",
            "capabilities": ["code_editing", "read_only"] if path else [],
            "authentication_state": "unknown",
        }
        result = (
            "healthy" if path else "unhealthy",
            None if path else f"Executable '{codex_binary}' not found.",
            details,
        )
        self._codex_health_cache = (now, result)
        return result

    async def _send_heartbeat(self, ws, *, deep_health: bool = True) -> None:
        import os

        health_state, health_reason, health_details = await self._codex_health_for_heartbeat(
            deep=deep_health
        )

        codex_cfg = self.config.agents.get("codex_cli", {})
        enabled = codex_cfg.get("enabled", True)
        supported_roots = codex_cfg.get("supported_workspace_roots", list(self.config.allowed_folders))

        codex_auth = health_details.get("authentication_state", "unknown")
        if codex_auth == "unknown":
            try:
                from megas.core.agent_health import probe_authentication_state

                codex_auth = probe_authentication_state(
                    "codex_cli",
                    str(health_details.get("executable_path") or ""),
                )
            except Exception:
                codex_auth = "unknown"
        agents_health = {
            "codex_cli": {
                "agent_id": f"codex_cli_w-{self.config.worker_id}",
                "agent_type": "codex_cli",
                "display_name": "Codex CLI",
                "executable_path": health_details.get("executable_path", ""),
                "executable_version": health_details.get("version", ""),
                "detected": health_details.get("detected", False),
                "installed": bool(health_details.get("detected", False)),
                "enabled": enabled,
                "authentication_state": codex_auth,
                "logged_in": codex_auth == "authenticated",
                "capabilities": health_details.get("capabilities", []),
                "supported_workspace_roots": supported_roots,
                "health_state": health_state,
                "health_reason": health_reason,
                "last_health_check": datetime.now(timezone.utc).isoformat(),
                "configuration_version": codex_cfg.get("configuration_version", 1)
            }
        }

        def apply_limit_state(agent_id: str, health: dict[str, Any]) -> None:
            state = self._agent_limit_states.get(agent_id)
            if not isinstance(state, dict):
                health["limit_status"] = "available"
                return
            expected = str(state.get("expected_available_at") or "")
            status = "limited"
            if expected:
                try:
                    expected_dt = datetime.fromisoformat(expected.replace("Z", "+00:00"))
                    if expected_dt.tzinfo is None:
                        expected_dt = expected_dt.replace(tzinfo=timezone.utc)
                    if datetime.now(timezone.utc) >= expected_dt:
                        status = "retry_available"
                except ValueError:
                    pass
            health.update(state)
            health["limit_status"] = status

        apply_limit_state("codex_cli", agents_health["codex_cli"])

        if deep_health:
            binaries = await asyncio.to_thread(get_installed_agent_binaries)
            self._agent_binaries_cache = dict(binaries)
        else:
            # Adapter health_status() may execute many `--version` probes. The
            # first/keepalive heartbeat must use only the latest deep snapshot.
            binaries = dict(self._agent_binaries_cache)
        all_agents = {
            "claude_code": "Claude Code",
            "aider": "Aider",
            "antigravity": "Antigravity",
            "kilo_code": "Kilo Code",
            "kiro_code": "Kiro Code",
            "grok_build": "Grok Build",
            "kimi_code": "Kimi Code",
            "glm_code": "GLM Code",
            "opencode": "OpenCode",
            "cline": "Cline",
            "devin_cli": "Devin CLI",
        }
        try:
            from megas.core.agent_health import check_agent_presence
        except Exception:
            check_agent_presence = None  # type: ignore[assignment]
        for binary_id, display_name in all_agents.items():
            agent_cfg = self.config.agents.get(binary_id, {})
            path = binaries.get(binary_id, "")
            if deep_health and check_agent_presence is not None:
                try:
                    presence = await check_agent_presence(binary_id, path, display_name)
                except Exception:
                    presence = {
                        "detected": bool(path),
                        "installed": bool(path),
                        "executable_path": path,
                        "executable_version": "1.0.0" if path else "",
                        "authentication_state": "unknown",
                        "logged_in": False,
                        "capabilities": ["code_editing", "read_only"] if path else [],
                        "health_state": "healthy" if path else "unhealthy",
                        "health_reason": None if path else "Executable not found.",
                    }
            else:
                try:
                    from megas.core.agent_health import probe_authentication_state
                    agent_auth = probe_authentication_state(binary_id, path)
                except Exception:
                    agent_auth = "unknown"
                presence = {
                    "detected": bool(path),
                    "installed": bool(path),
                    "executable_path": path,
                    "executable_version": "1.0.0" if path else "",
                    "authentication_state": agent_auth,
                    "logged_in": agent_auth == "authenticated",
                    "capabilities": ["code_editing", "read_only"] if path else [],
                    "health_state": "healthy" if path else "unhealthy",
                    "health_reason": None if path else "Executable not found.",
                }
            agents_health[binary_id] = {
                "agent_id": f"{binary_id}_w-{self.config.worker_id}",
                "agent_type": binary_id,
                "display_name": display_name,
                "executable_path": presence.get("executable_path", path),
                "executable_version": presence.get("executable_version", ""),
                "detected": bool(presence.get("detected")),
                "installed": bool(presence.get("installed", presence.get("detected"))),
                "enabled": agent_cfg.get("enabled", binary_id in CERTIFIED_AGENT_TYPES and bool(presence.get("detected"))),
                "authentication_state": presence.get("authentication_state", "unknown"),
                "logged_in": bool(presence.get("logged_in")),
                "capabilities": presence.get("capabilities") or [],
                "supported_workspace_roots": agent_cfg.get("supported_workspace_roots", []),
                "health_state": presence.get("health_state", "unhealthy"),
                "health_reason": presence.get("health_reason"),
                "last_health_check": datetime.now(timezone.utc).isoformat(),
                "configuration_version": agent_cfg.get("configuration_version", 1)
            }
            apply_limit_state(binary_id, agents_health[binary_id])

        if deep_health:
            manifest = await self._certified_runtime_manifest()
        else:
            # The backend requires the first heartbeat within 20 seconds.
            # A cold runtime-manifest build may probe host tools and exceed that
            # budget, so advertise a valid minimal manifest and enrich it from
            # _refresh_inventory_after_connect after the socket is accepted.
            manifest = self._runtime_manifest or {
                "schema_version": "megas.worker-runtime.v1",
                "protocol_version": 1,
                "capabilities": list(self.config.capabilities or []),
            }
        from .config import resolve_machine_label

        # Product Connected Agents title uses this as "{label}'s Codex CLI".
        # Prefer OS user over auto Windows hostnames (LAPTOP-XXXX).
        machine_label = resolve_machine_label(self.config.machine_name)
        if machine_label and machine_label != str(self.config.machine_name or "").strip():
            self.config.machine_name = machine_label
        # Prefer-local stream: advertise private LAN IPs for home direct path.
        lan_ips: list[str] = []
        try:
            hostname = socket.gethostname()
            for info in socket.getaddrinfo(hostname, None):
                ip = str(info[4][0] if info and info[4] else "")
                if not ip or ":" in ip:  # skip v6 for simple LAN path
                    continue
                if ip.startswith("127.") or ip.startswith("169.254."):
                    continue
                if (
                    ip.startswith("10.")
                    or ip.startswith("192.168.")
                    or ip.startswith("172.16.")
                    or ip.startswith("172.17.")
                    or ip.startswith("172.18.")
                    or ip.startswith("172.19.")
                    or ip.startswith("172.2")
                    or ip.startswith("172.3")
                ):
                    if ip not in lan_ips:
                        lan_ips.append(ip)
        except Exception:
            pass
        await ws.send(json.dumps({
            "type": "heartbeat",
            "status": "worker_online",
            "capabilities": runtime_capabilities_from_manifest(manifest),
            "agent_binaries": binaries,
            "runtime_manifest": manifest,
            "active_leases": list(self.active_leases.values()),
            "workspaces": self.config.allowed_folders,
            "agents_health": agents_health,
            "machine_name": machine_label,
            "display_name": machine_label,
            "stream_lan_ips": lan_ips[:8],
            "stream_lan": {
                "ips": lan_ips[:8],
                "port": 18765,
                "path": "/local/sessions",
            },
        }))
        try:
            from .service import mark_worker_connected

            mark_worker_connected()
        except Exception:
            pass

    async def _certified_runtime_manifest(self) -> dict[str, Any]:
        now = time.monotonic()
        if (
            self._runtime_manifest is None
            or now - self._runtime_manifest_built_at >= 300
        ):
            self._runtime_manifest = await asyncio.to_thread(
                build_runtime_manifest, self.config
            )
            self._runtime_manifest_built_at = now
        return self._runtime_manifest

    async def _heartbeat_loop(self, ws) -> None:
        # Backend closes the socket if the first frame is late (10s). Periodic
        # beats should stay well under that. Deep Codex probes are infrequent.
        # Local watchdog pulse is refreshed every beat so age never goes "never"
        # during a brief reconnect or slow deep health.
        last_deep = time.monotonic()
        deep_task: asyncio.Task | None = None

        async def refresh_deep_health() -> None:
            try:
                await self._send_heartbeat(ws, deep_health=True)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # A vendor probe failure must never take down the control socket.
                print(f"worker deep health refresh deferred: {redact(str(exc))}", flush=True)

        try:
            while True:
                await asyncio.sleep(8)
                try:
                    now = time.monotonic()
                    if now - last_deep >= 120 and (deep_task is None or deep_task.done()):
                        # Never await vendor CLI probes on the keepalive path.
                        deep_task = asyncio.create_task(refresh_deep_health())
                        last_deep = now
                    # _send_heartbeat refreshes the local pulse only after the
                    # WebSocket send succeeds. Never certify a dead socket first.
                    await self._send_heartbeat(ws, deep_health=False)

                    # Periodic local coding agent thread sync to Megas backend
                    # (every local CLI chat folder → /threads/sync → Android + web)
                    if not hasattr(self, "_last_thread_sync") or (now - self._last_thread_sync) >= 15:
                        self._last_thread_sync = now
                        asyncio.create_task(self._sync_agent_threads_to_backend())
                except Exception as exc:
                    print(f"worker heartbeat failed: {redact(str(exc))}", flush=True)
                    raise
        finally:
            if deep_task is not None and not deep_task.done():
                deep_task.cancel()
                await asyncio.gather(deep_task, return_exceptions=True)

    def _thread_sync_cursor_path(self) -> Path:
        home = (os.getenv("MEGAS_HOME") or "").strip()
        root = Path(home).expanduser() if home else Path.home() / ".megasmoves"
        return root / "thread_sync_cursors.json"

    def _load_thread_sync_cursors(self) -> dict[str, str]:
        """Persist cursors so historical thr_ catch-up survives worker restarts."""
        path = self._thread_sync_cursor_path()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return {str(k): str(v) for k, v in raw.items() if k and v is not None}
        except Exception:
            pass
        return {}

    def _save_thread_sync_cursors(self) -> None:
        path = self._thread_sync_cursor_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            cursors = getattr(self, "_thread_sync_cursors", None) or {}
            # Cap file size — keep most recent keys only.
            items = list(cursors.items())
            if len(items) > 5000:
                items = items[-5000:]
            path.write_text(
                json.dumps(dict(items), indent=0, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    async def _sync_agent_threads_to_backend(self) -> None:
        """Production chat index sync — not a folder backup.

        Plane split (thread-identity-v1):
          1) Light index of CORE CLI chats (cursor/mtime only)
          2) Full transcript POST only when native cursor advanced (delta)
          3) Open path: exact native_thread_read for one thr_ the user opened

        Never re-upload unchanged local history every tick.
        """
        # Single-flight: heartbeat schedules this every 15s; overlapping tasks
        # hammered the same failing thr_ and never advanced the old-sync queue.
        if getattr(self, "_thread_sync_inflight", False):
            return
        self._thread_sync_inflight = True
        try:
            import time as _time

            import httpx
            from .thread_sync import (
                _MAX_FULL_SYNCS_PER_CYCLE,
                _MSGS_PER_SYNC_REQUEST,
                cap_thread_for_sync,
                is_megas_internal_session,
                list_native_thread_index,
                read_native_thread,
                threads_needing_full_sync,
            )

            if not hasattr(self, "_thread_sync_cursors") or self._thread_sync_cursors is None:
                self._thread_sync_cursors = self._load_thread_sync_cursors()
            if not hasattr(self, "_thread_sync_backoff") or self._thread_sync_backoff is None:
                # key -> unix time when retry is allowed again
                self._thread_sync_backoff: dict[str, float] = {}

            # Large index for historical past-thread catch-up (external-v1 old sync).
            # This used to hardcode 200 per provider, which silently capped the whole
            # catch-up: a machine with 1,944 Codex conversations only ever indexed the
            # newest 200, so older local chats could never reach the phone. Use the
            # module ceiling (tunable via MEGAS_THREAD_INDEX_LIMIT_PER_AGENT).
            index = await asyncio.to_thread(list_native_thread_index)
            if not index:
                return

            # Prefer lighter stores first so Claude/Grok old thr_ land before huge Codex.
            _agent_prio = {
                "claude_code": 0,
                "grok_build": 1,
                "antigravity": 2,
                "opencode": 3,
                "codex_cli": 4,
            }
            index_sorted = sorted(
                index,
                key=lambda r: (
                    _agent_prio.get(str(r.get("agent_type") or ""), 9),
                    str(r.get("native_id") or ""),
                ),
            )

            need_full = threads_needing_full_sync(
                index_sorted,
                self._thread_sync_cursors,
                max_full=_MAX_FULL_SYNCS_PER_CYCLE * 3,  # over-fetch then filter backoff
            )
            now_ts = _time.time()
            # Drop thr_ still in failure backoff so one timeout cannot starve the queue.
            filtered: list = []
            for row in need_full:
                agent = str(row.get("agent_type") or "")
                native = str(row.get("native_id") or "")
                key = f"{agent}:{native}"
                until = float(self._thread_sync_backoff.get(key) or 0.0)
                if until > now_ts:
                    continue
                filtered.append(row)
                if len(filtered) >= _MAX_FULL_SYNCS_PER_CYCLE:
                    break
            need_full = filtered
            if not need_full:
                return

            url = f"{self.config.rest_base_url}/api/v1/threads/sync"
            headers = {
                "X-Megas-Worker-Id": self.config.worker_id,
                "X-Megas-Worker-Token": self.config.worker_token,
            }
            synced = 0
            failed = 0
            # Old-sync re-uploads can include large Codex rollouts — per-thread
            # isolation so one ReadTimeout does not abort the whole batch.
            async with httpx.AsyncClient(timeout=60.0) as http_client:
                for row in need_full:
                    agent = str(row.get("agent_type") or "")
                    native = str(row.get("native_id") or "")
                    key = f"{agent}:{native}"
                    try:
                        # Full parse only for delta/first-seen — never re-dump all locals.
                        full = await asyncio.to_thread(read_native_thread, agent, native)
                        if not full or not (full.get("messages") or []):
                            # Empty shell / unreadable: do NOT create empty thr_ on backend
                            # (that surfaces as "Grok session" → parser_error on open).
                            # Advance cursor so we do not spin forever.
                            self._thread_sync_cursors[key] = str(row.get("sync_cursor") or "")
                            self._thread_sync_backoff.pop(key, None)
                            continue
                        # Megas' own probe/smoke runs are not the owner's chats. The index
                        # only sees a generic title for some providers (e.g. "Antigravity
                        # session"), so the check must also run here, where the parsed
                        # transcript reveals the real title and opening prompt.
                        first_user = ""
                        for _m in (full.get("messages") or []):
                            if str(_m.get("role") or "").lower() in {"user", "human"}:
                                first_user = str(_m.get("content") or "")
                                break
                        if is_megas_internal_session(full.get("title"), first_user):
                            self._thread_sync_cursors[key] = str(row.get("sync_cursor") or "")
                            self._thread_sync_backoff.pop(key, None)
                            continue
                        # Bound the REQUEST, never the conversation. Truncating to the
                        # newest N messages meant a long chat arrived permanently clipped
                        # (threads visibly "stopped at 40"). The whole transcript is sent
                        # as a sequence of bounded chunks instead; the backend upserts by
                        # native seq, so chunks are idempotent and a retry cannot duplicate
                        # or reorder anything. This scales to any history size because cost
                        # per cycle is bounded by chunk size, not by total conversation
                        # length.
                        base = cap_thread_for_sync(full, max_messages=0)
                        all_msgs = list(base.get("messages") or [])
                        chunk_size = max(25, _MSGS_PER_SYNC_REQUEST)
                        chunks = [
                            all_msgs[i : i + chunk_size]
                            for i in range(0, len(all_msgs), chunk_size)
                        ] or [[]]
                        cursor_value = str(
                            row.get("sync_cursor") or base.get("sync_cursor") or ""
                        )
                        all_ok = True
                        last_status = 0
                        for part_index, part in enumerate(chunks):
                            part_thread = dict(base)
                            part_thread["messages"] = part
                            part_thread["sync_cursor"] = cursor_value
                            # Total is stated on every chunk so the backend never reports a
                            # partial count as the thread's real size.
                            part_thread["message_count"] = len(all_msgs)
                            part_thread["chunk_index"] = part_index
                            part_thread["chunk_total"] = len(chunks)
                            payload = {
                                "worker_id": self.config.worker_id,
                                "threads": [part_thread],
                            }
                            resp = await http_client.post(url, json=payload, headers=headers)
                            last_status = resp.status_code
                            if resp.status_code != 200:
                                all_ok = False
                                break
                        if all_ok:
                            synced += 1
                            # Cursor advances only after the FULL conversation landed, so an
                            # interrupted upload is retried from the start next cycle.
                            self._thread_sync_cursors[key] = str(row.get("sync_cursor") or "")
                            self._thread_sync_backoff.pop(key, None)
                        else:
                            failed += 1
                            # Back off failed thr_ so the rest of the old-sync queue advances.
                            self._thread_sync_backoff[key] = now_ts + 120.0
                            print(
                                f"[THREAD_SYNC] status {last_status} "
                                f"for {agent}:{native[:12]}",
                                flush=True,
                            )
                    except Exception as thr_exc:
                        failed += 1
                        self._thread_sync_backoff[key] = now_ts + 120.0
                        detail = (
                            str(thr_exc).strip()
                            or repr(thr_exc)
                            or type(thr_exc).__name__
                        )
                        print(
                            f"[THREAD_SYNC] skip {agent}:{native[:12]} "
                            f"{type(thr_exc).__name__}: {detail[:200]} "
                            f"(backoff 120s)",
                            flush=True,
                        )
                        continue
            if synced or failed:
                self._save_thread_sync_cursors()
                print(
                    f"[THREAD_SYNC] delta synced={synced}/{len(need_full)} "
                    f"failed={failed} (index_scanned={len(index)})",
                    flush=True,
                )
        except Exception as exc:
            # Never print empty "Sync error (non-fatal): " — always surface type/detail.
            detail = str(exc).strip() or repr(exc) or type(exc).__name__
            fname = getattr(exc, "filename", None) or getattr(exc, "filename2", None)
            if fname:
                detail = f"{detail} path={fname}"
            print(
                f"[THREAD_SYNC] Sync error (non-fatal): {type(exc).__name__}: {detail[:400]}",
                flush=True,
            )
        finally:
            self._thread_sync_inflight = False

    async def _handle_native_thread_read(
        self,
        ws,
        request_id: str,
        provider: str,
        native_id: str,
    ) -> None:
        """Exact native_thread_read → push one thread to backend → ack on control socket."""
        import httpx
        from .thread_sync import _MAX_MSGS_EXACT_READ, cap_thread_for_sync, read_native_thread

        status = "ok"
        detail = ""
        try:
            thread = await asyncio.to_thread(read_native_thread, provider, native_id)
            if not thread:
                status = "empty"
                detail = "native_thread_not_found_or_empty"
            else:
                capped = cap_thread_for_sync(thread, max_messages=_MAX_MSGS_EXACT_READ)
                payload = {
                    "worker_id": self.config.worker_id,
                    "threads": [capped],
                }
                url = f"{self.config.rest_base_url}/api/v1/threads/sync"
                headers = {
                    "X-Megas-Worker-Id": self.config.worker_id,
                    "X-Megas-Worker-Token": self.config.worker_token,
                }
                async with httpx.AsyncClient(timeout=30.0) as http_client:
                    resp = await http_client.post(url, json=payload, headers=headers)
                    if resp.status_code != 200:
                        status = "sync_failed"
                        detail = f"http_{resp.status_code}"
                    else:
                        detail = f"synced_msgs={len(capped.get('messages') or [])}"
        except Exception as exc:
            status = "error"
            detail = str(exc)[:200]
            print(f"[THREAD_READ] failed: {exc}", flush=True)

        try:
            await ws.send(
                json.dumps(
                    {
                        "type": "native_thread_read_result",
                        "request_id": request_id,
                        "provider": provider,
                        "native_thread_id": native_id,
                        "status": status,
                        "detail": detail,
                        "worker_id": self.config.worker_id,
                    }
                )
            )
        except Exception as exc:
            print(f"[THREAD_READ] ack failed: {exc}", flush=True)

    async def _handle_native_thread_resume(
        self,
        ws,
        request_id: str,
        provider: str,
        native_id: str,
        workspace_root: str,
    ) -> None:
        """Confirm native thread is present for exact resume (Codex/Antigravity/…)."""
        from .thread_sync import _MAX_MSGS_EXACT_READ, cap_thread_for_sync, read_native_thread
        from pathlib import Path

        status = "ok"
        detail = ""
        try:
            thread = await asyncio.to_thread(read_native_thread, provider, native_id)
            if not thread:
                status = "empty"
                detail = "native_thread_not_found_or_empty"
            else:
                cwd = str(thread.get("project_path") or "").strip()
                if workspace_root and cwd and Path(workspace_root).resolve() != Path(cwd).resolve():
                    # Soft warning: still allow resume; backend pins preferred worker.
                    detail = f"workspace_mismatch expected={workspace_root[:80]} got={cwd[:80]}"
                else:
                    detail = f"ready msgs={len(thread.get('messages') or [])}"
                # Refresh backend snapshot so continue has latest history.
                try:
                    import httpx

                    capped = cap_thread_for_sync(thread, max_messages=_MAX_MSGS_EXACT_READ)
                    payload = {
                        "worker_id": self.config.worker_id,
                        "threads": [capped],
                    }
                    url = f"{self.config.rest_base_url}/api/v1/threads/sync"
                    headers = {
                        "X-Megas-Worker-Id": self.config.worker_id,
                        "X-Megas-Worker-Token": self.config.worker_token,
                    }
                    async with httpx.AsyncClient(timeout=20.0) as http_client:
                        resp = await http_client.post(url, json=payload, headers=headers)
                        if resp.status_code != 200:
                            detail = f"{detail}; sync_http_{resp.status_code}"
                except Exception as sync_exc:
                    detail = f"{detail}; sync_err={str(sync_exc)[:80]}"
        except Exception as exc:
            status = "error"
            detail = str(exc)[:200]
            print(f"[THREAD_RESUME] failed: {exc}", flush=True)

        try:
            await ws.send(
                json.dumps(
                    {
                        "type": "native_thread_resume_result",
                        "request_id": request_id,
                        "provider": provider,
                        "native_thread_id": native_id,
                        "status": status,
                        "detail": detail,
                        "worker_id": self.config.worker_id,
                    }
                )
            )
        except Exception as exc:
            print(f"[THREAD_RESUME] ack failed: {exc}", flush=True)

    @staticmethod
    def _native_resume_context(
        command: dict[str, Any],
        context_pack: dict[str, Any],
    ) -> dict[str, str] | None:
        """Detect thr_ exact continue (provider_session_id + resume flags)."""
        pack = context_pack if isinstance(context_pack, dict) else {}
        native_id = str(
            pack.get("provider_session_id")
            or pack.get("native_thread_id")
            or pack.get("native_id")
            or command.get("provider_session_id")
            or ""
        ).strip()
        megas_th = str(pack.get("megas_thread_id") or command.get("megas_thread_id") or "").strip()
        resume = pack.get("resume_existing") is True or bool(megas_th)
        if not native_id or not resume:
            return None
        agent = str(
            pack.get("agent_type")
            or command.get("agent_type")
            or command.get("command_type")
            or ""
        ).strip()
        instruction = str(
            command.get("instruction")
            or pack.get("instruction")
            or pack.get("user_message")
            or pack.get("message")
            or ""
        ).strip()
        return {
            "native_id": native_id,
            "agent_type": agent,
            "instruction": instruction,
            "megas_thread_id": megas_th,
        }

    async def _snapshot_native_thread(self, agent_type: str, native_id: str) -> dict[str, Any] | None:
        from .thread_sync import read_native_thread

        try:
            return await asyncio.to_thread(read_native_thread, agent_type, native_id)
        except Exception as exc:
            print(f"[NATIVE_PROOF] pre/post snapshot failed: {exc}", flush=True)
            return None

    async def _prove_and_sync_native_resume(
        self,
        *,
        resume_ctx: dict[str, str],
        pre_thread: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """P0-1: re-read native thr_ after process exit; require prompt persistence proof."""
        from .thread_sync import (
            _MAX_MSGS_EXACT_READ,
            cap_thread_for_sync,
            confirm_native_persistence,
            read_native_thread,
        )

        agent = resume_ctx.get("agent_type") or ""
        native_id = resume_ctx.get("native_id") or ""
        prompt = resume_ctx.get("instruction") or ""
        post: dict[str, Any] | None = None
        # C.1.10: provider may flush after process exit — brief poll.
        delays = (0.0, 0.6, 1.2, 2.0)
        for delay in delays:
            if delay:
                await asyncio.sleep(delay)
            try:
                post = await asyncio.to_thread(read_native_thread, agent, native_id)
            except Exception as exc:
                print(f"[NATIVE_PROOF] re-read error: {exc}", flush=True)
                post = None
            proof = confirm_native_persistence(
                expected_native_id=native_id,
                submitted_prompt=prompt,
                pre_thread=pre_thread,
                post_thread=post,
                agent_type=agent,
            )
            if proof.get("ok"):
                break

        # Push verified native snapshot so thr_ open sees the new turn.
        if proof.get("ok") and post:
            try:
                capped = cap_thread_for_sync(post, max_messages=_MAX_MSGS_EXACT_READ)
                payload = {
                    "worker_id": self.config.worker_id,
                    "threads": [capped],
                }
                url = f"{self.config.rest_base_url}/api/v1/threads/sync"
                headers = {
                    "X-Megas-Worker-Id": self.config.worker_id,
                    "X-Megas-Worker-Token": self.config.worker_token,
                }
                async with httpx.AsyncClient(timeout=25.0) as http_client:
                    resp = await http_client.post(url, json=payload, headers=headers)
                    proof["sync_http"] = resp.status_code
            except Exception as sync_exc:
                proof["sync_error"] = str(sync_exc)[:120]

        status = str(proof.get("status") or "")
        print(
            f"[NATIVE_PROOF] native={native_id[:40]} status={status} ok={proof.get('ok')} "
            f"detail={str(proof.get('detail') or '')[:120]}",
            flush=True,
        )
        return proof

    async def _cancel_running_sessions(self) -> None:
        tasks = [task for task in self.running_sessions.values() if not task.done()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self.running_sessions.clear()
        self.active_leases.clear()
        self._inflight_command_ids.clear()
        control_tasks = [task for task in self.control_tasks if not task.done()]
        for task in control_tasks:
            task.cancel()
        if control_tasks:
            await asyncio.gather(*control_tasks, return_exceptions=True)
        self.control_tasks.clear()
        await self.browser_manager.shutdown()

    def _track_control_task(self, task: asyncio.Task) -> None:
        self.control_tasks.add(task)
        task.add_done_callback(self.control_tasks.discard)

    async def _run_browser_action(self, ws, message: dict[str, Any]) -> None:
        browser_session_id = str(message.get("browser_session_id") or "")
        action_id = str(message.get("action_id") or "")
        session_id = str(message.get("session_id") or "")
        try:
            if not browser_session_id or not action_id or not session_id:
                raise ValueError("browser_action_identity_incomplete")
            action = message.get("action") if isinstance(message.get("action"), dict) else {}
            approval = message.get("approval") if isinstance(message.get("approval"), dict) else None
            accepted = await self.browser_manager.execute(
                browser_session_id,
                action_id,
                action,
                approval,
            )
            await ws.send(json.dumps({
                "type": "browser_action_result",
                "browser_session_id": browser_session_id,
                "session_id": session_id,
                "action_id": action_id,
                "success": True,
                **accepted,
            }))
        except Exception as exc:
            await ws.send(json.dumps({
                "type": "browser_action_result",
                "browser_session_id": browser_session_id,
                "session_id": session_id,
                "action_id": action_id,
                "success": False,
                "error": redact(str(exc)),
            }))

    def _prune_completed_commands(self) -> None:
        """Drop completed-command memory older than 2h to bound memory."""
        cutoff = time.time() - 7200.0
        stale = [cid for cid, ts in self._completed_command_ids.items() if ts < cutoff]
        for cid in stale:
            self._completed_command_ids.pop(cid, None)

    def _should_accept_dispatch(self, command: dict[str, Any]) -> bool:
        """Idempotent dispatch: one agent run per command_id (first message bar)."""
        self._prune_completed_commands()
        session_id = str(command.get("session_id") or "")
        command_id = str(command.get("command_id") or "")
        if not session_id:
            return False
        if session_id in self.running_sessions:
            print(f"[DISPATCH] skip already-running session {session_id}", flush=True)
            return False
        if command_id and command_id in self._inflight_command_ids:
            print(f"[DISPATCH] skip inflight command {command_id}", flush=True)
            return False
        if command_id and command_id in self._completed_command_ids:
            print(
                f"[DISPATCH] skip already-finished command {command_id} "
                f"(prevents command_terminal_immutable re-run)",
                flush=True,
            )
            return False
        return True

    async def _handle_message(self, ws, message: dict[str, Any]) -> None:
        message_type = message.get("type")
        if message_type == "dispatch":
            command = message.get("command") if isinstance(message.get("command"), dict) else {}
            session_id = str(command.get("session_id") or "")
            command_id = str(command.get("command_id") or "")
            if not self._should_accept_dispatch(command):
                return
            if session_id:
                if command_id:
                    self._inflight_command_ids.add(command_id)
                task = asyncio.create_task(self._run_command(ws, command))

                def _log_session_done(done: asyncio.Task, *, sid: str = session_id) -> None:
                    try:
                        exc = done.exception()
                    except asyncio.CancelledError:
                        print(f"[SESSION] {sid} cancelled", flush=True)
                        return
                    except Exception as callback_exc:
                        print(f"[SESSION] {sid} done-callback error: {callback_exc}", flush=True)
                        return
                    if exc is not None:
                        # Never let an unhandled session task tear down the Worker loop.
                        print(f"[SESSION] {sid} ended with error (Worker stays online): {exc}", flush=True)

                task.add_done_callback(_log_session_done)
                self.running_sessions[session_id] = task
        elif message_type in {"cancel", "cancel_command"}:
            session_id = message.get("session_id")
            if session_id in self.running_sessions:
                self.running_sessions[session_id].cancel()
        elif message_type == "native_thread_read":
            # Exact one-thread rehydration: open/history on phone → backend asks this
            # worker to re-read the provider-native transcript and push via /threads/sync.
            request_id = str(message.get("request_id") or "").strip()
            provider = str(message.get("provider") or message.get("agent_type") or "").strip()
            native_id = str(message.get("native_thread_id") or message.get("native_id") or "").strip()
            print(
                f"[THREAD_READ] request={request_id} provider={provider} native={native_id[:40]}",
                flush=True,
            )
            task = asyncio.create_task(
                self._handle_native_thread_read(ws, request_id, provider, native_id)
            )
            self._track_control_task(task)
        elif message_type == "native_thread_resume":
            # Preflight exact resume: confirm native thread exists on this machine before
            # backend dispatches a Megas session with provider_session_id / resume flags.
            request_id = str(message.get("request_id") or "").strip()
            provider = str(message.get("provider") or message.get("agent_type") or "").strip()
            native_id = str(message.get("native_thread_id") or message.get("native_id") or "").strip()
            workspace = str(message.get("workspace_root") or "").strip()
            print(
                f"[THREAD_RESUME] request={request_id} provider={provider} native={native_id[:40]}",
                flush=True,
            )
            task = asyncio.create_task(
                self._handle_native_thread_resume(
                    ws, request_id, provider, native_id, workspace
                )
            )
            self._track_control_task(task)
        elif message_type == "session_steer":
            # Same-session steer/queue from phone/web: a follow-up command is already
            # queued on the backend. Surface acknowledgment into the live stream.
            session_id = str(message.get("session_id") or "").strip()
            instruction = str(message.get("instruction") or "").strip()
            mode = str(message.get("mode") or "steer").strip().lower()
            print(
                f"[STEER] session={session_id} mode={mode} text={instruction[:120]!r}",
                flush=True,
            )
            if session_id and instruction:
                try:
                    # Best-effort live line so the phone sees steer landed mid-run.
                    lease = self.active_leases.get(session_id) if isinstance(self.active_leases, dict) else None
                    lease_id = ""
                    if isinstance(lease, dict):
                        lease_id = str(lease.get("lease_id") or "")
                    await self._send_event(
                        ws,
                        session_id,
                        str(message.get("command_id") or ""),
                        lease_id,
                        WorkerEvent(
                            "terminal_stdout",
                            {
                                "text": f"[user {mode}] {instruction}\n",
                                "phase": "user_steer",
                            },
                        ),
                        int(time.time() * 1000) % 1_000_000,
                    )
                except Exception as exc:
                    print(f"[STEER] stream note failed: {exc}", flush=True)
        elif message_type == "browser_action_request":
            task = asyncio.create_task(self._run_browser_action(ws, message))
            self._track_control_task(task)
        elif message_type == "browser_session_stop":
            browser_session_id = str(message.get("browser_session_id") or "")
            request_id = str(message.get("request_id") or "")
            try:
                result = await self.browser_manager.stop(
                    browser_session_id,
                    str(message.get("reason") or "backend_requested"),
                )
                await ws.send(json.dumps({
                    "type": "browser_session_stop_result",
                    "browser_session_id": browser_session_id,
                    "session_id": str(message.get("session_id") or ""),
                    "request_id": request_id,
                    "success": bool(result.get("cleanup_ok", True)),
                    "result": result,
                }))
            except Exception as exc:
                await ws.send(json.dumps({
                    "type": "browser_session_stop_result",
                    "browser_session_id": browser_session_id,
                    "session_id": str(message.get("session_id") or ""),
                    "request_id": request_id,
                    "success": False,
                    "error": redact(str(exc)),
                }))
        elif message_type == "browser_profile_delete":
            profile_id = str(message.get("profile_id") or "")
            request_id = str(message.get("request_id") or "")
            try:
                deleted = await self.browser_manager.delete_profile(profile_id)
                await ws.send(json.dumps({
                    "type": "browser_profile_delete_result",
                    "profile_id": profile_id,
                    "request_id": request_id,
                    "success": deleted,
                }))
            except Exception as exc:
                await ws.send(json.dumps({
                    "type": "browser_profile_delete_result",
                    "profile_id": profile_id,
                    "request_id": request_id,
                    "success": False,
                    "error": redact(str(exc)),
                }))
        elif message_type == "worker_connected":
            print(">>> Connection established successfully! Listening for coding tasks...")
        elif message_type in {"inventory_refresh", "agent_refresh"}:
            asyncio.create_task(self._send_heartbeat(ws))
        elif message_type and message_type.endswith("_ack"):
            return
        elif message_type == "runtime_refresh":
            refresh_command = message.get("command") if isinstance(message.get("command"), dict) else message
            refresh_command["command_type"] = "runtime_refresh"
            target_runtime = str(refresh_command.get("runtime_id") or "")
            # Cancel all running sessions for the target runtime
            for sid, task in list(self.running_sessions.items()):
                if not task.done():
                    task.cancel()
            session_id = str(refresh_command.get("session_id") or refresh_command.get("refresh_id") or "")
            if session_id and session_id not in self.running_sessions:
                self.running_sessions[session_id] = asyncio.create_task(self._run_command(ws, refresh_command))
        elif message_type == "error":
            print(f"backend error: {message}")
        elif message_type == "create_checkpoint":
            runtime_id = str(message.get("runtime_id") or "")
            checkpoint_id = str(message.get("checkpoint_id") or "")
            workspace_path = message.get("workspace_path") or (self.config.allowed_folders[0] if self.config.allowed_folders else "")
            try:
                if not runtime_id or not checkpoint_id:
                    raise ValueError("Megas Backend checkpoint dispatch is missing runtime or checkpoint identity.")
                from .adapters.checkpoint import save_workspace_checkpoint
                workspace = resolve_allowed_workdir(workspace_path, self.config.allowed_folders)
                payload_bytes = save_workspace_checkpoint(str(workspace))
                async with httpx.AsyncClient(timeout=120.0) as http_client:
                    files = {"file": ("checkpoint.tar.gz", payload_bytes, "application/gzip")}
                    data = {
                        "checkpoint_id": checkpoint_id,
                        "checkpoint_type": "runtime_refresh",
                        "summary": f"Automated refresh checkpoint for runtime {runtime_id}"
                    }
                    headers = {
                        "X-Megas-Worker-Id": self.config.worker_id,
                        "X-Megas-Worker-Token": self.config.worker_token,
                    }
                    resp = await http_client.post(
                        f"{self.config.rest_base_url}/api/v1/runtimes/{runtime_id}/checkpoints",
                        files=files,
                        data=data,
                        headers=headers
                    )
                    resp.raise_for_status()
                    checkpoint_data = resp.json().get("checkpoint", {})
                await ws.send(json.dumps({
                    "type": "checkpoint_created",
                    "runtime_id": runtime_id,
                    "checkpoint_id": checkpoint_data.get("id") or checkpoint_id,
                    "success": True
                }))
            except Exception as e:
                await ws.send(json.dumps({
                    "type": "checkpoint_created",
                    "runtime_id": runtime_id,
                    "checkpoint_id": checkpoint_id or None,
                    "success": False,
                    "error": redact(str(e))
                }))
        elif message_type == "restore_checkpoint":
            runtime_id = str(message.get("runtime_id") or "")
            checkpoint_id = str(message.get("checkpoint_id") or "")
            workspace_path = message.get("workspace_path") or (self.config.allowed_folders[0] if self.config.allowed_folders else "")
            try:
                if not runtime_id or not checkpoint_id:
                    raise ValueError("Megas Backend restore dispatch is missing runtime or checkpoint identity.")
                workspace = resolve_allowed_workdir(workspace_path, self.config.allowed_folders)
                async with httpx.AsyncClient(timeout=120.0) as http_client:
                    headers = {
                        "X-Megas-Worker-Id": self.config.worker_id,
                        "X-Megas-Worker-Token": self.config.worker_token,
                    }
                    resp = await http_client.get(
                        f"{self.config.rest_base_url}/api/v1/runtimes/{runtime_id}/checkpoints/latest",
                        headers=headers,
                        params={"checkpoint_id": checkpoint_id},
                    )
                    resp.raise_for_status()
                    payload_bytes = resp.content
                    response_checkpoint_id = resp.headers.get("X-Megas-Checkpoint-Id", "")
                    expected_digest = resp.headers.get("X-Megas-Checkpoint-SHA256", "")
                actual_digest = hashlib.sha256(payload_bytes).hexdigest()
                if response_checkpoint_id != checkpoint_id or expected_digest != actual_digest:
                    raise ValueError("Megas Backend checkpoint identity or digest did not match the restore dispatch.")
                from .adapters.checkpoint import restore_workspace_checkpoint
                branch = restore_workspace_checkpoint(str(workspace), payload_bytes)
                await ws.send(json.dumps({
                    "type": "checkpoint_restored",
                    "runtime_id": runtime_id,
                    "checkpoint_id": checkpoint_id,
                    "sha256": actual_digest,
                    "success": True,
                    "branch": branch
                }))
            except Exception as e:
                await ws.send(json.dumps({
                    "type": "checkpoint_restored",
                    "runtime_id": runtime_id,
                    "checkpoint_id": checkpoint_id or None,
                    "success": False,
                    "error": redact(str(e))
                }))
        elif message_type == "connect_network":
            # Production: adapter_id preferred; provider_id kept for older dispatches.
            connect = message.get("connect") if isinstance(message.get("connect"), dict) else {}
            provider_id = (
                message.get("adapter_id")
                or message.get("provider_id")
                or connect.get("adapter_id")
                or connect.get("provider_id")
            )
            policy = message.get("policy") if isinstance(message.get("policy"), dict) else {}
            if not policy and isinstance(connect.get("policy"), dict):
                policy = connect.get("policy") or {}
            try:
                from .adapters.network_skill import NetworkSkill
                success = NetworkSkill.connect(str(provider_id or ""), policy)
                ip = NetworkSkill.get_public_ip()
                await ws.send(json.dumps({
                    "type": "network_connected",
                    "provider_id": provider_id,
                    "success": success,
                    "public_ip": ip
                }))
            except Exception as e:
                await ws.send(json.dumps({
                    "type": "network_connected",
                    "provider_id": provider_id,
                    "success": False,
                    "error": redact(str(e))
                }))
        elif message_type == "disconnect_network":
            provider_id = message.get("adapter_id") or message.get("provider_id")
            try:
                from .adapters.network_skill import NetworkSkill
                success = NetworkSkill.disconnect(str(provider_id or ""))
                await ws.send(json.dumps({
                    "type": "network_disconnected",
                    "provider_id": provider_id,
                    "success": success
                }))
            except Exception as e:
                await ws.send(json.dumps({
                    "type": "network_disconnected",
                    "provider_id": provider_id,
                    "success": False,
                    "error": redact(str(e))
                }))
        elif message_type == "verify_network":
            runtime_id = message.get("runtime_id")
            request_id = message.get("request_id")
            attempt = message.get("attempt")
            connect = message.get("connect") if isinstance(message.get("connect"), dict) else {}
            try:
                from .adapters.network_skill import NetworkSkill
                # Connect assigned profile first (Tailscale / Nord / WG / proxy), then verify.
                if connect.get("adapter_id") or connect.get("provider_type"):
                    adapter = str(
                        connect.get("adapter_id")
                        or f"provider-{connect.get('provider_type')}"
                    )
                    policy = connect.get("policy") if isinstance(connect.get("policy"), dict) else {}
                    connected = NetworkSkill.connect(adapter, policy)
                    if not connected:
                        await ws.send(json.dumps({
                            "type": "network_verified",
                            "runtime_id": runtime_id,
                            "request_id": request_id,
                            "attempt": attempt,
                            "success": False,
                            "public_ip": NetworkSkill.get_public_ip(),
                            "dns_ok": False,
                            "connectivity_ok": False,
                            "error": "network_connect_failed",
                            "connected": False,
                        }))
                        return
                evidence = NetworkSkill.collect_verification_evidence()
                # Mesh (Tailscale) may not change public egress IP — do not fail closed solely on that.
                if connect.get("provider_type") in {"tailscale", "ts"} or str(
                    connect.get("adapter_id") or ""
                ).endswith("tailscale"):
                    evidence["success"] = bool(
                        evidence.get("public_ip")
                        and evidence.get("dns_ok")
                        and evidence.get("connectivity_ok")
                    )
                    evidence["ip_changed_required"] = False
                await ws.send(json.dumps({
                    "type": "network_verified",
                    "runtime_id": runtime_id,
                    "request_id": request_id,
                    "attempt": attempt,
                    "connected": bool(connect),
                    **evidence,
                }))
            except Exception as e:
                await ws.send(json.dumps({
                    "type": "network_verified",
                    "runtime_id": runtime_id,
                    "request_id": request_id,
                    "attempt": attempt,
                    "success": False,
                    "public_ip": "",
                    "dns_ok": False,
                    "connectivity_ok": False,
                    "error": redact(str(e))
                }))

    async def _verify_snapshot_cross_device(self, command: dict[str, Any]) -> None:
        snapshot_id = command.get("context_snapshot_id")
        if not snapshot_id:
            raise ValueError("Command is missing context snapshot reference.")
        supplied_digest = command.get("context_snapshot_digest")
        if not supplied_digest:
            raise ValueError("Command is missing context snapshot digest.")

        import httpx
        from pathlib import Path
        headers = {
            "X-Megas-Worker-Id": self.config.worker_id,
            "X-Megas-Worker-Token": self.config.worker_token,
        }
        url = f"{self.config.rest_base_url}/api/v1/context/snapshots/{snapshot_id}"
        async with httpx.AsyncClient(timeout=10.0) as http_client:
            try:
                resp = await http_client.get(url, headers=headers)
            except Exception as e:
                raise ConnectionError(f"Failed to connect to backend for snapshot verification: {e}")
            if resp.status_code == 404:
                raise ValueError("The referenced context snapshot does not exist.")
            elif resp.status_code == 403:
                raise PermissionError("Snapshot ownership check failed: permission denied.")
            elif resp.status_code != 200:
                raise RuntimeError(f"Backend snapshot retrieval failed with status {resp.status_code}.")
            snapshot = resp.json()

        allowed_roots = self.config.allowed_folders or []
        canonical_allowed = [str(Path(p).resolve()) for p in allowed_roots]
        snapshot_roots = snapshot.get("allowed_workspace_roots") or []
        if snapshot_roots:
            for root in snapshot_roots:
                res_root = str(Path(root).resolve())
                if res_root not in canonical_allowed:
                    raise ValueError(f"Workspace path {root} is not allowed on this worker.")

        workdir = command.get("workdir") or (command.get("context_pack") or {}).get("workdir")
        base_commit = snapshot.get("base_commit")
        branch = snapshot.get("branch")
        if workdir and Path(workdir).exists() and Path(workdir).joinpath(".git").exists():
            import subprocess
            git_env = prefer_console_free_tool_path(dict(os.environ))
            if base_commit:
                try:
                    res = subprocess.run(
                        ["git", "rev-parse", "HEAD"],
                        cwd=workdir,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        timeout=5,
                        check=True,
                        env=git_env,
                        **subprocess_hide_window_kwargs(),
                    )
                    local_commit = res.stdout.strip()
                    if local_commit != base_commit:
                        raise ValueError(f"Base commit mismatch: local HEAD is {local_commit}, snapshot expected {base_commit}.")
                except subprocess.SubprocessError as e:
                    raise ValueError(f"Failed to verify base commit: {e}")
            if branch:
                try:
                    res = subprocess.run(
                        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                        cwd=workdir,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        timeout=5,
                        check=True,
                        env=git_env,
                        **subprocess_hide_window_kwargs(),
                    )
                    local_branch = res.stdout.strip()
                    if local_branch != branch:
                        raise ValueError(f"Branch mismatch: local branch is {local_branch}, snapshot expected {branch}.")
                except subprocess.SubprocessError as e:
                    raise ValueError(f"Failed to verify branch: {e}")

        import secrets
        stored_digest = snapshot.get("content_digest") or snapshot.get("payload_digest") or ""
        if not secrets.compare_digest(supplied_digest, stored_digest):
            raise ValueError(f"Supplied digest {supplied_digest} does not match stored snapshot digest {stored_digest}.")

        url_latest = f"{self.config.rest_base_url}/api/v1/context/sessions/{command['session_id']}/latest"
        async with httpx.AsyncClient(timeout=10.0) as http_client:
            try:
                resp_latest = await http_client.get(url_latest, headers=headers)
                if resp_latest.status_code == 200:
                    latest_snapshot = resp_latest.json()
                    latest_version = int(latest_snapshot.get("context_version") or 0)
                    command_version = int(command.get("context_snapshot_version") or 0)
                    if command_version < latest_version:
                        raise ValueError(f"Stale command: snapshot version {command_version} is older than latest session version {latest_version}.")
            except Exception as e:
                if isinstance(e, ValueError):
                    raise e

    async def _run_command(self, ws, command: dict[str, Any]) -> None:
        session_id = str(command.get("session_id") or "")
        command_id = str(command.get("command_id") or "")
        lease_id = str(command.get("lease_id") or "")
        task_id = command.get("task_id")
        if not session_id:
            return
        if command_id and lease_id:
            self.active_leases[session_id] = {
                "command_id": command_id,
                "lease_id": lease_id,
            }
        adapter: AgentAdapter | None = None
        is_refresh = False
        refresh_id = str(command.get("refresh_id") or "")
        runtime_id = str(command.get("runtime_id") or "")
        context_pack = command.get("context_pack") if isinstance(command.get("context_pack"), dict) else {}
        agent_type = str(context_pack.get("agent_type") or command.get("agent_type") or "")
        event_index = 0
        terminal_event_seen = False
        terminal_exit_code: int | None = None
        # Notion P0-1: thr_ continue must prove native persistence (not process exit alone).
        native_resume_ctx = self._native_resume_context(command, context_pack)
        pre_native_thread: dict[str, Any] | None = None
        if native_resume_ctx:
            pre_native_thread = await self._snapshot_native_thread(
                native_resume_ctx.get("agent_type") or agent_type,
                native_resume_ctx["native_id"],
            )
            print(
                f"[NATIVE_PROOF] pre-snapshot native={native_resume_ctx['native_id'][:40]} "
                f"msgs={len((pre_native_thread or {}).get('messages') or [])}",
                flush=True,
            )

        try:
            if str(command.get("command_type") or "") != "runtime_refresh":
                if not command_id or not lease_id:
                    raise ValueError("Megas Worker dispatch lease identity is incomplete.")
                context_proof = verify_worker_context(command)
                await self._verify_snapshot_cross_device(command)
                event_index += 1
                await self._send_event(
                    ws,
                    session_id,
                    command_id,
                    lease_id,
                    WorkerEvent("context_verified", context_proof),
                    event_index,
                )

                # Collect ALL code repository bindings for verification
                code_repo_bindings: List[Dict[str, Any]] = []

                direct_binding = command.get("repository_binding") or command.get("context_binding") or (context_pack.get("repository_binding") if isinstance(context_pack, dict) else None)
                if isinstance(direct_binding, dict):
                    code_repo_bindings.append(direct_binding)

                raw_items = []
                for src in (command.get("source_bindings"), command.get("context_items"), context_pack.get("source_bindings") if isinstance(context_pack, dict) else None, context_pack.get("context_items") if isinstance(context_pack, dict) else None):
                    if isinstance(src, list):
                        raw_items.extend(src)

                has_code_context = bool(command.get("code_source_id") or command.get("snapshot_id"))
                for item in raw_items:
                    if isinstance(item, dict):
                        kind = str(item.get("kind") or "").lower()
                        is_code_item = (
                            kind in ("code_snapshot", "code_source", "repository", "git_repo")
                            or bool(item.get("code_source_id") or item.get("snapshot_id") or item.get("provider_repository_id"))
                        )
                        if is_code_item:
                            has_code_context = True
                            if item not in code_repo_bindings:
                                code_repo_bindings.append(item)

                if has_code_context and not code_repo_bindings:
                    raise PermissionError("Repository verification gate failed: Code-bound session missing required repository_binding.")

                if code_repo_bindings:
                    from .repository_binding import verify_repository_workspace
                    default_ws = str(command.get("workspace_dir") or (self.config.allowed_folders[0] if self.config.allowed_folders else "."))
                    repo_ws_map = command.get("repository_workspaces") or (context_pack.get("repository_workspaces") if isinstance(context_pack, dict) else {}) or {}
                    is_multi_repo = len(code_repo_bindings) > 1

                    for binding in code_repo_bindings:
                        bid = str(binding.get("id") or binding.get("source_id") or binding.get("provider_repository_id") or "")
                        explicit_ws = binding.get("workspace_dir") or repo_ws_map.get(bid) or repo_ws_map.get(binding.get("provider_repository_id"))

                        if is_multi_repo and not explicit_ws:
                            raise PermissionError(
                                f"Multi-repository verification gate failed: Missing explicit workspace mapping for repository binding '{bid}'."
                            )

                        target_ws = str(explicit_ws or default_ws)
                        verification = verify_repository_workspace(target_ws, binding)
                        if not verification.is_valid:
                            raise PermissionError(f"Repository verification gate failed for '{bid}': {verification.error_detail}")

                        event_index += 1
                        await self._send_event(
                            ws,
                            session_id,
                            command_id,
                            lease_id,
                            WorkerEvent("repository_verified", {
                                "binding_id": bid,
                                "workspace_dir": target_ws,
                                **verification.to_dict(),
                            }),
                            event_index,
                        )
            from .adapters.network_skill import NetworkSkill
            if not NetworkSkill.is_execution_allowed():
                raise PermissionError("Command execution blocked: required network verification is incomplete or failed.")

            # Multi-agent chain: preferred first, then ONE limit failover only.
            # Timeouts never failover (see below) — that multi-minute chain felt 100x slow.
            from .agent_router import canonicalize_agent_id

            preferred = canonicalize_agent_id(
                agent_type or str(command.get("command_type") or "codex_cli")
            )
            policy_fallbacks: list[str] = []
            if isinstance(context_pack, dict):
                raw_fb = context_pack.get("fallback_agents") or context_pack.get("agent_fallbacks") or []
                if isinstance(raw_fb, list):
                    policy_fallbacks = [str(x) for x in raw_fb]
            available = available_coding_agents(
                self.adapters,
                capabilities=self.config.capabilities or None,
                write_mode=context_pack.get("write_mode") is True,
            )
            cmd_type = str(command.get("command_type") or "")
            cmd_obj = command.get("command") if isinstance(command.get("command"), dict) else {}
            single_shot = cmd_type in {
                "runtime_refresh",
                "create_commit",
                "create_draft_pr",
                "branch_cleanup",
                "safe_shell_command",
                "custom_shell",
            } or str(cmd_obj.get("name") or "") in {"apply_patch", "discard_patch"}
            if single_shot:
                agent_chain = [preferred]
            else:
                agent_chain = build_agent_chain(
                    preferred,
                    available=available,
                    fallbacks=policy_fallbacks,
                )

            last_limit_error = ""
            for attempt_index, candidate in enumerate(agent_chain):
                attempt_command = with_agent_type(command, candidate) if candidate else command
                attempt_output: list[str] = []
                limit_emitted_for_attempt = False

                async def emit_limit(*parts: Any) -> bool:
                    nonlocal event_index, limit_emitted_for_attempt, last_limit_error
                    if limit_emitted_for_attempt:
                        return True
                    info = parse_limit_failure(candidate, *parts)
                    if info is None:
                        return False
                    payload = info.to_payload()
                    if attempt_index + 1 < len(agent_chain):
                        payload["fallback_agent"] = agent_chain[attempt_index + 1]
                    self._agent_limit_states[candidate] = dict(payload)
                    last_limit_error = info.message
                    event_index += 1
                    await self._send_event(
                        ws,
                        session_id,
                        command_id,
                        lease_id,
                        WorkerEvent("agent_limit_reached", payload),
                        event_index,
                    )
                    limit_emitted_for_attempt = True
                    return True

                try:
                    await self._verify_agent_readiness(attempt_command)
                    adapter = self._select_adapter(attempt_command)
                except Exception as exc:
                    last_limit_error = str(exc)
                    err_l = str(exc).lower()
                    # Only failover on provider limit / missing binary — NOT on model
                    # timeouts (174s × N agents felt like 100x slow).
                    if attempt_index + 1 < len(agent_chain) and looks_like_limit_failure(str(exc)):
                        await emit_limit(str(exc))
                        print(f"[ROUTER] Skip {candidate}: {exc}")
                        continue
                    if attempt_index + 1 < len(agent_chain) and (
                        "not available" in err_l
                        or "not found" in err_l
                        or "quarantined" in err_l
                    ):
                        print(f"[ROUTER] Skip unavailable {candidate}: {exc}")
                        continue
                    if looks_like_limit_failure(str(exc)):
                        await emit_limit(str(exc))
                    raise

                is_refresh = getattr(adapter, "name", "") == "runtime_refresh"
                # Cloud stream attribution: every session_event carries the active agent.
                self._last_dispatch_agent = str(
                    candidate or getattr(adapter, "name", "") or preferred or ""
                )
                if attempt_index == 0:
                    print("\n" + "=" * 60)
                    print(f"        SESSION INITIATED: {session_id}")
                    print("=" * 60)
                    print(f"  * Agent:     {candidate or getattr(adapter, 'name', 'unknown')}")
                    print(f"  * Fallbacks: {', '.join(agent_chain[1:]) or 'none'}")
                    print(f"  * Command:   {command_id}")
                    print(f"  * Task ID:   {task_id or 'N/A'}")
                    print("-" * 60)
                else:
                    print(f"\n[ROUTER] Limit/availability failover → {candidate}")
                    event_index += 1
                    await self._send_event(
                        ws,
                        session_id,
                        command_id,
                        lease_id,
                        WorkerEvent(
                            "agent_failover",
                            {
                                "from_agent": agent_chain[attempt_index - 1],
                                "to_agent": candidate,
                                "reason": last_limit_error or "provider_limit_or_unavailable",
                                "attempt": attempt_index + 1,
                                "adapter": candidate,
                                "agent_type": candidate,
                            },
                        ),
                        event_index,
                    )

                terminal_event_seen = False
                terminal_exit_code = None
                pending_terminal_event: WorkerEvent | None = None
                pending_terminal_evidence: list[WorkerEvent] = []
                more_agents = attempt_index + 1 < len(agent_chain)
                try:
                    async for event in adapter.launch(attempt_command):
                        if event.event_type == "command_started":
                            cmd_list = event.payload.get("command") or []
                            cmd_str = " ".join(cmd_list) if isinstance(cmd_list, list) else str(cmd_list)
                            print(f"\n[RUNNING] Executing: {cmd_str}")
                            print(f"[WORKDIR] Directory: {event.payload.get('workdir')}\n")
                            event_index += 1
                            await self._send_event(ws, session_id, command_id, lease_id, event, event_index)
                        elif event.event_type in {"terminal_stdout", "terminal_stderr"}:
                            text = event.payload.get("text") or ""
                            attempt_output.append(text)
                            print(f"  | {text}")
                            # Stream progress; do not seal the command.
                            event_index += 1
                            await self._send_event(ws, session_id, command_id, lease_id, event, event_index)
                        elif event.event_type == "command_finished":
                            code = event.payload.get("exit_code")
                            terminal_event_seen = True
                            terminal_exit_code = int(code) if isinstance(code, int) else 1
                            dur = event.payload.get("duration_ms") or 0
                            status_text = "SUCCESS" if code == 0 else f"FAILED (exit: {code})"
                            print(f"\n[FINISHED] {status_text} in {dur}ms\n")
                            # Defer terminal seal until we know whether failover will run.
                            pending_terminal_event = event
                        elif event.event_type == "refresh_completed":
                            terminal_event_seen = True
                            terminal_exit_code = 0 if event.payload.get("success") is True else 1
                            print(f"\n[FINISHED] Runtime refresh {'succeeded' if terminal_exit_code == 0 else 'failed'}\n")
                            pending_terminal_event = event
                        elif event.event_type == "evidence":
                            summary = event.payload.get("summary") or "Evidence recorded"
                            payload = event.payload.get("payload") if isinstance(event.payload.get("payload"), dict) else {}
                            # Capture provider errors embedded in evidence for limit detection.
                            for key in ("error", "output_tail", "summary"):
                                if key in event.payload:
                                    attempt_output.append(str(event.payload.get(key)))
                                if key in payload:
                                    attempt_output.append(str(payload.get(key)))
                            print(f"  [EVIDENCE] {summary}")
                            # Defer terminal-ish evidence until chain decision; other evidence can stream.
                            evidence_type = str(
                                event.payload.get("evidence_type")
                                or payload.get("evidence_type")
                                or ""
                            )
                            if evidence_type in {
                                "terminal_result",
                                "evidence_agent_failed",
                                "evidence_command_failed",
                            }:
                                pending_terminal_evidence.append(event)
                            else:
                                await self._send_evidence(
                                    ws, session_id, command_id, lease_id, task_id, event
                                )
                        elif event.event_type != "evidence":
                            if event.event_type in {
                                "error",
                                "agent_error",
                                "command_error",
                                "worker_error",
                            }:
                                attempt_output.append(
                                    str(
                                        event.payload.get("message")
                                        or event.payload.get("error")
                                        or event.payload.get("detail")
                                        or ""
                                    )
                                )
                            event_index += 1
                            await self._send_event(ws, session_id, command_id, lease_id, event, event_index)
                except Exception as exc:
                    last_limit_error = str(exc)
                    attempt_output.append(str(exc))
                    if more_agents and looks_like_limit_failure(str(exc), *attempt_output):
                        await emit_limit(str(exc), *attempt_output)
                        print(f"[ROUTER] {candidate} hit limit-like failure: {exc}")
                        continue
                    if looks_like_limit_failure(str(exc), *attempt_output):
                        await emit_limit(str(exc), *attempt_output)
                    raise

                if not terminal_event_seen:
                    if more_agents:
                        last_limit_error = "adapter ended without command_finished"
                        continue
                    raise RuntimeError("Worker adapter ended without a command_finished event.")

                if terminal_exit_code == 0:
                    # thr_ exact resume: process exit is weak; re-read native + match prompt.
                    if native_resume_ctx:
                        # Prefer agent actually used for read (failover may change type).
                        proof_ctx = {
                            **native_resume_ctx,
                            "agent_type": str(
                                candidate
                                or native_resume_ctx.get("agent_type")
                                or agent_type
                                or ""
                            ),
                        }
                        if not proof_ctx.get("instruction"):
                            proof_ctx["instruction"] = str(
                                attempt_command.get("instruction")
                                or (attempt_command.get("context_pack") or {}).get("instruction")
                                or ""
                            ).strip()
                        proof = await self._prove_and_sync_native_resume(
                            resume_ctx=proof_ctx,
                            pre_thread=pre_native_thread,
                        )
                        event_index += 1
                        await self._send_event(
                            ws,
                            session_id,
                            command_id,
                            lease_id,
                            WorkerEvent("native_persistence_proof", dict(proof)),
                            event_index,
                        )
                        if not proof.get("ok"):
                            status = str(
                                proof.get("status")
                                or "ACCEPTANCE_AMBIGUOUS_REQUIRES_RECONCILIATION"
                            )
                            detail = str(proof.get("detail") or "native_persistence_unproven")
                            err = (
                                f"ACCEPTANCE_AMBIGUOUS_REQUIRES_RECONCILIATION: "
                                f"{status}: {detail}"
                            )
                            print(f"[NATIVE_PROOF] blocking COMPLETED: {err}", flush=True)
                            event_index += 1
                            await self._send_event(
                                ws,
                                session_id,
                                command_id,
                                lease_id,
                                WorkerEvent(
                                    "session_failed",
                                    {
                                        "error": err,
                                        "native_persistence_proof": proof,
                                        "reason": status,
                                    },
                                ),
                                event_index,
                            )
                            # Do not seal command_finished exit=0 (would mark session done).
                            terminal_exit_code = 2
                            for evidence_event in pending_terminal_evidence:
                                await self._send_evidence(
                                    ws, session_id, command_id, lease_id, task_id, evidence_event
                                )
                            if pending_terminal_event is not None:
                                # Rewrite finish as failure for backends that only watch exit_code.
                                fail_payload = dict(pending_terminal_event.payload or {})
                                fail_payload["exit_code"] = 2
                                fail_payload["native_persistence_proof"] = proof
                                fail_payload["error"] = err
                                event_index += 1
                                await self._send_event(
                                    ws,
                                    session_id,
                                    command_id,
                                    lease_id,
                                    WorkerEvent("command_finished", fail_payload),
                                    event_index,
                                )
                            break

                    prior_limit = self._agent_limit_states.pop(candidate, None)
                    if prior_limit:
                        event_index += 1
                        await self._send_event(
                            ws,
                            session_id,
                            command_id,
                            lease_id,
                            WorkerEvent(
                                "agent_limit_recovered",
                                {
                                    "agent_type": candidate,
                                    "message": f"{agent_display_name(candidate)} is available again.",
                                    "recovered_at": datetime.now(timezone.utc).isoformat(),
                                    "previous_code": prior_limit.get("code"),
                                },
                            ),
                            event_index,
                        )
                    for evidence_event in pending_terminal_evidence:
                        await self._send_evidence(
                            ws, session_id, command_id, lease_id, task_id, evidence_event
                        )
                    if pending_terminal_event is not None:
                        event_index += 1
                        await self._send_event(
                            ws,
                            session_id,
                            command_id,
                            lease_id,
                            pending_terminal_event,
                            event_index,
                        )
                    break

                joined = "\n".join(attempt_output)
                last_limit_error = joined[-2000:]
                # Model timeouts are not provider limits — do not burn another 90–180s
                # on antigravity/grok after Codex already waited.
                timed_out = (
                    "timed out" in joined.lower()
                    or "timeout waiting for response" in joined.lower()
                )
                if more_agents and looks_like_limit_failure(joined) and not timed_out:
                    await emit_limit(joined)
                    print(
                        f"[ROUTER] {candidate} exit {terminal_exit_code} looks like provider limit; "
                        "trying next agent (not sealing command yet)."
                    )
                    continue
                if looks_like_limit_failure(joined) and not timed_out:
                    await emit_limit(joined)
                if timed_out and more_agents:
                    print(
                        f"[ROUTER] {candidate} model/command timed out — not failing over "
                        f"(avoids multi-minute chain).",
                        flush=True,
                    )
                # Non-limit failure or last agent: seal with this attempt's terminal events.
                for evidence_event in pending_terminal_evidence:
                    await self._send_evidence(
                        ws, session_id, command_id, lease_id, task_id, evidence_event
                    )
                if pending_terminal_event is not None:
                    event_index += 1
                    await self._send_event(
                        ws,
                        session_id,
                        command_id,
                        lease_id,
                        pending_terminal_event,
                        event_index,
                    )
                break

            print("\n" + "=" * 60)
            result = "finished" if terminal_exit_code == 0 else f"failed with exit code {terminal_exit_code}"
            print(f"Session {session_id} {result}; Megas Backend verification is pending.")
            print("=" * 60 + "\n")
        except asyncio.CancelledError:
            err_msg = "Command execution cancelled by backend or timeout."
            print("\n" + "=" * 60)
            print(f"WARNING: Session {session_id} was cancelled by backend or timeout.")
            print("=" * 60 + "\n")
            terminal_payload = {
                "adapter": agent_type or getattr(adapter, "name", "unknown"),
                "command": agent_type or "shell",
                "workdir": "",
                "exit_code": -1,
                "duration_ms": 0,
                "output_tail": [{"stream": "stderr", "line": err_msg}],
                "git": {},
                "error": err_msg,
            }
            try:
                cancellation_evidence = WorkerEvent(
                    "evidence",
                    {
                        "evidence_type": "evidence_runtime_refresh_executed",
                        "summary": f"Runtime refresh cancelled: {err_msg}",
                        "payload": {"refresh_id": refresh_id, "runtime_id": runtime_id, "success": False, "error": err_msg},
                    },
                ) if is_refresh else WorkerEvent(
                    "evidence", {"evidence_type": "terminal_result", "summary": f"Cancelled: {err_msg}", "payload": terminal_payload}
                )
                await self._send_evidence(
                    ws,
                    session_id,
                    command_id,
                    lease_id,
                    task_id,
                    cancellation_evidence,
                )
                event_index += 1
                failure_event = WorkerEvent(
                    "refresh_completed",
                    {"refresh_id": refresh_id, "runtime_id": runtime_id, "success": False, "error": err_msg},
                ) if is_refresh else WorkerEvent("session_failed", {"error": err_msg})
                await asyncio.shield(self._send_event(
                    ws, session_id, command_id, lease_id,
                    failure_event, event_index,
                ))
            except Exception:
                pass
            raise
        except Exception as exc:
            err_msg = redact(str(exc))
            if _is_transport_error(exc):
                # A dropped control socket is transport state, not execution truth. The
                # coding agent may still be running and will persist its turn natively.
                # Marking the session failed here destroyed replies the user was waiting
                # on ("no close frame received or sent" killed live chats). Leave the
                # session non-terminal, reconnect, and let sync reconcile it.
                print(
                    f"[TRANSPORT] session {session_id} lost its control socket "
                    f"({err_msg[:160]}); not failing the run",
                    flush=True,
                )
                raise
            print("\n" + "=" * 60)
            print(f"ERROR: Session {session_id} failed: {err_msg}")
            print("=" * 60 + "\n")
            terminal_payload = {
                "adapter": agent_type or getattr(adapter, "name", "unknown"),
                "command": agent_type or "shell",
                "workdir": "",
                "exit_code": 1,
                "duration_ms": 0,
                "output_tail": [{"stream": "stderr", "line": err_msg}],
                "git": {},
                "error": err_msg,
            }
            failure_evidence = WorkerEvent(
                "evidence",
                {
                    "evidence_type": "evidence_runtime_refresh_executed",
                    "summary": f"Runtime refresh failed: {err_msg}",
                    "payload": {"refresh_id": refresh_id, "runtime_id": runtime_id, "success": False, "error": err_msg},
                },
            ) if is_refresh else WorkerEvent(
                "evidence", {"evidence_type": "terminal_result", "summary": f"Command failed: {err_msg}", "payload": terminal_payload}
            )
            await self._send_evidence(
                ws,
                session_id,
                command_id,
                lease_id,
                task_id,
                failure_evidence,
            )
            event_index += 1
            failure_event = WorkerEvent(
                "refresh_completed",
                {"refresh_id": refresh_id, "runtime_id": runtime_id, "success": False, "error": err_msg},
            ) if is_refresh else WorkerEvent("session_failed", {"error": err_msg})
            await self._send_event(
                ws, session_id, command_id, lease_id,
                failure_event, event_index,
            )
        finally:
            self.running_sessions.pop(session_id, None)
            self.active_leases.pop(session_id, None)
            if command_id:
                self._inflight_command_ids.discard(command_id)
                self._completed_command_ids[command_id] = time.time()

    def _select_adapter(self, command: dict[str, Any]) -> AgentAdapter:
        for adapter in self.adapters:
            if adapter.supports(command):
                return adapter
        raise PermissionError("No Megas Worker adapter supports this command.")

    async def _verify_agent_readiness(self, command: dict[str, Any]) -> None:
        from megas.core.agent_health import check_codex_health
        import os
        import shutil

        from .agent_router import canonicalize_agent_id as _canon_agent

        context_pack = command.get("context_pack") if isinstance(command.get("context_pack"), dict) else {}
        agent_type = str(context_pack.get("agent_type") or command.get("agent_type") or "")

        base_agent = agent_type
        for suffix in ["_w-", "_w_", "_worker_"]:
            if suffix in agent_type:
                base_agent = agent_type.split(suffix)[0]
                break
        # gemini_cli → antigravity so abandoned ids never block or double-run.
        base_agent = _canon_agent(base_agent) or base_agent

        # Builtin hands (shell/SSH/refresh) are always allowed; they are not
        # coding-agent inventory rows that can be "disabled" in agents_store.
        if base_agent.startswith("test_") or base_agent in {
            "",
            "custom_shell",
            "safe_shell_command",
            "runtime_refresh",
            "ssh_exec",
            "shell.ssh",
            "remote.ssh",
            "ssh",
        }:
            return

        agent_cfg = self.config.agents.get(base_agent, {})
        # Certified coding agents are enabled by default when installed.
        default_enabled = base_agent in CERTIFIED_AGENT_TYPES or base_agent == "codex_cli"
        if not agent_cfg.get("enabled", default_enabled):
            raise PermissionError(f"Agent '{base_agent}' is disabled in the worker configuration.")

        if base_agent == "codex_cli":
            codex_binary = os.getenv("MEGAS_CODEX_BINARY", "codex")
            health_state, health_reason, _ = await check_codex_health(codex_binary)
        else:
            if base_agent == "kilo_code":
                from .adapters.kilo import KiloCodeAdapter

                exe = KiloCodeAdapter(list(self.config.allowed_folders)).discover_executable()
                if not exe:
                    raise PermissionError("Agent 'kilo_code' is not available: executable not found.")
            elif base_agent == "grok_build":
                from .adapters.grok_build import GrokBuildAdapter

                exe = GrokBuildAdapter(list(self.config.allowed_folders)).discover_executable()
                if not exe:
                    raise PermissionError("Agent 'grok_build' is not available: executable not found.")
            else:
                binary_map = {
                    "claude_code": os.getenv("MEGAS_CLAUDE_BINARY", "claude"),
                    "aider": os.getenv("MEGAS_AIDER_BINARY", "aider"),
                    "antigravity": os.getenv(
                        "MEGAS_ANTIGRAVITY_BINARY",
                        os.getenv("MEGAS_GEMINI_BINARY", "agy"),
                    ),
                    "grok_build": os.getenv("MEGAS_GROK_BINARY", "grok"),
                    "kilo_code": os.getenv("MEGAS_KILO_BINARY", "kilocode"),
                    "opencode": os.getenv("MEGAS_OPENCODE_BINARY", "opencode"),
                    "cline": os.getenv("MEGAS_CLINE_BINARY", "cline"),
                    "devin_cli": os.getenv("MEGAS_DEVIN_BINARY", "devin"),
                    "kimi_code": os.getenv("MEGAS_KIMI_BINARY", "kimi"),
                    "glm_code": os.getenv("MEGAS_GLM_BINARY", "glm"),
                }
                binary_name = binary_map.get(base_agent, base_agent)
                if not shutil.which(binary_name):
                    raise PermissionError(f"Agent '{base_agent}' is not available: executable not found.")
            health_state = "healthy"
            health_reason = None

        if health_state != "healthy":
            raise PermissionError(f"Agent '{base_agent}' health check failed: {health_reason}")

    async def _live_ws(self, preferred=None):
        """Prefer the live control socket so mid-run reconnect can still publish events.

        Never use a brand-new socket before connect heartbeat succeeds — backend
        rejects non-heartbeat first frames with close 4400.

        When the control loop has no live socket at all (unit tests, or fully
        unbound), fall back to the caller's preferred socket immediately so
        offline unit tests do not burn 10s of sleep per publish.
        """
        if self._ws is not None and self._ws_ready:
            return self._ws
        # No control-loop socket yet — preferred is the only option (tests).
        if preferred is not None and self._ws is None:
            return preferred
        # Mid-reconnect: wait for heartbeat-ready on the new live socket.
        for _ in range(40):
            if self._ws is not None and self._ws_ready:
                return self._ws
            await asyncio.sleep(0.25)
        if preferred is not None and self._ws is None:
            return preferred
        raise RuntimeError("Megas Worker has no live backend socket for event publish.")

    async def _ws_send(self, preferred, payload: dict) -> None:
        last_exc: Exception | None = None
        for attempt in range(12):
            try:
                socket = await self._live_ws(preferred)
                await socket.send(json.dumps(payload))
                return
            except Exception as exc:
                last_exc = exc
                await asyncio.sleep(min(0.5 * (attempt + 1), 3.0))
        assert last_exc is not None
        raise last_exc

    async def _send_event(
        self,
        ws,
        session_id: str,
        command_id: str,
        lease_id: str,
        event: WorkerEvent,
        event_index: int,
    ) -> None:
        if event.event_type.startswith("refresh_"):
            await self._ws_send(
                ws,
                {
                    "type": event.event_type,
                    "refresh_id": event.payload.get("refresh_id"),
                    "runtime_id": event.payload.get("runtime_id"),
                    "payload": event.payload,
                },
            )
            return
        # Stamp agent identity so phone/cloud stream can attribute lines to the
        # connected agent without a local side-channel (all traffic is Megas cloud).
        payload = dict(event.payload) if isinstance(event.payload, dict) else {}
        if "adapter" not in payload and "agent_type" not in payload:
            try:
                # Best-effort: running session may carry agent on the command context.
                cmd = getattr(self, "_last_dispatch_agent", None)
                if cmd:
                    payload.setdefault("agent_type", str(cmd))
                    payload.setdefault("adapter", str(cmd))
            except Exception:
                pass
        stable_event_key = hashlib.sha256(
            json.dumps({"event_type": event.event_type, "payload": payload}, sort_keys=True).encode("utf-8")
        ).hexdigest()
        await self._ws_send(
            ws,
            {
                "type": "session_event",
                "session_id": session_id,
                "command_id": command_id,
                "lease_id": lease_id,
                "event_type": event.event_type,
                "payload": payload,
                "idempotency_key": f"{session_id}:{command_id}:{lease_id}:{event_index}:{stable_event_key}",
            },
        )

    async def _send_evidence(self, ws, session_id: str, command_id: str, lease_id: str, task_id: str | None, event: WorkerEvent) -> None:
        payload = event.payload
        evidence_payload = payload.get("payload") if isinstance(payload.get("payload"), dict) else {}
        if payload.get("evidence_type") == "evidence_runtime_refresh_executed":
            await self._ws_send(
                ws,
                {
                    "type": "refresh_evidence",
                    "refresh_id": evidence_payload.get("refresh_id"),
                    "evidence_type": payload.get("evidence_type"),
                    "summary": payload.get("summary") or "",
                    "payload": evidence_payload,
                },
            )
            return
        await self._ws_send(
            ws,
            {
                "type": "evidence",
                "session_id": session_id,
                "command_id": command_id,
                "lease_id": lease_id,
                "task_id": task_id,
                "evidence_type": payload.get("evidence_type") or "worker_evidence",
                "summary": payload.get("summary") or "",
                "payload": evidence_payload,
            },
        )
