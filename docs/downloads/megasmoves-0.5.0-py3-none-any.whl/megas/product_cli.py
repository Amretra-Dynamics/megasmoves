"""Installed Megas entrypoint.

Megas's primary job is to expose declared CLI/product capabilities through one
standard MCP server so any MCP-capable AI/client can use the same interface.
A capability manifest may wrap CLI commands directly or aggregate reviewed CLI
capabilities with explicitly allowlisted upstream MCP tools such as Chitraagni.
The older local MCP-management console remains a secondary surface and public
OpenAI publication checks remain optional compatibility tooling.
"""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import sys
from pathlib import Path
from typing import Any

from megas.mcp.argparse_bridge import convert_argparse_parser, load_parser_target
from megas.mcp.capability_manifest import (
    approve_capability_manifest,
    execute_capability_tool,
    serve_capability_manifest,
    validate_capability_manifest,
)
from megas.mcp.cli import main as mcp_main
from megas.mcp.cli_bridge import save_manifest
from megas.mcp.domain_verification import verify_domain_challenge
from megas.mcp.publishing import openai_plugin_readiness
from megas.mcp.secret_release import SecretReleasePolicy
from megas.mcp.store import MCPStore
from megas.mcp.submission import write_submission_pack


PRIMARY_COMMANDS = {
    "serve": "Serve a reviewed CLI or unified gateway manifest as one standard MCP stdio server",
    "validate": "Validate a CLI/gateway manifest and show the exact MCP tools it exposes",
    "exec": "Execute one reviewed capability locally through the same routing used by MCP",
    "convert": "Convert a selected argparse CLI command tree into an unreviewed CLI→MCP manifest",
    "review": "Explicitly approve a generated CLI/gateway manifest before AI execution",
}
PUBLICATION_COMMANDS = {
    "publish-check": "Inspect a registered MCP server for OpenAI Plugin submission readiness",
    "submission-pack": "Write a deterministic no-secret OpenAI submission evidence pack",
    "domain-check": "Verify the current OpenAI domain challenge endpoint without persisting its token",
}
REDACTED = "[REDACTED]"


def _emit(value: Any, machine: bool) -> None:
    if machine:
        print(json.dumps(value, indent=2, sort_keys=True, default=str))
        return
    if isinstance(value, list):
        if not value:
            print("(none)")
        for item in value:
            print(json.dumps(item, sort_keys=True, default=str) if isinstance(item, (dict, list)) else item)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                print(f"{key}: {json.dumps(item, sort_keys=True, default=str)}")
            else:
                print(f"{key}: {item}")
        return
    print(value)


def _redact_known_values(value: Any, secrets: list[str]) -> Any:
    active = [secret for secret in secrets if secret]
    if not active:
        return value
    if isinstance(value, str):
        text = value
        for secret in active:
            text = text.replace(secret, REDACTED)
        return text
    if isinstance(value, dict):
        return {
            str(key): _redact_known_values(item, active)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact_known_values(item, active) for item in value]
    if isinstance(value, tuple):
        return [_redact_known_values(item, active) for item in value]
    return value


def _normalized(argv: list[str]) -> tuple[list[str], bool]:
    # Only the leading Megas global flag is consumed here. A literal "--json"
    # later in argv may be real command/tool data and must not be silently removed.
    if argv and argv[0] == "--json":
        return argv[1:], True
    return list(argv), False


def _show_primary_help(argv: list[str]) -> bool:
    stripped, _machine = _normalized(argv)
    if stripped not in ([], ["--help"], ["-h"], ["help"]):
        return False
    print("Megas MCP — expose one reviewed capability surface to every MCP-capable AI.")
    print("\nprimary commands:")
    for command, description in PRIMARY_COMMANDS.items():
        print(f"  {command:<10} {description}")
    print("\nexamples:")
    print("  megas validate ./megas.gateway.json")
    print("  megas serve ./megas.gateway.json")
    print("  megas exec ./megas.gateway.json chitraagni_screen_create --arguments '{\"project_id\":\"...\",\"page_key\":\"home\"}'")
    print("  megas convert argparse megas.cli.main:build_parser --command megas --include-prefix monitor --output ./megas.cli.mcp.json")
    print("  megas review ./megas.cli.mcp.json --approve")
    print("\nsecondary local MCP console:")
    print("  megas mcp --help")
    return True


def _bridge_parser(command: str) -> argparse.ArgumentParser:
    if command == "serve":
        parser = argparse.ArgumentParser(
            prog="megas serve",
            description=(
                "Serve a reviewed CLI capability or unified Megas gateway manifest over MCP stdio. "
                "Only declared/allowlisted tools are exposed; arbitrary shell access is never added."
            ),
        )
        parser.add_argument("manifest")
        return parser
    if command == "validate":
        parser = argparse.ArgumentParser(prog="megas validate")
        parser.add_argument("manifest")
        return parser
    if command == "exec":
        parser = argparse.ArgumentParser(prog="megas exec")
        parser.add_argument("manifest")
        parser.add_argument("tool")
        parser.add_argument("--arguments", default="{}", metavar="JSON")
        parser.add_argument("--timeout", type=float)
        return parser
    if command == "review":
        parser = argparse.ArgumentParser(
            prog="megas review",
            description=(
                "Explicit owner approval gate. Review the manifest/tool contracts first; "
                "--approve changes review_state to reviewed and makes it eligible for execution."
            ),
        )
        parser.add_argument("manifest")
        parser.add_argument("--approve", action="store_true", required=True)
        parser.add_argument("--output")
        return parser

    parser = argparse.ArgumentParser(
        prog="megas convert argparse",
        description=(
            "Convert selected installed argparse leaf commands into a deterministic CLI→MCP manifest. "
            "Generated manifests are unreviewed. Secret-like CLI inputs are omitted and should be "
            "bound via env_refs instead of becoming AI-controlled tool inputs."
        ),
    )
    parser.add_argument("kind", choices=("argparse",))
    parser.add_argument("target", help="MODULE:FUNCTION returning argparse.ArgumentParser")
    parser.add_argument("--command", required=True, help="underlying CLI executable")
    parser.add_argument(
        "--base-arg",
        action="append",
        default=[],
        help="fixed executable argument before generated command paths; repeat as needed",
    )
    parser.add_argument(
        "--include-prefix",
        action="append",
        default=[],
        metavar="COMMAND_PATH",
        help="only convert leaves under this command prefix; repeat as needed",
    )
    parser.add_argument(
        "--exclude-prefix",
        action="append",
        default=[],
        metavar="COMMAND_PATH",
        help="exclude leaves under this command prefix even when included; repeat as needed",
    )
    parser.add_argument("--name")
    parser.add_argument("--description")
    parser.add_argument("--output", required=True)
    return parser


def _bridge_command(argv: list[str]) -> bool:
    stripped, machine = _normalized(argv)
    if not stripped or stripped[0] not in PRIMARY_COMMANDS:
        return False
    command = stripped[0]
    parser = _bridge_parser(command)
    args = parser.parse_args(stripped[1:])
    try:
        if command == "serve":
            # MCP protocol owns stdout while serving. Never emit human/status text here.
            serve_capability_manifest(args.manifest)
            return True
        if command == "validate":
            result: Any = validate_capability_manifest(args.manifest)
        elif command == "exec":
            arguments = json.loads(args.arguments)
            if not isinstance(arguments, dict):
                raise ValueError("--arguments must decode to a JSON object")
            result = execute_capability_tool(
                args.manifest,
                args.tool,
                arguments,
                timeout_seconds=args.timeout,
            )
        elif command == "review":
            if not args.approve:
                raise ValueError("review approval requires --approve")
            result = approve_capability_manifest(
                args.manifest,
                output=args.output,
            )
        else:
            argparse_parser = load_parser_target(args.target)
            conversion = convert_argparse_parser(
                argparse_parser,
                command=[args.command, *args.base_arg],
                name=args.name,
                description=args.description,
                include_prefixes=args.include_prefix,
                exclude_prefixes=args.exclude_prefix,
            )
            path = save_manifest(args.output, conversion.manifest)
            result = {
                "written": str(path),
                "review_state": conversion.manifest.review_state,
                "generated_by": conversion.manifest.generated_by,
                "tool_count": len(conversion.manifest.tools),
                "tools": [tool.name for tool in conversion.manifest.tools],
                "warnings": conversion.warnings,
            }
    except (
        FileNotFoundError,
        ImportError,
        KeyError,
        ValueError,
        RuntimeError,
        TimeoutError,
        PermissionError,
        OSError,
        json.JSONDecodeError,
    ) as exc:
        if machine:
            _emit({"error": type(exc).__name__, "message": str(exc)}, True)
        else:
            print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    _emit(result, machine)
    return True


def _publication_parser(command: str) -> argparse.ArgumentParser:
    if command == "publish-check":
        description = (
            "Deterministically inspect an MCP server for public OpenAI Plugin/ChatGPT "
            "submission readiness. This does not call an OpenAI model or submission API."
        )
    elif command == "submission-pack":
        description = (
            "Generate deterministic, credential-free evidence and manual submission templates "
            "from an OpenAI publication readiness scan."
        )
    else:
        description = (
            "Verify that the OpenAI domain-verification challenge URL returns only the "
            "exact current token. The token is read from an environment variable and is "
            "never persisted or returned."
        )

    parser = argparse.ArgumentParser(prog=f"megas mcp {command}", description=description)
    parser.add_argument("name", help="registered MCP server name or stable ID")
    parser.add_argument("--target", choices=("openai",), default="openai")

    if command == "domain-check":
        parser.add_argument(
            "--challenge-env",
            required=True,
            metavar="ENV_NAME",
            help="environment variable containing the current OpenAI challenge token",
        )
        parser.add_argument(
            "--challenge-base",
            metavar="HTTPS_ORIGIN",
            help="optional MCP host or parent HTTPS origin used for the challenge",
        )
        parser.add_argument("--timeout", type=float, default=5.0)
        return parser

    if command == "submission-pack":
        parser.add_argument("path", help="destination directory for the evidence pack")
        parser.add_argument(
            "--replace",
            action="store_true",
            help="replace an existing destination directory",
        )
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument(
        "--bearer-env",
        metavar="ENV_NAME",
        help=(
            "read a temporary bearer token from this environment variable for an "
            "authenticated live scan; the token is never persisted or returned"
        ),
    )
    parser.add_argument(
        "--no-live",
        action="store_true",
        help="check registry/transport requirements without contacting the MCP endpoint",
    )
    return parser


def _scan(
    store: MCPStore,
    *,
    name: str,
    timeout: float,
    no_live: bool,
    bearer_env: str | None,
) -> tuple[Any, dict[str, Any]]:
    configured = store.get_server(name)
    server = (
        SecretReleasePolicy(store).prepare_server(configured)
        if not no_live and configured.transport == "stdio"
        else configured
    )
    secrets_to_redact: list[str] = []
    if not no_live and configured.transport == "stdio":
        for source in server.env_refs.values():
            value = os.environ.get(source)
            if value:
                secrets_to_redact.append(value)

    bearer_token: str | None = None
    if bearer_env:
        bearer_token = os.environ.get(bearer_env)
        if not bearer_token:
            raise RuntimeError(
                f"publication bearer environment variable is not set: {bearer_env}"
            )
        secrets_to_redact.append(bearer_token)

    report = openai_plugin_readiness(
        server,
        timeout=timeout,
        live=not no_live,
        bearer_token=bearer_token,
    )
    report = _redact_known_values(report, secrets_to_redact)
    if not isinstance(report, dict):
        raise RuntimeError("publication readiness scanner returned an invalid report")
    report["live_scan_complete"] = not no_live
    if no_live:
        report["technical_ready"] = False
        blockers = list(report.get("blockers") or [])
        blockers.append(
            {
                "id": "OA-SCAN-000",
                "message": (
                    "Live MCP scan was skipped; registry/transport checks alone cannot "
                    "certify tool, UI, authentication, or OAuth publication readiness."
                ),
            }
        )
        report["blockers"] = blockers
    return configured, report


def _domain_check(store: MCPStore, args: argparse.Namespace) -> dict[str, Any]:
    if args.timeout <= 0 or args.timeout > 60:
        raise ValueError("--timeout must be between 0 and 60 seconds")
    token = os.environ.get(args.challenge_env)
    if not token:
        raise RuntimeError(
            f"domain challenge environment variable is not set: {args.challenge_env}"
        )
    server = store.get_server(args.name)
    result = verify_domain_challenge(
        server,
        token,
        challenge_base_url=args.challenge_base,
        timeout=args.timeout,
    )
    clean = _redact_known_values(result, [token])
    if not isinstance(clean, dict):
        raise RuntimeError("domain challenge verifier returned an invalid result")
    return clean


def _publication_command(argv: list[str]) -> bool:
    stripped, machine = _normalized(argv)
    if len(stripped) < 2 or stripped[0] != "mcp":
        return False
    command = stripped[1]
    if command not in PUBLICATION_COMMANDS:
        return False

    parser = _publication_parser(command)
    args = parser.parse_args(stripped[2:])
    store = MCPStore()
    try:
        if command == "domain-check":
            result: Any = _domain_check(store, args)
        else:
            if args.timeout <= 0 or args.timeout > 300:
                parser.error("--timeout must be between 0 and 300 seconds")
            if args.no_live and args.bearer_env:
                parser.error("--bearer-env cannot be used with --no-live")
            server, report = _scan(
                store,
                name=args.name,
                timeout=args.timeout,
                no_live=args.no_live,
                bearer_env=args.bearer_env,
            )
            if command == "publish-check":
                result = report
            else:
                result = write_submission_pack(
                    Path(args.path),
                    server,
                    report,
                    replace=args.replace,
                )
    except (
        FileExistsError,
        KeyError,
        ValueError,
        RuntimeError,
        TimeoutError,
        PermissionError,
        OSError,
    ) as exc:
        if machine:
            _emit({"error": type(exc).__name__, "message": str(exc)}, True)
        else:
            print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    _emit(result, machine)
    return True


def _show_mcp_help(argv: list[str]) -> bool:
    stripped, _machine = _normalized(argv)
    if stripped not in (["mcp", "--help"], ["mcp", "-h"]):
        return False

    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            mcp_main(["mcp", "--help"])
    except SystemExit as exc:
        if exc.code not in (0, None):
            raise
    text = buffer.getvalue().rstrip()
    if text:
        print(text)
    print("\noptional publication commands:")
    for command, description in PUBLICATION_COMMANDS.items():
        print(f"  {command:<16} {description}")
    return True


def main(argv: list[str] | None = None) -> None:
    actual = list(sys.argv[1:] if argv is None else argv)
    if actual and actual[0] == "--runtime-worker":
        mcp_main(actual)
        return
    if actual and actual[0] == "local":
        from megas.cli.commands.local import main as local_main
        local_main(actual[1:])
        return
    if _show_primary_help(actual):
        return
    if _bridge_command(actual):
        return
    if _show_mcp_help(actual):
        return
    if _publication_command(actual):
        return
    mcp_main(actual)


__all__ = ["main"]
