from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from .mcp.store import MCPStore
from .mcp.timeline import TimelineStore
from .mcp.timeline_maintenance import (
    DEFAULT_MAX_TERMINAL_SESSIONS,
    DEFAULT_RETENTION_DAYS,
    TimelineRetentionPolicy,
    plan_timeline_retention,
    prune_timeline,
    write_timeline_archive,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="megas timeline",
        description="Export or prune the local Megas MCP timeline without cloud access.",
    )
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    sub = parser.add_subparsers(dest="timeline_command", required=True)

    export = sub.add_parser("export", help="write a deterministic redacted timeline archive")
    export.add_argument("path")
    export.add_argument(
        "--session",
        action="append",
        default=[],
        help="export only this session ID; repeat to select multiple sessions",
    )

    plan = sub.add_parser("retention-plan", help="preview sessions selected by the retention policy")
    plan.add_argument("--days", type=int, default=DEFAULT_RETENTION_DAYS)
    plan.add_argument("--max-sessions", type=int, default=DEFAULT_MAX_TERMINAL_SESSIONS)

    prune = sub.add_parser("prune", help="delete terminal sessions selected by the retention policy")
    prune.add_argument("--days", type=int, default=DEFAULT_RETENTION_DAYS)
    prune.add_argument("--max-sessions", type=int, default=DEFAULT_MAX_TERMINAL_SESSIONS)
    prune.add_argument(
        "--yes",
        action="store_true",
        help="required to mutate timeline state; without this flag the command is a dry-run",
    )
    return parser


def _policy(args: argparse.Namespace) -> TimelineRetentionPolicy:
    return TimelineRetentionPolicy(
        max_age_days=args.days,
        max_terminal_sessions=args.max_sessions,
    )


def run(args: argparse.Namespace) -> Any:
    store = MCPStore()
    timeline = TimelineStore(store.mcp_dir)
    recovered = timeline.recover_incomplete()
    if recovered:
        store.record(
            "timeline.recovered",
            tool_call_ids=[row["id"] for row in recovered],
            count=len(recovered),
        )

    if args.timeline_command == "export":
        result = write_timeline_archive(
            timeline,
            args.path,
            session_ids=args.session or None,
        )
        store.record(
            "timeline.exported",
            path=result["path"],
            content_sha256=result["content_sha256"],
            sessions=result["sessions"],
            events=result["events"],
            tool_calls=result["tool_calls"],
        )
        return result

    if args.timeline_command == "retention-plan":
        return plan_timeline_retention(timeline, _policy(args))

    if args.timeline_command == "prune":
        result = prune_timeline(timeline, _policy(args), confirm=args.yes)
        if result.get("mutated"):
            store.record(
                "timeline.pruned",
                deleted_session_ids=result["deleted_session_ids"],
                deleted_call_ids=result["deleted_call_ids"],
                policy=result["policy"],
            )
        return result

    raise ValueError(f"unknown timeline command: {args.timeline_command}")


def _emit(value: Any, machine: bool) -> None:
    if machine:
        print(json.dumps(value, indent=2, sort_keys=True, default=str))
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                print(f"{key}: {json.dumps(item, sort_keys=True, default=str)}")
            else:
                print(f"{key}: {item}")
        return
    print(value)


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))
    try:
        _emit(run(args), args.json)
    except (FileNotFoundError, KeyError, ValueError, RuntimeError, PermissionError, OSError, json.JSONDecodeError) as exc:
        if args.json:
            _emit({"error": type(exc).__name__, "message": str(exc)}, True)
        else:
            print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


__all__ = ["build_parser", "main", "run"]
