from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any


WORKER_CONTEXT_SCHEMA = "megas.worker-context.v1"


def _context_payload(command: dict[str, Any]) -> dict[str, Any]:
    context_pack = command.get("context_pack")
    command_spec = command.get("command")
    if not isinstance(context_pack, dict):
        raise ValueError("Megas Worker dispatch context pack is invalid.")
    if not isinstance(command_spec, dict):
        raise ValueError("Megas Worker dispatch command is invalid.")
    command_args = command_spec.get("args")
    if not isinstance(command_args, list):
        raise ValueError("Megas Worker dispatch arguments are invalid.")
    session_id = str(command.get("session_id") or "")
    command_id = str(command.get("command_id") or "")
    if not session_id or not command_id:
        raise ValueError("Megas Worker dispatch identity is incomplete.")
    payload = {
        "schema_version": WORKER_CONTEXT_SCHEMA,
        "session_id": session_id,
        "command_id": command_id,
        "task_id": str(command.get("task_id") or "") or None,
        "instruction": str(command.get("instruction") or ""),
        "context_pack": context_pack,
        "workdir": str(command.get("workdir") or context_pack.get("workdir") or ""),
        "command": {
            "type": str(command.get("command_type") or "safe_shell_command"),
            "name": str(command_spec.get("name") or ""),
            "args": command_args,
        },
    }
    if "context_snapshot" in command:
        payload["context_snapshot"] = command["context_snapshot"]
    return payload


def worker_context_digest(command: dict[str, Any]) -> str:
    payload = _context_payload(command)
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def verify_worker_context(command: dict[str, Any]) -> dict[str, Any]:
    schema = str(command.get("context_schema_version") or "")
    snapshot_id = str(command.get("context_snapshot_id") or "")
    expected_digest = str(command.get("context_snapshot_digest") or "")
    try:
        snapshot_version = int(command.get("context_snapshot_version") or 0)
    except (TypeError, ValueError) as exc:
        raise ValueError("Megas Worker context snapshot version is invalid.") from exc
    if schema != WORKER_CONTEXT_SCHEMA:
        raise ValueError("Megas Worker context schema is unsupported.")
    if not snapshot_id.startswith("ctx_") or snapshot_version < 1:
        raise ValueError("Megas Worker context snapshot identity is invalid.")
    if len(expected_digest) != 64 or any(
        character not in "0123456789abcdef" for character in expected_digest
    ):
        raise ValueError("Megas Worker context snapshot digest is invalid.")

    if "context_snapshot" in command:
        actual_digest = command["context_snapshot"].get("content_digest") or ""
    else:
        actual_digest = worker_context_digest(command)
        
    if not secrets.compare_digest(expected_digest, actual_digest):
        raise ValueError("Megas Worker context snapshot digest mismatch.")
    return {
        "context_snapshot_id": snapshot_id,
        "context_snapshot_digest": expected_digest,
        "context_snapshot_version": snapshot_version,
        "context_schema_version": schema,
    }
