from __future__ import annotations

import sys
from contextlib import nullcontext
from typing import ContextManager

from .account_cli import main as account_main
from .agent_connections import main as agents_main
from .bounded_io import staged_bounded_import
from .devtool import main as dev_main
from .mcp.operator_http_runtime import main as operator_http_main
from .mcp.stdio_transport import serve_operator_stdio
from .product_cli import main as product_main
from .timeline_cli import main as timeline_main
from .workspace_cli import main as workspace_main


WORKSPACE_COMMANDS = {
    "add",
    "projects",
    "check",
    "open",
    "start",
    "stop",
    "restart",
    "status",
    "ports",
    "logs",
}


def _serve_help() -> None:
    print("usage: megas serve [gateway.json]")
    print()
    print("Without a manifest, serve the primary MegasMCP operator over stdio:")
    print("  MegasMoves local workspace + Chitraagni through the same Amretra identity")
    print()
    print("With gateway.json, serve an advanced explicit reviewed gateway instead.")
    print("For stateless Streamable HTTP use: megas serve-http --help")


def _portable_import_index(argv: list[str]) -> int | None:
    """Return the path argument index for the canonical portable import command."""

    offset = 1 if argv and argv[0] == "--json" else 0
    if len(argv) <= offset + 1 or argv[offset] != "import":
        return None
    return offset + 1


def _guarded_product_argv(argv: list[str]) -> ContextManager[list[str]]:
    """Snapshot public import input before the internal parser can read it unbounded."""

    index = _portable_import_index(argv)
    if index is None:
        return nullcontext(list(argv))

    class _Guard:
        def __init__(self) -> None:
            self._ctx = staged_bounded_import(argv[index])
            self._staged = None

        def __enter__(self) -> list[str]:
            self._staged = self._ctx.__enter__()
            guarded = list(argv)
            guarded[index] = str(self._staged)
            return guarded

        def __exit__(self, exc_type, exc, tb) -> bool:
            return bool(self._ctx.__exit__(exc_type, exc, tb))

    return _Guard()


def main(argv: list[str] | None = None) -> None:
    actual = list(sys.argv[1:] if argv is None else argv)

    if actual == ["serve"]:
        serve_operator_stdio()
        return
    if actual in (["serve", "--help"], ["serve", "-h"]):
        _serve_help()
        return

    if actual and actual[0] == "serve-http":
        operator_http_main(actual[1:])
        return

    if actual and actual[0] == "account":
        account_main(actual[1:])
        return
    if len(actual) >= 2 and actual[0] == "--json" and actual[1] == "account":
        account_main(["--json", *actual[2:]])
        return

    if actual and actual[0] == "agents":
        agents_main(actual[1:])
        return
    if len(actual) >= 2 and actual[0] == "--json" and actual[1] == "agents":
        agents_main(["--json", *actual[2:]])
        return

    if actual and actual[0] == "timeline":
        timeline_main(actual[1:])
        return
    if len(actual) >= 2 and actual[0] == "--json" and actual[1] == "timeline":
        timeline_main(["--json", *actual[2:]])
        return

    if actual and actual[0] in WORKSPACE_COMMANDS:
        workspace_main(actual)
        return
    if len(actual) >= 2 and actual[0] == "--json" and actual[1] in WORKSPACE_COMMANDS:
        workspace_main(["--json", *actual[1:]])
        return

    if actual and actual[0] == "dev":
        dev_main(actual[1:])
        return
    if len(actual) >= 2 and actual[0] == "--json" and actual[1] == "dev":
        dev_main(["--json", *actual[2:]])
        return

    if actual in ([], ["--help"], ["-h"], ["help"]):
        print("MegasMCP — local operator using the same Amretra identity across MegasMoves and Chitraagni.")
        print("\nlocal MegasMoves:")
        print("  megas add <folder>           Trust/add a local software folder")
        print("  megas projects               List added projects")
        print("  megas check <project>        Diagnose prerequisites without changing anything")
        print("  megas start <project>        Start only the selected project")
        print("  megas status <project>       Show runtime/readiness state")
        print("  megas ports [project]        Show local ports and PIDs")
        print("  megas logs <project> <svc>   Tail bounded service logs")
        print("  megas stop <project>         Stop the selected project")
        print("\nAmretra identity:")
        print("  megas account login          Sign in once through Amretra browser PKCE")
        print("  megas account status --verify")
        print("  megas account logout")
        print("  megas account chitraagni-permissions")
        print("\nagent connections:")
        print("  megas agents status")
        print("  megas agents connect codex --yes")
        print("  megas agents connect claude --yes")
        print("  megas agents connect cursor --yes")
        print("  megas agents verify")
        print("\ntimeline:")
        print("  megas timeline export <path>")
        print("  megas timeline retention-plan")
        print("  megas timeline prune --yes")
        print("\nMCP:")
        print("  megas serve                  Serve MegasMCP over stdio")
        print("  megas serve-http             Serve MegasMCP over loopback HTTP")
        print("  megas serve <gateway.json>   Advanced explicit reviewed gateway")
        print("\nadvanced compatibility:")
        print("  megas validate/exec/convert/review ...")
        print("  megas dev --help")
        return

    with _guarded_product_argv(actual) as guarded:
        product_main(guarded)


__all__ = ["main"]
