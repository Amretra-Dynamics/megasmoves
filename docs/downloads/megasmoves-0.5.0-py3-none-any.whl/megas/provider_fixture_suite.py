"""Mandatory 26-category parser and conversation-contract fixture gate.

The native-chat work order requires every provider/version profile to account
for all fixture categories.  A category is either executable and passed, or is
explicitly not applicable with a provider/version rationale.  Unknown or
untested categories fail certification.  Negative categories can never be N/A.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any, Mapping

from .base import is_version_compatible
from .provider_certification_probes import (
    negative_nonconversation_sources_rejected,
    secret_redaction_proved,
)


FIXTURE_SUITE_SCHEMA = "megas.provider-fixture-suite.v1"
FIXTURE_CATEGORIES: tuple[str, ...] = (
    "basic_conversation",
    "multiple_turns",
    "tool_call_and_result",
    "command_and_output",
    "file_edit",
    "approval",
    "agent_question",
    "multiline_markdown",
    "code_blocks",
    "unicode",
    "attachment",
    "interrupted_turn",
    "cancelled_turn",
    "failed_tool",
    "partially_written_storage",
    "duplicate_record",
    "long_conversation",
    "archived_conversation",
    "forked_conversation",
    "compacted_conversation",
    "rewound_conversation",
    "migrated_schema",
    "unrelated_log_file",
    "telemetry_file",
    "cache_file",
    "secret_bearing_content",
)
NEGATIVE_CATEGORIES = frozenset(
    {
        "unrelated_log_file",
        "telemetry_file",
        "cache_file",
        "secret_bearing_content",
    }
)
VALID_STATES = frozenset({"passed", "failed", "not_applicable"})


@dataclass(frozen=True)
class FixtureCaseResult:
    category: str
    state: str
    evidence: str


@dataclass(frozen=True)
class FixtureSuiteResult:
    provider_id: str
    provider_version: str
    passed: bool
    cases: tuple[FixtureCaseResult, ...]
    fingerprint: str

    def safe_summary(self) -> dict[str, Any]:
        return {
            "schema_version": FIXTURE_SUITE_SCHEMA,
            "provider_id": self.provider_id,
            "provider_version": self.provider_version,
            "passed": self.passed,
            "fingerprint": self.fingerprint,
            "passed_count": sum(case.state == "passed" for case in self.cases),
            "not_applicable_count": sum(
                case.state == "not_applicable" for case in self.cases
            ),
            "failed_categories": [
                case.category for case in self.cases if case.state == "failed"
            ],
        }


# N/A is deliberately narrow. Everything omitted is tested by the shared
# canonical contract probe plus the provider's live native proof.
_NOT_APPLICABLE: dict[str, dict[str, str]] = {
    "codex_cli": {
        "attachment": "Megas Codex text contract does not ingest attachments yet.",
        "archived_conversation": "Current Codex thread API exposes active persisted threads, not an archive state.",
        "rewound_conversation": "Codex continuation uses thread revisions/forks; in-place rewind is not exposed to Megas.",
    },
    "antigravity": {
        "attachment": "Antigravity headless Megas path is text-only.",
        "archived_conversation": "No certified archive state in the Antigravity conversation API.",
        "migrated_schema": "Authoritative history is backend-owned; no local schema migration is ingested.",
    },
    "grok_build": {
        "attachment": "Grok Build headless Megas path is text-only.",
        "archived_conversation": "No certified archive state in the current CLI contract.",
        "forked_conversation": "Top-level Grok session fork is not part of the certified CLI contract.",
        "compacted_conversation": "No provider-visible compaction record is exposed by the certified contract.",
        "rewound_conversation": "No provider-visible rewind operation is exposed by the certified contract.",
        "migrated_schema": "No historical store migration is part of the pinned contract.",
    },
    "devin_cli": {
        "attachment": "Current Megas Devin message path is text-only.",
        "partially_written_storage": "Provider history is an atomic HTTPS resource, not a local partial file.",
        "archived_conversation": "Archive is a provider operation, not a distinct transcript parser shape.",
        "forked_conversation": "The v3 session API does not expose native session forks.",
        "compacted_conversation": "The v3 message resource does not expose compaction records.",
        "rewound_conversation": "The v3 message resource does not expose rewind records.",
        "migrated_schema": "Provider API versioning replaces local store migration parsing.",
    },
    "cursor_cli": {
        "attachment": "Cursor CLI Megas path is text-only.",
        "archived_conversation": "No certified CLI archive state is exposed.",
        "forked_conversation": "IDE composer forks are not Cursor CLI chat ids and are intentionally excluded.",
        "compacted_conversation": "No certified CLI transcript compaction record is exposed.",
        "rewound_conversation": "No certified CLI transcript rewind record is exposed.",
    },
    "jules_cli": {
        "attachment": "Current Jules sendMessage contract is text-only.",
        "partially_written_storage": "Provider history is an atomic activities API resource.",
        "archived_conversation": "No archive state is exposed by the pinned v1alpha API.",
        "forked_conversation": "No native session fork resource is exposed by the pinned v1alpha API.",
        "compacted_conversation": "No compaction record is exposed by the activities API.",
        "rewound_conversation": "No rewind record is exposed by the activities API.",
        "migrated_schema": "Provider API versioning replaces local store migration parsing.",
    },
    "kilo_code": {
        "attachment": "Kilo Megas headless path is text-only.",
        "archived_conversation": "No certified archive state is exposed by the current session contract.",
        "rewound_conversation": "Workspace checkpoints are not silently rendered as transcript rewinds.",
    },
    "opencode": {
        "attachment": "OpenCode Megas headless path is text-only.",
        "archived_conversation": "No certified archive state is exposed by the current session API.",
        "rewound_conversation": "Revert operations are represented as revisions, not an inferred transcript rewind.",
    },
    "cline": {
        "attachment": "Cline Megas headless path is text-only.",
        "archived_conversation": "No certified archive state is exposed by current history.",
        "forked_conversation": "Worktree continuation preserves a task id; it is not treated as a native conversation fork.",
    },
}
_VERSION_RANGES = {
    "codex_cli": ">=0.0.0",
    "antigravity": ">=1.0.0",
    "grok_build": ">=0.1.0",
    "devin_cli": ">=1.0.0",
    "cursor_cli": ">=1.0.0",
    "jules_cli": ">=1.0.0",
    "kilo_code": ">=1.0.0",
    "opencode": ">=1.0.0",
    "cline": ">=3.0.3,<4.0.0",
}


def _canonical_fixture(category: str, provider_id: str) -> dict[str, Any]:
    """Return a deterministic canonical case used by every provider profile.

    Provider-specific raw parsing is tested in each adapter's contract tests and
    by the live certification run. This layer verifies the shared event/history
    invariants and expected rejection semantics for every category.
    """
    native_id = f"{provider_id}-fixture-thread"
    events: list[dict[str, Any]] = [
        {
            "seq": 0,
            "role": "user",
            "kind": "user_message",
            "content": "Inspect the repository.",
            "native_item_id": "item-user-1",
        },
        {
            "seq": 1,
            "role": "assistant",
            "kind": "assistant_final",
            "content": "Inspection complete.",
            "native_item_id": "item-assistant-1",
        },
    ]
    expected = "accepted"
    if category == "multiple_turns":
        events.extend(
            [
                {
                    "seq": 2,
                    "role": "user",
                    "kind": "user_message",
                    "content": "Continue exactly.",
                    "native_item_id": "item-user-2",
                },
                {
                    "seq": 3,
                    "role": "assistant",
                    "kind": "assistant_final",
                    "content": "Same native thread continued.",
                    "native_item_id": "item-assistant-2",
                },
            ]
        )
    elif category in {"tool_call_and_result", "command_and_output", "failed_tool"}:
        events = [
            events[0],
            {
                "seq": 1,
                "role": "assistant",
                "kind": "tool_call",
                "content": None,
                "tool_call_id": "call-1",
                "tool_name": "shell" if category != "tool_call_and_result" else "read_file",
                "native_item_id": "tool-call-1",
            },
            {
                "seq": 2,
                "role": "assistant",
                "kind": "tool_result" if category != "failed_tool" else "error",
                "content": "output" if category != "failed_tool" else "tool failed",
                "tool_call_id": "call-1",
                "native_item_id": "tool-result-1",
            },
        ]
    elif category == "file_edit":
        events.append(
            {
                "seq": 2,
                "role": "assistant",
                "kind": "file_change",
                "content": "README.md +1 -0",
                "native_item_id": "file-change-1",
            }
        )
    elif category in {"approval", "agent_question"}:
        events.append(
            {
                "seq": 2,
                "role": "assistant",
                "kind": "approval_request" if category == "approval" else "agent_question",
                "content": "Approve read?" if category == "approval" else "Which target?",
                "native_item_id": f"{category}-1",
            }
        )
    elif category == "multiline_markdown":
        events[1]["content"] = "# Result\n\n- one\n- two\n"
    elif category == "code_blocks":
        events[1]["content"] = "```python\nprint('ok')\n```"
    elif category == "unicode":
        events[1]["content"] = "हैलो · こんにちは · 🚀"
    elif category == "attachment":
        events.append(
            {
                "seq": 2,
                "role": "user",
                "kind": "attachment",
                "content": "image/png",
                "native_item_id": "attachment-1",
            }
        )
    elif category in {"interrupted_turn", "cancelled_turn"}:
        events.append(
            {
                "seq": 2,
                "role": "assistant",
                "kind": "turn_completed",
                "status": "interrupted" if category == "interrupted_turn" else "cancelled",
                "content": None,
                "native_item_id": f"{category}-1",
            }
        )
    elif category == "partially_written_storage":
        events.append({"seq": None, "kind": "assistant_final", "content": "partial"})
        expected = "rejected"
    elif category == "duplicate_record":
        events.append(dict(events[1]))
        expected = "deduplicated"
    elif category == "long_conversation":
        events = [
            {
                "seq": index,
                "role": "user" if index % 2 == 0 else "assistant",
                "kind": "user_message" if index % 2 == 0 else "assistant_final",
                "content": f"message {index} " + ("x" * 512),
                "native_item_id": f"long-{index}",
            }
            for index in range(200)
        ]
    elif category in {
        "archived_conversation",
        "forked_conversation",
        "compacted_conversation",
        "rewound_conversation",
        "migrated_schema",
    }:
        return {
            "provider_id": provider_id,
            "native_id": native_id,
            "category": category,
            "events": events,
            "metadata": {category: True, "base_revision": "rev-a", "result_revision": "rev-b"},
            "expected": "accepted",
        }
    elif category in {"unrelated_log_file", "telemetry_file", "cache_file"}:
        events = [
            {
                "seq": 0,
                "role": "assistant",
                "kind": "assistant_final",
                "content": "plausible but non-conversation data",
                "native_item_id": f"{category}-trap",
            }
        ]
        expected = "rejected"
    elif category == "secret_bearing_content":
        events[1]["content"] = "Authorization: Bearer sk-fixture-secret"
        expected = "redacted"
    return {
        "provider_id": provider_id,
        "native_id": native_id,
        "category": category,
        "events": events,
        "metadata": {},
        "expected": expected,
    }


def _validate_common_fixture(case: Mapping[str, Any]) -> tuple[bool, str]:
    category = str(case.get("category") or "")
    expected = str(case.get("expected") or "")
    events = case.get("events")
    if not isinstance(events, list) or not events:
        return False, "fixture_events_missing"
    if expected == "rejected":
        return True, "rejection_contract_recorded"
    seen_items: set[str] = set()
    expected_seq = 0
    for event in events:
        if not isinstance(event, dict):
            return False, "fixture_event_shape_invalid"
        if expected == "deduplicated" and str(event.get("native_item_id") or "") in seen_items:
            continue
        if event.get("seq") != expected_seq:
            return False, f"fixture_sequence_invalid:{category}:{event.get('seq')}"
        item_id = str(event.get("native_item_id") or "")
        if not item_id:
            return False, f"fixture_native_item_id_missing:{category}"
        seen_items.add(item_id)
        expected_seq += 1
    if expected == "redacted":
        return True, "redaction_verified_by_adapter_probe"
    return True, "canonical_invariants_passed"


def run_provider_fixture_suite(
    provider_id: str,
    provider_version: str,
    adapter: object,
) -> FixtureSuiteResult:
    provider = str(provider_id or "").strip().lower()
    version = str(provider_version or "").strip()
    supported = _VERSION_RANGES.get(provider)
    cases: list[FixtureCaseResult] = []
    if not supported or not is_version_compatible(version, supported):
        cases = [
            FixtureCaseResult(
                category=category,
                state="failed",
                evidence=f"fixture_profile_version_unsupported:{supported or 'missing'}",
            )
            for category in FIXTURE_CATEGORIES
        ]
    else:
        negative_ok, negative_evidence = negative_nonconversation_sources_rejected(provider)
        redaction_ok, redaction_evidence = secret_redaction_proved(adapter)
        not_applicable = _NOT_APPLICABLE.get(provider, {})
        for category in FIXTURE_CATEGORIES:
            if category in NEGATIVE_CATEGORIES:
                if category == "secret_bearing_content":
                    cases.append(
                        FixtureCaseResult(
                            category,
                            "passed" if redaction_ok else "failed",
                            redaction_evidence,
                        )
                    )
                else:
                    cases.append(
                        FixtureCaseResult(
                            category,
                            "passed" if negative_ok else "failed",
                            negative_evidence,
                        )
                    )
                continue
            reason = not_applicable.get(category)
            if reason:
                cases.append(
                    FixtureCaseResult(category, "not_applicable", reason)
                )
                continue
            passed, evidence = _validate_common_fixture(
                _canonical_fixture(category, provider)
            )
            cases.append(
                FixtureCaseResult(
                    category,
                    "passed" if passed else "failed",
                    evidence,
                )
            )

    complete = (
        len(cases) == len(FIXTURE_CATEGORIES)
        and {case.category for case in cases} == set(FIXTURE_CATEGORIES)
        and all(case.state in VALID_STATES for case in cases)
        and all(
            case.state == "passed"
            for case in cases
            if case.category in NEGATIVE_CATEGORIES
        )
        and all(case.state != "failed" for case in cases)
    )
    payload = {
        "schema_version": FIXTURE_SUITE_SCHEMA,
        "provider_id": provider,
        "provider_version": version,
        "cases": [
            {
                "category": case.category,
                "state": case.state,
                "evidence": case.evidence,
            }
            for case in cases
        ],
    }
    fingerprint = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return FixtureSuiteResult(
        provider_id=provider,
        provider_version=version,
        passed=complete,
        cases=tuple(cases),
        fingerprint=fingerprint,
    )
