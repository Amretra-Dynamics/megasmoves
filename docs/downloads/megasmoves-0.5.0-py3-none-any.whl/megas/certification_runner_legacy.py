"""Live provider certification runner.

This is the only path that may issue an installation certificate.  It executes
real provider turns in an isolated workspace, re-reads the provider's own
history, proves exact resume and negative behavior, and writes an atomic local
certificate.  Failures produce an incomplete certificate for diagnostics but
never enable dispatch.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import time
from typing import Any, Iterable

from .adapter_certification import (
    CHECK_FAILED,
    CHECK_NOT_RUN,
    CHECK_PASSED,
    CORE_REQUIRED_CHECKS,
    adapter_authentication_identity,
    build_certificate,
    evaluate_certificate,
    installation_identity,
    write_certificate,
)
from .adapters.base import subprocess_hide_window_kwargs
from .provider_certification_probes import (
    install_strict_readers,
    negative_nonconversation_sources_rejected,
    secret_redaction_proved,
)
from .runtime_manifest import _agent_adapter_classes, _auth_mode
from . import certified_thread_sync as history


@dataclass(frozen=True)
class RunEvidence:
    succeeded: bool
    native_id: str | None
    events: tuple[dict[str, Any], ...]
    event_types: tuple[str, ...]
    fatal_error: str | None


@dataclass(frozen=True)
class CertificationRunResult:
    provider_id: str
    certified: bool
    certificate_path: str
    status: str
    reason: str
    checks: dict[str, str]
    verified_capabilities: tuple[str, ...]
    evidence: dict[str, Any]


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _marker(label: str) -> str:
    return f"MEGAS_CERT_{label}_{secrets.token_hex(16)}"


def _provider_bogus_id(provider_id: str) -> str:
    token = secrets.token_hex(12)
    if provider_id in {"codex_cli", "antigravity"}:
        return "00000000-0000-4000-8000-" + token[:12]
    if provider_id == "devin_cli":
        return f"devin-megas-bogus-{token}"
    if provider_id == "jules_cli":
        return f"sessions/megas-bogus-{token}"
    if provider_id in {"opencode", "kilo_code"}:
        return f"ses_megas_bogus_{token}"
    if provider_id == "cline":
        return f"session_megas_bogus_{token}"
    return f"megas-bogus-{token}"


def _event_payload(event: object) -> dict[str, Any]:
    payload = getattr(event, "payload", None)
    return dict(payload) if isinstance(payload, dict) else {}


def _event_type(event: object) -> str:
    return str(getattr(event, "event_type", "") or "")


def _announced_native_ids(events: Iterable[object]) -> set[str]:
    ids: set[str] = set()
    for event in events:
        event_type = _event_type(event)
        payload = _event_payload(event)
        # Diagnostic/error events may carry the ID that was requested, but a
        # provider did not verify. Only successful lifecycle events may prove
        # that a native conversation identity was actually selected.
        if event_type == "agent_error":
            continue
        if event_type == "command_finished":
            try:
                if int(payload.get("exit_code") or 0) != 0:
                    continue
            except (TypeError, ValueError):
                continue
        value = str(
            payload.get("provider_session_id")
            or payload.get("native_id")
            or payload.get("thread_id")
            or ""
        ).strip()
        if value:
            ids.add(value)
    return ids


def _run_succeeded(events: Iterable[object]) -> tuple[bool, str | None]:
    finished = False
    exit_code: int | None = None
    fatal_error: str | None = None
    for event in events:
        event_type = _event_type(event)
        payload = _event_payload(event)
        if event_type == "command_finished":
            finished = True
            try:
                exit_code = int(payload.get("exit_code") or 0)
            except (TypeError, ValueError):
                exit_code = 1
        if event_type == "agent_error" and bool(payload.get("fatal", True)):
            fatal_error = str(payload.get("message") or payload.get("error_code") or "agent_error")[:500]
    return bool(finished and exit_code == 0 and fatal_error is None), fatal_error


async def _execute_adapter(
    adapter: object,
    *,
    provider_id: str,
    workspace: Path,
    instruction: str,
    native_id: str = "",
    timeout_seconds: float,
) -> RunEvidence:
    context: dict[str, Any] = {
        "agent_type": provider_id,
        "provider_session_id": native_id,
        "native_thread_id": native_id,
        "resume_existing": bool(native_id),
        "chat_mode": "agent_chat",
        "source": "megas_runtime_certification",
        "write_mode": False,
        "title": "Megas adapter certification",
        "require_plan_approval": False,
    }
    if provider_id == "jules_cli":
        source = os.getenv("JULES_CERT_SOURCE", "").strip()
        branch = os.getenv("JULES_CERT_STARTING_BRANCH", "").strip()
        if source:
            context["jules_source"] = source
        if branch:
            context["starting_branch"] = branch
    if provider_id == "devin_cli":
        repos = [
            item.strip()
            for item in os.getenv("DEVIN_CERT_REPOS", "").split(",")
            if item.strip()
        ]
        if repos:
            context["devin_repos"] = repos
        context["max_acu_limit"] = 1

    command = {
        "session_id": "cert_" + secrets.token_hex(12),
        "command_id": "certcmd_" + secrets.token_hex(12),
        "instruction": instruction,
        "workdir": str(workspace),
        "timeout_sec": timeout_seconds,
        "context_pack": context,
    }
    events: list[object] = []

    async def consume() -> None:
        launch = getattr(adapter, "launch", None)
        if not callable(launch):
            raise RuntimeError("adapter_launch_missing")
        async for event in launch(command):
            events.append(event)

    fatal: str | None = None
    try:
        await asyncio.wait_for(consume(), timeout=timeout_seconds + 30.0)
    except Exception as exc:
        fatal = f"{type(exc).__name__}:{str(exc)[:300]}"
    succeeded, event_error = _run_succeeded(events)
    ids = _announced_native_ids(events)
    native = next(iter(ids)) if len(ids) == 1 else None
    safe_events = tuple(
        {
            "type": _event_type(event),
            "provider_session_id": str(
                _event_payload(event).get("provider_session_id")
                or _event_payload(event).get("native_id")
                or _event_payload(event).get("thread_id")
                or ""
            )[:300],
            "exit_code": _event_payload(event).get("exit_code"),
            "acceptance_ambiguous": bool(
                _event_payload(event).get("acceptance_ambiguous")
            ),
        }
        for event in events[-200:]
    )
    return RunEvidence(
        succeeded=succeeded and fatal is None,
        native_id=native,
        events=safe_events,
        event_types=tuple(_event_type(event) for event in events),
        fatal_error=fatal or event_error,
    )


def _raw_reader(provider_id: str):
    install_strict_readers()
    return history._READERS.get(provider_id)


def _raw_index_ids(provider_id: str, *, limit: int = 5_000) -> set[str]:
    reader = _raw_reader(provider_id)
    if reader is None:
        return set()
    try:
        rows = reader.index(limit)
    except Exception:
        return set()
    return {
        str(row.get("native_id") or "").strip()
        for row in rows or []
        if isinstance(row, dict) and str(row.get("native_id") or "").strip()
    }


def _thread_texts(thread: dict[str, Any] | None) -> list[str]:
    if not isinstance(thread, dict):
        return []
    values: list[str] = []
    for message in thread.get("messages") or []:
        if not isinstance(message, dict):
            continue
        for key in ("content", "text", "tool_input", "tool_output", "error_message"):
            value = message.get(key)
            if isinstance(value, str) and value:
                values.append(value)
    return values


def _marker_count(thread: dict[str, Any] | None, marker: str) -> int:
    return sum(text.count(marker) for text in _thread_texts(thread))


def _raw_read(provider_id: str, native_id: str) -> dict[str, Any] | None:
    reader = _raw_reader(provider_id)
    if reader is None:
        return None
    try:
        thread = reader.read(native_id)
    except Exception:
        return None
    if not thread:
        return None
    if str(thread.get("native_id") or "") != native_id:
        return None
    if str(thread.get("agent_type") or "") != provider_id:
        return None
    return thread


def _wait_for_persistence(
    provider_id: str,
    native_id: str,
    marker: str,
    *,
    timeout_seconds: float = 30.0,
) -> dict[str, Any] | None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        thread = _raw_read(provider_id, native_id)
        if thread and _marker_count(thread, marker) >= 1:
            return thread
        time.sleep(0.5)
    return _raw_read(provider_id, native_id)


def _prepare_workspace(root: Path) -> Path:
    workspace = root / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / "README.md").write_text(
        "# Megas adapter certification\n\nThis disposable repository contains no user data.\n",
        encoding="utf-8",
    )
    git = shutil.which("git")
    if git:
        subprocess.run(
            [git, "init", "-q"],
            cwd=str(workspace),
            capture_output=True,
            timeout=15,
            check=False,
            **subprocess_hide_window_kwargs(),
        )
    return workspace


def _bind_certification_workspace(adapter: object, workspace: Path) -> None:
    """Limit one live certification run to its Megas-owned repository."""

    resolved = str(workspace.resolve())
    try:
        setattr(adapter, "allowed_folders", [resolved])
    except Exception as exc:
        raise RuntimeError("adapter_certification_workspace_binding_failed") from exc


async def _run_live_certification(
    provider_id: str,
    adapter: object,
    workspace: Path,
    *,
    timeout_seconds: float,
) -> tuple[dict[str, str], dict[str, Any], set[str]]:
    checks = {name: CHECK_NOT_RUN for name in CORE_REQUIRED_CHECKS}
    evidence: dict[str, Any] = {"provider_id": provider_id}
    capabilities: set[str] = set()

    checks["binary_identity"] = CHECK_PASSED
    checks["provider_version"] = CHECK_PASSED
    checks["authentication"] = CHECK_PASSED

    negative_ok, negative_reason = negative_nonconversation_sources_rejected(
        provider_id
    )
    checks["negative_nonconversation_sources_rejected"] = (
        CHECK_PASSED if negative_ok else CHECK_FAILED
    )
    evidence["negative_probe"] = negative_reason

    redaction_ok, redaction_reason = secret_redaction_proved(adapter)
    checks["secret_redaction"] = CHECK_PASSED if redaction_ok else CHECK_FAILED
    evidence["redaction_probe"] = redaction_reason

    before_ids = _raw_index_ids(provider_id)
    marker_one = _marker("NEW")
    first = await _execute_adapter(
        adapter,
        provider_id=provider_id,
        workspace=workspace,
        instruction=(
            "Reply with this exact certification marker and nothing sensitive: "
            + marker_one
        ),
        timeout_seconds=timeout_seconds,
    )
    evidence["first_run"] = {
        "succeeded": first.succeeded,
        "native_id_hash": _hash(first.native_id) if first.native_id else None,
        "event_types": sorted(set(first.event_types)),
        "fatal_error": first.fatal_error,
    }
    checks["realtime_stream"] = (
        CHECK_PASSED
        if first.succeeded
        and any(
            event_type
            not in {"command_started", "command_finished", "agent_thread_started"}
            for event_type in first.event_types
        )
        else CHECK_FAILED
    )
    if not first.succeeded or not first.native_id:
        checks["new_thread"] = CHECK_FAILED
        return checks, evidence, capabilities

    native_id = first.native_id
    checks["new_thread"] = CHECK_PASSED
    after_new_ids = _raw_index_ids(provider_id)
    checks["thread_list"] = (
        CHECK_PASSED if native_id in after_new_ids else CHECK_FAILED
    )
    first_thread = _wait_for_persistence(provider_id, native_id, marker_one)
    checks["thread_read"] = CHECK_PASSED if first_thread else CHECK_FAILED
    checks["native_persistence"] = (
        CHECK_PASSED if _marker_count(first_thread, marker_one) == 1 else CHECK_FAILED
    )
    created_ids = after_new_ids - before_ids
    checks["no_sibling_thread_created"] = (
        CHECK_PASSED if created_ids == {native_id} else CHECK_FAILED
    )

    marker_two = _marker("RESUME")
    second = await _execute_adapter(
        adapter,
        provider_id=provider_id,
        workspace=workspace,
        instruction=(
            "Continue the same native chat and reply with this exact marker once: "
            + marker_two
        ),
        native_id=native_id,
        timeout_seconds=timeout_seconds,
    )
    evidence["resume_run"] = {
        "succeeded": second.succeeded,
        "announced_id_matches": second.native_id == native_id,
        "event_types": sorted(set(second.event_types)),
        "fatal_error": second.fatal_error,
    }
    checks["exact_resume_same_native_id"] = (
        CHECK_PASSED
        if second.succeeded and second.native_id == native_id
        else CHECK_FAILED
    )
    after_resume_ids = _raw_index_ids(provider_id)
    if after_resume_ids - after_new_ids:
        checks["no_sibling_thread_created"] = CHECK_FAILED
    reconciled = _wait_for_persistence(provider_id, native_id, marker_two)
    checks["post_turn_reconciliation"] = (
        CHECK_PASSED
        if reconciled and _marker_count(reconciled, marker_two) >= 1
        else CHECK_FAILED
    )
    checks["no_duplicate_turn"] = (
        CHECK_PASSED if _marker_count(reconciled, marker_two) == 1 else CHECK_FAILED
    )

    bogus_id = _provider_bogus_id(provider_id)
    bogus_marker = _marker("BOGUS")
    before_bogus_ids = set(after_resume_ids)
    bogus = await _execute_adapter(
        adapter,
        provider_id=provider_id,
        workspace=workspace,
        instruction="This bogus-id probe must not create a chat: " + bogus_marker,
        native_id=bogus_id,
        timeout_seconds=min(timeout_seconds, 120.0),
    )
    after_bogus_ids = _raw_index_ids(provider_id)
    bogus_rejected = (
        not bogus.succeeded
        and bogus.native_id != bogus_id
        and not (after_bogus_ids - before_bogus_ids)
    )
    checks["bogus_native_id_rejected"] = (
        CHECK_PASSED if bogus_rejected else CHECK_FAILED
    )
    evidence["bogus_probe"] = {
        "succeeded": bogus.succeeded,
        "created_thread_count": len(after_bogus_ids - before_bogus_ids),
        "fatal_error": bogus.fatal_error,
    }

    if all(checks.get(name) == CHECK_PASSED for name in CORE_REQUIRED_CHECKS):
        capabilities.update(
            {
                "new_thread",
                "thread_list",
                "thread_read",
                "exact_resume",
                "realtime_stream",
                "native_persistence",
                "reconciliation",
                "offline_replica",
            }
        )
        try:
            adapter_caps = set(getattr(adapter, "capabilities")() or [])
        except Exception:
            adapter_caps = set()
        if "provider_cancellation" in adapter_caps or "cancellation" in adapter_caps:
            capabilities.add("cancellation")
        if "limit_state" in adapter_caps:
            capabilities.add("limit_state")
    return checks, evidence, capabilities


def certify_agent_installation(
    provider_id: str,
    *,
    timeout_seconds: float = 300.0,
    expires_days: int = 30,
) -> CertificationRunResult:
    provider = str(provider_id or "").strip().lower()
    classes = _agent_adapter_classes()
    adapter_class = classes.get(provider)
    if adapter_class is None:
        raise ValueError(f"No executable adapter is registered for {provider}")
    adapter = adapter_class([])
    executable = adapter.discover_executable()
    if executable is None:
        raise FileNotFoundError(f"{provider} executable was not found")
    version = adapter.detect_version()
    if not version:
        raise RuntimeError(f"{provider} version could not be verified")
    health = str(adapter.health_status())
    if health != "available":
        raise RuntimeError(f"{provider} is not ready for certification: {health}")
    auth_mode = _auth_mode(provider, adapter)
    if auth_mode == "unauthenticated":
        raise PermissionError(f"{provider} authentication is required")

    identity = installation_identity(
        provider_id=provider,
        executable=Path(executable),
        provider_version=str(version),
        adapter_contract_version=str(getattr(adapter, "contract_version", "unknown")),
        auth_mode=auth_mode,
        execution_mode="inspect",
        authentication_identity=adapter_authentication_identity(adapter),
    )
    root = Path(tempfile.mkdtemp(prefix=f"megas-cert-{provider}-"))
    try:
        workspace = _prepare_workspace(root)
        _bind_certification_workspace(adapter, workspace)
        checks, evidence, capabilities = asyncio.run(
            _run_live_certification(
                provider,
                adapter,
                workspace,
                timeout_seconds=min(max(float(timeout_seconds), 30.0), 1800.0),
            )
        )
    finally:
        shutil.rmtree(root, ignore_errors=True)

    issued = datetime.now(timezone.utc)
    certificate = build_certificate(
        identity=identity,
        checks=checks,
        verified_capabilities=capabilities,
        evidence={
            **evidence,
            "provider_version": str(version),
            "adapter_contract_version": str(getattr(adapter, "contract_version", "unknown")),
            "evidence_format": "privacy_safe_hashes_and_counts_only",
        },
        issued_at=issued,
        expires_at=issued + timedelta(days=min(max(int(expires_days), 1), 90)),
    )
    path = write_certificate(certificate)
    decision = evaluate_certificate(identity=identity, certificate=certificate)
    return CertificationRunResult(
        provider_id=provider,
        certified=decision.certified,
        certificate_path=str(path),
        status=decision.status,
        reason=decision.reason,
        checks=dict(certificate.get("checks") or {}),
        verified_capabilities=decision.verified_capabilities,
        evidence=dict(certificate.get("evidence") or {}),
    )
