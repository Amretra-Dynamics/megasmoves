"""The pip command is a launcher for the installed Windows product, not another operator."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys


def main(argv: list[str] | None = None) -> None:
    if os.name != "nt":
        from .installed_entrypoint import main as source_main
        source_main(argv)
        return
    from .updater import product_install_binary
    product = product_install_binary()
    if product is None:
        from .package_install import install_windows_product
        try:
            product = install_windows_product()
        except (RuntimeError, OSError, ValueError, subprocess.SubprocessError) as exc:
            raise SystemExit(f"MegasMoves app installation could not complete: {exc}") from exc
    try:
        manifest = json.loads(product.with_suffix(".release.json").read_text(encoding="utf-8"))
        with product.open("rb") as stream:
            valid = stream.read(2) == b"MZ"
        if not valid or manifest.get("native_ui") != "WinUI 3" or manifest.get("embedded_megas_mcp") is not True:
            raise ValueError("not a native embedded-MCP product")
    except (OSError, ValueError, TypeError) as exc:
        raise SystemExit("MegasMoves installation metadata is invalid; repair the installed app.") from exc
    actual = list(sys.argv[1:] if argv is None else argv)
    # Human CLI arguments are interpreted by the consumer's narrow launcher.
    # Never resolve a binary from PATH or launch the source Python operator.
    # WinExe children need STARTF_USESTDHANDLES explicitly; inheriting a pip
    # console launcher's defaults silently loses stdout and MCP pipe handles.
    result = subprocess.run([str(product), *actual], shell=False, check=False,
                            stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    raise SystemExit(result.returncode)
