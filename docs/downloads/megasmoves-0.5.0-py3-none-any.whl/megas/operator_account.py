from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .amretra_chitraagni_auth import OAuthCredentialBundle, current_access_token, interactive_login
from .chitraagni_http import CHITRAAGNI_IDENTITY_PATH, request_json
from .credential_store import (
    LinuxSecretServiceCredentialStore,
    MacOSKeychainCredentialStore,
    WindowsDPAPICredentialStore,
)


ACCOUNT_FORMAT = "megas-operator-account"
ACCOUNT_VERSION = 3
DEFAULT_CHITRAAGNI_API_BASE = "http://127.0.0.1:8000/api/v1"
DEFAULT_CHITRAAGNI_TOKEN_ENV = "CHITRAAGNI_TOKEN"  # legacy/test-only compatibility
MAX_ACCOUNT_BYTES = 512 * 1024
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
SECURE_CREDENTIAL_KINDS = {
    "windows-dpapi",
    "macos-keychain",
    "linux-secret-service",
}


def _megas_home() -> Path:
    configured = os.environ.get("MEGAS_HOME")
    return Path(configured).expanduser() if configured else Path.home() / ".megas"


def _account_path() -> Path:
    return _megas_home() / "operator" / "account.json"


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _safe_api_base(value: str) -> str:
    text = str(value or "").strip().rstrip("/")
    if not text:
        raise ValueError("Chitraagni API base must be non-empty")
    parsed = urlsplit(text)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in {"http", "https"} or not host:
        raise ValueError("Chitraagni API base must be an absolute http(s) URL")
    if parsed.username or parsed.password:
        raise ValueError("Chitraagni API base must not contain credentials")
    if parsed.scheme == "http" and host not in LOOPBACK_HOSTS:
        raise ValueError("remote Chitraagni API bases must use https")
    if parsed.query or parsed.fragment:
        raise ValueError("Chitraagni API base must not contain query or fragment components")
    return text


def _token_from_env(name: str) -> str:
    env_name = str(name or "").strip()
    if not env_name:
        raise ValueError("token environment-variable name must be non-empty")
    token = os.environ.get(env_name, "").strip()
    if not token:
        raise RuntimeError(f"required Chitraagni token environment variable is not set: {env_name}")
    return token


def _secure_credential_store(kind: str | None = None) -> Any:
    classes = {
        "windows-dpapi": WindowsDPAPICredentialStore,
        "macos-keychain": MacOSKeychainCredentialStore,
        "linux-secret-service": LinuxSecretServiceCredentialStore,
    }
    requested = str(kind or "").strip().lower()
    if requested:
        cls = classes.get(requested)
        if cls is None:
            raise ValueError(f"unsupported secure credential kind: {requested}")
        store = cls()
        if not store.available():
            raise RuntimeError(f"secure credential store is unavailable: {requested}")
        return store
    for name in ("windows-dpapi", "macos-keychain", "linux-secret-service"):
        store = classes[name]()
        if store.available():
            return store
    raise RuntimeError(
        "no supported native secure credential store is available for the Amretra session"
    )


@dataclass(slots=True)
class ChitraagniBinding:
    """Non-secret Chitraagni target metadata for one Amretra identity.

    The class name is retained internally for compatibility with the operator
    catalog. It is not a second user-account relationship: `amretra_user_id` is
    the authoritative cross-product identity and the credential is an Amretra
    OAuth session stored outside this JSON record.
    """

    api_base: str
    user_id: str
    email: str
    amretra_user_id: str
    full_name: str | None = None
    amretra_id: str | None = None
    credential_kind: str = "env"
    token_env: str | None = DEFAULT_CHITRAAGNI_TOKEN_ENV
    firebase_uid: str | None = None

    def validate(self) -> None:
        self.api_base = _safe_api_base(self.api_base)
        self.user_id = str(self.user_id or "").strip()
        self.email = str(self.email or "").strip()
        self.amretra_user_id = str(self.amretra_user_id or "").strip()
        if not self.user_id:
            raise ValueError("Chitraagni local user row ID must be non-empty")
        if not self.email:
            raise ValueError("Amretra email must be non-empty")
        if not self.amretra_user_id and self.credential_kind != "firebase-owner-local":
            raise ValueError("Amretra user ID must be non-empty")
        self.full_name = None if self.full_name is None else str(self.full_name)
        self.amretra_id = None if self.amretra_id is None else str(self.amretra_id)
        self.credential_kind = str(self.credential_kind or "env").strip().lower()
        if self.credential_kind not in {"env", "firebase-owner-local", *SECURE_CREDENTIAL_KINDS}:
            raise ValueError(f"unsupported Amretra credential kind: {self.credential_kind}")
        if self.credential_kind == "firebase-owner-local":
            if urlsplit(self.api_base).hostname not in LOOPBACK_HOSTS or not self.firebase_uid:
                raise ValueError("Owner-local Firebase binding requires loopback and a pinned UID")
        if self.credential_kind == "env":
            self.token_env = str(self.token_env or "").strip()
            if not self.token_env:
                raise ValueError("environment credential requires token_env")
        else:
            self.token_env = None

    def token(self, *, timeout: float = 15.0) -> str:
        self.validate()
        if self.credential_kind == "firebase-owner-local":
            from .firebase_account import current_token, _claims
            token = current_token()
            if _claims(token).get("sub") != self.firebase_uid:
                raise PermissionError("The local owner Firebase identity changed")
            return token
        if self.credential_kind == "env":
            assert self.token_env is not None
            return _token_from_env(self.token_env)
        credential_store = _secure_credential_store(self.credential_kind)
        try:
            return current_access_token(credential_store, timeout=timeout)
        except ValueError as exc:
            raise PermissionError(
                "stored credential predates Amretra OAuth; run `megas account login` to replace it"
            ) from exc

    def credential_available(self) -> bool:
        self.validate()
        if self.credential_kind == "firebase-owner-local":
            try:
                return bool(self.token())
            except (ValueError, RuntimeError, PermissionError, OSError):
                return False
        if self.credential_kind == "env":
            assert self.token_env is not None
            return bool(os.environ.get(self.token_env, "").strip())
        try:
            return bool(_secure_credential_store(self.credential_kind).exists())
        except RuntimeError:
            return False

    def verify_token(self, token: str, *, timeout: float = 15.0) -> dict[str, Any]:
        value = request_json("GET", self.api_base + CHITRAAGNI_IDENTITY_PATH, token=token, timeout=timeout)
        if not isinstance(value, dict):
            raise RuntimeError("Chitraagni /me returned an invalid identity response")
        current_user_id = str(value.get("id") or "").strip()
        if current_user_id != self.user_id:
            raise PermissionError(
                "Chitraagni resolved the credential to a different product user record"
            )
        if self.credential_kind == "firebase-owner-local":
            if value.get("identity_provider") != "firebase-owner-local" or value.get("firebase_uid") != self.firebase_uid or value.get("is_active") is False:
                raise PermissionError("Chitraagni did not verify the pinned local owner")
            return value
        current_amretra_user_id = str(value.get("amretra_user_id") or "").strip()
        if current_amretra_user_id != self.amretra_user_id:
            raise PermissionError(
                "Chitraagni resolved the credential to a different Amretra identity"
            )
        if value.get("identity_provider") not in {None, "amretra"}:
            raise PermissionError("Chitraagni did not resolve an Amretra identity")
        if value.get("is_active") is False:
            raise PermissionError("the Chitraagni product record for this Amretra identity is inactive")
        return value

    def verify_current_identity(self, *, timeout: float = 15.0) -> dict[str, Any]:
        token = self.token(timeout=timeout)
        return self.verify_token(token, timeout=timeout)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "api_base": self.api_base,
            "credential_kind": self.credential_kind,
            "token_env": self.token_env,
            "user_id": self.user_id,
            "email": self.email,
            "amretra_user_id": self.amretra_user_id,
            "full_name": self.full_name,
            "amretra_id": self.amretra_id,
            "firebase_uid": self.firebase_uid,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ChitraagniBinding":
        binding = cls(
            api_base=str(value.get("api_base") or ""),
            credential_kind=str(value.get("credential_kind") or "env"),
            token_env=(
                str(value.get("token_env") or "")
                if value.get("token_env") is not None
                else None
            ),
            user_id=str(value.get("user_id") or ""),
            email=str(value.get("email") or ""),
            amretra_user_id=str(value.get("amretra_user_id") or ""),
            full_name=value.get("full_name"),
            amretra_id=value.get("amretra_id"),
            firebase_uid=value.get("firebase_uid"),
        )
        binding.validate()
        return binding


@dataclass(slots=True)
class OperatorAccount:
    chitraagni: ChitraagniBinding | None = None
    format: str = ACCOUNT_FORMAT
    version: int = ACCOUNT_VERSION

    def validate(self) -> None:
        if self.format != ACCOUNT_FORMAT:
            raise ValueError(f"unsupported operator-account format: {self.format}")
        if self.version != ACCOUNT_VERSION:
            raise ValueError(f"unsupported operator-account version: {self.version}")
        if self.chitraagni is not None:
            self.chitraagni.validate()

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "format": self.format,
            "version": self.version,
            "identity": {
                "authority": "amretra",
                "chitraagni": self.chitraagni.to_dict() if self.chitraagni else None,
            },
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "OperatorAccount":
        if str(value.get("format") or "") != ACCOUNT_FORMAT:
            raise ValueError(f"unsupported operator-account format: {value.get('format')}")
        raw_version = int(value.get("version") or 0)
        if raw_version not in {1, 2, ACCOUNT_VERSION}:
            raise ValueError(f"unsupported operator-account version: {raw_version}")

        if raw_version == ACCOUNT_VERSION:
            identity = value.get("identity")
            raw_binding = identity.get("chitraagni") if isinstance(identity, dict) else None
            account = cls(
                format=ACCOUNT_FORMAT,
                version=ACCOUNT_VERSION,
                chitraagni=(
                    ChitraagniBinding.from_dict(raw_binding)
                    if isinstance(raw_binding, dict)
                    else None
                ),
            )
            account.validate()
            return account

        # Versions 1/2 represented a separate Chitraagni account-link model and
        # lack the authoritative Amretra user UUID. Do not guess identity during
        # migration. A single explicit `megas account login` recreates the state
        # from Amretra and overwrites any legacy secure credential.
        return cls(format=ACCOUNT_FORMAT, version=ACCOUNT_VERSION, chitraagni=None)


class OperatorAccountStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or _account_path()

    def load(self) -> OperatorAccount:
        if not self.path.exists():
            # A cached Firebase token/profile is not an Amretra SSO binding.
            # Only explicit Amretra OAuth login establishes the cross-product UUID.
            return OperatorAccount()
        raw = self.path.read_bytes()
        if len(raw) > MAX_ACCOUNT_BYTES:
            raise ValueError("operator-account file exceeds 512 KiB")
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("operator-account file must contain a JSON object")
        return OperatorAccount.from_dict(value)

    def save(self, account: OperatorAccount) -> None:
        account.validate()
        _atomic_json(self.path, account.to_dict())

    def _save_binding(self, binding: ChitraagniBinding) -> None:
        account = self.load()
        account.chitraagni = binding
        self.save(account)

    @staticmethod
    def _binding_from_identity(
        identity: Any,
        *,
        api_base: str,
        credential_kind: str,
        token_env: str | None,
    ) -> ChitraagniBinding:
        if not isinstance(identity, dict):
            raise RuntimeError("Chitraagni /me returned an invalid identity response")
        user_id = str(identity.get("id") or "").strip()
        email = str(identity.get("email") or "").strip()
        amretra_user_id = str(identity.get("amretra_user_id") or "").strip()
        if not user_id or not email or not amretra_user_id:
            raise RuntimeError("Chitraagni /me did not return the required Amretra identity")
        if identity.get("identity_provider") not in {None, "amretra"}:
            raise PermissionError("Chitraagni /me did not resolve an Amretra identity")
        if identity.get("is_active") is False:
            raise PermissionError("Chitraagni product access is inactive")
        binding = ChitraagniBinding(
            api_base=api_base,
            credential_kind=credential_kind,
            token_env=token_env,
            user_id=user_id,
            email=email,
            amretra_user_id=amretra_user_id,
            full_name=identity.get("full_name"),
            amretra_id=identity.get("amretra_id"),
        )
        binding.validate()
        return binding

    def login_amretra(
        self,
        *,
        api_base: str = DEFAULT_CHITRAAGNI_API_BASE,
        login_timeout: float = 180.0,
        api_timeout: float = 15.0,
    ) -> dict[str, Any]:
        credential_store = _secure_credential_store()
        normalized_base = _safe_api_base(api_base)
        bundle = interactive_login(timeout=login_timeout)

        identity = request_json(
            "GET",
            normalized_base + CHITRAAGNI_IDENTITY_PATH,
            token=bundle.access_token,
            timeout=api_timeout,
        )
        binding = self._binding_from_identity(
            identity,
            api_base=normalized_base,
            credential_kind=str(credential_store.kind),
            token_env=None,
        )

        bootstrap = request_json(
            "POST",
            normalized_base + "/auth/bootstrap",
            token=bundle.access_token,
            timeout=api_timeout,
        )
        if not isinstance(bootstrap, dict):
            raise RuntimeError("Chitraagni bootstrap returned an invalid response")

        credential_store.write(bundle.to_secret())
        try:
            self._save_binding(binding)
        except Exception:
            credential_store.delete()
            raise
        return self.status(verify=True, timeout=api_timeout)

    def link_local_firebase_owner(self, *, api_base: str, timeout: float = 15.0) -> dict[str, Any]:
        """Private machine setup; reuse the existing DPAPI Firebase session."""
        normalized = _safe_api_base(api_base)
        if urlsplit(normalized).hostname not in LOOPBACK_HOSTS:
            raise ValueError("Owner-local access requires loopback")
        from .firebase_account import current_token, _claims
        token = current_token()
        uid = _claims(token)["sub"]
        identity = request_json("GET", normalized + CHITRAAGNI_IDENTITY_PATH, token=token, timeout=timeout)
        if not isinstance(identity, dict) or identity.get("identity_provider") != "firebase-owner-local" or identity.get("firebase_uid") != uid or not identity.get("id") or not identity.get("email"):
            raise PermissionError("Chitraagni did not verify the local owner")
        binding = ChitraagniBinding(api_base=normalized, user_id=str(identity["id"]), email=str(identity["email"]),
                                   amretra_user_id="", credential_kind="firebase-owner-local", token_env=None,
                                   firebase_uid=uid, full_name=identity.get("full_name"))
        binding.verify_token(token, timeout=timeout)
        existing = self.load().chitraagni
        if existing and (existing.user_id != binding.user_id or existing.api_base != binding.api_base):
            raise PermissionError("Explicitly unlink the existing Chitraagni target before replacement")
        request_json("POST", normalized + "/auth/bootstrap", token=token, timeout=timeout)
        self._save_binding(binding)
        return self.status(verify=True, timeout=timeout)

    def configure_environment_credential(
        self,
        *,
        token_env: str,
        api_base: str = DEFAULT_CHITRAAGNI_API_BASE,
        timeout: float = 15.0,
    ) -> dict[str, Any]:
        """Compatibility/test path; not normal human onboarding."""
        normalized_base = _safe_api_base(api_base)
        token = _token_from_env(token_env)
        identity = request_json("GET", normalized_base + CHITRAAGNI_IDENTITY_PATH, token=token, timeout=timeout)
        self._save_binding(
            self._binding_from_identity(
                identity,
                api_base=normalized_base,
                credential_kind="env",
                token_env=token_env,
            )
        )
        return self.status(verify=True, timeout=timeout)

    def bootstrap_chitraagni(self, *, timeout: float = 15.0) -> dict[str, Any]:
        binding = self.load().chitraagni
        if binding is None:
            raise PermissionError("Amretra login is required")
        token = binding.token(timeout=timeout)
        binding.verify_token(token, timeout=timeout)
        value = request_json(
            "POST",
            binding.api_base + "/auth/bootstrap",
            token=token,
            timeout=timeout,
        )
        if not isinstance(value, dict):
            raise RuntimeError("Chitraagni bootstrap returned an invalid response")
        return value

    def logout_amretra(self) -> dict[str, Any]:
        account = self.load()
        binding = account.chitraagni
        changed = binding is not None
        result: dict[str, Any] = {"amretra_authenticated": False, "changed": changed}
        if binding is not None and binding.credential_kind in SECURE_CREDENTIAL_KINDS:
            try:
                result["stored_credential_deleted"] = bool(
                    _secure_credential_store(binding.credential_kind).delete()
                )
            except RuntimeError:
                result["stored_credential_deleted"] = False
                result["stored_credential_store_unavailable"] = True
        account.chitraagni = None
        self.save(account)
        return result

    def status(self, *, verify: bool = False, timeout: float = 15.0) -> dict[str, Any]:
        binding = self.load().chitraagni
        if binding is None:
            return {
                "identity_authority": "amretra",
                "amretra_authenticated": False,
                "chitraagni_target_ready": False,
                # Read-only compatibility aliases for older local status views.
                # They do not restore the removed separate Chitraagni login model.
                "chitraagni_linked": False,
                "credential_available": False,
                "token_available": False,
                "operator_scope": "MegasMoves local workspace only",
            }

        credential_available = binding.credential_available()
        value: dict[str, Any] = {
            "identity_authority": "firebase-owner-local" if binding.credential_kind == "firebase-owner-local" else "amretra",
            "amretra_authenticated": binding.credential_kind != "firebase-owner-local",
            "chitraagni_target_ready": True,
            "chitraagni_linked": True,
            "operator_scope": "MegasMoves local workspace + authorized Chitraagni product surface",
            "api_base": binding.api_base,
            "credential_kind": binding.credential_kind,
            "credential_available": credential_available,
            "token_available": credential_available,
            "user": {
                "chitraagni_user_id": binding.user_id,
                "amretra_user_id": binding.amretra_user_id,
                "email": binding.email,
                "full_name": binding.full_name,
                "amretra_id": binding.amretra_id,
            },
        }
        if verify:
            current = binding.verify_current_identity(timeout=timeout)
            value["identity_verified"] = True
            value["current_user"] = {
                key: current.get(key)
                for key in (
                    "id",
                    "amretra_user_id",
                    "email",
                    "full_name",
                    "amretra_id",
                    "identity_provider",
                    "is_active",
                    "is_tester",
                )
            }
        return value


__all__ = [
    "ACCOUNT_FORMAT",
    "ACCOUNT_VERSION",
    "ChitraagniBinding",
    "DEFAULT_CHITRAAGNI_API_BASE",
    "DEFAULT_CHITRAAGNI_TOKEN_ENV",
    "OperatorAccount",
    "OperatorAccountStore",
    "SECURE_CREDENTIAL_KINDS",
    "OAuthCredentialBundle",
    "request_json",
]
