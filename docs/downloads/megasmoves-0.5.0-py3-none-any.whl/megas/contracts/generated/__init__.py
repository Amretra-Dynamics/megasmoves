"""Generated Megas CLI and Local Worker contract models."""
