"""Generated from contracts/monitor/incidents.v1.json. Do not edit."""

from __future__ import annotations

from typing import Any, Literal, Mapping, NotRequired, TypedDict, cast

SOURCE_SHA256 = "0ce0b29d5762f4bedf637b0effe4d27b42a400a85063e0e4edb7941c941fcb2a"
SCHEMA_VERSION = "1.0.0"
MONITOR_INCIDENT_LIST_ROUTE = "/api/v1/monitor/incidents"
MONITOR_INCIDENT_DETAIL_ROUTE = "/api/v1/monitor/incidents/{incident_id}"
MONITOR_INCIDENT_TIMELINE_ROUTE = "/api/v1/monitor/incidents/{incident_id}/timeline"
MONITOR_INCIDENT_CORRELATIONS_ROUTE = "/api/v1/monitor/incidents/{incident_id}/correlations"
MONITOR_INCIDENT_ACKNOWLEDGE_ROUTE = "/api/v1/monitor/incidents/{incident_id}/acknowledge"
MONITOR_INCIDENT_ASSIGN_ROUTE = "/api/v1/monitor/incidents/{incident_id}/assign"
MONITOR_INCIDENT_SUPPRESS_ROUTE = "/api/v1/monitor/incidents/{incident_id}/suppress"
MONITOR_INCIDENT_MITIGATE_ROUTE = "/api/v1/monitor/incidents/{incident_id}/mitigate"
MONITOR_INCIDENT_RESOLVE_ROUTE = "/api/v1/monitor/incidents/{incident_id}/resolve"
MONITOR_INCIDENT_REOPEN_ROUTE = "/api/v1/monitor/incidents/{incident_id}/reopen"

MonitorIncidentSeverityV1 = Literal['info', 'warning', 'error', 'critical']
MonitorIncidentStateV1 = Literal['detected', 'investigating', 'acknowledged', 'mitigated', 'resolved', 'reopened', 'suppressed']

MONITOR_INCIDENT_TRANSITIONS = {
    'detected': frozenset(('investigating', 'acknowledged', 'mitigated', 'resolved', 'suppressed',)),
    'investigating': frozenset(('acknowledged', 'mitigated', 'resolved', 'suppressed',)),
    'acknowledged': frozenset(('investigating', 'mitigated', 'resolved', 'suppressed',)),
    'mitigated': frozenset(('resolved', 'reopened', 'investigating',)),
    'resolved': frozenset(('reopened',)),
    'reopened': frozenset(('investigating', 'acknowledged', 'mitigated', 'resolved', 'suppressed',)),
    'suppressed': frozenset(('detected', 'reopened', 'resolved',)),
}
MONITOR_INCIDENT_OPEN_STATES = frozenset(('detected', 'investigating', 'acknowledged', 'mitigated', 'reopened'))

class MonitorIncidentV1(TypedDict):
    incident_id: str
    tenant_id: NotRequired[str | None]
    project_id: NotRequired[str | None]
    environment: NotRequired[str | None]
    state: MonitorIncidentStateV1
    severity: MonitorIncidentSeverityV1
    title: str
    summary: NotRequired[str | None]
    primary_fingerprint: NotRequired[str | None]
    service_name: NotRequired[str | None]
    source_types: NotRequired[list[str] | None]
    affected_services: NotRequired[list[str] | None]
    affected_environments: NotRequired[list[str] | None]
    affected_versions: NotRequired[list[str] | None]
    affected_resources: NotRequired[list[str] | None]
    occurrence_count: int
    first_seen_at: str
    last_seen_at: str
    detected_at: str
    resolved_at: NotRequired[str | None]
    acknowledged_at: NotRequired[str | None]
    assigned_to: NotRequired[str | None]
    root_cause: NotRequired[str | None]
    root_cause_confidence: NotRequired[float | None]
    root_cause_kind: NotRequired[str | None]
    correlation_reasons: NotRequired[list[str] | None]
    is_flapping: NotRequired[bool | None]
    suppressed_until: NotRequired[str | None]
    deployment_id: NotRequired[str | None]
    release_version: NotRequired[str | None]
    created_at: str
    updated_at: str

class MonitorIncidentListResponseV1(TypedDict):
    schema_version: Literal['1.0.0']
    incidents: list[MonitorIncidentV1]
    count: int

class MonitorIncidentDetailResponseV1(TypedDict):
    schema_version: Literal['1.0.0']
    incident: MonitorIncidentV1

class MonitorIncidentTimelineEntryV1(TypedDict):
    entry_id: str
    incident_id: str
    entry_type: str
    at: str
    actor: NotRequired[str | None]
    summary: str
    details: dict[str, Any]
    event_id: NotRequired[str | None]
    immutable: bool

class MonitorIncidentTimelineResponseV1(TypedDict):
    schema_version: Literal['1.0.0']
    incident_id: str
    timeline: list[MonitorIncidentTimelineEntryV1]
    count: int

class MonitorIncidentCorrelationV1(TypedDict):
    correlation_id: str
    event_id: NotRequired[str | None]
    fingerprint: NotRequired[str | None]
    role: str
    reasons: list[str]
    confidence: NotRequired[float | None]
    kind: NotRequired[str | None]
    summary: NotRequired[str | None]

class MonitorIncidentCorrelationsResponseV1(TypedDict):
    schema_version: Literal['1.0.0']
    incident_id: str
    correlations: list[MonitorIncidentCorrelationV1]

def _mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be an object")
    return value


def _required_value(payload: Mapping[str, Any], key: str) -> Any:
    if key not in payload:
        raise ValueError(f"{key} is required")
    return payload[key]


def _required_literal(payload: Mapping[str, Any], key: str, expected: str) -> str:
    value = _required_string(payload, key)
    if value != expected:
        raise ValueError(f"unsupported {key}: {value}")
    return value


def _required_string(payload: Mapping[str, Any], key: str) -> str:
    value = _required_value(payload, key)
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string")
    return value


def _optional_string(payload: Mapping[str, Any], key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string or null")
    return value


def _required_integer(payload: Mapping[str, Any], key: str) -> int:
    value = _required_value(payload, key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{key} must be an integer")
    return value


def _optional_integer(payload: Mapping[str, Any], key: str) -> int | None:
    value = payload.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{key} must be an integer or null")
    return value


def _required_number(payload: Mapping[str, Any], key: str) -> float:
    value = _required_value(payload, key)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{key} must be a number")
    return float(value)


def _optional_number(payload: Mapping[str, Any], key: str) -> float | None:
    value = payload.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{key} must be a number or null")
    return float(value)


def _required_boolean(payload: Mapping[str, Any], key: str) -> bool:
    value = _required_value(payload, key)
    if not isinstance(value, bool):
        raise ValueError(f"{key} must be a boolean")
    return value


def _optional_boolean(payload: Mapping[str, Any], key: str) -> bool | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, bool):
        raise ValueError(f"{key} must be a boolean or null")
    return value


def _required_mapping(payload: Mapping[str, Any], key: str) -> dict[str, Any]:
    return dict(_mapping(_required_value(payload, key), key))


def _optional_mapping(payload: Mapping[str, Any], key: str) -> dict[str, Any] | None:
    value = payload.get(key)
    return None if value is None else dict(_mapping(value, key))


def _required_list(payload: Mapping[str, Any], key: str) -> list[Any]:
    value = _required_value(payload, key)
    if not isinstance(value, list):
        raise ValueError(f"{key} must be an array")
    return value


def _optional_list(payload: Mapping[str, Any], key: str) -> list[Any] | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError(f"{key} must be an array or null")
    return value


def _required_string_list(payload: Mapping[str, Any], key: str) -> list[str]:
    values = _required_list(payload, key)
    if not all(isinstance(value, str) for value in values):
        raise ValueError(f"{key} must contain only strings")
    return cast(list[str], values)


def _optional_string_list(payload: Mapping[str, Any], key: str) -> list[str] | None:
    values = _optional_list(payload, key)
    if values is None:
        return None
    if not all(isinstance(value, str) for value in values):
        raise ValueError(f"{key} must contain only strings")
    return cast(list[str], values)

def _parse_MonitorIncidentSeverityV1(value: Any, label: str) -> MonitorIncidentSeverityV1:
    if not isinstance(value, str) or value not in ('info', 'warning', 'error', 'critical'):
        raise ValueError(f"{label} is not a valid MonitorIncidentSeverityV1")
    return cast(MonitorIncidentSeverityV1, value)


def _parse_MonitorIncidentStateV1(value: Any, label: str) -> MonitorIncidentStateV1:
    if not isinstance(value, str) or value not in ('detected', 'investigating', 'acknowledged', 'mitigated', 'resolved', 'reopened', 'suppressed'):
        raise ValueError(f"{label} is not a valid MonitorIncidentStateV1")
    return cast(MonitorIncidentStateV1, value)


def parse_MonitorIncidentV1(value: Any) -> MonitorIncidentV1:
    payload = _mapping(value, "MonitorIncidentV1")
    return cast(MonitorIncidentV1, {
        "incident_id": _required_string(payload, "incident_id"),
        "tenant_id": _optional_string(payload, "tenant_id"),
        "project_id": _optional_string(payload, "project_id"),
        "environment": _optional_string(payload, "environment"),
        "state": _parse_MonitorIncidentStateV1(_required_value(payload, "state"), "state"),
        "severity": _parse_MonitorIncidentSeverityV1(_required_value(payload, "severity"), "severity"),
        "title": _required_string(payload, "title"),
        "summary": _optional_string(payload, "summary"),
        "primary_fingerprint": _optional_string(payload, "primary_fingerprint"),
        "service_name": _optional_string(payload, "service_name"),
        "source_types": _optional_string_list(payload, "source_types"),
        "affected_services": _optional_string_list(payload, "affected_services"),
        "affected_environments": _optional_string_list(payload, "affected_environments"),
        "affected_versions": _optional_string_list(payload, "affected_versions"),
        "affected_resources": _optional_string_list(payload, "affected_resources"),
        "occurrence_count": _required_integer(payload, "occurrence_count"),
        "first_seen_at": _required_string(payload, "first_seen_at"),
        "last_seen_at": _required_string(payload, "last_seen_at"),
        "detected_at": _required_string(payload, "detected_at"),
        "resolved_at": _optional_string(payload, "resolved_at"),
        "acknowledged_at": _optional_string(payload, "acknowledged_at"),
        "assigned_to": _optional_string(payload, "assigned_to"),
        "root_cause": _optional_string(payload, "root_cause"),
        "root_cause_confidence": _optional_number(payload, "root_cause_confidence"),
        "root_cause_kind": _optional_string(payload, "root_cause_kind"),
        "correlation_reasons": _optional_string_list(payload, "correlation_reasons"),
        "is_flapping": _optional_boolean(payload, "is_flapping"),
        "suppressed_until": _optional_string(payload, "suppressed_until"),
        "deployment_id": _optional_string(payload, "deployment_id"),
        "release_version": _optional_string(payload, "release_version"),
        "created_at": _required_string(payload, "created_at"),
        "updated_at": _required_string(payload, "updated_at"),
    })


def parse_MonitorIncidentListResponseV1(value: Any) -> MonitorIncidentListResponseV1:
    payload = _mapping(value, "MonitorIncidentListResponseV1")
    return cast(MonitorIncidentListResponseV1, {
        "schema_version": _required_literal(payload, "schema_version", '1.0.0'),
        "incidents": [parse_MonitorIncidentV1(item) for item in _required_list(payload, "incidents")],
        "count": _required_integer(payload, "count"),
    })


def parse_MonitorIncidentDetailResponseV1(value: Any) -> MonitorIncidentDetailResponseV1:
    payload = _mapping(value, "MonitorIncidentDetailResponseV1")
    return cast(MonitorIncidentDetailResponseV1, {
        "schema_version": _required_literal(payload, "schema_version", '1.0.0'),
        "incident": parse_MonitorIncidentV1(_required_value(payload, "incident")),
    })


def parse_MonitorIncidentTimelineEntryV1(value: Any) -> MonitorIncidentTimelineEntryV1:
    payload = _mapping(value, "MonitorIncidentTimelineEntryV1")
    return cast(MonitorIncidentTimelineEntryV1, {
        "entry_id": _required_string(payload, "entry_id"),
        "incident_id": _required_string(payload, "incident_id"),
        "entry_type": _required_string(payload, "entry_type"),
        "at": _required_string(payload, "at"),
        "actor": _optional_string(payload, "actor"),
        "summary": _required_string(payload, "summary"),
        "details": _required_mapping(payload, "details"),
        "event_id": _optional_string(payload, "event_id"),
        "immutable": _required_boolean(payload, "immutable"),
    })


def parse_MonitorIncidentTimelineResponseV1(value: Any) -> MonitorIncidentTimelineResponseV1:
    payload = _mapping(value, "MonitorIncidentTimelineResponseV1")
    return cast(MonitorIncidentTimelineResponseV1, {
        "schema_version": _required_literal(payload, "schema_version", '1.0.0'),
        "incident_id": _required_string(payload, "incident_id"),
        "timeline": [parse_MonitorIncidentTimelineEntryV1(item) for item in _required_list(payload, "timeline")],
        "count": _required_integer(payload, "count"),
    })


def parse_MonitorIncidentCorrelationV1(value: Any) -> MonitorIncidentCorrelationV1:
    payload = _mapping(value, "MonitorIncidentCorrelationV1")
    return cast(MonitorIncidentCorrelationV1, {
        "correlation_id": _required_string(payload, "correlation_id"),
        "event_id": _optional_string(payload, "event_id"),
        "fingerprint": _optional_string(payload, "fingerprint"),
        "role": _required_string(payload, "role"),
        "reasons": _required_string_list(payload, "reasons"),
        "confidence": _optional_number(payload, "confidence"),
        "kind": _optional_string(payload, "kind"),
        "summary": _optional_string(payload, "summary"),
    })


def parse_MonitorIncidentCorrelationsResponseV1(value: Any) -> MonitorIncidentCorrelationsResponseV1:
    payload = _mapping(value, "MonitorIncidentCorrelationsResponseV1")
    return cast(MonitorIncidentCorrelationsResponseV1, {
        "schema_version": _required_literal(payload, "schema_version", '1.0.0'),
        "incident_id": _required_string(payload, "incident_id"),
        "correlations": [parse_MonitorIncidentCorrelationV1(item) for item in _required_list(payload, "correlations")],
    })
