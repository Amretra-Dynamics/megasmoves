"""Versioned Megas CLI and Local Worker wire contracts."""
