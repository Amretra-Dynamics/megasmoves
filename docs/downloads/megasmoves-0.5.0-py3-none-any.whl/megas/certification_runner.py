"""Public certification runner with granular, no-prompt history fallback."""

from __future__ import annotations

from contextlib import contextmanager
from threading import RLock
from typing import Any, Iterator

from . import certification_runner_legacy as _legacy


CertificationRunResult = _legacy.CertificationRunResult
RunEvidence = getattr(_legacy, "RunEvidence", None)


def _marker_count(thread: dict[str, Any] | None, marker: str) -> int:
    if not isinstance(thread, dict):
        return 0
    count = 0
    for message in thread.get("messages") or []:
        if not isinstance(message, dict):
            continue
        if str(message.get("role") or "").lower() != "user":
            continue
        for key in ("content", "text"):
            value = message.get(key)
            if isinstance(value, str):
                count += value.count(marker)
    return count


marker_count_in_native_user_turns = _marker_count
_LEGACY_RUN_LOCK = RLock()


@contextmanager
def _scoped_native_user_marker_counter() -> Iterator[None]:
    """Install the strict counter only for one serialized legacy live run."""

    with _LEGACY_RUN_LOCK:
        previous = getattr(_legacy, "_marker_count", None)
        _legacy._marker_count = _marker_count
        try:
            yield
        finally:
            if previous is None:
                delattr(_legacy, "_marker_count")
            else:
                _legacy._marker_count = previous


_HISTORY_CAPABILITIES = frozenset(
    {
        "thread_list",
        "thread_read",
        "native_persistence",
        "reconciliation",
    }
)


def _as_public_result(result: object):
    return CertificationRunResult(
        provider_id=str(getattr(result, "provider_id")),
        certified=bool(getattr(result, "certified")),
        certificate_path=str(getattr(result, "certificate_path")),
        status=str(getattr(result, "status")),
        reason=str(getattr(result, "reason")),
        checks=dict(getattr(result, "checks")),
        verified_capabilities=tuple(
            getattr(result, "verified_capabilities")
        ),
        evidence=dict(getattr(result, "evidence")),
    )


def _declares_full_execution(provider_id: str) -> bool:
    adapter_class = _legacy._agent_adapter_classes().get(provider_id)
    if adapter_class is None:
        return False
    try:
        adapter = adapter_class([])
        declaration = getattr(adapter, "provider_capabilities", None)
        if not callable(declaration):
            return True
        capabilities = declaration()
        return bool(
            getattr(capabilities, "create_conversation", False)
            and getattr(capabilities, "exact_resume", False)
            and getattr(capabilities, "headless_runtime", False)
        )
    except Exception:
        return False


def _history_result(provider_id: str, *, expires_days: int):
    from .history_certification import certify_history_installation

    return _as_public_result(
        certify_history_installation(
            provider_id,
            expires_days=expires_days,
        )
    )


def certify_agent_installation(
    provider_id: str,
    *,
    timeout_seconds: float = 300.0,
    expires_days: int = 30,
):
    """Certify the exact capability set without unsafe probe escalation.

    Providers that do not declare a provable fresh-create and exact-resume
    contract go directly to the read-only history proof. Other providers run
    the full live matrix first; a failed live matrix may retain a separately
    proved history subset, but can never become executable from that subset.
    """

    provider = str(provider_id or "").strip().lower()
    if not _declares_full_execution(provider):
        return _history_result(provider, expires_days=expires_days)

    live_error: Exception | None = None
    try:
        with _scoped_native_user_marker_counter():
            live_result = _legacy.certify_agent_installation(
                provider,
                timeout_seconds=timeout_seconds,
                expires_days=expires_days,
            )
    except Exception as exc:
        live_error = exc
    else:
        if live_result.certified:
            return live_result
        if _HISTORY_CAPABILITIES.issubset(
            set(live_result.verified_capabilities)
        ):
            return live_result

    try:
        history_result = _history_result(
            provider,
            expires_days=expires_days,
        )
    except Exception:
        if live_error is not None:
            raise live_error
        if "live_result" in locals():
            return live_result
        raise

    if history_result.verified_capabilities:
        return history_result
    if live_error is not None:
        raise live_error
    if "live_result" in locals():
        return live_result
    return history_result
