"""Authoritative install metadata for the Megas launch adapter matrix.

The persistent agent store may contain stale live-registry records from an older
Worker.  These product-owned records are applied after every store load so
installation, discovery, certification, and runtime routing use the same IDs.
"""

from __future__ import annotations

from typing import Any, MutableMapping


LAUNCH_AGENT_IDS = (
    "codex_cli",
    "antigravity",
    "grok_build",
    "devin_cli",
    "cursor_cli",
    "jules_cli",
    "kilo_code",
    "opencode",
    "cline",
)


def apply_launch_install_overrides(
    catalog: MutableMapping[str, Any],
    *,
    spec_type: type,
    strategy_type: type,
) -> MutableMapping[str, Any]:
    """Replace stale launch-agent records with reviewed official installers."""

    def strategy(
        strategy_id: str,
        kind: str,
        *,
        argv: tuple[str, ...] = (),
        platforms: tuple[str, ...] = ("*",),
        requires: tuple[str, ...] = (),
        summary: str,
        script_windows: str = "",
        script_unix: str = "",
        manual_url: str = "",
    ) -> Any:
        return strategy_type(
            id=strategy_id,
            kind=kind,
            argv=argv,
            platforms=platforms,
            requires=requires,
            summary=summary,
            script_windows=script_windows,
            script_unix=script_unix,
            manual_url=manual_url,
        )

    def put(
        agent_id: str,
        display_name: str,
        aliases: tuple[str, ...],
        binaries: tuple[str, ...],
        binary_env: str,
        installers: tuple[Any, ...],
        auth_hint: str,
        packages: tuple[str, ...] = (),
    ) -> None:
        catalog[agent_id] = spec_type(
            agent_id=agent_id,
            display_name=display_name,
            aliases=aliases,
            binary_names=binaries,
            binary_env=binary_env,
            certified=True,
            installers=installers,
            auth_hint=auth_hint,
            package_hints=packages,
        )

    put(
        "codex_cli",
        "OpenAI Codex CLI",
        ("codex", "codex_cli", "codex-cli", "openai-codex"),
        ("codex",),
        "MEGAS_CODEX_BINARY",
        (
            strategy(
                "npm",
                "npm",
                argv=("npm", "install", "-g", "@openai/codex"),
                requires=("npm",),
                summary="npm install -g @openai/codex",
            ),
        ),
        "Sign in with ChatGPT or set OPENAI_API_KEY.",
        ("@openai/codex",),
    )
    put(
        "antigravity",
        "Antigravity CLI",
        ("agy", "antigravity", "gravity"),
        ("agy",),
        "MEGAS_ANTIGRAVITY_BINARY",
        (
            strategy(
                "official_windows",
                "script",
                platforms=("windows",),
                summary="Official Antigravity PowerShell installer",
                script_windows="irm https://antigravity.google/cli/install.ps1 | iex",
            ),
            strategy(
                "official_unix",
                "script",
                platforms=("darwin", "linux"),
                summary="Official Antigravity installer",
                script_unix="curl -fsSL https://antigravity.google/cli/install.sh | bash",
            ),
        ),
        "Run agy once and complete Google sign-in before certification.",
    )
    put(
        "grok_build",
        "Grok Build",
        ("grok", "grok_build", "grok-build", "xai"),
        ("grok",),
        "MEGAS_GROK_BINARY",
        (
            strategy(
                "official_unix",
                "script",
                platforms=("darwin", "linux"),
                summary="Official Grok Build installer",
                script_unix="curl -fsSL https://x.ai/cli/install.sh | bash",
            ),
            strategy(
                "official_docs",
                "manual",
                platforms=("windows",),
                summary="Install Grok Build from the official xAI documentation",
                manual_url="https://docs.x.ai/build/overview",
            ),
        ),
        "Complete browser sign-in or set XAI_API_KEY.",
    )
    put(
        "devin_cli",
        "Devin CLI",
        ("devin", "devin_cli", "devin-cli", "cognition"),
        ("devin",),
        "MEGAS_DEVIN_BINARY",
        (
            strategy(
                "official_windows",
                "script",
                platforms=("windows",),
                summary="Official Devin PowerShell installer",
                script_windows="irm https://static.devin.ai/cli/setup.ps1 | iex",
            ),
            strategy(
                "official_unix",
                "script",
                platforms=("darwin", "linux"),
                summary="Official Devin CLI installer",
                script_unix="curl -fsSL https://cli.devin.ai/install.sh | bash",
            ),
        ),
        "Run devin auth login or set DEVIN_API_KEY.",
    )
    put(
        "cursor_cli",
        "Cursor Agent CLI",
        ("cursor", "cursor_agent", "cursor-agent", "cursor_cli"),
        ("cursor-agent",),
        "MEGAS_CURSOR_BINARY",
        (
            strategy(
                "official_unix",
                "script",
                platforms=("darwin", "linux"),
                summary="Official Cursor CLI installer",
                script_unix="curl https://cursor.com/install -fsS | bash",
            ),
            strategy(
                "official_docs",
                "manual",
                platforms=("windows",),
                summary="Install Cursor CLI through WSL or the official guide",
                manual_url="https://docs.cursor.com/en/cli/installation",
            ),
        ),
        "Run cursor-agent login or set CURSOR_API_KEY.",
    )
    put(
        "jules_cli",
        "Jules Tools CLI",
        ("jules", "jules_cli", "jules-cli", "google-jules"),
        ("jules",),
        "MEGAS_JULES_BINARY",
        (
            strategy(
                "npm",
                "npm",
                argv=("npm", "install", "-g", "@google/jules"),
                requires=("npm",),
                summary="npm install -g @google/jules",
            ),
        ),
        "Run jules login; Megas API execution also requires JULES_API_KEY.",
        ("@google/jules",),
    )
    put(
        "kilo_code",
        "Kilo Code CLI",
        ("kilo", "kilocode", "kilo_code", "kilo-code"),
        ("kilo", "kilocode"),
        "MEGAS_KILO_BINARY",
        (
            strategy(
                "npm",
                "npm",
                argv=("npm", "install", "-g", "@kilocode/cli"),
                requires=("npm",),
                summary="npm install -g @kilocode/cli",
            ),
        ),
        "Run kilo and use /connect before certification.",
        ("@kilocode/cli",),
    )
    put(
        "opencode",
        "OpenCode",
        ("opencode", "open-code", "open_code"),
        ("opencode",),
        "MEGAS_OPENCODE_BINARY",
        (
            strategy(
                "official_unix",
                "script",
                platforms=("darwin", "linux"),
                summary="Official OpenCode installer",
                script_unix="curl -fsSL https://opencode.ai/install | bash",
            ),
            strategy(
                "npm",
                "npm",
                argv=("npm", "install", "-g", "opencode-ai"),
                requires=("npm",),
                summary="npm install -g opencode-ai",
            ),
        ),
        "Connect an LLM provider before certification.",
        ("opencode-ai",),
    )
    put(
        "cline",
        "Cline CLI",
        ("cline", "cline_cli", "cline-cli"),
        ("cline",),
        "MEGAS_CLINE_BINARY",
        (
            strategy(
                "npm",
                "npm",
                argv=("npm", "install", "-g", "cline"),
                requires=("npm",),
                summary="npm install -g cline",
            ),
        ),
        "Run cline auth and configure a provider before certification.",
        ("cline",),
    )
    return catalog
