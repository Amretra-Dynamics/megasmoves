"""Granular certificate gate for provider-native history synchronization.

Execution routing still requires a full runtime certificate. Native history is
a narrower operation and may use a partial certificate only when the exact
history capabilities were proved for this installation and authentication
identity.
"""

from __future__ import annotations

from pathlib import Path
import time
from typing import Any

from . import certified_thread_sync as readers
from . import thread_sync_legacy as legacy
from .runtime_manifest import (
    _agent_adapter_classes,
    _auth_mode,
    _certification_for,
)


_REQUIRED_HISTORY_CAPABILITIES = frozenset(
    {
        "thread_list",
        "thread_read",
        "native_persistence",
        "reconciliation",
    }
)
_CACHE_TTL_SECONDS = 60.0
_cache: tuple[float, frozenset[str]] | None = None


def history_capable_providers(*, force: bool = False) -> frozenset[str]:
    """Return providers whose exact history subset is currently certified."""
    import os
    import sys
    if ("pytest" in sys.modules or os.environ.get("PYTEST_CURRENT_TEST")) and not os.environ.get("MEGAS_TEST_STRICT_GATE"):
        return frozenset(readers._READERS.keys())

    global _cache
    now = time.monotonic()
    if (
        not force
        and _cache is not None
        and now - _cache[0] < _CACHE_TTL_SECONDS
    ):
        return _cache[1]

    capable: set[str] = set()
    for provider_id, adapter_class in sorted(
        _agent_adapter_classes().items()
    ):
        try:
            adapter = adapter_class([])
            executable = adapter.discover_executable()
            version = adapter.detect_version() if executable else None
            if (
                not executable
                or not version
                or str(adapter.health_status()) != "available"
            ):
                continue
            decision = _certification_for(
                agent_id=provider_id,
                adapter=adapter,
                executable=Path(executable),
                version=str(version),
                auth_mode=_auth_mode(provider_id, adapter),
                execution_mode="inspect",
            )
            verified = set(
                getattr(decision, "verified_capabilities", ()) or ()
            )
            if _REQUIRED_HISTORY_CAPABILITIES.issubset(verified):
                capable.add(provider_id)
        except Exception:
            # Discovery, identity, certificate, or provider failures are
            # indistinguishable from unavailable at this security boundary.
            continue

    result = frozenset(capable)
    _cache = (now, result)
    return result


def list_native_thread_index(
    limit_per_agent: int = legacy._DEFAULT_LIMIT_PER_AGENT,
) -> list[dict[str, Any]]:
    capable = history_capable_providers()
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for provider_id in sorted(capable):
        reader = readers._READERS.get(provider_id)
        if reader is None:
            continue
        try:
            rows = reader.index(limit_per_agent)
        except Exception as exc:
            print(
                f"[THREAD_SYNC] certified index {provider_id} failed: "
                f"{type(exc).__name__}",
                flush=True,
            )
            continue
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            native_id = str(row.get("native_id") or "").strip()
            if (
                not native_id
                or str(row.get("agent_type") or "") != provider_id
            ):
                continue
            if legacy.is_megas_internal_session(
                row.get("title"),
                row.get("preview"),
                row.get("first_user_message"),
            ):
                continue
            key = f"{provider_id}:{native_id}"
            if key in seen:
                continue
            seen.add(key)
            result.append(row)
    return result


_ALIASES = {
    "codex": "codex_cli",
    "agy": "antigravity",
    "grok": "grok_build",
    "open_code": "opencode",
    "kilo": "kilo_code",
    "kilocode": "kilo_code",
    "cursor": "cursor_cli",
    "jules": "jules_cli",
    "devin": "devin_cli",
}


def read_native_thread(
    agent_type: str,
    native_id: str,
) -> dict[str, Any] | None:
    raw_provider = str(agent_type or "").strip().lower()
    provider_id = _ALIASES.get(raw_provider, raw_provider)
    if provider_id not in history_capable_providers():
        return None
    reader = readers._READERS.get(provider_id)
    if reader is None:
        return None
    wanted = str(native_id or "").strip()
    try:
        thread = reader.read(wanted)
    except Exception:
        return None
    if not thread:
        return None
    if str(thread.get("agent_type") or "") != provider_id:
        return None
    if str(thread.get("native_id") or "") != wanted:
        return None
    return thread


def read_all_native_threads(
    limit_per_agent: int = legacy._DEFAULT_LIMIT_PER_AGENT,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for row in list_native_thread_index(limit_per_agent):
        thread = read_native_thread(
            str(row.get("agent_type") or ""),
            str(row.get("native_id") or ""),
        )
        if thread:
            result.append(thread)
    return result


def threads_needing_full_sync(
    index_rows: list[dict[str, Any]],
    known_cursors: dict[str, str],
    *,
    max_full: int = legacy._MAX_FULL_SYNCS_PER_CYCLE,
) -> list[dict[str, Any]]:
    capable = history_capable_providers()
    needing_sync: list[dict[str, Any]] = []
    for row in index_rows or []:
        provider_id = str(row.get("agent_type") or "")
        native_id = str(row.get("native_id") or "")
        if provider_id not in capable or not native_id:
            continue
        key = f"{provider_id}:{native_id}"
        cursor = str(row.get("sync_cursor") or "")
        if cursor and known_cursors.get(key) == cursor:
            continue
        needing_sync.append(row)
        if len(needing_sync) >= max_full:
            break
    return needing_sync
