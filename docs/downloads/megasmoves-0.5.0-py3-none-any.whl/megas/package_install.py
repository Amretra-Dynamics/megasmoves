"""Human pip-launcher bootstrap for the same installed Windows product.

Not an MCP tool. Uses fixed product paths and the vendor's bounded release catalog.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
from urllib.parse import urlsplit
from urllib.request import urlopen


def install_windows_product() -> Path:
    if os.name != "nt":
        raise RuntimeError("The Windows app installer is only supported on Windows.")
    origin = os.environ.get("MEGAS_INSTALL_SITE", "https://megasmoves.io").rstrip("/")
    parsed = urlsplit(origin)
    preview = parsed.hostname in {"127.0.0.1", "localhost", "::1"}
    if parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment:
        raise RuntimeError("Invalid product download origin.")
    if not (preview and parsed.scheme in {"http", "https"}) and origin != "https://megasmoves.io":
        raise RuntimeError("Use the official HTTPS download origin.")
    with urlopen(origin + "/downloads.json", timeout=30) as response:
        if response.geturl() != origin + "/downloads.json":
            raise RuntimeError("Release catalog redirected to a different location.")
        raw = response.read(262145)
    if len(raw) > 262144:
        raise RuntimeError("Release catalog exceeded its size limit.")
    catalog = json.loads(raw)
    if catalog.get("scope") != ("local-development-preview" if preview else "public-release"):
        raise RuntimeError("The public native Windows release is not available yet.")
    rows = [row for row in catalog.get("artifacts", []) if row.get("title") == "Windows installer"]
    if len(rows) != 1:
        raise RuntimeError("Exactly one Windows installer is required.")
    artifact = rows[0]
    import re
    name, sha, size = artifact.get("filename", ""), artifact.get("sha256", ""), artifact.get("size_bytes")
    href = artifact.get("href", "")
    release_asset = bool(re.fullmatch(r"https://github\.com/Amretra-Dynamics/megasmoves/releases/download/[A-Za-z0-9._-]+/" + re.escape(name), href))
    if (not re.fullmatch(r"MegasSetup-\d+\.\d+\.\d+(?:[-.][A-Za-z0-9.-]+)?\.exe", name)
            or not re.fullmatch(r"[a-f0-9]{64}", sha) or type(size) is not int or not 2 <= size <= 2147483648
            or (not release_asset and href != "./downloads/" + name)):
        raise RuntimeError("Invalid Windows installer record.")
    base = "http://127.0.0.1:3106/megasmoves" if preview else origin
    url = href if release_asset and not preview else base + "/downloads/" + name
    with tempfile.TemporaryDirectory(prefix="MegasMoves-pip-install-") as stage:
        installer = Path(stage) / name
        digest, received = hashlib.sha256(), 0
        deadline = time.monotonic() + 600
        with urlopen(url, timeout=30) as response, installer.open("wb") as output:
            final = urlsplit(response.geturl())
            trusted_cdn = release_asset and final.scheme == "https" and final.hostname == "release-assets.githubusercontent.com" and not final.username and not final.password
            if response.geturl() != url and not trusted_cdn:
                raise RuntimeError("Installer redirected to a different location.")
            read = getattr(response, "read1", response.read)
            while block := read(1024 * 1024):
                if time.monotonic() > deadline:
                    raise RuntimeError("Installer download exceeded its time limit.")
                received += len(block)
                if received > size:
                    raise RuntimeError("Installer exceeded the declared size.")
                digest.update(block)
                output.write(block)
        if received != size or digest.hexdigest() != sha:
            raise RuntimeError("Installer size or SHA-256 verification failed.")
        with installer.open("rb") as stream:
            if stream.read(2) != b"MZ":
                raise RuntimeError("Installer is not a Windows executable.")
        from .adapters.base import subprocess_hide_window_kwargs
        subprocess.run([str(installer), "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART"],
                       check=True, timeout=600, shell=False, **subprocess_hide_window_kwargs())
    from .updater import product_install_binary
    product = product_install_binary()
    if product is None:
        raise RuntimeError("Installation did not create the canonical MegasMoves app.")
    return product
