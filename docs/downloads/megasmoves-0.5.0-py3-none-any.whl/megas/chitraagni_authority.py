from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .mcp.model import utc_now


AUTHORITY_FORMAT = "megas-chitraagni-authority"
AUTHORITY_VERSION = 2
PRODUCTION_WRITE_CAPABILITY = "production.write/v1"
REMOTE_ACCESS_CAPABILITY = "remote.access/v1"
MAX_AUTHORITY_BYTES = 2 * 1024 * 1024


def _megas_home() -> Path:
    configured = os.environ.get("MEGAS_HOME")
    return Path(configured).expanduser() if configured else Path.home() / ".megas"


def _authority_path() -> Path:
    return _megas_home() / "operator" / "chitraagni_permissions.json"


def tool_contract_fingerprint(tool: dict[str, Any]) -> str:
    """Fingerprint the public contract a human actually approved.

    A binary/app upgrade that changes the tool schema, annotations or descriptive
    contract invalidates the old grant until it is explicitly approved again.
    This prevents a familiar tool name from silently acquiring broader powers.
    """

    public = {
        key: tool.get(key)
        for key in (
            "name",
            "title",
            "description",
            "inputSchema",
            "outputSchema",
            "annotations",
            "securitySchemes",
            "_meta",
        )
        if key in tool
    }
    encoded = json.dumps(public, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def _is_remote_api(api_base: str) -> bool:
    parsed = urlsplit(api_base)
    return (parsed.hostname or "").lower() not in {"localhost", "127.0.0.1", "::1"}


def chitraagni_authority_scope(*, api_base: str, user_id: str) -> str:
    """Return a non-secret stable scope for one linked Chitraagni target identity.

    Local-development permission must never become production permission merely
    because the linked API base changes, and a grant for one Chitraagni account
    must never survive a relink to another account. The scope therefore binds
    authority to both the normalized API target and the pinned Chitraagni user.
    """

    text = str(api_base or "").strip().rstrip("/")
    user = str(user_id or "").strip()
    parsed = urlsplit(text)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Chitraagni authority scope requires an absolute http(s) API base")
    if not user:
        raise ValueError("Chitraagni authority scope requires a linked user_id")
    host = (parsed.hostname or "").lower()
    canonical_target = {
        "scheme": parsed.scheme.lower(),
        "host": host,
        "port": parsed.port,
        "path": parsed.path.rstrip("/"),
    }
    encoded = json.dumps(
        {"target": canonical_target, "user_id": user},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return "scope:sha256:" + hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True, slots=True)
class ChitraagniToolGrant:
    tool: str
    fingerprint: str
    granted_at: str


class ChitraagniAuthorityStore:
    """Machine-local authority for the built-in Chitraagni operator.

    Account linking proves identity but grants *zero* MCP invocation authority.
    Exact tool grants are fingerprint-bound, machine-local, and scoped to the
    linked user + API target. Remote access and production writes are independent
    gates in the same scope. Changing from local developer Chitraagni to hosted
    production, changing production hosts, or relinking another user therefore
    fails closed and requires explicit approval again.
    """

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or _authority_path()

    def _empty(self, *, scope: str | None = None) -> dict[str, Any]:
        return {
            "format": AUTHORITY_FORMAT,
            "version": AUTHORITY_VERSION,
            "scope": scope,
            "tool_grants": [],
            "remote_access": None,
            "production_write": None,
        }

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return self._empty()
        raw = self.path.read_bytes()
        if len(raw) > MAX_AUTHORITY_BYTES:
            raise ValueError("Chitraagni local-authority file exceeds 2 MiB")
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("Chitraagni local-authority file must contain a JSON object")
        if value.get("format") != AUTHORITY_FORMAT:
            raise ValueError("unsupported Chitraagni local-authority format")
        version = int(value.get("version") or 0)
        if version == 1:
            # Version 1 grants were not bound to an account/API target. Reusing
            # them after a relink could silently authorize another account or a
            # production endpoint. Migrate fail-closed: retain no authority.
            migrated = self._empty()
            migrated["migration"] = {
                "from_version": 1,
                "at": utc_now(),
                "reason": "unscoped grants revoked during scope-safe migration",
            }
            self._save(migrated)
            return migrated
        if version != AUTHORITY_VERSION:
            raise ValueError("unsupported Chitraagni local-authority version")
        if not isinstance(value.get("tool_grants"), list):
            raise ValueError("Chitraagni tool_grants must be an array")
        scope = value.get("scope")
        if scope is not None and (not isinstance(scope, str) or not scope.startswith("scope:sha256:")):
            raise ValueError("Chitraagni local-authority scope is malformed")
        return value

    def _save(self, value: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=f".{self.path.name}.", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    @staticmethod
    def _tool_name(tool: dict[str, Any]) -> str:
        name = str(tool.get("name") or "").strip()
        if not name.startswith("chitraagni_"):
            raise ValueError("only explicit Chitraagni operator tools can receive Chitraagni authority")
        return name

    @staticmethod
    def _require_scope(scope: str) -> str:
        value = str(scope or "").strip()
        if not value.startswith("scope:sha256:"):
            raise ValueError("a valid linked Chitraagni authority scope is required")
        return value

    def _scoped_value(self, scope: str, *, activate: bool) -> dict[str, Any]:
        scope = self._require_scope(scope)
        value = self._load()
        current = value.get("scope")
        if current == scope:
            return value
        if not activate:
            return self._empty(scope=scope)
        # Changing linked account or target invalidates all previous authority.
        # This is an authorization boundary, so fail-closed reset is preferable
        # to carrying convenience state across identities/environments.
        value = self._empty(scope=scope)
        value["scope_changed_at"] = utc_now()
        self._save(value)
        return value

    def clear(self) -> bool:
        existed = self.path.exists()
        self._save(self._empty())
        return existed

    def list_tool_grants(self, *, scope: str) -> list[ChitraagniToolGrant]:
        value = self._scoped_value(scope, activate=False)
        result: list[ChitraagniToolGrant] = []
        seen: set[str] = set()
        for row in value["tool_grants"]:
            if not isinstance(row, dict):
                raise ValueError("Chitraagni tool grant is malformed")
            tool = str(row.get("tool") or "").strip()
            fingerprint = str(row.get("fingerprint") or "").strip()
            granted_at = str(row.get("granted_at") or "").strip()
            if not tool or not fingerprint or not granted_at or tool in seen:
                raise ValueError("Chitraagni tool grant is incomplete or duplicated")
            seen.add(tool)
            result.append(ChitraagniToolGrant(tool, fingerprint, granted_at))
        return sorted(result, key=lambda row: row.tool)

    def grant_tool(self, tool: dict[str, Any], *, scope: str) -> ChitraagniToolGrant:
        name = self._tool_name(tool)
        fingerprint = tool_contract_fingerprint(tool)
        now = utc_now()
        value = self._scoped_value(scope, activate=True)
        rows = [row for row in value["tool_grants"] if isinstance(row, dict) and row.get("tool") != name]
        row = {"tool": name, "fingerprint": fingerprint, "granted_at": now}
        rows.append(row)
        value["tool_grants"] = sorted(rows, key=lambda item: str(item.get("tool") or ""))
        self._save(value)
        return ChitraagniToolGrant(name, fingerprint, now)

    def revoke_tool(self, tool_name: str, *, scope: str) -> bool:
        name = str(tool_name or "").strip()
        value = self._scoped_value(scope, activate=False)
        before = len(value["tool_grants"])
        value["tool_grants"] = [
            row for row in value["tool_grants"]
            if not isinstance(row, dict) or str(row.get("tool") or "") != name
        ]
        changed = len(value["tool_grants"]) != before
        if changed:
            self._save(value)
        return changed

    def tool_status(self, tool: dict[str, Any], *, scope: str) -> str:
        name = self._tool_name(tool)
        expected = tool_contract_fingerprint(tool)
        grant = next((row for row in self.list_tool_grants(scope=scope) if row.tool == name), None)
        if grant is None:
            return "denied"
        if grant.fingerprint != expected:
            return "stale"
        return "allowed"

    def assert_tool_allowed(self, tool: dict[str, Any], *, scope: str) -> None:
        name = self._tool_name(tool)
        status = self.tool_status(tool, scope=scope)
        if status == "stale":
            raise PermissionError(
                f"Chitraagni tool {name} changed since its local approval; review and grant the current contract again"
            )
        if status != "allowed":
            raise PermissionError(
                f"Chitraagni tool {name} is denied by Megas MCP local policy for this linked account/target; approve it explicitly before invocation"
            )

    def _set_capability(self, key: str, capability: str, allowed: bool, *, scope: str) -> None:
        value = self._scoped_value(scope, activate=True)
        value[key] = {"capability": capability, "granted_at": utc_now()} if allowed else None
        self._save(value)

    def _capability_allowed(self, key: str, capability: str, *, scope: str) -> bool:
        value = self._scoped_value(scope, activate=False)
        row = value.get(key)
        return isinstance(row, dict) and row.get("capability") == capability

    def set_remote_access(self, allowed: bool, *, scope: str) -> None:
        self._set_capability("remote_access", REMOTE_ACCESS_CAPABILITY, allowed, scope=scope)

    def set_production_write(self, allowed: bool, *, scope: str) -> None:
        self._set_capability("production_write", PRODUCTION_WRITE_CAPABILITY, allowed, scope=scope)

    def assert_target_allowed(self, *, api_base: str, mutating: bool, scope: str) -> None:
        self._require_scope(scope)
        if not _is_remote_api(api_base):
            return
        if not self._capability_allowed("remote_access", REMOTE_ACCESS_CAPABILITY, scope=scope):
            raise PermissionError(
                "remote Chitraagni access is denied by Megas MCP local policy for this linked account/target; approve remote access explicitly"
            )
        if mutating and not self._capability_allowed("production_write", PRODUCTION_WRITE_CAPABILITY, scope=scope):
            raise PermissionError(
                "hosted Chitraagni mutation requires the additional Megas MCP production.write approval for this linked account/target"
            )

    def status(
        self,
        tools: list[dict[str, Any]] | None = None,
        *,
        api_base: str | None = None,
        scope: str | None = None,
    ) -> dict[str, Any]:
        active_scope = self._require_scope(scope) if scope is not None else None
        stored = self._load()
        scope_matches = active_scope is not None and stored.get("scope") == active_scope
        if active_scope is None:
            scoped = self._empty()
        else:
            scoped = self._scoped_value(active_scope, activate=False)
        tool_rows = []
        if tools is not None and active_scope is not None:
            tool_rows = [
                {
                    "tool": self._tool_name(tool),
                    "status": self.tool_status(tool, scope=active_scope),
                    "read_only": bool((tool.get("annotations") or {}).get("readOnlyHint", False)),
                    "destructive": bool((tool.get("annotations") or {}).get("destructiveHint", False)),
                }
                for tool in tools
                if str(tool.get("name") or "").startswith("chitraagni_")
            ]
        remote_allowed = bool(
            active_scope
            and self._capability_allowed("remote_access", REMOTE_ACCESS_CAPABILITY, scope=active_scope)
        )
        production_write = bool(
            active_scope
            and self._capability_allowed("production_write", PRODUCTION_WRITE_CAPABILITY, scope=active_scope)
        )
        grants = self.list_tool_grants(scope=active_scope) if active_scope else []
        return {
            "deny_by_default": True,
            "api_target": (
                "remote" if api_base and _is_remote_api(api_base) else "local"
                if api_base else None
            ),
            "authority_scope": active_scope,
            "scope_matches_stored_authority": scope_matches,
            "remote_access": remote_allowed,
            "production_write": production_write,
            "tool_grants": [
                {"tool": row.tool, "fingerprint": row.fingerprint, "granted_at": row.granted_at}
                for row in grants
            ],
            "tools": tool_rows,
            "portable": False,
            "stored_at": str(self.path),
            "format": stored["format"],
            "version": stored["version"],
            "migration": stored.get("migration"),
        }


__all__ = [
    "AUTHORITY_FORMAT",
    "AUTHORITY_VERSION",
    "ChitraagniAuthorityStore",
    "ChitraagniToolGrant",
    "PRODUCTION_WRITE_CAPABILITY",
    "REMOTE_ACCESS_CAPABILITY",
    "chitraagni_authority_scope",
    "tool_contract_fingerprint",
]
