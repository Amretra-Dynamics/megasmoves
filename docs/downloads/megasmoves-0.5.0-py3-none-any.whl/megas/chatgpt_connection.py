"""Human-controlled OpenAI tunnel lifecycle for the packaged Windows product."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import uuid

from megas.credential_store import WindowsDPAPICredentialStore
from megas.adapters.base import windows_subprocess_kwargs


class RuntimeNotFound(RuntimeError):
    pass


class ChatGPTConnection:
    def __init__(self, home=None, *, client=None, executable=None, owner=None):
        self.home = Path(home or os.environ.get("MEGAS_HOME") or Path.home() / ".megas")
        self.store = WindowsDPAPICredentialStore(self.home / "chatgpt" / "connection.credential")
        self.client = Path(client or Path(sys.executable).parent / "tunnel-client.exe")
        self.executable = Path(executable or os.environ.get("MEGAS_EXECUTABLE") or "")
        self.owner = owner or self._firebase_owner
        self._lock = threading.RLock()
        self._busy = False
        self._last_poll = 0.0
        self._supervisor = None
        self._stop_reconnect = threading.Event()
        self._next_retry = 0.0
        self._retry_failures = 0
        self._unhealthy_checks = 0
        self._last_unhealthy_check = float('-inf')
        self._last_health_restart = float('-inf')
        self._status = {"state": "not_configured", "process_running": False, "healthy": False, "ready": False}

    @staticmethod
    def _firebase_owner():
        from megas.firebase_account import status
        account = status()
        if not account.get("firebase_authenticated"):
            raise PermissionError("Sign in to Amretra Firebase before connecting ChatGPT")
        return account["identity"]["user_id"]

    def _settings(self):
        return json.loads(self.store.read()) if self.store.exists() else None

    def configure(self, tunnel_id, runtime_key="", *, auto_connect=True):
        if not isinstance(tunnel_id, str) or not re.fullmatch(r"tunnel_[a-zA-Z0-9_-]{16,80}", tunnel_id):
            raise ValueError("Enter a valid OpenAI tunnel ID")
        with self._lock:
            if self._busy:
                raise RuntimeError("ChatGPT connection is busy")
            owner = self.owner()
            existing = self._settings()
            if existing and existing["owner"] != owner:
                raise PermissionError("Forget the previous account's connection before configuring another account")
            if existing:
                self._last_poll = 0
                current = self.status()
                if current.get("process_running") or current["state"] == "status_unavailable":
                    raise RuntimeError("Disconnect before changing the tunnel configuration")
            key = runtime_key or (existing or {}).get("runtime_key", "")
            if not isinstance(key, str) or not key.startswith("sk-") or not 10 <= len(key) <= 4096:
                raise ValueError("Enter an OpenAI runtime API key with tunnel permissions")
            settings = {"version": 1, "owner": owner, "tunnel_id": tunnel_id, "runtime_key": key,
                        "alias": (existing or {}).get("alias") or "megas-" + uuid.uuid4().hex,
                        "auto_connect": bool(auto_connect)}
            self.store.write(json.dumps(settings))
            self._status = {"state": "disconnected", "process_running": False, "healthy": False, "ready": False}
            self._last_poll = 0
        return self.status(refresh=False)

    def _run(self, arguments, settings, *, timeout=10):
        if not self.client.is_file():
            raise RuntimeError("Bundled OpenAI tunnel client is missing; reinstall Megas Moves")
        environment = dict(os.environ)
        environment["MEGAS_TUNNEL_RUNTIME_KEY"] = settings["runtime_key"]
        environment["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
        # Kill-on-close parent containment remains; managed runtime supervision
        # is delegated to the official client, never a shell or arbitrary argv.
        completed = subprocess.run([str(self.client), "runtimes", *arguments], env=environment,
                                   capture_output=True, text=True, encoding="utf-8", errors="replace",
                                   timeout=timeout, stdin=subprocess.DEVNULL,
                                   **windows_subprocess_kwargs())
        if len(completed.stdout) > 256 * 1024 or len(completed.stderr) > 256 * 1024:
            raise RuntimeError("Tunnel client response exceeded the limit")
        if completed.returncode:
            if f"alias {settings['alias']} is not known" in completed.stderr:
                raise RuntimeNotFound("Tunnel runtime has not been started")
            # Do not reflect vendor diagnostics or credentials into UI/history.
            raise RuntimeError("OpenAI tunnel operation failed; check the tunnel ID, runtime key, permissions, and internet connection")
        return completed.stdout

    @staticmethod
    def _flags(payload):
        # Official v0.0.15 status exposes these at the root. Never infer ready
        # from nested diagnostics, strings, or historical process records.
        if not isinstance(payload, dict):
            raise ValueError("Unexpected tunnel status")
        flags = {key: payload.get(key) is True for key in ("process_running", "healthy", "ready")}
        poll = payload.get("control_plane_poll_health")
        if isinstance(poll, dict) and poll.get("state") not in (None, "", "healthy", "direct", "unknown"):
            flags["ready"] = False
        flags["ready"] = all(flags.values())
        return flags

    def status(self, *, refresh=True):
        with self._lock:
            try:
                settings = self._settings()
            except Exception:
                return {"state": "credential_unavailable", "configured": self.store.exists(),
                        "client_available": self.client.is_file(), "tunnel_id": "", "auto_connect": False,
                        "process_running": False, "healthy": False, "ready": False}
            result = {**self._status, "configured": bool(settings), "client_available": self.client.is_file(),
                      "tunnel_id": (settings or {}).get("tunnel_id", ""),
                      "auto_connect": (settings or {}).get("auto_connect", False)}
            if not settings or not refresh or self._busy or time.monotonic() - self._last_poll < 10:
                return result
            self._last_poll = time.monotonic()
        try:
            payload = json.loads(self._run(["status", settings["alias"], "--json"], settings, timeout=5))
            flags = self._flags(payload)
            state = "ready" if all(flags.values()) else "connecting" if flags["process_running"] else "disconnected"
            poll = payload.get('control_plane_poll_health')
            update = {"state": state, **flags,
                      "polling_unhealthy": isinstance(poll, dict) and poll.get('state') == 'unhealthy'}
        except RuntimeNotFound:
            update = {"state": "disconnected", "process_running": False, "healthy": False, "ready": False}
        except Exception:
            update = {"state": "status_unavailable", "process_running": False, "healthy": False, "ready": False}
        with self._lock:
            self._status = update
            return {**result, **update}

    def connect(self, *, automatic=False):
        with self._lock:
            if self._busy:
                raise RuntimeError("ChatGPT connection is busy")
            settings = self._settings()
            if not settings:
                raise ValueError("Configure the tunnel ID and runtime key first")
            # Recheck persisted human intent at dispatch, not only when the
            # monitor observed a stopped runtime. Disconnect must remain final.
            if automatic and not settings.get("auto_connect"):
                return self.status(refresh=False)
            if settings["owner"] != self.owner():
                raise PermissionError("This connection belongs to a different Amretra account")
            if not self.executable.is_file():
                raise RuntimeError("Megas Moves product executable is unavailable")
            self._busy = True
            self._status = {"state": "connecting", "process_running": False, "healthy": False, "ready": False}
        try:
            self._run(["connect", "--alias", settings["alias"], "--profile", settings["alias"],
                       "--profile-dir", str(self.home / "chatgpt" / "profiles"),
                       "--tunnel-id", settings["tunnel_id"],
                       # The official client parses this command with shell-style
                       # quoting, even on Windows. Forward slashes preserve the
                       # absolute path instead of treating backslashes as escapes.
                       "--mcp-command", f'"{self.executable.resolve().as_posix()}" serve',
                       "--runtime-api-key", "env:MEGAS_TUNNEL_RUNTIME_KEY"], settings, timeout=60)
            with self._lock:
                if not automatic:
                    settings["auto_connect"] = True
                    self.store.write(json.dumps(settings))
        except Exception as exc:
            with self._lock:
                self._status = {"state": "connection_failed", "process_running": False, "healthy": False, "ready": False}
            raise RuntimeError("ChatGPT connection failed; verify your OpenAI tunnel access and network") from exc
        finally:
            with self._lock:
                self._busy = False
                self._last_poll = 0
        return self.status()

    def disconnect(self, *, forget=False, suspend=False):
        with self._lock:
            if self._busy:
                raise RuntimeError("ChatGPT connection is busy")
            settings = self._settings()
            if not settings:
                return self.status(refresh=False)
            # Consult the official supervisor before claiming a running process stopped.
            try:
                self._run(["stop", settings["alias"], "--json"], settings, timeout=15)
            except RuntimeNotFound:
                pass
            if forget:
                self.store.delete()
            elif not suspend:
                settings["auto_connect"] = False
                self.store.write(json.dumps(settings))
            self._status = {"state": "not_configured" if forget else "disconnected", "process_running": False, "healthy": False, "ready": False}
            self._last_poll = time.monotonic()
        return self.status(refresh=False)

    def _reconnect_once(self, *, now=None):
        now = time.monotonic() if now is None else now
        with self._lock:
            if self._busy or self._stop_reconnect.is_set() or now < self._next_retry:
                return
            try:
                settings = self._settings()
            except Exception:
                self._status = {"state": "credential_unavailable", "process_running": False, "healthy": False, "ready": False}
                return
            if not settings or not settings.get("auto_connect"):
                return
        current = self.status()
        if current.get("ready"):
            with self._lock:
                self._retry_failures = 0
                self._next_retry = 0
                self._unhealthy_checks = 0
            return
        # Only explicit unhealthy poll evidence can trigger recovery of a live
        # process. Three spaced observations and a five-minute cooldown avoid
        # replacing a starting/unknown runtime or creating restart storms.
        if current.get('process_running') and current.get('polling_unhealthy') is True:
            with self._lock:
                if now - self._last_unhealthy_check < 10:
                    return
                self._last_unhealthy_check = now
                self._unhealthy_checks += 1
                if self._unhealthy_checks < 3 or now - self._last_health_restart < 300:
                    return
                self._last_health_restart = now
                self._unhealthy_checks = 0
                self._next_retry = now + 30
            # Use the official supervisor; do not kill an unknown process.
            # Preserve the owner's auto-connect choice and encrypted identity.
            self.disconnect(suspend=True)
            with self._lock:
                self._last_poll = 0
            stopped = self.status()
            if stopped.get('state') != 'disconnected' or stopped.get('process_running'):
                return
            self.connect(automatic=True)
            return
        self._unhealthy_checks = 0
        # An unavailable status is not proof of a dead runtime. Never replace
        # a running/unknown supervisor or create duplicate operator processes.
        if current.get("process_running") or current["state"] not in {"disconnected", "connection_failed"}:
            return
        with self._lock:
            self._next_retry = now + 10
        try:
            result = self.connect(automatic=True)
            failed = not result.get("process_running")
        except Exception:
            failed = True
        with self._lock:
            if failed:
                self._retry_failures = min(self._retry_failures + 1, 6)
                self._next_retry = now + min(10 * 2 ** (self._retry_failures - 1), 300)
            else:
                self._retry_failures = 0
                self._next_retry = 0

    def stop_reconnect(self):
        """Stop local monitoring without changing the human's saved choice."""
        self._stop_reconnect.set()

    def resume(self):
        try:
            settings = self._settings()
        except Exception:
            self._status = {"state": "credential_unavailable", "process_running": False, "healthy": False, "ready": False}
            return
        if settings and settings.get("auto_connect"):
            with self._lock:
                if self._supervisor is not None and self._supervisor.is_alive():
                    return
                self._stop_reconnect.clear()
                def run():
                    while not self._stop_reconnect.is_set():
                        try:
                            self._reconnect_once()
                        except Exception:
                            # Keep diagnostics bounded and credentials private.
                            pass
                        self._stop_reconnect.wait(10)
                self._supervisor = threading.Thread(target=run, name="MegasChatGPTReconnect", daemon=True)
                self._supervisor.start()
