from __future__ import annotations

import base64
import json
import os
import shutil
import subprocess
from megas.adapters.base import windows_subprocess_kwargs
import sys
import tempfile
from pathlib import Path
from typing import Any


CREDENTIAL_FORMAT = "megas-windows-dpapi-credential"
CREDENTIAL_VERSION = 1
MAX_CREDENTIAL_BYTES = 1024 * 1024
KEYCHAIN_SERVICE = b"com.amretra.megasmoves.chitraagni"
KEYCHAIN_ACCOUNT = b"access-token"
LINUX_SECRET_ATTRIBUTES = ("service", "megasmoves", "account", "chitraagni-access-token")


def _megas_home() -> Path:
    configured = os.environ.get("MEGAS_HOME")
    return Path(configured).expanduser() if configured else Path.home() / ".megas"


def _default_path() -> Path:
    return _megas_home() / "operator" / "chitraagni.credential"


def _atomic_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _windows_dpapi_protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI credential storage is available only on Windows")

    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    buffer = ctypes.create_string_buffer(data)
    input_blob = DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    output_blob = DATA_BLOB()
    CRYPTPROTECT_UI_FORBIDDEN = 0x1
    description = "MegasMoves Chitraagni credential"

    # Private DLL/function bindings avoid another credential helper changing
    # ctypes.windll's cached function argument types to a different DATA_BLOB.
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    protect = crypt32.CryptProtectData
    protect.argtypes = [ctypes.POINTER(DATA_BLOB), wintypes.LPCWSTR,
                        ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p,
                        wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
    protect.restype = wintypes.BOOL
    local_free = kernel32.LocalFree
    local_free.argtypes = [ctypes.c_void_p]
    local_free.restype = ctypes.c_void_p
    ok = protect(
        ctypes.byref(input_blob),
        description,
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(output_blob),
    )
    if not ok:
        raise OSError(ctypes.get_last_error(), "CryptProtectData failed")
    try:
        return ctypes.string_at(output_blob.pbData, output_blob.cbData)
    finally:
        local_free(output_blob.pbData)


def _windows_dpapi_unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI credential storage is available only on Windows")

    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    buffer = ctypes.create_string_buffer(data)
    input_blob = DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    output_blob = DATA_BLOB()
    CRYPTPROTECT_UI_FORBIDDEN = 0x1

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    unprotect = crypt32.CryptUnprotectData
    unprotect.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_void_p,
                          ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p,
                          wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
    unprotect.restype = wintypes.BOOL
    local_free = kernel32.LocalFree
    local_free.argtypes = [ctypes.c_void_p]
    local_free.restype = ctypes.c_void_p
    ok = unprotect(
        ctypes.byref(input_blob),
        None,
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(output_blob),
    )
    if not ok:
        raise OSError(ctypes.get_last_error(), "CryptUnprotectData failed")
    try:
        return ctypes.string_at(output_blob.pbData, output_blob.cbData)
    finally:
        local_free(output_blob.pbData)


class WindowsDPAPICredentialStore:
    kind = "windows-dpapi"

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or _default_path()

    @staticmethod
    def available() -> bool:
        return os.name == "nt"

    def exists(self) -> bool:
        return self.path.is_file()

    def write(self, token: str) -> None:
        value = str(token or "").strip()
        if not value:
            raise ValueError("credential token must be non-empty")
        protected = _windows_dpapi_protect(value.encode("utf-8"))
        payload = {
            "format": CREDENTIAL_FORMAT,
            "version": CREDENTIAL_VERSION,
            "protected": base64.b64encode(protected).decode("ascii"),
        }
        raw = (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
        if len(raw) > MAX_CREDENTIAL_BYTES:
            raise ValueError("protected credential is unexpectedly large")
        _atomic_bytes(self.path, raw)

    def read(self) -> str:
        if not self.path.is_file():
            raise RuntimeError("stored Chitraagni credential is missing")
        raw = self.path.read_bytes()
        if len(raw) > MAX_CREDENTIAL_BYTES:
            raise ValueError("credential file exceeds size limit")
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("credential file is malformed")
        if value.get("format") != CREDENTIAL_FORMAT or int(value.get("version") or 0) != CREDENTIAL_VERSION:
            raise ValueError("unsupported credential format")
        encoded = str(value.get("protected") or "")
        if not encoded:
            raise ValueError("credential file has no protected payload")
        try:
            protected = base64.b64decode(encoded, validate=True)
        except Exception as exc:
            raise ValueError("credential protected payload is invalid") from exc
        token = _windows_dpapi_unprotect(protected).decode("utf-8").strip()
        if not token:
            raise RuntimeError("stored Chitraagni credential decrypted to an empty value")
        return token

    def delete(self) -> bool:
        existed = self.path.exists()
        self.path.unlink(missing_ok=True)
        return existed

    def metadata(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "available": self.available(),
            "stored": self.exists(),
            "path": str(self.path),
        }


def _mac_security_handles() -> tuple[Any, Any]:
    if sys.platform != "darwin":
        raise RuntimeError("macOS Keychain credential storage is available only on macOS")
    import ctypes
    from ctypes.util import find_library

    security_path = find_library("Security") or "/System/Library/Frameworks/Security.framework/Security"
    core_path = find_library("CoreFoundation") or "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation"
    return ctypes.CDLL(security_path), ctypes.CDLL(core_path)


class MacOSKeychainCredentialStore:
    """Store the Chitraagni token in the current user's default macOS Keychain.

    The Security.framework API is used directly so the secret is never placed in
    a command-line argument or a Megas-owned plaintext file.
    """

    kind = "macos-keychain"
    ERR_SEC_ITEM_NOT_FOUND = -25300

    @staticmethod
    def available() -> bool:
        return sys.platform == "darwin"

    @staticmethod
    def _find() -> tuple[int, Any, Any, int, Any]:
        import ctypes

        security, core = _mac_security_handles()
        password_length = ctypes.c_uint32(0)
        password_data = ctypes.c_void_p()
        item = ctypes.c_void_p()
        security.SecKeychainFindGenericPassword.restype = ctypes.c_int32
        status = int(
            security.SecKeychainFindGenericPassword(
                None,
                len(KEYCHAIN_SERVICE),
                KEYCHAIN_SERVICE,
                len(KEYCHAIN_ACCOUNT),
                KEYCHAIN_ACCOUNT,
                ctypes.byref(password_length),
                ctypes.byref(password_data),
                ctypes.byref(item),
            )
        )
        return status, security, core, int(password_length.value), (password_data, item)

    def exists(self) -> bool:
        if not self.available():
            return False
        import ctypes

        status, security, core, length, handles = self._find()
        password_data, item = handles
        try:
            if status == 0:
                return True
            if status == self.ERR_SEC_ITEM_NOT_FOUND:
                return False
            raise OSError(status, "SecKeychainFindGenericPassword failed")
        finally:
            if status == 0 and password_data:
                security.SecKeychainItemFreeContent(None, password_data)
            if item:
                core.CFRelease(ctypes.c_void_p(item.value))

    def write(self, token: str) -> None:
        if not self.available():
            raise RuntimeError("macOS Keychain credential storage is unavailable")
        import ctypes

        value = str(token or "").strip()
        if not value:
            raise ValueError("credential token must be non-empty")
        raw = value.encode("utf-8")
        status, security, core, _length, handles = self._find()
        password_data, item = handles
        try:
            if status == 0:
                security.SecKeychainItemModifyAttributesAndData.restype = ctypes.c_int32
                changed = int(
                    security.SecKeychainItemModifyAttributesAndData(
                        item,
                        None,
                        len(raw),
                        raw,
                    )
                )
                if changed != 0:
                    raise OSError(changed, "SecKeychainItemModifyAttributesAndData failed")
                return
            if status != self.ERR_SEC_ITEM_NOT_FOUND:
                raise OSError(status, "SecKeychainFindGenericPassword failed")
            created = ctypes.c_void_p()
            security.SecKeychainAddGenericPassword.restype = ctypes.c_int32
            added = int(
                security.SecKeychainAddGenericPassword(
                    None,
                    len(KEYCHAIN_SERVICE),
                    KEYCHAIN_SERVICE,
                    len(KEYCHAIN_ACCOUNT),
                    KEYCHAIN_ACCOUNT,
                    len(raw),
                    raw,
                    ctypes.byref(created),
                )
            )
            if added != 0:
                raise OSError(added, "SecKeychainAddGenericPassword failed")
            if created:
                core.CFRelease(created)
        finally:
            if status == 0 and password_data:
                security.SecKeychainItemFreeContent(None, password_data)
            if item:
                core.CFRelease(item)

    def read(self) -> str:
        if not self.available():
            raise RuntimeError("macOS Keychain credential storage is unavailable")
        import ctypes

        status, security, core, length, handles = self._find()
        password_data, item = handles
        try:
            if status == self.ERR_SEC_ITEM_NOT_FOUND:
                raise RuntimeError("stored Chitraagni credential is missing")
            if status != 0:
                raise OSError(status, "SecKeychainFindGenericPassword failed")
            raw = ctypes.string_at(password_data, length)
            value = raw.decode("utf-8").strip()
            if not value:
                raise RuntimeError("stored Chitraagni credential is empty")
            return value
        finally:
            if status == 0 and password_data:
                security.SecKeychainItemFreeContent(None, password_data)
            if item:
                core.CFRelease(item)

    def delete(self) -> bool:
        if not self.available():
            return False
        import ctypes

        status, security, core, _length, handles = self._find()
        password_data, item = handles
        try:
            if status == self.ERR_SEC_ITEM_NOT_FOUND:
                return False
            if status != 0:
                raise OSError(status, "SecKeychainFindGenericPassword failed")
            security.SecKeychainItemDelete.restype = ctypes.c_int32
            deleted = int(security.SecKeychainItemDelete(item))
            if deleted != 0:
                raise OSError(deleted, "SecKeychainItemDelete failed")
            return True
        finally:
            if status == 0 and password_data:
                security.SecKeychainItemFreeContent(None, password_data)
            if item:
                core.CFRelease(item)

    def metadata(self) -> dict[str, Any]:
        return {"kind": self.kind, "available": self.available(), "stored": self.exists()}


class LinuxSecretServiceCredentialStore:
    """Store the token through libsecret's `secret-tool` command.

    The secret is provided on stdin rather than argv, avoiding process-list
    exposure. `secret-tool` is the standard CLI for Secret Service/libsecret.
    """

    kind = "linux-secret-service"

    @staticmethod
    def available() -> bool:
        return sys.platform.startswith("linux") and shutil.which("secret-tool") is not None

    @staticmethod
    def _run(args: list[str], *, input_text: str | None = None) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["secret-tool", *args],
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10.0,
            check=False,
            shell=False,
            **windows_subprocess_kwargs(),
        )

    def exists(self) -> bool:
        if not self.available():
            return False
        result = self._run(["lookup", *LINUX_SECRET_ATTRIBUTES])
        return result.returncode == 0 and bool(result.stdout.strip())

    def write(self, token: str) -> None:
        if not self.available():
            raise RuntimeError("Linux Secret Service credential storage is unavailable; install libsecret/secret-tool or use a token environment reference")
        value = str(token or "").strip()
        if not value:
            raise ValueError("credential token must be non-empty")
        result = self._run(
            ["store", "--label=MegasMoves Chitraagni credential", *LINUX_SECRET_ATTRIBUTES],
            input_text=value + "\n",
        )
        if result.returncode != 0:
            raise RuntimeError("Linux Secret Service failed to store the Chitraagni credential")

    def read(self) -> str:
        if not self.available():
            raise RuntimeError("Linux Secret Service credential storage is unavailable")
        result = self._run(["lookup", *LINUX_SECRET_ATTRIBUTES])
        value = result.stdout.strip() if result.returncode == 0 else ""
        if not value:
            raise RuntimeError("stored Chitraagni credential is missing")
        return value

    def delete(self) -> bool:
        if not self.available():
            return False
        existed = self.exists()
        result = self._run(["clear", *LINUX_SECRET_ATTRIBUTES])
        if result.returncode != 0 and existed:
            raise RuntimeError("Linux Secret Service failed to delete the Chitraagni credential")
        return existed

    def metadata(self) -> dict[str, Any]:
        return {"kind": self.kind, "available": self.available(), "stored": self.exists()}


def secure_credential_store(kind: str | None = None) -> Any:
    requested = str(kind or "").strip().lower()
    if requested:
        stores = {
            WindowsDPAPICredentialStore.kind: WindowsDPAPICredentialStore,
            MacOSKeychainCredentialStore.kind: MacOSKeychainCredentialStore,
            LinuxSecretServiceCredentialStore.kind: LinuxSecretServiceCredentialStore,
        }
        cls = stores.get(requested)
        if cls is None:
            raise ValueError(f"unsupported secure credential kind: {requested}")
        store = cls()
        if not store.available():
            raise RuntimeError(f"secure credential store is unavailable: {requested}")
        return store

    for cls in (
        WindowsDPAPICredentialStore,
        MacOSKeychainCredentialStore,
        LinuxSecretServiceCredentialStore,
    ):
        store = cls()
        if store.available():
            return store
    raise RuntimeError(
        "no supported native secure credential store is available; use a Chitraagni token environment reference"
    )


__all__ = [
    "CREDENTIAL_FORMAT",
    "CREDENTIAL_VERSION",
    "LinuxSecretServiceCredentialStore",
    "MacOSKeychainCredentialStore",
    "WindowsDPAPICredentialStore",
    "secure_credential_store",
]
