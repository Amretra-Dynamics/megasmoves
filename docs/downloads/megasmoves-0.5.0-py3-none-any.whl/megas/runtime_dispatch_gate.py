"""Pure fail-closed dispatch decisions for certified coding-agent runtimes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


# Include every recognized legacy coding-agent ID, not only the launch matrix.
# Unsupported/uncertifiable extras must hit this gate and be denied because the
# runtime manifest cannot provide a matching verified installation report.
EXECUTABLE_AGENT_TYPES = frozenset(
    {
        "codex_cli",
        "antigravity",
        "grok_build",
        "devin_cli",
        "cursor_cli",
        "jules_cli",
        "kilo_code",
        "opencode",
        "cline",
        "claude_code",
        "aider",
        "kiro_code",
        "kimi_code",
        "glm_code",
    }
)

_BASE_EXECUTION_CAPABILITIES = frozenset({"new_thread", "realtime_stream"})
_RESUME_CAPABILITIES = frozenset(
    {
        "thread_read",
        "exact_resume",
        "native_persistence",
        "reconciliation",
    }
)
_VERIFIED_STATUSES = frozenset({"verified", "certified"})


@dataclass(frozen=True)
class DispatchGateDecision:
    allowed: bool
    reason: str
    required_capabilities: tuple[str, ...]


def required_capabilities(command: Mapping[str, Any]) -> frozenset[str]:
    """Derive the exact certificate capabilities needed by one dispatch."""

    pack = command.get("context_pack")
    context = pack if isinstance(pack, Mapping) else {}
    required = set(_BASE_EXECUTION_CAPABILITIES)
    native_id = str(
        context.get("provider_session_id")
        or context.get("native_thread_id")
        or context.get("native_id")
        or command.get("provider_session_id")
        or ""
    ).strip()
    resume = bool(
        context.get("resume_existing") is True
        or context.get("megas_thread_id")
        or command.get("megas_thread_id")
    )
    if native_id or resume:
        required.update(_RESUME_CAPABILITIES)
    return frozenset(required)


def evaluate_dispatch_report(
    report: Mapping[str, Any] | None,
    *,
    required: frozenset[str],
) -> DispatchGateDecision:
    """Allow dispatch only from a matching, runtime-verified manifest report."""

    ordered_required = tuple(sorted(required))
    if not isinstance(report, Mapping):
        return DispatchGateDecision(False, "runtime_certification_report_missing", ordered_required)
    if str(report.get("status") or "") != "available":
        reason = str(
            report.get("certification_reason")
            or report.get("reason")
            or "runtime_certification_required"
        )
        return DispatchGateDecision(False, reason, ordered_required)
    certification_status = str(report.get("certification_status") or "").lower()
    if certification_status not in _VERIFIED_STATUSES:
        return DispatchGateDecision(
            False,
            f"runtime_certification_status:{certification_status or 'missing'}",
            ordered_required,
        )
    verified = {
        str(item).strip()
        for item in report.get("verified_capabilities") or []
        if str(item).strip()
    }
    missing = sorted(required - verified)
    if missing:
        return DispatchGateDecision(
            False,
            f"runtime_capability_unverified:{missing[0]}",
            ordered_required,
        )
    return DispatchGateDecision(True, "runtime_certification_verified", ordered_required)
