import hashlib
import json
import os
import platform
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from .thread_model import LogicalThread

def _prepare_frozen_sqlite_search_path() -> None:
    """Onefile (Py 3.14) needs MEIPASS on PATH so _sqlite3.pyd finds sqlite3.dll."""
    import sys

    if not getattr(sys, "frozen", False):
        return
    meipass = getattr(sys, "_MEIPASS", None)
    if not meipass:
        return
    try:
        if hasattr(os, "add_dll_directory"):
            os.add_dll_directory(str(meipass))
    except Exception:
        pass
    try:
        path = os.environ.get("PATH", "")
        if str(meipass) not in path.split(os.pathsep):
            os.environ["PATH"] = str(meipass) + os.pathsep + path
    except Exception:
        pass


# Lazy sqlite so JSONL thr_ readers (Grok/Claude) still work if the frozen
# binary is missing _sqlite3 (PyInstaller/Python 3.14 packaging edge).
_prepare_frozen_sqlite_search_path()
try:
    import sqlite3  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    sqlite3 = None  # type: ignore


def _require_sqlite3():
    """Return sqlite3 module or raise a clear packaging error."""
    if sqlite3 is None:
        raise RuntimeError(
            "sqlite3/_sqlite3 unavailable in this worker build; "
            "rebuild megasmoves with --hidden-import sqlite3 and sqlite DLLs"
        )
    return sqlite3

_METADATA_RE = re.compile(r"(?is)<ADDITIONAL_METADATA>.*?</ADDITIONAL_METADATA>")
_USER_REQUEST_RE = re.compile(r"(?is)</?USER_REQUEST>")
_USER_SETTINGS_RE = re.compile(r"(?is)<USER_SETTINGS_CHANGE>.*?</USER_SETTINGS_CHANGE>")
# Grok Build wraps real user turns; docs: ~/.grok/docs/user-guide/17-sessions.md
_GROK_USER_QUERY_RE = re.compile(r"(?is)<user_query>\s*(.*?)\s*</user_query>")
_GROK_SKIP_SYNTHETIC = frozenset(
    {
        "compaction_meta",
        "project_instructions",
        "system_reminder",
        "user_guide",
        "skills",
    }
)
# Parser provenance for thr_ metadata (do not merge with pre-adapter garbage).
_GROK_PARSER_VERSION = "grok_build.v2.updates_jsonl"
# Bump when native parsers change so in-memory (and future persisted) cursors
# force a full re-upload of existing thr_ history (old sync priority).
_NATIVE_PARSER_EPOCH = "pv10-agy-lineage-install"


def _cursor_with_epoch(cursor: str) -> str:
    """Append parser epoch so stale thr_ re-sync after adapter fixes."""
    base = str(cursor or "").strip()
    if not base:
        return _NATIVE_PARSER_EPOCH
    if base.endswith(f"|{_NATIVE_PARSER_EPOCH}") or base == _NATIVE_PARSER_EPOCH:
        return base
    return f"{base}|{_NATIVE_PARSER_EPOCH}"


def _normalize_project_path(path: Optional[str]) -> Optional[str]:
    """Strip Windows \\\\?\\ prefixes so worker allowlists match thr_ project_path.

    Never persist disposable light-chat sandboxes (``/tmp/megas-opencode-*``) —
    thr_ continue would fail with "Workspace is not allowed" after cleanup.
    """
    if not path:
        return path
    raw = str(path).strip()
    if raw.startswith("\\\\?\\"):
        raw = raw[4:]
    elif raw.startswith("//?/"):
        raw = raw[4:]
    if raw.upper().startswith("UNC\\"):
        raw = "\\" + raw[3:]
    try:
        from megas.policy import is_ephemeral_megas_sandbox

        if is_ephemeral_megas_sandbox(raw):
            return None
    except Exception:
        # Keep path if policy import fails; better a stale path than a crash.
        pass
    try:
        return str(Path(raw).expanduser().resolve())
    except Exception:
        return raw


def _sanitize_provider_text(text: Optional[str]) -> str:
    """Strip provider scaffolding so Megas never indexes garbage as chat turns."""
    if not text:
        return ""
    cleaned = _METADATA_RE.sub("", str(text))
    cleaned = _USER_SETTINGS_RE.sub("", cleaned)
    cleaned = _USER_REQUEST_RE.sub("", cleaned)
    cleaned = cleaned.replace("<USER_REQUEST>\n", "").replace("\n</USER_REQUEST>", "")
    # Agent transcripts can carry raw bytes from tool output. PostgreSQL rejects NUL in a
    # string literal ("A string literal cannot contain NUL (0x00) characters"), which made
    # /threads/sync return 500 and left long conversations permanently stuck mid-upload
    # (observed on grok_build 019f6599… seq=2937 and two Codex threads). Drop NUL and other
    # non-printable control bytes, keeping tab/newline/carriage return.
    if "\x00" in cleaned:
        cleaned = cleaned.replace("\x00", "")
    cleaned = "".join(
        ch for ch in cleaned if ch in "\t\n\r" or ord(ch) >= 0x20
    )
    return cleaned.strip()


# Keep /threads/sync under nginx client_max_body_size (50M) and open latency budgets.
_MAX_FIELD_CHARS = 8000
# Periodic sync bounds the REQUEST, not the conversation. Truncating to the newest N
# messages permanently clipped long chats (threads visibly "stopped at 40"), and no cap
# value is ever right: it is either too small for a real conversation or too large for a
# proxy. Whole transcripts are uploaded as a sequence of chunks of this size, upserted by
# native seq so retries are idempotent. Cost per cycle stays bounded by chunk size
# regardless of how much history a machine holds.
_MSGS_PER_SYNC_REQUEST = max(
    25,
    int(os.environ.get("MEGAS_THREAD_SYNC_MSGS_PER_REQUEST") or 250),
)
# Open/exact read: richer window for one conversation the user actually opened.
_MAX_MSGS_EXACT_READ = 400
# Index size per provider (metadata only until cursor advances).
# A real developer machine holds far more than a few hundred conversations: this owner's
# PC has 1,944 Codex rollout files, and a ceiling of 500 meant the older ~1,400 local
# chats were never indexed, so they could never appear on the phone or be resumed.
# The index is metadata + cursor only (full transcripts still load on demand), so the
# ceiling is raised and made tunable per machine.
_DEFAULT_LIMIT_PER_AGENT = max(
    100,
    int(os.environ.get("MEGAS_THREAD_INDEX_LIMIT_PER_AGENT") or 5000),
)
# Full transcript posts per heartbeat cycle — product chat, not Drive backup.
# High enough for historical old-sync; per-thread isolation + 40-msg caps prevent timeout abort.
_MAX_FULL_SYNCS_PER_CYCLE = 80

# Production chat plane: real coding CLIs with native stores. Not random home-folder crawl.
# External-v1 (B.1 Tier 4): Kilo stays RESEARCHED/disabled for product sync until Phase-0
# proves exact non-interactive resume of an arbitrary historical thread.
CORE_SYNC_AGENTS = frozenset(
    {
        "codex_cli",
        "claude_code",
        "antigravity",
        "grok_build",
        # gemini_cli abandoned — AGY transcripts already cover that binary
        "opencode",
        # "kilo_code" — gated off (external-v1 Tier 4)
    }
)


def _worker_installation_id() -> str:
    """Stable, secret-free worker install fingerprint (rotates with MEGAS_HOME / host)."""
    home = (os.getenv("MEGAS_HOME") or "").strip() or str(Path.home() / ".megasmoves")
    try:
        home = str(Path(home).expanduser().resolve())
    except Exception:
        pass
    material = f"megas-worker-install-v1|{home}|{platform.node()}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:26]


def provider_installation_id(provider_id: str, *data_roots: Any) -> str:
    """External-v1 C.1.1-style installation id (no secrets; account=unknown-account until Phase-0)."""
    roots: List[str] = []
    for raw in data_roots:
        if not raw:
            continue
        try:
            p = Path(str(raw)).expanduser()
            roots.append(str(p.resolve()) if p.exists() else str(p))
        except Exception:
            roots.append(str(raw))
    roots_s = "|".join(sorted(set(roots))) if roots else "unknown-root"
    material = (
        f"megas-piid-v1|{provider_id}|{_worker_installation_id()}|"
        f"{roots_s}|unknown-account"
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:26]


def _merge_thread_metadata(thread: Dict[str, Any], extra: Dict[str, Any]) -> Dict[str, Any]:
    meta: Dict[str, Any] = {}
    raw = thread.get("metadata_json")
    if isinstance(raw, str) and raw.strip():
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                meta = parsed
        except Exception:
            meta = {}
    elif isinstance(raw, dict):
        meta = dict(raw)
    meta.update({k: v for k, v in (extra or {}).items() if v is not None})
    out = dict(thread)
    out["metadata_json"] = json.dumps(meta, separators=(",", ":"), ensure_ascii=False)
    if extra.get("provider_installation_id"):
        out["provider_installation_id"] = extra["provider_installation_id"]
    if extra.get("parse_status"):
        out["parse_status"] = extra["parse_status"]
    return out


def _stamp_provider_installation(
    thread: Dict[str, Any],
    *,
    provider_id: str,
    data_roots: List[Any],
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    piid = provider_installation_id(provider_id, *data_roots)
    payload = {
        "provider_installation_id": piid,
        "adapter_contract": "external_v1_p0",
        "provider_id": provider_id,
        "canonical_schema_version": 1,
        "worker_installation_id": _worker_installation_id(),
    }
    if extra:
        payload.update(extra)
    return _merge_thread_metadata(thread, payload)


def compute_thread_revision(
    *,
    provider_id: str,
    native_id: str,
    messages: List[Dict[str, Any]],
    source_hint: str = "",
) -> str:
    """Notion H.4 ThreadRevision (lightweight): stable id for delta + rebuild detection.

    Uses existing thr_ message rows — no new store. SHA256 over count + first/last
    content hashes + provider/native id + parser epoch.
    """
    msgs = [m for m in (messages or []) if isinstance(m, dict)]
    n = len(msgs)

    def _h(m: Dict[str, Any]) -> str:
        blob = "|".join(
            [
                str(m.get("seq") or ""),
                str(m.get("role") or ""),
                str(m.get("kind") or ""),
                str(m.get("content") or "")[:500],
                str(m.get("tool_name") or ""),
            ]
        )
        return hashlib.sha256(blob.encode("utf-8", errors="replace")).hexdigest()[:16]

    first_h = _h(msgs[0]) if msgs else "empty"
    last_h = _h(msgs[-1]) if msgs else "empty"
    material = (
        f"rev1|{provider_id}|{native_id}|{_NATIVE_PARSER_EPOCH}|{n}|"
        f"{first_h}|{last_h}|{source_hint}"
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]


def finalize_native_thread(
    thread: Dict[str, Any],
    *,
    provider_id: str,
    data_roots: List[Any],
    source_hint: str = "",
    extra_meta: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Adopt existing thr_ dict → stamp installation + result_revision (Notion G/H)."""
    if not thread:
        return thread
    out = dict(thread)
    msgs = list(out.get("messages") or [])
    # Content hashes on rows (provenance lite — existing message shape).
    for m in msgs:
        if not isinstance(m, dict):
            continue
        if not m.get("content_hash"):
            raw = f"{m.get('role')}|{m.get('kind')}|{m.get('content') or ''}|{m.get('tool_name') or ''}"
            m["content_hash"] = hashlib.sha256(
                raw.encode("utf-8", errors="replace")
            ).hexdigest()[:24]
        if not m.get("native_item_id") and m.get("seq") is not None:
            m["native_item_id"] = f"{provider_id}:{out.get('native_id')}:{m.get('seq')}"
    out["messages"] = msgs
    rev = compute_thread_revision(
        provider_id=provider_id,
        native_id=str(out.get("native_id") or ""),
        messages=msgs,
        source_hint=source_hint or str(out.get("project_path") or ""),
    )
    out["result_revision"] = rev
    # Prefer revision as primary cursor when present (keeps mtime epoch for index).
    base_cursor = str(out.get("sync_cursor") or "")
    if base_cursor and rev not in base_cursor:
        out["sync_cursor"] = f"{base_cursor}|rev:{rev[:12]}"
    elif not base_cursor:
        out["sync_cursor"] = f"rev:{rev}"
    meta_extra = {
        "result_revision": rev,
        "event_count": len(msgs),
        "source_hint": source_hint or None,
    }
    if extra_meta:
        meta_extra.update(extra_meta)
    return _stamp_provider_installation(
        out, provider_id=provider_id, data_roots=data_roots, extra=meta_extra
    )


# Notion A.2.4 / C.1.9 / I.1 — post-resume native persistence proof (thr_ path).
PROOF_RESUMED_EXACT = "RESUMED_EXACT"
PROOF_NATIVE_MISSING = "NATIVE_MISSING"
PROOF_NATIVE_ID_MISMATCH = "NATIVE_ID_MISMATCH"
PROOF_PROMPT_NOT_PERSISTED = "PROMPT_NOT_PERSISTED"
PROOF_NO_GROWTH = "NO_GROWTH"
PROOF_AMBIGUOUS = "ACCEPTANCE_AMBIGUOUS_REQUIRES_RECONCILIATION"
PROOF_SKIPPED = "PROOF_SKIPPED"


def normalize_prompt_for_match(text: Any) -> str:
    """Normalize user prompt / native user turn for persistence matching."""
    if text is None:
        return ""
    raw = str(text)
    # Unwrap Grok <user_query> shells when present in store or submitted text.
    m = _GROK_USER_QUERY_RE.search(raw)
    if m:
        raw = m.group(1)
    raw = _sanitize_provider_text(raw)
    # Collapse whitespace for stable compare (providers may reflow newlines).
    return " ".join(raw.split()).strip()


def content_hash_for_turn(
    *,
    role: str,
    kind: str,
    content: str,
    tool_name: str = "",
) -> str:
    """Same formula as finalize_native_thread message content_hash."""
    raw = f"{role}|{kind}|{content or ''}|{tool_name or ''}"
    return hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()[:24]


def _user_turn_fingerprints(thread: Optional[Dict[str, Any]]) -> set[str]:
    """Stable fingerprints of user turns already present pre-run."""
    out: set[str] = set()
    if not thread:
        return out
    for m in thread.get("messages") or []:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role") or "").lower()
        kind = str(m.get("kind") or "").lower()
        if role != "user" and kind != "user_message":
            continue
        content = str(m.get("content") or "")
        norm = normalize_prompt_for_match(content)
        if not norm:
            continue
        ch = str(m.get("content_hash") or "") or content_hash_for_turn(
            role="user", kind="user_message", content=content
        )
        out.add(f"hash:{ch}")
        out.add(f"norm:{norm}")
        # seq-scoped when available
        if m.get("seq") is not None:
            out.add(f"seq:{m.get('seq')}:{ch}")
    return out


def _prompt_matches_user_content(msg_content: str, submitted_prompt: str) -> bool:
    a = normalize_prompt_for_match(msg_content)
    b = normalize_prompt_for_match(submitted_prompt)
    if not a or not b:
        return False
    if a == b:
        return True
    # Native may store full CLI prompt wrapper; submitted is the thr_ continue message.
    if b in a:
        return True
    # Rare: store is shorter extract of a long prompt.
    if len(a) >= 12 and a in b:
        return True
    return False


def confirm_native_persistence(
    *,
    expected_native_id: str,
    submitted_prompt: str,
    pre_thread: Optional[Dict[str, Any]],
    post_thread: Optional[Dict[str, Any]],
    agent_type: str = "",
) -> Dict[str, Any]:
    """Notion rung-3 lite: after continue, same native id + new user turn matches prompt.

    Process exit alone is insufficient. Returns proof dict; ``ok`` True only for RESUMED_EXACT.
    Does not invent thr_ messages.
    """
    expected = str(expected_native_id or "").strip()
    prompt = str(submitted_prompt or "").strip()
    prompt_norm = normalize_prompt_for_match(prompt)
    prompt_hash = content_hash_for_turn(
        role="user", kind="user_message", content=prompt
    ) if prompt else ""

    base: Dict[str, Any] = {
        "ok": False,
        "status": PROOF_AMBIGUOUS,
        "expected_native_id": expected,
        "agent_type": agent_type or "",
        "prompt_norm_len": len(prompt_norm),
        "prompt_content_hash": prompt_hash,
        "pre_msg_count": len((pre_thread or {}).get("messages") or []) if pre_thread else 0,
        "post_msg_count": 0,
        "matched_seq": None,
        "detail": "",
        "proof_version": "external_v1_p0_1",
    }

    if not expected:
        base["status"] = PROOF_SKIPPED
        base["detail"] = "no_expected_native_id"
        base["ok"] = True  # not a native-resume path
        return base
    if not prompt_norm:
        base["status"] = PROOF_AMBIGUOUS
        base["detail"] = "empty_submitted_prompt"
        return base
    if not post_thread:
        base["status"] = PROOF_NATIVE_MISSING
        base["detail"] = "post_run_native_thread_missing_or_empty"
        return base

    post_id = str(post_thread.get("native_id") or "").strip()
    base["post_native_id"] = post_id
    base["post_msg_count"] = len(post_thread.get("messages") or [])
    if post_id and post_id != expected:
        base["status"] = PROOF_NATIVE_ID_MISMATCH
        base["detail"] = f"expected={expected[:80]} got={post_id[:80]}"
        return base

    pre_fps = _user_turn_fingerprints(pre_thread)
    pre_count = base["pre_msg_count"]
    post_msgs = [m for m in (post_thread.get("messages") or []) if isinstance(m, dict)]
    post_count = len(post_msgs)
    grew = post_count > pre_count

    # Prefer turns that were not present pre-run (new user turns).
    new_user_matches: List[Dict[str, Any]] = []
    any_user_match = False
    for m in post_msgs:
        role = str(m.get("role") or "").lower()
        kind = str(m.get("kind") or "").lower()
        if role != "user" and kind != "user_message":
            continue
        content = str(m.get("content") or "")
        if not _prompt_matches_user_content(content, prompt):
            continue
        any_user_match = True
        ch = str(m.get("content_hash") or "") or content_hash_for_turn(
            role="user", kind="user_message", content=content
        )
        norm = normalize_prompt_for_match(content)
        is_new = (
            f"hash:{ch}" not in pre_fps
            and f"norm:{norm}" not in pre_fps
        )
        if is_new or not pre_fps:
            new_user_matches.append(
                {
                    "seq": m.get("seq"),
                    "content_hash": ch,
                    "is_new": is_new,
                }
            )

    if new_user_matches:
        hit = new_user_matches[-1]
        base["ok"] = True
        base["status"] = PROOF_RESUMED_EXACT
        base["matched_seq"] = hit.get("seq")
        base["matched_content_hash"] = hit.get("content_hash")
        base["detail"] = "same_native_id+new_user_turn_matches_prompt"
        base["grew"] = grew
        return base

    if any_user_match and not grew:
        # Prompt already in history pre-run (idempotent retry / re-send same text).
        base["ok"] = True
        base["status"] = PROOF_RESUMED_EXACT
        base["detail"] = "prompt_present_in_native_history_idempotent"
        base["grew"] = False
        return base

    if not grew and post_count == pre_count and pre_count > 0:
        base["status"] = PROOF_NO_GROWTH
        base["detail"] = "native_message_count_unchanged_prompt_not_found_as_new"
        return base

    if grew:
        base["status"] = PROOF_PROMPT_NOT_PERSISTED
        base["detail"] = "native_grew_but_submitted_prompt_not_in_new_user_turns"
        return base

    base["status"] = PROOF_PROMPT_NOT_PERSISTED
    base["detail"] = "submitted_prompt_not_found_in_native_user_turns"
    return base


def _truncate_field(value: Any, limit: int = _MAX_FIELD_CHARS) -> Optional[str]:
    if value is None:
        return None
    text = str(value)
    # Tool output is raw bytes from the agent's shell. NUL and other control bytes make
    # PostgreSQL reject the row, which 500s the whole sync chunk.
    if "\x00" in text:
        text = text.replace("\x00", "")
    text = "".join(ch for ch in text if ch in "\t\n\r" or ord(ch) >= 0x20)
    if len(text) <= limit:
        return text
    return text[: limit - 20] + "\n…[truncated]"


def cap_thread_for_sync(
    thread: Dict[str, Any],
    *,
    max_messages: int = 60,
    content_limit: int = 2000,
    tool_limit: int = 1500,
) -> Dict[str, Any]:
    """Return a copy safe to POST to /threads/sync (bounded message count + field size).

    Preserves native seq numbers (never re-number) so upserts stay idempotent.
    """
    if not thread:
        return thread
    out = dict(thread)
    title = _sanitize_provider_text(out.get("title") or "")
    out["title"] = (title[:80] if title else out.get("title") or "Chat")
    if out.get("project_path"):
        out["project_path"] = _normalize_project_path(out.get("project_path"))
    msgs = list(out.get("messages") or [])
    if max_messages > 0 and len(msgs) > max_messages:
        # A plain tail slice dropped the conversation: tool rows outnumber real turns
        # roughly 5:1 in a Codex transcript, so the newest 40 rows were almost all tool
        # activity and a long chat arrived looking like "1 or 2 turns", capped at exactly
        # 40 rows. Real user/assistant turns are the product; keep every one of them and
        # spend whatever budget is left on the most recent tool rows.
        def _is_turn(row: Any) -> bool:
            if not isinstance(row, dict):
                return False
            role = str(row.get("role") or "").strip().lower()
            kind = str(row.get("kind") or "").strip().lower()
            if kind in {"tool_call", "tool_result"}:
                return False
            return role in {"user", "human", "assistant", "ai"} or kind in {
                "user_message",
                "assistant_final",
                "assistant_message",
                "error",
            }

        turns = [m for m in msgs if _is_turn(m)]
        others = [m for m in msgs if not _is_turn(m)]
        if len(turns) >= max_messages:
            # Even the real turns exceed the budget: keep the most recent ones.
            msgs = turns[-max_messages:]
        else:
            room = max_messages - len(turns)
            keep_ids = {id(m) for m in turns} | {id(m) for m in others[-room:]} if room else {
                id(m) for m in turns
            }
            # Preserve original native ordering.
            msgs = [m for m in msgs if id(m) in keep_ids]
    capped: List[Dict[str, Any]] = []
    for m in msgs:
        if not isinstance(m, dict):
            continue
        row = dict(m)
        if row.get("content") is not None:
            row["content"] = _truncate_field(
                _sanitize_provider_text(row.get("content")), content_limit
            )
        if row.get("tool_input") is not None:
            row["tool_input"] = _truncate_field(row.get("tool_input"), tool_limit)
        if row.get("tool_output") is not None:
            row["tool_output"] = _truncate_field(row.get("tool_output"), tool_limit)
        capped.append(row)
    out["messages"] = capped
    # Cursor tracks highest native seq when present (not window length).
    last_seq = None
    if capped:
        try:
            last_seq = int(capped[-1].get("seq"))
        except (TypeError, ValueError):
            last_seq = None
    out["sync_cursor"] = str(last_seq if last_seq is not None else len(capped))
    return out


def _parse_agy_transcript(
    transcript_file: Path,
) -> tuple[List[Dict[str, Any]], Optional[str], Dict[str, Any]]:
    """Parse one Antigravity transcript.jsonl. Empty messages when unreadable — never synthetic.

    Returns (messages, title, parse_diagnostics). Malformed lines are counted, not invented.
    """
    messages: List[Dict[str, Any]] = []
    title: Optional[str] = None
    seq = 0
    diagnostics: Dict[str, Any] = {
        "skipped_lines": 0,
        "unsupported_types": 0,
        "errors": [],
    }
    try:
        with open(transcript_file, "r", encoding="utf-8", errors="replace") as f:
            for line_no, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    step_type = data.get("type")
                    content = data.get("content") or ""
                    created_at = data.get("created_at") or ""

                    if step_type in ("USER_INPUT", "USER_EXPLICIT"):
                        clean_text = _sanitize_provider_text(content)
                        if not title and clean_text:
                            title = clean_text[:80]
                        messages.append({
                            "seq": seq,
                            "role": "user",
                            "kind": "user_message",
                            "content": clean_text,
                            "native_step": data.get("step_index"),
                            "created_at": created_at,
                        })
                        seq += 1
                    elif step_type in ("PLANNER_RESPONSE", "MODEL", "TOOL_CALL", "TOOL_RESULT"):
                        tool_calls = data.get("tool_calls") or []
                        prose = None if step_type == "TOOL_RESULT" else _sanitize_provider_text(content)
                        if prose:
                            messages.append({
                                "seq": seq,
                                "role": "assistant",
                                "kind": "assistant_final",
                                "content": prose,
                                "native_step": data.get("step_index"),
                                "created_at": created_at,
                            })
                            seq += 1
                        if tool_calls:
                            for tc in tool_calls:
                                name = tc.get("name") if isinstance(tc, dict) else None
                                args = tc.get("args") if isinstance(tc, dict) else None
                                tc_id = None
                                if isinstance(tc, dict):
                                    tc_id = tc.get("id") or tc.get("tool_call_id")
                                messages.append({
                                    "seq": seq,
                                    "role": "assistant",
                                    "kind": "tool_call",
                                    "tool_name": name,
                                    "tool_input": json.dumps(args) if isinstance(args, (dict, list)) else str(args) if args else None,
                                    "tool_call_id": str(tc_id) if tc_id else None,
                                    "native_step": data.get("step_index"),
                                    "created_at": created_at,
                                })
                                seq += 1
                        elif step_type == "TOOL_RESULT" or data.get("tool_output") or data.get("result"):
                            tool_output = data.get("tool_output") or data.get("result")
                            messages.append({
                                "seq": seq,
                                "role": "assistant",
                                "kind": "tool_result",
                                "tool_output": str(tool_output) if tool_output else None,
                                "native_step": data.get("step_index"),
                                "created_at": created_at,
                            })
                            seq += 1
                    else:
                        diagnostics["unsupported_types"] += 1
                        if len(diagnostics["errors"]) < 20:
                            diagnostics["errors"].append(
                                {"line": line_no, "type": str(step_type or "unknown"), "reason": "unsupported_type"}
                            )
                except Exception as exc:
                    diagnostics["skipped_lines"] += 1
                    if len(diagnostics["errors"]) < 20:
                        diagnostics["errors"].append(
                            {"line": line_no, "reason": "parse_error", "detail": str(exc)[:120]}
                        )
                    continue
    except Exception as exc:
        diagnostics["errors"].append({"reason": "file_error", "detail": str(exc)[:160]})
        return [], None, diagnostics
    return messages, title, diagnostics


def _agy_summaries_db_index() -> Dict[str, Dict[str, Any]]:
    """Authoritative conversation index from Antigravity's own ``conversation_summaries.db``.

    Columns include ``project_id``, ``workspace_uris`` (a JSON **array** — a Project can span
    multiple folders per /docs/projects), ``parent_conversation_id`` (fork lineage) and
    ``app_data_dir``. Both product shapes are explicit here, so neither is inferred:

    * ``project_id = "outside-of-project"`` — standalone conversation (isolated scratch folder)
    * ``project_id = "default-cli-project"`` — the CLI's own default project
    * ``project_id = <uuid>`` with ``workspace_uris`` — a real multi-folder Project
    """
    import sqlite3
    import urllib.parse

    out: Dict[str, Dict[str, Any]] = {}
    for base in (
        Path.home() / ".gemini" / "antigravity-cli",
        Path.home() / ".gemini" / "antigravity",
    ):
        db = base / "conversation_summaries.db"
        if not db.is_file():
            continue
        try:
            # Provider stores may be open by Antigravity while Megas is syncing.
            # Read-only discovery must fail fast on a lock, never inherit SQLite's
            # multi-second default wait and pin a sync batch.
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=0.25)
            con.execute("PRAGMA busy_timeout = 250")
            try:
                rows = con.execute(
                    "SELECT conversation_id, title, preview, project_id, workspace_uris, "
                    "parent_conversation_id, app_data_dir FROM conversation_summaries"
                ).fetchall()
            finally:
                con.close()
        except Exception:
            continue
        for conv_id, title, preview, project_id, workspace_uris, parent_id, app_dir in rows or []:
            conv = str(conv_id or "").strip()
            if not conv:
                continue
            folders: List[str] = []
            raw_ws = str(workspace_uris or "").strip()
            if raw_ws:
                try:
                    parsed = json.loads(raw_ws)
                except Exception:
                    parsed = [raw_ws]
                if isinstance(parsed, str):
                    parsed = [parsed]
                for uri in parsed or []:
                    text = str(uri or "").strip()
                    if text.startswith("file:///"):
                        text = urllib.parse.unquote(text[len("file:///") :])
                    if text:
                        folders.append(text.replace("/", os.sep))
            pid = str(project_id or "").strip()
            if pid == "outside-of-project":
                scope = "standalone"
            elif pid and pid != "default-cli-project":
                scope = "project" if folders else "project_no_workspace"
            elif pid == "default-cli-project":
                scope = "default_project"
            else:
                scope = "unknown"
            out[conv] = {
                "project_id": pid,
                "project_scope": scope,
                # First folder is the primary project path; all folders are kept because a
                # Project may legitimately span several codebases.
                "project_path": folders[0] if folders else "",
                "project_folders": folders,
                "title": str(title or "").strip() or str(preview or "").strip(),
                "parent_conversation_id": str(parent_id or "").strip(),
                "app_data_dir": str(app_dir or "").strip(),
            }
    return out


def _agy_summaries_file() -> Optional[Path]:
    for base in (
        Path.home() / ".gemini" / "antigravity",
        Path.home() / ".gemini" / "antigravity-cli",
    ):
        candidate = base / "agyhub_summaries_proto.pb"
        if candidate.is_file():
            return candidate
    return None


def agy_conversation_index() -> Dict[str, Dict[str, str]]:
    """Conservative diagnostics from the Desktop sidebar protobuf.

    Antigravity 2.0 groups conversations by **Project** (a configuration of one or more
    folders — official docs, /docs/projects), and conversations started outside a Project
    run in an isolated scratch folder. That grouping is not derivable from transcript text,
    and guessing it from folder names mentioned in a chat mis-attributed conversations.

    The protobuf is provider-owned, but this repository has not established a stable
    field-level schema for binding its repeated UUID/URI fields to one conversation.
    Therefore it is *not* used to assign a Project.  We retain only an unresolved
    diagnostic; callers must fail closed until a structurally decoded provider record is
    available.  This prevents the previous nearby-UUID/URI association bug.
    """
    path = _agy_summaries_file()
    if path is None:
        return {}
    try:
        raw = path.read_bytes()
    except Exception:
        return {}

    import urllib.parse

    # Records appear as: $<uuid> ... <title> ... file:///<project folder>
    uuid_re = re.compile(
        rb"\$([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
    )
    uri_re = re.compile(rb"file:///([ -~]{3,240}?)(?=[\x00-\x1f]|$)")
    out: Dict[str, Dict[str, str]] = {}
    conv_marks = list(uuid_re.finditer(raw))
    for index, marker in enumerate(conv_marks):
        conv = marker.group(1).decode("ascii")
        end = conv_marks[index + 1].start() if index + 1 < len(conv_marks) else len(raw)
        segment = raw[marker.end():end]
        uris = list(uri_re.finditer(segment))
        project_ids = [
            m.group(1).decode("ascii")
            for m in uuid_re.finditer(segment)
        ]
        entry = out.setdefault(conv, {})
        if uris or project_ids:
            entry["metadata_confidence"] = "unresolved"
            entry["metadata_source"] = "agyhub_summaries_proto_unverified"
            entry["metadata_candidates"] = str(len(uris)) + ":" + str(len(project_ids))
    return out


def _agy_brain_roots() -> List[Path]:
    """Every Antigravity conversation store on this machine.

    Antigravity ships two products that share a layout: the CLI (``antigravity-cli``) and the
    desktop IDE (``antigravity``). Only the CLI root was indexed, so 112 desktop
    conversations — the ones the owner actually recognises, grouped by project in the
    desktop sidebar — were invisible to Megas.
    """
    home = Path.home()
    roots = [
        home / ".gemini" / "antigravity-cli" / "brain",
        home / ".gemini" / "antigravity" / "brain",
    ]
    return [r for r in roots if r.exists()]


def _agy_transcript(conv_dir: Path) -> Path:
    return conv_dir / ".system_generated" / "logs" / "transcript.jsonl"


def _agy_messages_dir(conv_dir: Path) -> Path:
    return conv_dir / ".system_generated" / "messages"


def _agy_conv_dirs() -> List[Path]:
    """Conversation dirs across both roots that hold readable turns."""
    dirs: List[Path] = []
    for root in _agy_brain_roots():
        try:
            for d in root.iterdir():
                if not d.is_dir():
                    continue
                if _agy_transcript(d).is_file():
                    dirs.append(d)
                elif _agy_messages_dir(d).is_dir() and any(
                    _agy_messages_dir(d).glob("*.json")
                ):
                    # Desktop conversations frequently store one JSON per message instead
                    # of a transcript; 66 of 112 on this machine had no transcript at all.
                    dirs.append(d)
        except Exception:
            continue

    def _mtime(d: Path) -> float:
        try:
            t = _agy_transcript(d)
            if t.is_file():
                return t.stat().st_mtime
            return d.stat().st_mtime
        except Exception:
            return 0.0

    dirs.sort(key=_mtime, reverse=True)
    return dirs


def _agy_provider_roots() -> List[tuple[str, Path]]:
    """Return the two Antigravity installations without consulting the /resume picker."""
    home = Path.home() / ".gemini"
    return [
        ("cli", home / "antigravity-cli"),
        ("desktop", home / "antigravity"),
    ]


def _agy_all_conv_dirs() -> List[Path]:
    """Union provider conversation DBs and brain directories, read-only.

    The picker is cwd-scoped.  The provider stores are the catalog.  A DB may exist
    without a brain directory and a brain directory may temporarily outlive its DB,
    so both are included and deduplicated by native id.
    """
    found: Dict[str, Path] = {}
    for _surface, root in _agy_provider_roots():
        db_root = root / "conversations"
        if db_root.is_dir():
            for db in db_root.glob("*.db"):
                if db.stem:
                    found.setdefault(db.stem, root / "brain" / db.stem)
        # Brain/artifact folders are supporting evidence only.  They are not allowed to
        # expand the catalog beyond provider summary/SQLite conversation records.
    return list(found.values())


def _agy_surface_for_native(native_id: str) -> str:
    """Return desktop/cli based on the authoritative per-installation store."""
    for surface, root in _agy_provider_roots():
        if (root / "conversations" / f"{native_id}.db").is_file() or (
            root / "brain" / native_id
        ).is_dir():
            return surface
    return "unknown"


def _agy_parent_map() -> Dict[str, str]:
    """Read CLI parent references from SQLite blobs without writing provider state."""
    parents: Dict[str, str] = {}
    uuid_re = re.compile(
        rb"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I
    )
    for _surface, root in _agy_provider_roots():
        for db in (root / "conversations").glob("*.db"):
            try:
                con = _require_sqlite3().connect(f"file:{db}?mode=ro", uri=True)
                try:
                    rows = con.execute("SELECT data FROM parent_references").fetchall()
                finally:
                    con.close()
            except Exception:
                continue
            refs: List[str] = []
            for (blob,) in rows or []:
                raw = bytes(blob or b"")
                refs.extend(x.decode("ascii", "ignore").lower() for x in uuid_re.findall(raw))
            if refs:
                # Provider records the source conversation as the final UUID in the blob.
                candidate = refs[-1]
                if candidate != db.stem.lower():
                    parents[db.stem] = candidate
    return parents


def _agy_lineage_class(surface: str, parent_id: str, parent_surface: str) -> str:
    if parent_id and parent_surface == "desktop" and surface == "cli":
        return "desktop_imported_cli_child"
    if parent_id:
        return "cli_fork_descendant" if surface == "cli" else "unresolved_orphan"
    return "desktop_only_root" if surface == "desktop" else "cli_native_root"


def _agy_reconcile_logical_threads(threads: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Collapse only verified Desktop→CLI imports into one canonical card.

    Titles, folder names and timestamps are deliberately not used as identity keys.
    """
    by_id = {str(t.get("native_id") or ""): t for t in threads if t.get("native_id")}
    parents = _agy_parent_map()
    for native_id, thread in by_id.items():
        raw_meta = thread.get("metadata_json") or "{}"
        try:
            meta = json.loads(raw_meta) if isinstance(raw_meta, str) else dict(raw_meta)
        except Exception:
            meta = {}
        surface = _agy_surface_for_native(native_id)
        parent_id = parents.get(native_id) or str(meta.get("parent_native_id") or "")
        parent = by_id.get(parent_id)
        parent_surface = _agy_surface_for_native(parent_id) if parent_id else ""
        meta.update({
            "source_surface": surface,
            "execution_surface": surface,
            "parent_native_id": parent_id or None,
            "lineage_class": _agy_lineage_class(surface, parent_id, parent_surface),
            "provider_scope": meta.get("project_scope") or "unresolved",
        })
        if parent:
            meta["origin_native_id"] = parent_id
            meta["origin_surface"] = parent_surface
            meta["execution_native_id"] = native_id
            # Imported CLI summaries may be rewritten to default-cli-project. Preserve
            # the Desktop source's provider scope/project/workspace projection.
            try:
                parent_meta = json.loads(parent.get("metadata_json") or "{}")
            except Exception:
                parent_meta = {}
            for key in ("project_scope", "provider_scope", "project_label", "project_id", "workspace_uris", "project_folders"):
                if parent_meta.get(key) not in (None, "", [], {}):
                    meta[key] = parent_meta[key]
            thread["project_path"] = parent.get("project_path") or ""
            meta["provider_scope"] = meta.get("project_scope") or "unresolved"
        else:
            meta.setdefault("origin_native_id", native_id)
            meta.setdefault("origin_surface", surface)
            meta.setdefault("execution_native_id", native_id)
        # Materialize the provider-neutral projection at the adapter boundary.  The
        # shared backend receives the original provider metadata too, but never needs to
        # understand Antigravity's SQLite or Desktop/CLI rules.
        projected = LogicalThread.from_provider_record(thread, logical_thread_id=native_id)
        meta["logical_thread_id"] = projected.logical_thread_id
        thread["metadata_json"] = json.dumps(meta, separators=(",", ":"), ensure_ascii=False)

    merged: List[Dict[str, Any]] = []
    consumed: set[str] = set()
    imported_sources = {
        str(json.loads(t.get("metadata_json") or "{}").get("parent_native_id") or "")
        for t in by_id.values()
        if str(json.loads(t.get("metadata_json") or "{}").get("lineage_class") or "")
        == "desktop_imported_cli_child"
    }
    for native_id, thread in by_id.items():
        if native_id in consumed:
            continue
        if native_id in imported_sources:
            consumed.add(native_id)
            continue
        meta = json.loads(thread.get("metadata_json") or "{}")
        parent_id = str(meta.get("parent_native_id") or "")
        if meta.get("lineage_class") == "desktop_imported_cli_child" and parent_id in by_id:
            # The CLI child contains the imported history and is the stable executable.
            # Keep the Desktop origin in metadata, but emit one canonical card.
            consumed.add(parent_id)
            merged.append(thread)
        else:
            merged.append(thread)
        consumed.add(native_id)
    return merged


def _agy_merge_lineage_messages(origin: Dict[str, Any], child: Dict[str, Any]) -> None:
    """Merge a verified import using native step identity, never message similarity.

    Antigravity's imported CLI store can contain a copy of the Desktop trajectory.  The
    first child user step is the provider's branch boundary: origin steps before that
    boundary are retained, and child steps from it onward are authoritative.  Equal text
    is deliberately irrelevant, so repeated prompts remain separate turns.
    """
    origin_messages = list(origin.get("messages") or [])
    child_messages = list(child.get("messages") or [])
    child_user_steps = [
        int(m["native_step"])
        for m in child_messages
        if str(m.get("role") or "").lower() in {"user", "human"}
        and isinstance(m.get("native_step"), int)
    ]
    if not child_user_steps:
        # Without native ordering we cannot prove a branch boundary; fail closed by
        # preserving the execution store rather than guessing a merge.
        meta = json.loads(child.get("metadata_json") or "{}")
        meta["lineage_merge"] = {"status": "unresolved_missing_native_step"}
        child["metadata_json"] = json.dumps(meta, separators=(",", ":"), ensure_ascii=False)
        return
    branch_step = min(child_user_steps)
    prefix = [m for m in origin_messages if isinstance(m.get("native_step"), int) and m["native_step"] < branch_step]
    continuation = [m for m in child_messages if isinstance(m.get("native_step"), int) and m["native_step"] >= branch_step]
    merged = prefix + continuation
    for seq, message in enumerate(merged):
        message["seq"] = seq
    child["messages"] = merged
    meta = json.loads(child.get("metadata_json") or "{}")
    meta["lineage_merge"] = {
        "status": "merged_by_native_step",
        "origin_native_id": origin.get("native_id"),
        "execution_native_id": child.get("native_id"),
        "branch_native_step": branch_step,
        "origin_prefix_count": len(prefix),
        "child_continuation_count": len(continuation),
    }
    child["metadata_json"] = json.dumps(meta, separators=(",", ":"), ensure_ascii=False)


def _agy_conv_dir(native_id: str) -> Optional[Path]:
    for root in _agy_brain_roots():
        candidate = root / native_id
        if candidate.is_dir():
            return candidate
    # Keep the provider DB as the exact identity anchor when the artifact directory is
    # missing.  Callers that need human-readable messages will report an honest empty
    # snapshot rather than inventing a transcript.
    for _surface, root in _agy_provider_roots():
        if (root / "conversations" / f"{native_id}.db").is_file():
            return root / "brain" / native_id
    return None


def agy_workspace_roots() -> List[str]:
    """Real project folders Antigravity groups conversations under.

    The desktop sidebar groups chats by project (megas-moves, NightClosure, amretra, …).
    That grouping lives in the IDE's VS Code state DB under
    ``antigravityUnifiedStateSync.sidebarWorkspaces`` as base64 protobuf containing
    ``file:///`` workspace URIs. Megas previously stored Antigravity's own brain directory
    as ``project_path``, so no real project name was ever recorded.
    """
    import base64
    import sqlite3
    import urllib.parse

    found: List[str] = []
    seen: set[str] = set()
    home = Path.home()
    candidates = [
        home / "AppData" / "Roaming" / "Antigravity" / "User" / "globalStorage" / "state.vscdb",
        home / "AppData" / "Roaming" / "Antigravity IDE" / "User" / "globalStorage" / "state.vscdb",
        home / ".config" / "Antigravity" / "User" / "globalStorage" / "state.vscdb",
        home / "Library" / "Application Support" / "Antigravity" / "User" / "globalStorage" / "state.vscdb",
    ]
    for db in candidates:
        if not db.is_file():
            continue
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=0.25)
            con.execute("PRAGMA busy_timeout = 250")
            try:
                rows = con.execute(
                    "SELECT value FROM ItemTable WHERE key LIKE ?",
                    ("%sidebarWorkspaces%",),
                ).fetchall()
            finally:
                con.close()
        except Exception:
            continue
        for (value,) in rows or []:
            raw = value if isinstance(value, (bytes, bytearray)) else str(value).encode()
            blobs = [raw]
            try:
                text = raw.decode("utf-8", "replace")
                blobs.append(base64.b64decode(text + "=" * (-len(text) % 4)))
            except Exception:
                pass
            for blob in blobs:
                try:
                    decoded = blob.decode("utf-8", "replace")
                except Exception:
                    continue
                for uri in re.findall(r"file:///[^\x00-\x1f\"']{3,240}", decoded):
                    path = urllib.parse.unquote(uri[len("file:///") :]).strip()
                    if not path:
                        continue
                    norm = path.replace("/", os.sep)
                    key = norm.lower()
                    if key in seen:
                        continue
                    seen.add(key)
                    found.append(norm)
    return found


def agy_project_label(project_path: str, project_scope: str) -> str:
    """Group label matching the Antigravity desktop sidebar exactly.

    The sidebar shows a **Projects** list whose entries are the workspace folder names
    (megas-moves, NightClosure, amretra, TheHumanoidTech, tab1, DEVMergeAI, JOB, Brandmaker,
    Play Store, chitraagni-backend, chitraagni-frontend, …), a project row literally named
    **CLI Project** for the CLI's ``default-cli-project``, and a separate **Conversations**
    section holding the standalone chats (``outside-of-project``).
    """
    if project_scope == "default_project":
        return "CLI Project"
    if project_scope == "standalone":
        return "Conversations"
    if project_scope == "project_no_workspace":
        return "Project (no workspace)"
    if project_scope == "project" and project_path:
        return Path(project_path).name or project_path
    return ""


def _agy_project_scope(conv_dir: Path) -> tuple[str, str]:
    """Return ``(project_path, project_scope)`` for one conversation.

    ``project_scope`` is one of:

    * ``project``         — belongs to a Project (``workspace_uris`` may list several folders)
    * ``default_project`` — the CLI's own ``default-cli-project`` ("CLI Project" in the UI)
    * ``standalone``      — provider says ``outside-of-project`` (the UI's "Conversations")
    * ``unknown``         — absent from the provider's index; Megas claims neither

    Both product shapes are read from the provider, never inferred. ``standalone`` and
    ``unknown`` stay distinct: the first is a real state the UI should group on its own, the
    second is missing information.
    """
    fallback = agy_conversation_index().get(conv_dir.name) or {}
    entry = _agy_summaries_db_index().get(conv_dir.name)
    if entry:
        scope = str(entry.get("project_scope") or "unknown")
        path = str(entry.get("project_path") or "")
        if scope == "project" and not path:
            # Project membership is known but its folders are not recorded in the DB row;
            # the desktop sidebar index still carries the folder URI.
            path = str(fallback.get("project_path") or "")
        return path, scope
    # Desktop store has no summaries DB; its sidebar index is the fallback.
    scope = str(fallback.get("project_scope") or "")
    if scope in {"project", "project_no_workspace"}:
        return str(fallback.get("project_path") or ""), scope
    if scope == "standalone":
        return "", "standalone"
    return "", "unknown"


def _agy_project_for(conv_dir: Path, workspaces: List[str]) -> str:
    """Real project for one conversation, from Antigravity's own sidebar index.

    ``workspaces`` is accepted for backward compatibility but is no longer used for
    matching: deriving a project from folder names mentioned inside a transcript
    mis-attributed conversations (75 of 163 collapsed onto one project on this machine).
    Membership comes from the provider's index, and a conversation that is standalone or
    unmapped stays unassigned rather than being given someone else's project.
    """
    return _agy_project_scope(conv_dir)[0]


def _parse_agy_messages_dir(messages_dir: Path) -> tuple[List[Dict[str, Any]], Optional[str], Dict[str, Any]]:
    """Parse a desktop conversation stored as one JSON file per message.

    66 of 112 desktop conversations on this machine have no ``transcript.jsonl`` at all, so
    without this they synced as nothing. Ordering uses the provider's own step index, then
    timestamp, so native order is preserved.
    """
    diagnostics: Dict[str, Any] = {"files": 0, "skipped": 0, "errors": []}
    rows: List[tuple[int, str, Dict[str, Any]]] = []
    title: Optional[str] = None
    try:
        files = sorted(messages_dir.glob("*.json"))
    except Exception as exc:
        diagnostics["errors"].append({"reason": "list_error", "detail": str(exc)[:160]})
        return [], None, diagnostics

    for path in files:
        diagnostics["files"] += 1
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            diagnostics["skipped"] += 1
            continue
        if not isinstance(data, dict):
            diagnostics["skipped"] += 1
            continue
        content = data.get("content")
        if isinstance(content, list):
            parts = [
                str(item.get("text") or "")
                for item in content
                if isinstance(item, dict) and item.get("text")
            ]
            text = "\n".join(parts)
        else:
            text = str(content or "")
        text = _sanitize_provider_text(text)
        if not text:
            diagnostics["skipped"] += 1
            continue

        source = data.get("sourceMetadata") if isinstance(data.get("sourceMetadata"), dict) else {}
        tool_meta = source.get("tool") if isinstance(source.get("tool"), dict) else {}
        step = tool_meta.get("stepIndex")
        try:
            step_index = int(step)
        except (TypeError, ValueError):
            step_index = -1

        sender = str(data.get("sender") or "")
        # A sender of "<conversation-id>/task-N" is the agent reporting a task result;
        # a bare conversation id (or "user") is the human turn.
        is_user = sender.lower() in {"user", "human"} or (
            bool(sender) and "/" not in sender and "task" not in sender.lower()
        )
        tool_call = tool_meta.get("toolCall") if isinstance(tool_meta.get("toolCall"), dict) else {}
        tool_name = str(tool_call.get("name") or "").strip() or None

        if tool_name:
            role, kind = "assistant", "tool_result"
        elif is_user:
            role, kind = "user", "user_message"
        else:
            role, kind = "assistant", "assistant_final"

        if kind == "user_message" and not title:
            title = text.strip().splitlines()[0][:120] if text.strip() else None

        rows.append(
            (
                step_index,
                str(data.get("timestamp") or ""),
                {
                    "role": role,
                    "kind": kind,
                    "content": text,
                    "tool_name": tool_name,
                    "tool_input": _truncate_field(tool_call.get("argumentsJson")) if tool_call else None,
                    "created_at": _iso_from_epoch_or_text(data.get("timestamp")),
                    "native_step": step_index if step_index >= 0 else None,
                },
            )
        )

    rows.sort(key=lambda r: (r[0] if r[0] >= 0 else 1 << 30, r[1]))
    messages: List[Dict[str, Any]] = []
    for seq, (_step, _ts, row) in enumerate(rows):
        row["seq"] = seq
        messages.append(row)
    return messages, title, diagnostics


def read_agy_thread(native_id: str) -> Optional[Dict[str, Any]]:
    """Exact native-thread read for one Antigravity conversation id. None if missing/empty."""
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    conv_dir = _agy_conv_dir(native_id)
    if conv_dir is None:
        return None
    transcript_file = _agy_transcript(conv_dir)
    if transcript_file.is_file():
        messages, title, diagnostics = _parse_agy_transcript(transcript_file)
        source_hint = str(transcript_file)
        layout = "transcript_jsonl"
    else:
        messages, title, diagnostics = _parse_agy_messages_dir(_agy_messages_dir(conv_dir))
        source_hint = str(_agy_messages_dir(conv_dir))
        layout = "messages_dir"
    if not messages:
        return None
    project, scope = _agy_project_scope(conv_dir)
    parent_map = _agy_parent_map()
    parent_id = parent_map.get(native_id, "")
    parent_dir = _agy_conv_dir(parent_id) if parent_id else None
    parent_project, parent_scope = _agy_project_scope(parent_dir) if parent_dir else ("", "")
    surface = _agy_surface_for_native(native_id)
    imported = bool(parent_id and surface == "cli" and _agy_surface_for_native(parent_id) == "desktop")
    if imported and parent_project:
        # The CLI summary row is often rewritten to default-cli-project after import;
        # the Desktop source remains the authoritative project/workspace context.
        project, scope = parent_project, parent_scope or scope
    th = {
        "native_id": native_id,
        "agent_type": "antigravity",
        # Empty when the conversation is standalone (Antigravity 2.0 runs those in an
        # isolated scratch folder) or not present in the provider index. ``project_scope``
        # in metadata keeps those two cases distinguishable.
        "project_path": project,
        "title": title or "Antigravity session",
        "status": "active",
        "sync_cursor": str(len(messages)),
        "messages": messages,
        "metadata_json": json.dumps(
            {
                "parse_diagnostics": diagnostics,
                "store_root": conv_dir.parent.parent.name,
                "layout": layout,
                "project_scope": scope,
                "project_label": agy_project_label(project, scope),
                "source_surface": surface,
                "origin_surface": "desktop" if imported else surface,
                "origin_native_id": parent_id or native_id,
                "execution_surface": surface,
                "execution_native_id": native_id,
                "parent_native_id": parent_id or None,
                "lineage_class": "desktop_imported_cli_child" if imported else (
                    "cli_fork_descendant" if parent_id else (
                        "desktop_only_root" if surface == "desktop" else "cli_native_root"
                    )
                ),
                "origin_project_path": parent_project or None,
                "origin_project_scope": parent_scope or None,
                "project_metadata_confidence": "unresolved" if surface == "desktop" else "authoritative",
                "project_metadata_source": "desktop_index_unverified" if surface == "desktop" else "cli_summary_db",
            }
        ),
    }
    if imported and parent_id:
        # Exact open must expose the same logical history as catalog sync:
        # Desktop prefix + only the CLI continuation from the native branch
        # step. Never merge by title, text, or timestamp.
        origin = read_agy_thread(parent_id)
        if origin:
            _agy_merge_lineage_messages(origin, th)
    return finalize_native_thread(
        th,
        provider_id="antigravity",
        # Installation identity is provider-root scoped. Including conv_dir
        # made every exact read look like a different provider installation.
        data_roots=[root for _surface, root in _agy_provider_roots()],
        source_hint=source_hint,
        extra_meta={"identity_source": "provider_store_root"},
    )


def read_agy_threads(limit: int = 0) -> List[Dict[str, Any]]:
    """Read and reconcile the complete local Desktop+CLI provider catalog.

    ``limit`` remains for compatibility with older callers; non-positive values mean
    complete catalog and the canonical index path always uses the complete union.
    """
    threads: List[Dict[str, Any]] = []
    try:
        conv_dirs = _agy_all_conv_dirs()
        desktop_index = agy_conversation_index()
        for conv_dir in conv_dirs:
            transcript = _agy_transcript(conv_dir)
            if transcript.is_file():
                messages, title, diagnostics = _parse_agy_transcript(transcript)
                layout = "transcript_jsonl"
            else:
                messages, title, diagnostics = _parse_agy_messages_dir(_agy_messages_dir(conv_dir))
                layout = "messages_dir"
            # A provider DB with no readable transcript is still a real conversation.
            # Emit an honest empty record so it appears in the catalog; never invent a
            # message or placeholder turn.
            project, scope = _agy_project_scope(conv_dir)
            summary = _agy_summaries_db_index().get(conv_dir.name) or {}
            provider_index = desktop_index.get(conv_dir.name) or {}
            threads.append({
                "native_id": conv_dir.name,
                "agent_type": "antigravity",
                "project_path": project,
                "title": title or summary.get("title") or "Antigravity session",
                "status": "active",
                "sync_cursor": str(len(messages)),
                "messages": messages,
                "metadata_json": json.dumps(
                    {
                        "parse_diagnostics": diagnostics,
                        "layout": layout,
                        "project_scope": scope,
                        "project_label": agy_project_label(project, scope),
                        "project_id": summary.get("project_id") or provider_index.get("project_id"),
                        "workspace_uris": summary.get("project_folders") or [],
                        "project_metadata_confidence": summary.get("metadata_confidence") or provider_index.get("metadata_confidence") or ("authoritative" if summary else "unresolved"),
                        "project_metadata_source": summary.get("metadata_source") or provider_index.get("metadata_source") or ("cli_summary_db" if summary else "unresolved"),
                    }
                ),
            })
    except Exception:
        pass
    # Build the canonical detail history before collapsing the origin card.  Only the
    # provider's explicit parent reference and native step ordering may join stores.
    by_id = {str(t.get("native_id") or ""): t for t in threads}
    for child_id, parent_id in _agy_parent_map().items():
        child = by_id.get(child_id)
        origin = by_id.get(parent_id)
        if not child or not origin:
            continue
        if _agy_surface_for_native(child_id) == "cli" and _agy_surface_for_native(parent_id) == "desktop":
            _agy_merge_lineage_messages(origin, child)
    return _agy_reconcile_logical_threads(threads)


# Claude Code control/meta line types — not chat turns.
_CLAUDE_SKIP_TYPES = frozenset(
    {
        "queue-operation",
        "attachment",
        "mode",
        "permission-mode",
        "file-history-snapshot",
        "system",
        "ai-title",
        "progress",
        "summary",
        "//",
    }
)


def _claude_projects_dir() -> Path:
    return Path.home() / ".claude" / "projects"


def _list_claude_jsonl_files(limit: int = 50) -> List[Path]:
    """Prefer official ~/.claude/projects/**/*.jsonl; fall back to other session jsonl."""
    home = Path.home()
    claude_dir = home / ".claude"
    if not claude_dir.exists():
        return []
    files: List[Path] = []
    projects = claude_dir / "projects"
    try:
        if projects.is_dir():
            files.extend([p for p in projects.rglob("*.jsonl") if p.is_file()])
    except Exception:
        pass
    # Legacy / alternate roots (exclude projects already covered).
    if len(files) < limit:
        try:
            for p in claude_dir.glob("**/*.jsonl"):
                if not p.is_file():
                    continue
                try:
                    if projects in p.parents or p.parent == projects:
                        continue
                except Exception:
                    pass
                # Skip noisy non-session dumps.
                if p.name in ("history.jsonl", "stats-cache.jsonl"):
                    continue
                files.append(p)
        except Exception:
            pass
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return files[: max(limit * 3, limit)]


def _append_claude_content_blocks(
    content: Any,
    *,
    role: str,
    created_at: str,
    messages: List[Dict[str, Any]],
    seq: int,
    title: Optional[str],
) -> tuple[int, Optional[str]]:
    """Expand Claude content (str | list blocks) into canonical thr_ rows."""
    if isinstance(content, list):
        for item in content:
            if not isinstance(item, dict):
                if isinstance(item, str):
                    txt = _sanitize_provider_text(item)
                    if txt:
                        if role == "user" and not title:
                            title = txt[:80]
                        messages.append(
                            {
                                "seq": seq,
                                "role": role,
                                "kind": "user_message" if role == "user" else "assistant_final",
                                "content": txt,
                                "created_at": created_at,
                            }
                        )
                        seq += 1
                continue
            itype = str(item.get("type") or "")
            if itype == "text" or (not itype and item.get("text")):
                txt = _sanitize_provider_text(str(item.get("text") or ""))
                if txt:
                    if role == "user" and not title:
                        title = txt[:80]
                    messages.append(
                        {
                            "seq": seq,
                            "role": role,
                            "kind": "user_message" if role == "user" else "assistant_final",
                            "content": txt,
                            "created_at": created_at,
                        }
                    )
                    seq += 1
            elif itype == "tool_use":
                name = item.get("name")
                inp = json.dumps(item.get("input")) if item.get("input") is not None else None
                messages.append(
                    {
                        "seq": seq,
                        "role": "assistant",
                        "kind": "tool_call",
                        "tool_name": name,
                        "tool_input": inp,
                        "tool_call_id": str(item.get("id") or "") or None,
                        "created_at": created_at,
                    }
                )
                seq += 1
            elif itype == "tool_result":
                out = item.get("content", "")
                if isinstance(out, list):
                    parts = []
                    for part in out:
                        if isinstance(part, dict):
                            parts.append(str(part.get("text") or part.get("content") or ""))
                        else:
                            parts.append(str(part))
                    out = "\n".join(p for p in parts if p)
                out_s = str(out) if out else ""
                messages.append(
                    {
                        "seq": seq,
                        "role": "assistant",
                        "kind": "tool_result",
                        "tool_output": out_s if out_s else None,
                        "tool_call_id": str(item.get("tool_use_id") or item.get("id") or "") or None,
                        "created_at": created_at,
                    }
                )
                seq += 1
        return seq, title

    if isinstance(content, dict):
        content = content.get("text") or content.get("content") or ""
    txt = _sanitize_provider_text(str(content or ""))
    if txt:
        if role == "user" and not title:
            title = txt[:80]
        messages.append(
            {
                "seq": seq,
                "role": role,
                "kind": "user_message" if role == "user" else "assistant_final",
                "content": txt,
                "created_at": created_at,
            }
        )
        seq += 1
    return seq, title


def _parse_claude_transcript(
    path: Path,
) -> tuple[List[Dict[str, Any]], Optional[str], Optional[str]]:
    """Parse one Claude Code JSONL session.

    Production store (Claude Code): nested ``message.content`` under type user/assistant,
    with ``cwd`` on the line. Also accepts flat role/content JSONL (tests / exports).

    Notion C.2.4: transcript is a DAG (parentUuid). Prefer active leaf chain
    (non-sidechain path to newest leaf); fall back to line order when no UUIDs.
    Returns (messages, title, project_cwd). Never invents synthetic turns.
    """
    title: Optional[str] = None
    project_cwd: Optional[str] = None
    # Collect chat records for DAG selection.
    records: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            line_no = 0
            for line in f:
                line = line.strip()
                if not line:
                    continue
                line_no += 1
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                if not isinstance(data, dict):
                    continue
                if not project_cwd and data.get("cwd"):
                    project_cwd = str(data.get("cwd") or "").strip() or None

                top_type = str(data.get("type") or "").lower()
                if top_type in _CLAUDE_SKIP_TYPES:
                    continue

                nested = data.get("message") if isinstance(data.get("message"), dict) else None
                if nested:
                    role_raw = str(nested.get("role") or top_type or "").lower()
                    content = nested.get("content")
                else:
                    role_raw = str(data.get("role") or top_type or "").lower()
                    content = data.get("content") if data.get("content") is not None else data.get("text")

                if role_raw in ("user", "human", "user_message") or top_type == "user":
                    role = "user"
                elif role_raw in ("assistant", "model", "assistant_message") or top_type == "assistant":
                    role = "assistant"
                else:
                    continue

                records.append(
                    {
                        "uuid": str(data.get("uuid") or data.get("id") or f"line-{line_no}"),
                        "parentUuid": str(data.get("parentUuid") or data.get("parent_uuid") or "")
                        or None,
                        "isSidechain": bool(data.get("isSidechain")),
                        "role": role,
                        "content": content,
                        "created_at": str(data.get("timestamp") or data.get("created_at") or ""),
                        "sessionId": str(data.get("sessionId") or data.get("session_id") or ""),
                        "line_no": line_no,
                    }
                )
    except Exception:
        return [], None, project_cwd

    if not records:
        return [], None, project_cwd

    # --- Active leaf chain (Notion C.2.4) ---
    by_id = {r["uuid"]: r for r in records}
    has_links = any(r.get("parentUuid") for r in records)
    ordered: List[Dict[str, Any]]
    if has_links:
        # Nodes that are parents of someone (have children).
        is_parent: set[str] = {
            str(r.get("parentUuid"))
            for r in records
            if r.get("parentUuid")
        }
        non_side = [r for r in records if not r.get("isSidechain")]
        pool = non_side or records
        leaf_candidates = [r for r in pool if r["uuid"] not in is_parent]
        if not leaf_candidates:
            leaf_candidates = pool
        # Newest leaf by line order
        leaf = max(leaf_candidates, key=lambda r: int(r.get("line_no") or 0))
        chain: List[Dict[str, Any]] = []
        cur: Optional[Dict[str, Any]] = leaf
        seen_ids: set[str] = set()
        while cur is not None and cur["uuid"] not in seen_ids:
            seen_ids.add(cur["uuid"])
            chain.append(cur)
            pid = cur.get("parentUuid")
            cur = by_id.get(pid) if pid else None
        chain.reverse()
        ordered = chain
    else:
        ordered = records

    messages: List[Dict[str, Any]] = []
    seq = 0
    for rec in ordered:
        before = len(messages)
        seq, title = _append_claude_content_blocks(
            rec.get("content"),
            role=str(rec.get("role") or "assistant"),
            created_at=str(rec.get("created_at") or ""),
            messages=messages,
            seq=seq,
            title=title,
        )
        # Attach native ids on newly added rows
        for m in messages[before:]:
            m["native_turn_id"] = rec.get("uuid")
            if rec.get("sessionId"):
                m.setdefault("native_item_id", f"{rec.get('sessionId')}:{rec.get('uuid')}:{m.get('seq')}")
    return messages, title, project_cwd


def read_claude_threads(limit: int = 10) -> List[Dict[str, Any]]:
    """Read local Claude Code sessions (projects-first, nested message.content)."""
    threads: List[Dict[str, Any]] = []
    try:
        for p in _list_claude_jsonl_files(limit):
            if len(threads) >= limit:
                break
            messages, title, project_cwd = _parse_claude_transcript(p)
            if not messages:
                continue
            project_path = project_cwd or str(p.parent)
            # Identity: prefer sessionId from first record when filename differs (Notion C.2.3)
            native_id = p.stem
            th = {
                "native_id": native_id,
                "agent_type": "claude_code",
                "project_path": _normalize_project_path(project_path) or project_path,
                "title": (title or "Claude Code session")[:80],
                "status": "active",
                "sync_cursor": str(len(messages)),
                "messages": messages,
            }
            threads.append(
                finalize_native_thread(
                    th,
                    provider_id="claude_code",
                    data_roots=[Path.home() / ".claude", p.parent],
                    source_hint=str(p),
                    extra_meta={"identity_source": "projects_jsonl", "ordering": "dag_or_line"},
                )
            )
    except Exception:
        return threads
    return threads


def read_claude_thread(native_id: str) -> Optional[Dict[str, Any]]:
    """Exact native-thread read for one Claude Code session. None if missing/empty."""
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    home = Path.home()
    claude_dir = home / ".claude"
    if not claude_dir.exists():
        return None
    # Prefer projects/ match; accept any under .claude.
    candidates: List[Path] = []
    projects = claude_dir / "projects"
    try:
        if projects.is_dir():
            candidates.extend(list(projects.rglob(f"{native_id}.jsonl")))
    except Exception:
        pass
    if not candidates:
        try:
            candidates = list(claude_dir.glob(f"**/{native_id}.jsonl"))
        except Exception:
            candidates = []
    if not candidates:
        return None
    # Newest if duplicates
    candidates.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    target = candidates[0]
    messages, title, project_cwd = _parse_claude_transcript(target)
    if not messages:
        return None
    project_path = project_cwd or str(target.parent)
    th = {
        "native_id": native_id,
        "agent_type": "claude_code",
        "project_path": _normalize_project_path(project_path) or project_path,
        "title": (title or "Claude Code session")[:80],
        "status": "active",
        "sync_cursor": str(len(messages)),
        "messages": messages,
    }
    return finalize_native_thread(
        th,
        provider_id="claude_code",
        data_roots=[Path.home() / ".claude", target.parent],
        source_hint=str(target),
        extra_meta={"identity_source": "projects_jsonl", "ordering": "dag_or_line"},
    )


def _codex_state_db_paths() -> List[Path]:
    """Codex may keep state_5.sqlite at ~/.codex/ or ~/.codex/sqlite/ (both real)."""
    home = Path.home()
    candidates = [
        home / ".codex" / "state_5.sqlite",
        home / ".codex" / "sqlite" / "state_5.sqlite",
    ]
    out: List[Path] = []
    seen: set[str] = set()
    for p in candidates:
        try:
            if not p.is_file():
                continue
            key = str(p.resolve())
        except Exception:
            if not p.is_file():
                continue
            key = str(p)
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def _parse_codex_rollout_meta(rollout_path: str) -> Dict[str, str]:
    """First session_meta line → native thread id / cwd.

    Aligns with Remodex ``session-jsonl-history.js`` (proven phone↔Codex bridge):
    identity is ``payload.id | thread_id | threadId | session_id`` — **not** filename.
    """
    path = Path(rollout_path) if rollout_path else None
    meta: Dict[str, str] = {}
    if not path or not path.exists():
        return meta
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                if i > 30:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                # Capture the opening user prompt while we are already in this file.
                # The index otherwise only knows a generic "Codex session" title, which
                # is not enough to recognise Megas' own health-probe sessions.
                if "first_user_message" not in meta:
                    payload_any = data.get("payload") if isinstance(data.get("payload"), dict) else {}
                    if str(payload_any.get("type") or "") == "user_message":
                        prompt = str(payload_any.get("message") or payload_any.get("text") or "").strip()
                        if prompt:
                            meta["first_user_message"] = prompt[:400]
                if data.get("type") != "session_meta":
                    continue
                payload = data.get("payload") if isinstance(data.get("payload"), dict) else data
                # Remodex order: id, thread_id, threadId — then session_id aliases.
                sid = str(
                    payload.get("id")
                    or payload.get("thread_id")
                    or payload.get("threadId")
                    or payload.get("session_id")
                    or data.get("session_id")
                    or data.get("id")
                    or ""
                ).strip()
                cwd = str(
                    payload.get("cwd")
                    or payload.get("current_working_directory")
                    or payload.get("working_directory")
                    or ""
                ).strip()
                if sid:
                    meta["session_id"] = sid
                if cwd:
                    meta["cwd"] = cwd
                # session_meta is the first line, so keep scanning the bounded window
                # until the opening prompt is seen too.
                if meta.get("session_id") and meta.get("first_user_message"):
                    break
    except Exception:
        return meta
    return meta


def _codex_sessions_root() -> Path:
    """Remodex resolveSessionsRoot: $CODEX_HOME/sessions (dated rollout tree)."""
    env = (os.getenv("CODEX_HOME") or "").strip()
    home = Path(env).expanduser() if env else Path.home() / ".codex"
    return home / "sessions"


def _codex_session_index_path() -> Path:
    env = (os.getenv("CODEX_HOME") or "").strip()
    home = Path(env).expanduser() if env else Path.home() / ".codex"
    return home / "session_index.jsonl"


def _iter_codex_session_index_rows(limit: int = 200) -> List[Dict[str, Any]]:
    """Parse session_index.jsonl (append-only). Last write wins per thread id."""
    path = _codex_session_index_path()
    if not path.is_file():
        return []
    by_id: Dict[str, Dict[str, Any]] = {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                if not isinstance(data, dict):
                    continue
                sid = str(
                    data.get("id")
                    or data.get("thread_id")
                    or data.get("threadId")
                    or data.get("session_id")
                    or ""
                ).strip()
                if not sid:
                    continue
                by_id[sid] = data
    except Exception:
        return []
    # Prefer most recently touched if updated_at present.
    rows = list(by_id.values())

    def _sort_key(r: Dict[str, Any]) -> str:
        return str(r.get("updated_at") or r.get("updatedAt") or r.get("created_at") or "")

    rows.sort(key=_sort_key, reverse=True)
    return rows[: max(limit, 1)]


def _iter_codex_rollout_files(limit: int = 200) -> List[Path]:
    """Walk ~/.codex/sessions for rollout-*.jsonl (Remodex sessions tree)."""
    root = _codex_sessions_root()
    if not root.is_dir():
        # Fall back to whole CODEX_HOME tree (older layouts).
        env = (os.getenv("CODEX_HOME") or "").strip()
        root = Path(env).expanduser() if env else Path.home() / ".codex"
        if not root.is_dir():
            return []
    files: List[Path] = []
    try:
        for path in root.rglob("rollout-*.jsonl"):
            if path.is_file():
                files.append(path)
        if not files:
            for path in root.rglob("*rollout*.jsonl"):
                if path.is_file() and path.name.endswith(".jsonl"):
                    files.append(path)
    except Exception:
        return []
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return files[: max(limit, 1)]


_TOOL_SUMMARY_LIMIT = 400

# Sessions Megas itself creates while probing or smoke-testing an agent. They are our
# machinery, not the owner's conversations, and they must never reach the chat list:
# `codex exec wait-cancel-test-prompt` runs on every health check and Codex persists a
# rollout for each one (1,833 on a single machine), which buried real local chats.
_MEGAS_INTERNAL_SESSION_MARKERS: tuple[str, ...] = (
    "wait-cancel-test-prompt",
    "smoke self-test:",
    "megas smoke",
    "megas self-test",
    "parity resume probe",
    "fleet_agy_ok",
    "milna_agy_probe_ok",
    "megas_codex_probe_ok",
    "megas_fleet_probe_ok",
    "proof_agent_chat_ok",
    "status poll for prior self-check runs:",
    "run a basic self-check:",
    "final antigravity smoke:",
    "production ranking smoke:",
    "chat save probe",
    "quiet smoke",
    "kilo smoke:",
    "agy smoke:",
)


def is_megas_internal_session(*texts: Any) -> bool:
    """True when a native session was generated by Megas' own probes/smoke tests."""
    for text in texts:
        body = str(text or "").strip().lower()
        if not body:
            continue
        head = body[:400]
        for marker in _MEGAS_INTERNAL_SESSION_MARKERS:
            if marker in head:
                return True
    return False


def _iso_from_epoch_or_text(raw: Any) -> str:
    """Normalize a provider timestamp to ISO-8601 UTC.

    Grok writes unix timestamps and the parser passed them through verbatim, so
    ``last_message_at`` held values like ``1784996399``. Those never compare correctly
    against ISO strings, which broke recency ordering and made recent Grok chats look
    unsynced. Seconds, milliseconds and already-ISO text are all accepted.
    """
    if raw is None:
        return ""
    text = str(raw).strip()
    if not text:
        return ""
    try:
        value = float(text)
    except (TypeError, ValueError):
        return text  # already ISO (or provider-specific text) — leave it alone
    if value <= 0:
        return ""
    # Heuristic: values far above plausible seconds are milliseconds.
    if value > 1e12:
        value /= 1000.0
    try:
        from datetime import datetime, timezone

        return datetime.fromtimestamp(value, tz=timezone.utc).isoformat()
    except (OverflowError, OSError, ValueError):
        return text


def _tool_call_summary(name: Any, args_text: Optional[str]) -> str:
    """Short, honest one-liner for a tool invocation.

    Coding-agent desktop UIs show *what the agent ran*, not a blank row. Tool rows
    previously stored no ``content``, so they rendered as nothing and made a synced
    thread look empty while still counting toward ``message_count``.
    """
    tool = str(name or "tool").strip() or "tool"
    detail = ""
    raw = (args_text or "").strip()
    if raw:
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = None
        if isinstance(parsed, dict):
            # Prefer the fields humans recognise: a command, a path, a query.
            for key in ("command", "cmd", "script", "path", "file_path", "query", "pattern", "input"):
                value = parsed.get(key)
                if isinstance(value, list):
                    value = " ".join(str(part) for part in value)
                if value not in (None, "", []):
                    detail = str(value)
                    break
            if not detail:
                detail = ", ".join(f"{k}={parsed[k]!s}" for k in list(parsed)[:3])
        elif parsed is not None:
            detail = str(parsed)
        else:
            detail = raw
    detail = _sanitize_provider_text(detail).replace("\n", " ").strip()
    if len(detail) > _TOOL_SUMMARY_LIMIT:
        detail = detail[:_TOOL_SUMMARY_LIMIT].rstrip() + "…"
    return f"{tool}: {detail}" if detail else tool


def _tool_result_summary(output_text: Optional[str]) -> str:
    """First meaningful lines of a tool result, bounded."""
    text = _sanitize_provider_text(output_text or "").strip()
    if not text:
        return ""
    lines = [line for line in text.splitlines() if line.strip()][:6]
    joined = "\n".join(lines)
    if len(joined) > _TOOL_SUMMARY_LIMIT:
        joined = joined[:_TOOL_SUMMARY_LIMIT].rstrip() + "…"
    return joined


def _parse_codex_rollout_messages(rollout_path: str, updated_ts: str = "") -> List[Dict[str, Any]]:
    """Parse one Codex rollout JSONL into canonical message rows. Empty on failure — never synthetic."""
    messages: List[Dict[str, Any]] = []
    seq = 0
    path = Path(rollout_path) if rollout_path else None
    if not path or not path.exists():
        return messages
    # Deduplicate agent_message + response_item twin rows (same text).
    seen_text: set[str] = set()
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    stype = data.get("type")
                    payload = data.get("payload") or {}
                    if not isinstance(payload, dict):
                        payload = {}
                    timestamp = data.get("timestamp") or updated_ts

                    # Codex rollout shapes (openai/codex): event_msg + response_item.
                    if stype == "event_msg":
                        ptype = str(payload.get("type") or "")
                        if ptype == "user_message":
                            text = _sanitize_provider_text(
                                payload.get("message") or payload.get("text") or ""
                            )
                            if text:
                                key = f"u:{text}"
                                if key not in seen_text:
                                    seen_text.add(key)
                                    messages.append(
                                        {
                                            "seq": seq,
                                            "role": "user",
                                            "kind": "user_message",
                                            "content": text,
                                            "created_at": timestamp,
                                        }
                                    )
                                    seq += 1
                        elif ptype in ("agent_message", "assistant_message", "agent_reasoning"):
                            # Official: event_msg agent_message.message (final / commentary).
                            if ptype == "agent_reasoning":
                                continue  # optional; avoid noise for old sync timeline
                            text = _sanitize_provider_text(
                                payload.get("message") or payload.get("text") or ""
                            )
                            if text:
                                key = f"a:{text}"
                                if key not in seen_text:
                                    seen_text.add(key)
                                    messages.append(
                                        {
                                            "seq": seq,
                                            "role": "assistant",
                                            "kind": "assistant_final",
                                            "content": text,
                                            "created_at": timestamp,
                                        }
                                    )
                                    seq += 1
                    elif stype == "response_item":
                        ptype = payload.get("type")
                        role = payload.get("role")
                        if role in ("assistant", "user") or ptype in ("message", "output_message"):
                            content = payload.get("content")
                            text_str = ""
                            if isinstance(content, list):
                                text_parts = [
                                    item.get("text", "")
                                    for item in content
                                    if isinstance(item, dict)
                                    and item.get("type") in ("text", "output_text", "input_text")
                                ]
                                text_str = "\n".join(text_parts).strip()
                            elif isinstance(content, str):
                                text_str = content.strip()
                            text_str = _sanitize_provider_text(text_str)
                            if text_str:
                                is_user = role == "user"
                                key = f"{'u' if is_user else 'a'}:{text_str}"
                                if key not in seen_text:
                                    seen_text.add(key)
                                    messages.append(
                                        {
                                            "seq": seq,
                                            "role": "user" if is_user else "assistant",
                                            "kind": "user_message" if is_user else "assistant_final",
                                            "content": text_str,
                                            "created_at": timestamp,
                                        }
                                    )
                                    seq += 1
                        elif ptype in ("function_call", "custom_tool_call"):
                            name = payload.get("name")
                            args = payload.get("arguments")
                            args_text = (
                                json.dumps(args)
                                if isinstance(args, (dict, list))
                                else str(args)
                                if args
                                else None
                            )
                            messages.append(
                                {
                                    "seq": seq,
                                    "role": "assistant",
                                    "kind": "tool_call",
                                    # Codex's own UI shows the invoked command, so store a
                                    # displayable summary too. Tool rows used to carry no
                                    # `content` at all: 85% of parsed rows were blank, which
                                    # inflated message_count (400 rows for 15 real turns) and
                                    # left resumed chats looking empty.
                                    "content": _tool_call_summary(name, args_text),
                                    "tool_name": name,
                                    "tool_input": args_text,
                                    "created_at": timestamp,
                                }
                            )
                            seq += 1
                        elif ptype in ("function_call_output", "custom_tool_call_output"):
                            output = payload.get("output")
                            output_text = str(output)[:30000] if output else None
                            messages.append(
                                {
                                    "seq": seq,
                                    "role": "assistant",
                                    "kind": "tool_result",
                                    "content": _tool_result_summary(output_text),
                                    "tool_output": output_text,
                                    "created_at": timestamp,
                                }
                            )
                            seq += 1
                    elif stype in ("user_message", "user") or data.get("role") in ("user", "human"):
                        text = _sanitize_provider_text(
                            data.get("message") or data.get("content") or data.get("text") or ""
                        )
                        if text:
                            key = f"u:{text}"
                            if key not in seen_text:
                                seen_text.add(key)
                                messages.append(
                                    {
                                        "seq": seq,
                                        "role": "user",
                                        "kind": "user_message",
                                        "content": text,
                                        "created_at": timestamp,
                                    }
                                )
                                seq += 1
                    elif stype in ("assistant_message", "assistant", "agent_message") or data.get(
                        "role"
                    ) in ("assistant", "model"):
                        content = data.get("content") or data.get("text") or data.get("message") or ""
                        if isinstance(content, list):
                            text_parts = []
                            for item in content:
                                if isinstance(item, dict) and item.get("type") in (
                                    "text",
                                    "output_text",
                                ):
                                    text_parts.append(str(item.get("text") or ""))
                                elif isinstance(item, str):
                                    text_parts.append(item)
                            content = "\n".join(text_parts)
                        text = _sanitize_provider_text(str(content))
                        if text:
                            key = f"a:{text}"
                            if key not in seen_text:
                                seen_text.add(key)
                                messages.append(
                                    {
                                        "seq": seq,
                                        "role": "assistant",
                                        "kind": "assistant_final",
                                        "content": text,
                                        "created_at": timestamp,
                                    }
                                )
                                seq += 1
                except Exception:
                    continue
    except Exception:
        return []
    return messages


def _codex_data_roots() -> List[Any]:
    roots: List[Any] = [Path.home() / ".codex"]
    env = (os.getenv("CODEX_HOME") or "").strip()
    if env:
        roots.insert(0, env)
    roots.extend(_codex_state_db_paths())
    return roots


def _codex_identity_from_rollout(
    rollout_path: str,
    *,
    sqlite_id: str = "",
    requested_id: str = "",
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Return (authoritative_native_id, parse_status, cwd) from session_meta.

    External-v1 C.1.3: session_meta is identity root of truth. Filename / sqlite id
    are hints. On disagreement → IDENTITY_MISMATCH (caller must quarantine).
    """
    meta = _parse_codex_rollout_meta(rollout_path)
    meta_id = str(meta.get("session_id") or "").strip()
    cwd = meta.get("cwd") or None
    if not meta_id:
        # No session_meta: fall back to sqlite / request but flag weak identity.
        fallback = (sqlite_id or requested_id or "").strip() or None
        return fallback, ("OK_WEAK_IDENTITY" if fallback else None), cwd
    if sqlite_id and sqlite_id.strip() and sqlite_id.strip() != meta_id:
        return meta_id, "IDENTITY_MISMATCH", cwd
    if requested_id and requested_id.strip() and requested_id.strip() != meta_id:
        # Filename/hint matched but meta is different authority — quarantine.
        if requested_id not in meta_id and meta_id not in requested_id:
            return meta_id, "IDENTITY_MISMATCH", cwd
    return meta_id, "OK", cwd


def read_codex_thread(native_id: str) -> Optional[Dict[str, Any]]:
    """Exact native-thread read for one Codex thread id. None if missing/empty/quarantined."""
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    roots = _codex_data_roots()

    def _finish(
        *,
        sid: str,
        title: str,
        cwd: Optional[str],
        messages: List[Dict[str, Any]],
        parse_status: str,
        index_agreement: str,
        rpath: str = "",
    ) -> Optional[Dict[str, Any]]:
        if parse_status == "IDENTITY_MISMATCH":
            # External-v1: quarantine — do not upload as certified native history.
            return None
        if not messages:
            return None
        th = {
            "native_id": sid,
            "agent_type": "codex_cli",
            "project_path": _normalize_project_path(cwd) or cwd,
            "title": (title or "Codex session")[:80],
            "status": "active",
            "sync_cursor": str(len(messages)),
            "messages": messages,
        }
        return finalize_native_thread(
            th,
            provider_id="codex_cli",
            data_roots=roots + ([rpath] if rpath else []),
            source_hint=rpath or "",
            extra_meta={
                "parse_status": parse_status,
                "index_agreement": index_agreement,
                "identity_source": "session_meta",
            },
        )

    # 1) sqlite index (both state locations)
    for db_path in _codex_state_db_paths():
        try:
            _sql = _require_sqlite3()
            conn = _sql.connect(str(db_path))
            conn.row_factory = _sql.Row
            cur = conn.cursor()
            cur.execute(
                "SELECT id, title, cwd, rollout_path, created_at, updated_at "
                "FROM threads WHERE id = ? LIMIT 1",
                (native_id,),
            )
            r = cur.fetchone()
            conn.close()
            if not r:
                continue
            rpath = str(r["rollout_path"] or "")
            auth_id, parse_status, meta_cwd = _codex_identity_from_rollout(
                rpath, sqlite_id=str(r["id"] or ""), requested_id=native_id
            )
            if parse_status == "IDENTITY_MISMATCH":
                return None
            messages = _parse_codex_rollout_messages(rpath, str(r["updated_at"] or ""))
            title = _sanitize_provider_text(r["title"] or "") or "Codex session"
            cwd = meta_cwd or r["cwd"]
            return _finish(
                sid=str(auth_id or r["id"]),
                title=title,
                cwd=cwd,
                messages=messages,
                parse_status=parse_status or "OK",
                index_agreement="SQLITE_PLUS_ROLLOUT",
                rpath=rpath,
            )
        except Exception:
            continue
    # 2) Orphan rollout by session_meta id (authoritative) or filename hint
    codex_home = Path.home() / ".codex"
    if not codex_home.exists():
        return None
    try:
        for pattern in ("**/rollout*.jsonl", "**/session_*.jsonl", "**/*rollout*.jsonl"):
            for path in codex_home.glob(pattern):
                if not path.is_file():
                    continue
                p_str = str(path)
                meta = _parse_codex_rollout_meta(p_str)
                sid = str(meta.get("session_id") or "").strip()
                stem = path.stem
                # Prefer session_meta match; filename is hint only.
                if sid:
                    if sid != native_id and not (
                        native_id in sid or sid.endswith(native_id) or native_id.endswith(sid)
                    ):
                        # Filename may match requested id but meta is SoT — if stem matches
                        # request and meta differs, quarantine.
                        if native_id in stem or stem.endswith(native_id):
                            return None
                        continue
                else:
                    if native_id not in (stem,) and not stem.endswith(native_id) and native_id not in stem:
                        continue
                auth_id, parse_status, meta_cwd = _codex_identity_from_rollout(
                    p_str, requested_id=native_id
                )
                if parse_status == "IDENTITY_MISMATCH":
                    return None
                messages = _parse_codex_rollout_messages(p_str, "")
                if not messages:
                    continue
                title = None
                for m in messages:
                    if m.get("role") == "user" and m.get("content"):
                        title = str(m["content"])[:80]
                        break
                cwd = meta_cwd or meta.get("cwd") or str(path.parent)
                return _finish(
                    sid=str(auth_id or sid or native_id),
                    title=title or "Codex session",
                    cwd=cwd,
                    messages=messages,
                    parse_status=parse_status or "OK",
                    index_agreement="FILE_ONLY" if not sid else "SESSION_META",
                    rpath=p_str,
                )
    except Exception:
        return None
    return None


def read_codex_threads(limit: int = 10) -> List[Dict[str, Any]]:
    """Read local Codex CLI sessions from sqlite + rollout JSONL under ~/.codex.

    Covers official openai/codex stores: state_5.sqlite (root + sqlite/), and
    orphan rollout JSONL with session_meta native ids so every local chat can
    reach Megas (old sync priority).
    """
    codex_home = Path.home() / ".codex"
    threads: List[Dict[str, Any]] = []
    seen_ids: set[str] = set()
    seen_paths: set[str] = set()

    def _append(
        sid: str,
        title: str,
        cwd: Optional[str],
        messages: List[Dict[str, Any]],
        rpath: Optional[str] = None,
    ) -> None:
        if sid in seen_ids:
            return
        if rpath:
            p_str = str(rpath).strip()
            seen_paths.add(p_str)
            seen_paths.add(Path(p_str).stem)
        has_user_msg = any(m.get("role") == "user" and m.get("content") for m in messages)
        title_l = (title or "").lower()
        is_synthetic_test = any(
            bad in title_l
            for bad in (
                "wait-cancel-test",
                "check_quick",
                "test_prompt",
                "tmp_rollout",
                "synthetic_test",
            )
        )
        if not messages or not has_user_msg or is_synthetic_test:
            return
        seen_ids.add(sid)
        threads.append(
            {
                "native_id": sid,
                "agent_type": "codex_cli",
                "project_path": _normalize_project_path(cwd) or cwd,
                "title": (title or "Codex session")[:80],
                "status": "active",
                "sync_cursor": str(len(messages)),
                "messages": messages,
            }
        )

    for db_path in _codex_state_db_paths():
        try:
            _sql = _require_sqlite3()
            conn = _sql.connect(str(db_path))
            conn.row_factory = _sql.Row
            cur = conn.cursor()
            cur.execute(
                "SELECT id, title, cwd, rollout_path, created_at, updated_at "
                "FROM threads ORDER BY updated_at DESC LIMIT ?",
                (max(limit * 3, limit),),
            )
            rows = cur.fetchall()
            conn.close()
            for r in rows:
                if len(threads) >= limit:
                    break
                sid = str(r["id"] or "").strip()
                if not sid:
                    continue
                title = _sanitize_provider_text(r["title"] or "") or "Codex session"
                rpath = str(r["rollout_path"] or "")
                messages = _parse_codex_rollout_messages(rpath, str(r["updated_at"] or ""))
                _append(sid, title, r["cwd"], messages, rpath=rpath)
        except Exception:
            continue

    # Orphan rollouts / session files not indexed in sqlite yet.
    if len(threads) < limit and codex_home.exists():
        try:
            candidates: List[Path] = []
            for pattern in ("**/session_*.jsonl", "**/rollout*.jsonl", "**/*rollout*.jsonl"):
                try:
                    candidates.extend([p for p in codex_home.glob(pattern) if p.is_file()])
                except Exception:
                    continue
            candidates.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
            for path in candidates:
                if len(threads) >= limit:
                    break
                p_str = str(path)
                meta = _parse_codex_rollout_meta(p_str)
                sid = (meta.get("session_id") or path.stem).strip()
                if sid in seen_ids or path.stem in seen_ids or p_str in seen_paths:
                    continue
                # Skip if stem already covered via sqlite rollout path.
                if any(sid in s or path.stem in s for s in seen_paths):
                    continue
                messages = _parse_codex_rollout_messages(p_str, "")
                title = None
                for m in messages:
                    if m.get("role") == "user" and m.get("content"):
                        title = str(m["content"])[:80]
                        break
                cwd = meta.get("cwd") or str(path.parent)
                _append(sid, title or "Codex session", cwd, messages, rpath=p_str)
        except Exception:
            pass

    return threads[:limit]


def read_native_thread(agent_type: str, native_id: str) -> Optional[Dict[str, Any]]:
    """Exact single-thread read by provider + native id. Returns None when empty or missing."""
    provider = (agent_type or "").strip().lower()
    if provider in ("codex", "codex_cli"):
        return read_codex_thread(native_id)
    if provider in ("antigravity", "agy"):
        return read_agy_thread(native_id)
    if provider in ("gemini", "gemini_cli"):
        # Prefer pure Gemini CLI sessions; fall back to AGY only if that is the store.
        return read_gemini_thread(native_id) or read_agy_thread(native_id)
    if provider in ("claude", "claude_code"):
        return read_claude_thread(native_id)
    if provider in ("grok", "grok_build"):
        return read_grok_thread(native_id)
    if provider in ("opencode", "open_code"):
        return read_opencode_thread(native_id)
    if provider in ("kilo", "kilo_code", "kilocode"):
        return read_kilo_thread(native_id)
    return None


def _grok_home() -> Path:
    """Resolve Grok home the way the CLI does (GROK_HOME, else ~/.grok)."""
    env = (os.getenv("GROK_HOME") or "").strip()
    if env:
        return Path(env).expanduser()
    return Path.home() / ".grok"


def _grok_sessions_root() -> Path:
    return _grok_home() / "sessions"


def _decode_grok_cwd_segment(segment: str) -> str:
    """Grok stores cwd as a single URL-encoded path segment under sessions/."""
    try:
        from urllib.parse import unquote

        return unquote(segment or "")
    except Exception:
        return segment or ""


def _extract_grok_text_payload(content: Any) -> str:
    """Normalize Grok content blocks (string | {type,text} | [{type,text}])."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, dict):
                itype = str(item.get("type") or "")
                if itype in {"text", "output_text", "summary_text", ""} or "text" in item:
                    parts.append(str(item.get("text") or item.get("content") or ""))
                elif itype == "content" and isinstance(item.get("content"), dict):
                    parts.append(_extract_grok_text_payload(item.get("content")))
                elif isinstance(item.get("content"), str):
                    parts.append(item["content"])
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(p for p in parts if p)
    if isinstance(content, dict):
        if content.get("type") in {"text", "output_text", "summary_text"} or "text" in content:
            return str(content.get("text") or content.get("content") or "")
        return str(content.get("text") or content.get("content") or "")
    return str(content)


def _extract_grok_user_visible_text(raw: str) -> str:
    """Prefer <user_query> body (official wrap); slash commands may be unwrapped."""
    text = str(raw or "")
    m = _GROK_USER_QUERY_RE.search(text)
    if m:
        return _sanitize_provider_text(m.group(1))
    return _sanitize_provider_text(text)


def _grok_text_is_shell_noise(text: str) -> bool:
    """System/skills/meta blobs are not product chat turns."""
    low = (text or "").strip().lower()
    if not low:
        return True
    if low.startswith("<system-reminder>") or low.startswith("<user_info>"):
        return True
    if low.startswith("<git_status>") and "<user_query>" not in low:
        return True
    if low.startswith("you are grok"):
        return True
    return False


def _grok_session_has_user_chat(session_dir: Path) -> bool:
    """Cheap probe: real user/assistant chat exists (not skills-only shell session).

    Empty shells were indexed as thr_ \"Grok session\" then open → parser_error.
    """
    if not session_dir.is_dir():
        return False
    for name in ("updates.jsonl", "chat_history.jsonl"):
        path = session_dir / name
        if not path.is_file():
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for i, line in enumerate(f):
                    if i > 250:
                        break
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(data, dict):
                        continue
                    # ACP updates.jsonl
                    if data.get("method") == "session/update":
                        upd = (data.get("params") or {}).get("update") or {}
                        if not isinstance(upd, dict):
                            continue
                        su = str(upd.get("sessionUpdate") or "")
                        if su == "user_message_chunk":
                            vis = _extract_grok_user_visible_text(
                                _extract_grok_text_payload(upd.get("content"))
                            )
                            if vis and not _grok_text_is_shell_noise(vis):
                                return True
                        if su == "agent_message_chunk":
                            vis = _sanitize_provider_text(
                                _extract_grok_text_payload(upd.get("content"))
                            )
                            if vis and not _grok_text_is_shell_noise(vis):
                                return True
                        continue
                    # chat_history.jsonl ConversationItems
                    step = str(data.get("type") or data.get("role") or "").lower()
                    synth = str(data.get("synthetic_reason") or "").strip()
                    raw = _extract_grok_text_payload(data.get("content"))
                    if synth and synth in _GROK_SKIP_SYNTHETIC:
                        if not _GROK_USER_QUERY_RE.search(raw or ""):
                            continue
                    if step in {"user", "human", "user_message", "user_input"}:
                        vis = _extract_grok_user_visible_text(raw)
                        if vis and not _grok_text_is_shell_noise(vis):
                            return True
                    if step in {"assistant", "model", "ai", "bot"}:
                        prose = _sanitize_provider_text(raw)
                        if prose and not _grok_text_is_shell_noise(prose):
                            return True
                        if data.get("tool_calls"):
                            return True
        except Exception:
            continue
    return False


def _grok_session_dir(native_id: str) -> Optional[Path]:
    """Locate ~/.grok/sessions/<cwd_enc>/<session-id>/ directory."""
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    root = _grok_sessions_root()
    if not root.is_dir():
        return None
    try:
        for cwd_dir in root.iterdir():
            if not cwd_dir.is_dir():
                continue
            if cwd_dir.name.endswith(".sqlite"):
                continue
            candidate = cwd_dir / native_id
            if candidate.is_dir() and (
                (candidate / "chat_history.jsonl").is_file()
                or (candidate / "updates.jsonl").is_file()
                or (candidate / "summary.json").is_file()
            ):
                return candidate
    except Exception:
        pass
    try:
        matches = [
            p.parent
            for p in root.glob(f"**/{native_id}/chat_history.jsonl")
            if p.is_file()
        ] + [
            p.parent
            for p in root.glob(f"**/{native_id}/updates.jsonl")
            if p.is_file()
        ]
        if matches:
            matches.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
            return matches[0]
    except Exception:
        pass
    return None


def _list_grok_session_dirs(limit: int = 50) -> List[Path]:
    """Newest session directories under GROK_HOME/sessions (official layout)."""
    root = _grok_sessions_root()
    if not root.is_dir():
        return []
    dirs: List[Path] = []
    try:
        for path in root.rglob("summary.json"):
            if path.is_file() and path.parent.is_dir():
                dirs.append(path.parent)
        if not dirs:
            for path in root.rglob("chat_history.jsonl"):
                if path.is_file():
                    dirs.append(path.parent)
            for path in root.rglob("updates.jsonl"):
                if path.is_file() and path.parent not in dirs:
                    dirs.append(path.parent)
    except Exception:
        return []
    dirs.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    # de-dupe preserving order
    seen: set[str] = set()
    out: List[Path] = []
    for d in dirs:
        key = str(d.resolve()) if d.exists() else str(d)
        if key in seen:
            continue
        seen.add(key)
        out.append(d)
        if len(out) >= max(1, int(limit)):
            break
    return out


def _read_grok_summary(session_dir: Path) -> Dict[str, Any]:
    """summary.json is the index entry (title, git_root_dir, timestamps, counts)."""
    path = session_dir / "summary.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _grok_meta_from_sqlite(native_id: str) -> Dict[str, Any]:
    """Optional FTS index enrichment only — never message source of truth."""
    db_path = _grok_sessions_root() / "session_search.sqlite"
    if not db_path.exists():
        return {}
    try:
        _sql = _require_sqlite3()
        conn = _sql.connect(str(db_path))
        conn.row_factory = _sql.Row
        cur = conn.cursor()
        cur.execute(
            "SELECT session_id, cwd, updated_at, title FROM session_docs WHERE session_id = ? LIMIT 1",
            (native_id,),
        )
        r = cur.fetchone()
        conn.close()
        if not r:
            return {}
        return {
            "title": r["title"] or "",
            "cwd": r["cwd"] or "",
            "updated_at": str(r["updated_at"] or ""),
        }
    except Exception:
        return {}


def _parse_grok_updates_jsonl(path: Path) -> tuple[List[Dict[str, Any]], Optional[str], Dict[str, Any]]:
    """Parse official ACP updates.jsonl (authoritative conversation log for resume).

    Docs (17-sessions.md): updates.jsonl drives /resume; chat_history.jsonl is the
    raw model payload. We coalesce user/agent chunks and keep tool_call + results.
    """
    messages: List[Dict[str, Any]] = []
    title: Optional[str] = None
    seq = 0
    diagnostics: Dict[str, Any] = {
        "source_format": "updates.jsonl",
        "parser_version": _GROK_PARSER_VERSION,
        "skipped_lines": 0,
        "unsupported_kinds": 0,
    }
    user_buf: List[str] = []
    agent_buf: List[str] = []
    thought_buf: List[str] = []
    # Last tool_call_update content per toolCallId (streaming intermediate updates)
    tool_final: Dict[str, Dict[str, Any]] = {}
    tool_order: List[str] = []

    def _ts_from_line(data: dict) -> str:
        raw = data.get("timestamp")
        if raw is None:
            return ""
        return _iso_from_epoch_or_text(raw)

    def flush_user(created_at: str = "") -> None:
        nonlocal seq, title
        if not user_buf:
            return
        raw = "".join(user_buf)
        user_buf.clear()
        visible = _extract_grok_user_visible_text(raw)
        if not visible:
            return
        low = visible.lower()
        if low.startswith("<user_info>") or low.startswith("<system-reminder>"):
            return
        if not title:
            title = visible[:80]
        messages.append(
            {
                "seq": seq,
                "role": "user",
                "kind": "user_message",
                "content": visible,
                "created_at": created_at,
            }
        )
        seq += 1

    def flush_thought(created_at: str = "") -> None:
        nonlocal seq
        if not thought_buf:
            return
        text = _sanitize_provider_text("".join(thought_buf))
        thought_buf.clear()
        if not text:
            return
        messages.append(
            {
                "seq": seq,
                "role": "assistant",
                "kind": "reasoning",
                "content": text[:8000],
                "created_at": created_at,
            }
        )
        seq += 1

    def flush_agent(created_at: str = "") -> None:
        nonlocal seq
        if not agent_buf:
            return
        text = _sanitize_provider_text("".join(agent_buf))
        agent_buf.clear()
        if not text:
            return
        messages.append(
            {
                "seq": seq,
                "role": "assistant",
                "kind": "assistant_final",
                "content": text,
                "created_at": created_at,
            }
        )
        seq += 1

    def flush_tools() -> None:
        nonlocal seq
        for tc_id in tool_order:
            row = tool_final.get(tc_id) or {}
            out = row.get("content")
            if out is None:
                continue
            messages.append(
                {
                    "seq": seq,
                    "role": "assistant",
                    "kind": "tool_result",
                    "tool_name": row.get("name"),
                    "tool_call_id": tc_id,
                    "tool_output": str(out)[:30000],
                    "created_at": row.get("created_at") or "",
                }
            )
            seq += 1
        tool_final.clear()
        tool_order.clear()

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    diagnostics["skipped_lines"] += 1
                    continue
                if not isinstance(data, dict):
                    diagnostics["skipped_lines"] += 1
                    continue
                method = str(data.get("method") or "")
                if method not in {"session/update", "_x.ai/session/update"}:
                    diagnostics["unsupported_kinds"] += 1
                    continue
                params = data.get("params") if isinstance(data.get("params"), dict) else {}
                su = params.get("update") if isinstance(params.get("update"), dict) else params
                if not isinstance(su, dict):
                    continue
                kind = str(su.get("sessionUpdate") or "").strip()
                created_at = _ts_from_line(data)

                if kind == "user_message_chunk":
                    flush_agent(created_at)
                    flush_thought(created_at)
                    text = _extract_grok_text_payload(su.get("content"))
                    if text:
                        user_buf.append(text)
                elif kind == "agent_message_chunk":
                    flush_user(created_at)
                    text = _extract_grok_text_payload(su.get("content"))
                    if text:
                        agent_buf.append(text)
                elif kind == "agent_thought_chunk":
                    flush_user(created_at)
                    text = _extract_grok_text_payload(su.get("content"))
                    if text:
                        thought_buf.append(text)
                elif kind == "tool_call":
                    flush_user(created_at)
                    flush_thought(created_at)
                    flush_agent(created_at)
                    tc_id = str(su.get("toolCallId") or su.get("tool_call_id") or "")
                    name = str(
                        su.get("title")
                        or (su.get("_meta") or {}).get("x.ai/tool", {}).get("name")
                        if isinstance(su.get("_meta"), dict)
                        else su.get("title")
                        or ""
                    )
                    # Prefer x.ai tool name when present
                    meta = su.get("_meta") if isinstance(su.get("_meta"), dict) else {}
                    tool_meta = meta.get("x.ai/tool") if isinstance(meta.get("x.ai/tool"), dict) else {}
                    if tool_meta.get("name"):
                        name = str(tool_meta.get("name"))
                    raw_in = su.get("rawInput")
                    messages.append(
                        {
                            "seq": seq,
                            "role": "assistant",
                            "kind": "tool_call",
                            "tool_name": name or None,
                            "tool_call_id": tc_id or None,
                            "tool_input": json.dumps(raw_in)
                            if isinstance(raw_in, (dict, list))
                            else (str(raw_in) if raw_in is not None else None),
                            "created_at": created_at,
                        }
                    )
                    seq += 1
                    if tc_id and tc_id not in tool_final:
                        tool_order.append(tc_id)
                        tool_final[tc_id] = {
                            "name": name,
                            "content": None,
                            "created_at": created_at,
                        }
                elif kind == "tool_call_update":
                    tc_id = str(su.get("toolCallId") or su.get("tool_call_id") or "")
                    content = _extract_grok_text_payload(su.get("content"))
                    if tc_id:
                        if tc_id not in tool_final:
                            tool_order.append(tc_id)
                            tool_final[tc_id] = {
                                "name": str(su.get("title") or ""),
                                "content": None,
                                "created_at": created_at,
                            }
                        # Keep latest non-empty content (streaming updates)
                        if content:
                            tool_final[tc_id]["content"] = content
                            tool_final[tc_id]["created_at"] = created_at
                            if su.get("title"):
                                tool_final[tc_id]["name"] = str(su.get("title"))
                elif kind == "turn_completed":
                    flush_user(created_at)
                    flush_thought(created_at)
                    flush_agent(created_at)
                    flush_tools()
                elif kind in {
                    "plan",
                    "session_recap",
                    "task_backgrounded",
                    "task_completed",
                    "retry_state",
                    "auto_compact_started",
                    "auto_compact_completed",
                    "compaction_checkpoint",
                    "subagent_spawned",
                    "subagent_finished",
                    "goal_updated",
                    "scheduled_task_created",
                    "scheduled_task_deleted",
                }:
                    # Structured session signals — not chat turns; skip without error.
                    flush_user(created_at)
                    flush_thought(created_at)
                    flush_agent(created_at)
                else:
                    if kind:
                        diagnostics["unsupported_kinds"] += 1
        # EOF flush
        flush_user()
        flush_thought()
        flush_agent()
        flush_tools()
    except Exception as exc:
        diagnostics["errors"] = [str(exc)[:160]]
        return [], None, diagnostics
    return messages, title, diagnostics


def _parse_grok_chat_history(path: Path) -> tuple[List[Dict[str, Any]], Optional[str], Dict[str, Any]]:
    """Parse chat_history.jsonl ConversationItems (model payload).

    Official types observed: system, user, assistant, reasoning, tool_result,
    backend_tool_call. User role is keyed on ``type`` (not ``role``); prompts
    usually wrap in <user_query>; synthetic_reason marks injected scaffolding.
    """
    messages: List[Dict[str, Any]] = []
    title: Optional[str] = None
    seq = 0
    diagnostics: Dict[str, Any] = {
        "source_format": "chat_history.jsonl",
        "parser_version": _GROK_PARSER_VERSION,
        "skipped_lines": 0,
    }
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    diagnostics["skipped_lines"] += 1
                    continue
                if not isinstance(data, dict):
                    continue
                step_type = str(data.get("type") or data.get("role") or "").strip().lower()
                synthetic = str(data.get("synthetic_reason") or "").strip().lower()
                if synthetic and (
                    synthetic in _GROK_SKIP_SYNTHETIC or synthetic.startswith("compaction")
                ):
                    continue
                created_at = str(
                    data.get("created_at")
                    or data.get("timestamp")
                    or data.get("updated_at")
                    or ""
                )

                if step_type == "system":
                    continue

                if step_type in {"user", "human", "user_input", "user_message"}:
                    # Compaction/meta synthetic rows (skills, project_instructions, …)
                    synth = str(data.get("synthetic_reason") or "").strip()
                    raw_text = _extract_grok_text_payload(data.get("content"))
                    if synth and synth in _GROK_SKIP_SYNTHETIC:
                        if not _GROK_USER_QUERY_RE.search(raw_text or ""):
                            continue
                    visible = _extract_grok_user_visible_text(raw_text)
                    if not visible or _grok_text_is_shell_noise(visible):
                        continue
                    if not title:
                        title = visible[:80]
                    messages.append(
                        {
                            "seq": seq,
                            "role": "user",
                            "kind": "user_message",
                            "content": visible,
                            "created_at": created_at,
                        }
                    )
                    seq += 1
                    continue

                if step_type == "reasoning":
                    # Prefer summary_text blocks; encrypted_content is not useful.
                    summary = data.get("summary")
                    text = _extract_grok_text_payload(summary) or _extract_grok_text_payload(
                        data.get("content")
                    )
                    text = _sanitize_provider_text(text)
                    if text:
                        messages.append(
                            {
                                "seq": seq,
                                "role": "assistant",
                                "kind": "reasoning",
                                "content": text[:8000],
                                "created_at": created_at,
                            }
                        )
                        seq += 1
                    continue

                if step_type in {"assistant", "model", "ai", "bot"}:
                    prose = _sanitize_provider_text(
                        _extract_grok_text_payload(data.get("content"))
                    )
                    tool_calls = data.get("tool_calls") or []
                    if prose:
                        messages.append(
                            {
                                "seq": seq,
                                "role": "assistant",
                                "kind": "assistant_final",
                                "content": prose,
                                "created_at": created_at,
                            }
                        )
                        seq += 1
                    if isinstance(tool_calls, list):
                        for tc in tool_calls:
                            if not isinstance(tc, dict):
                                continue
                            name = tc.get("name")
                            args = tc.get("arguments") or tc.get("args")
                            tc_id = tc.get("id") or tc.get("tool_call_id")
                            messages.append(
                                {
                                    "seq": seq,
                                    "role": "assistant",
                                    "kind": "tool_call",
                                    "tool_name": name,
                                    "tool_call_id": str(tc_id) if tc_id else None,
                                    "tool_input": json.dumps(args)
                                    if isinstance(args, (dict, list))
                                    else (str(args) if args is not None else None),
                                    "created_at": created_at,
                                }
                            )
                            seq += 1
                    continue

                if step_type == "tool_result":
                    out = _extract_grok_text_payload(data.get("content"))
                    messages.append(
                        {
                            "seq": seq,
                            "role": "assistant",
                            "kind": "tool_result",
                            "tool_call_id": str(data.get("tool_call_id") or "") or None,
                            "tool_output": str(out)[:30000] if out else None,
                            "created_at": created_at,
                        }
                    )
                    seq += 1
                    continue

                if step_type == "backend_tool_call":
                    kind = data.get("kind") if isinstance(data.get("kind"), dict) else {}
                    name = str(kind.get("tool_type") or "backend_tool")
                    action = kind.get("action") if isinstance(kind.get("action"), dict) else {}
                    messages.append(
                        {
                            "seq": seq,
                            "role": "assistant",
                            "kind": "tool_call",
                            "tool_name": name,
                            "tool_call_id": str(kind.get("id") or "") or None,
                            "tool_input": json.dumps(action) if action else None,
                            "created_at": created_at,
                        }
                    )
                    seq += 1
                    continue
    except Exception as exc:
        diagnostics["errors"] = [str(exc)[:160]]
        return [], None, diagnostics
    return messages, title, diagnostics


def _thread_from_grok_session_dir(session_dir: Path) -> Optional[Dict[str, Any]]:
    """Build thr_ payload from an official Grok session directory.

    Preference order (official 17-sessions.md):
      1) updates.jsonl — authoritative ACP log for resume
      2) chat_history.jsonl — raw model ConversationItems
    Metadata from summary.json (title, git_root_dir); FTS sqlite is last resort.
    """
    if not session_dir.is_dir():
        return None
    sid = session_dir.name.strip()
    if not sid:
        return None

    summary = _read_grok_summary(session_dir)
    updates = session_dir / "updates.jsonl"
    history = session_dir / "chat_history.jsonl"

    messages: List[Dict[str, Any]] = []
    parsed_title: Optional[str] = None
    diagnostics: Dict[str, Any] = {}
    source = ""

    if updates.is_file() and updates.stat().st_size > 0:
        messages, parsed_title, diagnostics = _parse_grok_updates_jsonl(updates)
        source = "updates.jsonl"
    if (not messages) and history.is_file():
        messages, parsed_title, diagnostics = _parse_grok_chat_history(history)
        source = "chat_history.jsonl"
    if not messages:
        return None

    # Real workspace: summary.git_root_dir (not encoded sessions path).
    project_path = str(summary.get("git_root_dir") or "").strip()
    fts = _grok_meta_from_sqlite(sid)
    if not project_path:
        project_path = str(fts.get("cwd") or "").strip()
    if not project_path:
        # Fall back to URL-decoded parent segment; optional .cwd file
        parent = session_dir.parent
        cwd_file = parent / ".cwd"
        if cwd_file.is_file():
            try:
                project_path = cwd_file.read_text(encoding="utf-8", errors="replace").strip()
            except Exception:
                project_path = ""
        if not project_path:
            project_path = _decode_grok_cwd_segment(parent.name)

    title = (
        str(summary.get("generated_title") or summary.get("session_summary") or "").strip()
        or str(fts.get("title") or "").strip()
        or (parsed_title or "")
        or "Grok session"
    )[:80]

    # Cursor: max mtime|size across authoritative files so deltas fire on any change.
    cursor_parts: List[str] = []
    for p in (updates, history, session_dir / "summary.json"):
        try:
            if p.is_file():
                st = p.stat()
                cursor_parts.append(f"{int(st.st_mtime)}|{int(st.st_size)}")
        except Exception:
            pass
    cursor = ";".join(cursor_parts) if cursor_parts else str(len(messages))

    th = {
        "native_id": sid,
        "agent_type": "grok_build",
        "project_path": _normalize_project_path(project_path) if project_path else project_path,
        "title": title,
        "status": "active",
        "sync_cursor": cursor,
        "messages": messages,
        "metadata_json": json.dumps(
            {
                "provider": "grok_build",
                "parser_version": _GROK_PARSER_VERSION,
                "source_format": source or diagnostics.get("source_format"),
                "source_path": str(session_dir),
                "native_thread_id": sid,
                "chat_format_version": summary.get("chat_format_version"),
                "agent_name": summary.get("agent_name"),
                "parse_diagnostics": {
                    k: diagnostics.get(k)
                    for k in ("skipped_lines", "unsupported_kinds", "errors")
                    if diagnostics.get(k) not in (None, 0, [], "")
                },
            }
        ),
    }
    return finalize_native_thread(
        th,
        provider_id="grok_build",
        data_roots=[_grok_home(), session_dir],
        source_hint=str(session_dir),
        extra_meta={"identity_source": "session_dir", "source_format": source},
    )


def read_grok_thread(native_id: str) -> Optional[Dict[str, Any]]:
    """Exact native-thread read for one Grok Build session.

    Official layout (17-sessions.md)::

        $GROK_HOME/sessions/<encoded-cwd>/<session-id>/
          summary.json, updates.jsonl, chat_history.jsonl, ...

    ``session_search.sqlite`` is FTS only — never the transcript source of truth.
    """
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    session_dir = _grok_session_dir(native_id)
    if session_dir is not None:
        return _thread_from_grok_session_dir(session_dir)

    # Legacy / unit-test path: session_docs.content as JSON message list.
    db_path = _grok_sessions_root() / "session_search.sqlite"
    if not db_path.exists():
        return None
    try:
        _sql = _require_sqlite3()
        conn = _sql.connect(str(db_path))
        conn.row_factory = _sql.Row
        cur = conn.cursor()
        cur.execute(
            "SELECT session_id, cwd, updated_at, title, content FROM session_docs WHERE session_id = ? LIMIT 1",
            (native_id,),
        )
        r = cur.fetchone()
        conn.close()
        if not r:
            return None
        title = r["title"] or "Grok session"
        cwd = r["cwd"]
        updated_ts = str(r["updated_at"] or "")
        raw_content = r["content"] or ""
        messages: List[Dict[str, Any]] = []
        seq = 0
        if raw_content:
            try:
                parsed = json.loads(raw_content)
                if isinstance(parsed, list):
                    for item in parsed:
                        if not isinstance(item, dict):
                            continue
                        role = item.get("role") or (
                            "user" if item.get("type") == "user" else "assistant"
                        )
                        content = item.get("content") or item.get("text") or ""
                        if isinstance(content, list):
                            content = _extract_grok_text_payload(content)
                        text = _sanitize_provider_text(str(content))
                        if not text:
                            continue
                        messages.append(
                            {
                                "seq": seq,
                                "role": role,
                                "kind": "user_message" if role == "user" else "assistant_final",
                                "content": text,
                                "created_at": updated_ts,
                            }
                        )
                        seq += 1
            except Exception:
                pass
        if not messages:
            return None
        return {
            "native_id": native_id,
            "agent_type": "grok_build",
            "project_path": cwd,
            "title": str(title)[:80],
            "status": "active",
            "sync_cursor": str(len(messages)),
            "messages": messages,
            "metadata_json": json.dumps(
                {
                    "provider": "grok_build",
                    "parser_version": _GROK_PARSER_VERSION,
                    "source_format": "session_docs_json_legacy",
                }
            ),
        }
    except Exception:
        return None


def read_grok_threads(limit: int = 10) -> List[Dict[str, Any]]:
    """List Grok Build sessions from official session dirs (not FTS alone)."""
    limit = max(1, int(limit or 10))
    threads: List[Dict[str, Any]] = []
    seen: set[str] = set()

    for session_dir in _list_grok_session_dirs(limit * 3):
        if len(threads) >= limit:
            break
        sid = session_dir.name
        if sid in seen:
            continue
        row = _thread_from_grok_session_dir(session_dir)
        if not row:
            continue
        seen.add(sid)
        threads.append(row)

    return threads[:limit]


def _parse_generic_jsonl_messages(path: Path) -> List[Dict[str, Any]]:
    """Best-effort role/content extraction for unknown CLI JSONL stores."""
    messages: List[Dict[str, Any]] = []
    seq = 0
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                if not isinstance(data, dict):
                    continue
                role = str(data.get("role") or data.get("type") or "").lower()
                content = data.get("content") or data.get("text") or data.get("message") or ""
                if isinstance(content, list):
                    parts = []
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "text":
                            parts.append(str(item.get("text") or ""))
                        elif isinstance(item, str):
                            parts.append(item)
                    content = "\n".join(p for p in parts if p)
                text = _sanitize_provider_text(str(content))
                if not text:
                    continue
                if role in {"user", "human", "user_input", "user_message"}:
                    messages.append({
                        "seq": seq,
                        "role": "user",
                        "kind": "user_message",
                        "content": text,
                        "created_at": str(data.get("timestamp") or data.get("created_at") or ""),
                    })
                    seq += 1
                elif role in {"assistant", "model", "ai", "assistant_message"}:
                    messages.append({
                        "seq": seq,
                        "role": "assistant",
                        "kind": "assistant_final",
                        "content": text,
                        "created_at": str(data.get("timestamp") or data.get("created_at") or ""),
                    })
                    seq += 1
    except Exception:
        return []
    return messages


def _scan_jsonl_agent_roots(
    roots: List[Path],
    *,
    agent_type: str,
    limit: int = 5,
) -> List[Dict[str, Any]]:
    """Scan directory trees for *.jsonl session files (gemini/opencode/kilo/…)."""
    files: List[Path] = []
    for root in roots:
        if not root.exists():
            continue
        try:
            files.extend([p for p in root.rglob("*.jsonl") if p.is_file()])
        except Exception:
            continue
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    threads: List[Dict[str, Any]] = []
    for path in files[: max(limit * 3, limit)]:
        if len(threads) >= limit:
            break
        # Skip AGY brain already covered by read_agy_threads.
        if "antigravity" in str(path).lower():
            continue
        if f"{os.sep}brain{os.sep}" in str(path) or f"{os.sep}scratch{os.sep}" in str(path):
            continue
        messages = _parse_generic_jsonl_messages(path)
        if not messages:
            continue
        native_id = path.stem
        title = None
        for m in messages:
            if m.get("role") == "user" and m.get("content"):
                title = str(m["content"])[:80]
                break
        threads.append({
            "native_id": native_id,
            "agent_type": agent_type,
            "project_path": str(path.parent),
            "title": title or f"{agent_type} session",
            "status": "active",
            "sync_cursor": str(len(messages)),
            "messages": messages,
        })
    return threads


def read_gemini_threads(limit: int = 10) -> List[Dict[str, Any]]:
    home = Path.home()
    return _scan_jsonl_agent_roots(
        [home / ".gemini" / "tmp", home / ".gemini" / "sessions", home / ".config" / "gemini"],
        agent_type="gemini_cli",
        limit=limit,
    )


def read_gemini_thread(native_id: str) -> Optional[Dict[str, Any]]:
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    for th in read_gemini_threads(limit=50):
        if th.get("native_id") == native_id:
            return th
    return None


def _opencode_roots() -> List[Path]:
    home = Path.home()
    return [
        home / ".local" / "share" / "opencode",
        home / ".config" / "opencode",
        home / ".opencode",
        home / "AppData" / "Roaming" / "opencode",
        home / "AppData" / "Local" / "opencode",
    ]


def _kilo_roots() -> List[Path]:
    home = Path.home()
    return [
        home / ".kilocode",
        home / ".kilo",
        home / ".config" / "kilocode",
        home / ".config" / "kilo",
        home / "AppData" / "Roaming" / "kilocode",
        home / "AppData" / "Roaming" / "Kilo",
        home / "AppData" / "Roaming" / "Kilo Code",
        home / "AppData" / "Local" / "kilocode",
        home / "AppData" / "Local" / "Kilo",
    ]


def _find_sqlite_under(roots: List[Path], names: tuple[str, ...]) -> List[Path]:
    found: List[Path] = []
    seen: set[str] = set()
    for root in roots:
        if not root.exists():
            continue
        for name in names:
            p = root / name
            try:
                if p.is_file():
                    key = str(p.resolve())
                    if key not in seen:
                        seen.add(key)
                        found.append(p)
            except Exception:
                if p.is_file() and str(p) not in seen:
                    found.append(p)
        # Shallow recursive look for known db basenames
        try:
            for p in root.rglob("*.db"):
                if p.name.lower() in {n.lower() for n in names} or p.name.lower() in {
                    "opencode.db",
                    "kilo.db",
                    "store.db",
                    "data.db",
                }:
                    try:
                        key = str(p.resolve())
                    except Exception:
                        key = str(p)
                    if key not in seen:
                        seen.add(key)
                        found.append(p)
        except Exception:
            continue
    return found


def _sqlite_table_names(conn: Any) -> set[str]:
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return {str(r[0]) for r in cur.fetchall()}


def _message_role_from_data(data: Any) -> Optional[str]:
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except Exception:
            return None
    if not isinstance(data, dict):
        return None
    role = str(data.get("role") or data.get("type") or "").lower()
    if role in ("user", "human", "user_message"):
        return "user"
    if role in ("assistant", "model", "ai", "assistant_message"):
        return "assistant"
    return None


def _extract_text_from_part_row(row: Any, cols: set[str]) -> tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """Return (kind, text, tool_name, tool_payload) from a part-like row."""
    ptype = ""
    if "type" in cols:
        ptype = str(row["type"] or "").lower()
    text = None
    for key in ("text", "content", "output", "value"):
        if key in cols and row[key]:
            text = str(row[key])
            break
    # JSON data column
    data_obj = None
    if "data" in cols and row["data"]:
        raw = row["data"]
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode("utf-8", errors="replace")
        if isinstance(raw, str):
            try:
                data_obj = json.loads(raw)
            except Exception:
                if not text:
                    text = raw
        elif isinstance(raw, dict):
            data_obj = raw
    if isinstance(data_obj, dict):
        if not text:
            text = (
                data_obj.get("text")
                or data_obj.get("content")
                or data_obj.get("output")
                or data_obj.get("message")
            )
            if isinstance(text, list):
                parts = []
                for it in text:
                    if isinstance(it, dict) and it.get("text"):
                        parts.append(str(it["text"]))
                    elif isinstance(it, str):
                        parts.append(it)
                text = "\n".join(parts)
            if text is not None:
                text = str(text)
        tool_name = data_obj.get("name") or data_obj.get("toolName") or data_obj.get("tool")
        if ptype in ("tool", "tool_use", "tool-invocation", "tool_call") or tool_name:
            return "tool_call", text, str(tool_name) if tool_name else None, json.dumps(data_obj.get("input") or data_obj.get("arguments") or data_obj)[:8000]
        if ptype in ("tool_result", "tool-result", "tool_output"):
            return "tool_result", text, None, None
    if ptype in ("tool", "tool_use", "tool-invocation", "tool_call"):
        name = None
        if "tool" in cols:
            name = str(row["tool"] or "") or None
        return "tool_call", text, name, text
    if ptype in ("tool_result", "tool-result"):
        return "tool_result", text, None, None
    if text:
        return "text", text, None, None
    return None, None, None, None


def _read_sqlite_session_store(
    db_path: Path,
    *,
    agent_type: str,
    limit: int = 10,
    only_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Opportunistic reader for OpenCode/Kilo-style session/message/part SQLite stores.

    Supports common shapes:
      - session(id, title, directory|cwd|path, time_updated|updated_at|…)
      - message(id, session_id, role|data, time_created|…)
      - optional part(message_id, type, text|data)
      - optional session_message join table
    Empty / unknown schemas return [] — never synthetic.
    """
    if not db_path.is_file():
        return []
    out: List[Dict[str, Any]] = []
    try:
        _sql = _require_sqlite3()
        conn = _sql.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = _sql.Row
        tables = {t.lower(): t for t in _sqlite_table_names(conn)}
        # Resolve table names case-insensitively
        session_t = tables.get("session") or tables.get("sessions") or tables.get("chat") or tables.get("threads")
        message_t = tables.get("message") or tables.get("messages")
        part_t = tables.get("part") or tables.get("parts") or tables.get("message_part")
        if not session_t or not message_t:
            conn.close()
            return []
        cur = conn.cursor()
        cur.execute(f"PRAGMA table_info({session_t})")
        sess_cols = {str(r[1]).lower(): str(r[1]) for r in cur.fetchall()}
        cur.execute(f"PRAGMA table_info({message_t})")
        msg_cols = {str(r[1]).lower(): str(r[1]) for r in cur.fetchall()}
        id_col = sess_cols.get("id") or sess_cols.get("session_id")
        if not id_col:
            conn.close()
            return []
        title_col = sess_cols.get("title") or sess_cols.get("name") or sess_cols.get("summary")
        cwd_col = (
            sess_cols.get("directory")
            or sess_cols.get("cwd")
            or sess_cols.get("path")
            or sess_cols.get("project_path")
            or sess_cols.get("workspace")
        )
        updated_col = (
            sess_cols.get("time_updated")
            or sess_cols.get("updated_at")
            or sess_cols.get("updated")
            or sess_cols.get("time_created")
            or sess_cols.get("created_at")
        )
        order_sql = f" ORDER BY {updated_col} DESC" if updated_col else ""
        if only_id:
            cur.execute(f"SELECT * FROM {session_t} WHERE {id_col} = ? LIMIT 1", (only_id,))
            sessions = cur.fetchall()
        else:
            cur.execute(f"SELECT * FROM {session_t}{order_sql} LIMIT ?", (max(limit * 2, limit),))
            sessions = cur.fetchall()

        msg_session_col = msg_cols.get("session_id") or msg_cols.get("sessionid") or msg_cols.get("chat_id")
        msg_id_col = msg_cols.get("id") or msg_cols.get("message_id")
        msg_role_col = msg_cols.get("role") or msg_cols.get("type")
        msg_data_col = msg_cols.get("data") or msg_cols.get("content") or msg_cols.get("body")
        msg_time_col = (
            msg_cols.get("time_created")
            or msg_cols.get("created_at")
            or msg_cols.get("time")
            or msg_cols.get("timestamp")
        )
        if not msg_session_col:
            conn.close()
            return []

        part_cols: Dict[str, str] = {}
        part_msg_col = None
        part_id_col = None
        if part_t:
            cur.execute(f"PRAGMA table_info({part_t})")
            part_cols = {str(r[1]).lower(): str(r[1]) for r in cur.fetchall()}
            part_msg_col = part_cols.get("message_id") or part_cols.get("messageid")
            part_id_col = part_cols.get("id") or part_cols.get("part_id")

        for sess in sessions:
            if len(out) >= limit:
                break
            sid = str(sess[id_col] or "").strip()
            if not sid:
                continue
            title = ""
            if title_col:
                title = _sanitize_provider_text(str(sess[title_col] or ""))
            cwd = None
            if cwd_col:
                cwd = str(sess[cwd_col] or "").strip() or None
            order_msg = f" ORDER BY {msg_time_col} ASC" if msg_time_col else ""
            cur.execute(
                f"SELECT * FROM {message_t} WHERE {msg_session_col} = ?{order_msg}",
                (sid,),
            )
            msg_rows = cur.fetchall()
            messages: List[Dict[str, Any]] = []
            seq = 0
            for mr in msg_rows:
                mid = str(mr[msg_id_col]) if msg_id_col and mr[msg_id_col] is not None else ""
                role = None
                if msg_role_col:
                    role = str(mr[msg_role_col] or "").lower()
                    if role in ("user", "human", "user_message"):
                        role = "user"
                    elif role in ("assistant", "model", "ai", "assistant_message"):
                        role = "assistant"
                    else:
                        role = None
                raw_data = mr[msg_data_col] if msg_data_col else None
                if role is None:
                    role = _message_role_from_data(raw_data)
                if role not in ("user", "assistant"):
                    continue
                created_at = str(mr[msg_time_col] or "") if msg_time_col else ""
                # Prefer parts when present
                part_rows = []
                if part_t and part_msg_col and mid:
                    cur.execute(
                        f"SELECT * FROM {part_t} WHERE {part_msg_col} = ?",
                        (mid,),
                    )
                    part_rows = cur.fetchall()
                if part_rows:
                    for pr in part_rows:
                        part_native_id = (
                            str(pr[part_id_col] or "").strip()
                            if part_id_col and pr[part_id_col] is not None
                            else ""
                        )
                        kind, text, tool_name, tool_in = _extract_text_from_part_row(
                            pr, set(part_cols.keys())
                        )
                        if kind == "tool_call":
                            messages.append(
                                {
                                    "seq": seq,
                                    "role": "assistant",
                                    "kind": "tool_call",
                                    "tool_name": tool_name,
                                    "tool_input": tool_in,
                                    "created_at": created_at,
                                    **(
                                        {"native_item_id": part_native_id}
                                        if part_native_id
                                        else {}
                                    ),
                                }
                            )
                            seq += 1
                        elif kind == "tool_result":
                            messages.append(
                                {
                                    "seq": seq,
                                    "role": "assistant",
                                    "kind": "tool_result",
                                    "tool_output": _sanitize_provider_text(text or "") or None,
                                    "created_at": created_at,
                                    **(
                                        {"native_item_id": part_native_id}
                                        if part_native_id
                                        else {}
                                    ),
                                }
                            )
                            seq += 1
                        elif text:
                            txt = _sanitize_provider_text(text)
                            if not txt:
                                continue
                            if role == "user" and not title:
                                title = txt[:80]
                            messages.append(
                                {
                                    "seq": seq,
                                    "role": role,
                                    "kind": "user_message" if role == "user" else "assistant_final",
                                    "content": txt,
                                    "created_at": created_at,
                                    **(
                                        {"native_item_id": part_native_id}
                                        if part_native_id
                                        else {}
                                    ),
                                }
                            )
                            seq += 1
                    continue
                # Flat message content / data
                content = None
                if raw_data is not None:
                    if isinstance(raw_data, (bytes, bytearray)):
                        raw_data = raw_data.decode("utf-8", errors="replace")
                    if isinstance(raw_data, str):
                        try:
                            parsed = json.loads(raw_data)
                            if isinstance(parsed, dict):
                                content = (
                                    parsed.get("content")
                                    or parsed.get("text")
                                    or parsed.get("message")
                                )
                                if isinstance(content, list):
                                    parts = []
                                    for it in content:
                                        if isinstance(it, dict) and it.get("text"):
                                            parts.append(str(it["text"]))
                                        elif isinstance(it, str):
                                            parts.append(it)
                                    content = "\n".join(parts)
                            else:
                                content = raw_data
                        except Exception:
                            content = raw_data
                    else:
                        content = str(raw_data)
                txt = _sanitize_provider_text(str(content or ""))
                if not txt:
                    continue
                if role == "user" and not title:
                    title = txt[:80]
                messages.append(
                    {
                        "seq": seq,
                        "role": role,
                        "kind": "user_message" if role == "user" else "assistant_final",
                        "content": txt,
                        "created_at": created_at,
                        **({"native_item_id": mid} if mid else {}),
                    }
                )
                seq += 1
            if not messages:
                continue
            out.append(
                {
                    "native_id": sid,
                    "agent_type": agent_type,
                    "project_path": _normalize_project_path(cwd) or cwd,
                    "title": (title or f"{agent_type} session")[:80],
                    "status": "active",
                    "sync_cursor": str(len(messages)),
                    "messages": messages,
                }
            )
        conn.close()
    except Exception:
        return out
    return out


def read_opencode_threads(limit: int = 10) -> List[Dict[str, Any]]:
    """OpenCode: prefer opencode.db session store; fall back to JSONL scan."""
    roots = _opencode_roots()
    threads: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for db in _find_sqlite_under(roots, ("opencode.db", "store.db", "data.db")):
        for th in _read_sqlite_session_store(db, agent_type="opencode", limit=limit):
            sid = str(th.get("native_id") or "")
            if sid and sid not in seen:
                seen.add(sid)
                threads.append(th)
            if len(threads) >= limit:
                return threads[:limit]
    if len(threads) < limit:
        for th in _scan_jsonl_agent_roots(roots, agent_type="opencode", limit=limit):
            sid = str(th.get("native_id") or "")
            if sid and sid not in seen:
                seen.add(sid)
                threads.append(th)
            if len(threads) >= limit:
                break
    return threads[:limit]


def read_opencode_thread(native_id: str) -> Optional[Dict[str, Any]]:
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    for db in _find_sqlite_under(_opencode_roots(), ("opencode.db", "store.db", "data.db")):
        rows = _read_sqlite_session_store(
            db, agent_type="opencode", limit=1, only_id=native_id
        )
        if rows:
            return rows[0]
    for th in read_opencode_threads(limit=50):
        if th.get("native_id") == native_id:
            return th
    return None


def read_kilo_threads(limit: int = 10) -> List[Dict[str, Any]]:
    """Kilo Code: prefer kilo.db (session/message/part); fall back to JSONL."""
    roots = _kilo_roots()
    threads: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for db in _find_sqlite_under(roots, ("kilo.db", "store.db", "data.db", "kilocode.db")):
        for th in _read_sqlite_session_store(db, agent_type="kilo_code", limit=limit):
            sid = str(th.get("native_id") or "")
            if sid and sid not in seen:
                seen.add(sid)
                threads.append(th)
            if len(threads) >= limit:
                return threads[:limit]
    if len(threads) < limit:
        for th in _scan_jsonl_agent_roots(roots, agent_type="kilo_code", limit=limit):
            sid = str(th.get("native_id") or "")
            if sid and sid not in seen:
                seen.add(sid)
                threads.append(th)
            if len(threads) >= limit:
                break
    return threads[:limit]


def read_kilo_thread(native_id: str) -> Optional[Dict[str, Any]]:
    native_id = (native_id or "").strip()
    if not native_id:
        return None
    for db in _find_sqlite_under(_kilo_roots(), ("kilo.db", "store.db", "data.db", "kilocode.db")):
        rows = _read_sqlite_session_store(
            db, agent_type="kilo_code", limit=1, only_id=native_id
        )
        if rows:
            return rows[0]
    for th in read_kilo_threads(limit=50):
        if th.get("native_id") == native_id:
            return th
    return None


def _index_row(
    *,
    native_id: str,
    agent_type: str,
    title: str,
    project_path: Optional[str],
    sync_cursor: str,
) -> Dict[str, Any]:
    return {
        "native_id": native_id,
        "agent_type": agent_type,
        "title": (title or "Chat")[:80],
        "project_path": project_path,
        "status": "active",
        "sync_cursor": str(sync_cursor or ""),
        "messages": [],  # index only — full body on cursor change or open
    }


def index_codex_threads(limit: int = 30) -> List[Dict[str, Any]]:
    """Codex light index — Remodex + Notion C.1.3 three-source union.

    Sources:
      1) state_*.sqlite ``threads`` table
      2) ``session_index.jsonl`` (append-only)
      3) ``sessions/`` tree ``rollout-*.jsonl`` (session_meta id)

    Each row gets ``index_agreement`` in metadata:
    ALL_AGREE | SQLITE_ONLY | INDEX_ONLY | FILE_ONLY | SQLITE_PLUS_FILE |
    INDEX_PLUS_FILE | SQLITE_PLUS_INDEX | CONFLICT
    """
    # sid -> accumulator
    acc: Dict[str, Dict[str, Any]] = {}

    def _touch(
        sid: str,
        *,
        source: str,
        title: str = "",
        cwd: Any = None,
        rpath: str = "",
        updated: str = "",
    ) -> None:
        if not sid:
            return
        row = acc.get(sid)
        if row is None:
            row = {
                "sources": set(),
                "title": "",
                "cwd": None,
                "rpath": "",
                "updated": "",
            }
            acc[sid] = row
        row["sources"].add(source)
        if title and not row["title"]:
            row["title"] = title
        if cwd and not row["cwd"]:
            row["cwd"] = cwd
        if rpath and not row["rpath"]:
            row["rpath"] = rpath
        if updated and (not row["updated"] or str(updated) > str(row["updated"])):
            row["updated"] = str(updated)

    # --- 1) SQLite ---
    for db_path in _codex_state_db_paths():
        try:
            _sql = _require_sqlite3()
            conn = _sql.connect(str(db_path))
            conn.row_factory = _sql.Row
            cur = conn.cursor()
            cur.execute(
                "SELECT id, title, cwd, rollout_path, updated_at FROM threads "
                "ORDER BY updated_at DESC LIMIT ?",
                (max(limit * 3, limit),),
            )
            for r in cur.fetchall():
                sid = str(r["id"] or "").strip()
                if not sid:
                    continue
                title = _sanitize_provider_text(r["title"] or "") or ""
                if title and any(
                    bad in title.lower()
                    for bad in (
                        "wait-cancel-test",
                        "check_quick",
                        "test_prompt",
                        "tmp_rollout",
                        "synthetic_test",
                    )
                ):
                    continue
                _touch(
                    sid,
                    source="sqlite",
                    title=title or "Codex session",
                    cwd=r["cwd"],
                    rpath=str(r["rollout_path"] or ""),
                    updated=str(r["updated_at"] or ""),
                )
            conn.close()
        except Exception:
            continue

    # --- 2) session_index.jsonl ---
    for data in _iter_codex_session_index_rows(limit * 3):
        sid = str(
            data.get("id")
            or data.get("thread_id")
            or data.get("threadId")
            or data.get("session_id")
            or ""
        ).strip()
        if not sid:
            continue
        title = _sanitize_provider_text(
            data.get("title") or data.get("name") or ""
        ) or ""
        cwd = data.get("cwd") or data.get("cwd_path") or data.get("working_directory")
        rpath = str(
            data.get("rollout_path")
            or data.get("path")
            or data.get("file")
            or ""
        )
        _touch(
            sid,
            source="index",
            title=title or "Codex session",
            cwd=cwd,
            rpath=rpath,
            updated=str(data.get("updated_at") or data.get("updatedAt") or ""),
        )

    # --- 3) sessions/ rollouts (session_meta id — Remodex SoT for disk) ---
    for path in _iter_codex_rollout_files(limit * 4):
        try:
            p_str = str(path)
            meta = _parse_codex_rollout_meta(p_str)
            sid = str(meta.get("session_id") or "").strip()
            if not sid:
                # No session_meta id → do not invent from filename (authority rule).
                continue
            # Megas' own `codex exec wait-cancel-test-prompt` health probe persists a
            # rollout per health check. Those are our machinery, never the owner's chat.
            if is_megas_internal_session(meta.get("first_user_message")):
                continue
            mtime = ""
            try:
                mtime = str(int(path.stat().st_mtime))
            except Exception:
                mtime = ""
            _touch(
                sid,
                source="file",
                title="",
                cwd=meta.get("cwd"),
                rpath=p_str,
                updated=mtime,
            )
        except Exception:
            continue

    def _agreement(sources: set) -> str:
        has_s = "sqlite" in sources
        has_i = "index" in sources
        has_f = "file" in sources
        n = len(sources)
        if n == 3:
            return "ALL_AGREE"
        if has_s and has_i and not has_f:
            return "SQLITE_PLUS_INDEX"
        if has_s and has_f and not has_i:
            return "SQLITE_PLUS_FILE"
        if has_i and has_f and not has_s:
            return "INDEX_PLUS_FILE"
        if has_s:
            return "SQLITE_ONLY"
        if has_i:
            return "INDEX_ONLY"
        if has_f:
            return "FILE_ONLY"
        return "CONFLICT"

    # Sort by updated desc; emit up to limit.
    items = sorted(
        acc.items(),
        key=lambda kv: str(kv[1].get("updated") or ""),
        reverse=True,
    )
    out: List[Dict[str, Any]] = []
    for sid, row in items:
        if len(out) >= limit:
            break
        title = row.get("title") or "Codex session"
        rpath = str(row.get("rpath") or "")
        mtime = ""
        try:
            if rpath and Path(rpath).exists():
                mtime = str(int(Path(rpath).stat().st_mtime))
        except Exception:
            mtime = ""
        agreement = _agreement(set(row.get("sources") or set()))
        cursor = _cursor_with_epoch(
            f"{row.get('updated') or ''}|{mtime}|{rpath[-48:] if rpath else ''}|{agreement}"
        )
        th = _index_row(
            native_id=sid,
            agent_type="codex_cli",
            title=title[:80],
            project_path=_normalize_project_path(row.get("cwd")) or row.get("cwd"),
            sync_cursor=cursor,
        )
        out.append(
            _merge_thread_metadata(
                th,
                {
                    "index_agreement": agreement,
                    "index_sources": sorted(row.get("sources") or []),
                    "identity_source": "session_meta_or_sqlite",
                    "adapter_contract": "remodex_aligned_c13",
                },
            )
        )
    return out


def index_agy_threads(limit: int = 30) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    try:
        conv_dirs = _agy_all_conv_dirs()
        parent_map = _agy_parent_map()
        summaries = _agy_summaries_db_index()
        for conv_dir in conv_dirs:
            # Keep both physical records until reconciliation. The Desktop source
            # carries the authoritative project/workspace projection needed by its
            # imported CLI execution child. _agy_reconcile_logical_threads collapses
            # the verified lineage to one card after that metadata is transferred.
            transcript = _agy_transcript(conv_dir)
            if transcript.is_file():
                st = transcript.stat()
                cursor = f"{int(st.st_mtime)}|{int(st.st_size)}"
            else:
                # Per-message layout: cursor must move when a message is added or changed.
                files = sorted(_agy_messages_dir(conv_dir).glob("*.json"))
                if files:
                    newest = max(int(f.stat().st_mtime) for f in files)
                    total = sum(int(f.stat().st_size) for f in files)
                    cursor = f"{newest}|{total}|{len(files)}"
                else:
                    db = next((r / "conversations" / f"{conv_dir.name}.db" for _s, r in _agy_provider_roots() if (r / "conversations" / f"{conv_dir.name}.db").is_file()), None)
                    if not db:
                        continue
                    st = db.stat()
                    cursor = f"db|{int(st.st_mtime)}|{int(st.st_size)}"
            summary = summaries.get(conv_dir.name) or {}
            if summary:
                project = str(summary.get("project_path") or "")
                scope = str(summary.get("project_scope") or "unknown")
            else:
                project, scope = _agy_project_scope(conv_dir)
            out.append(_merge_thread_metadata(
                _index_row(
                    native_id=conv_dir.name,
                    agent_type="antigravity",
                    title=str(summary.get("title") or "Antigravity session")[:80],
                    project_path=project,
                    sync_cursor=_cursor_with_epoch(cursor),
                ),
                {
                    "source_surface": _agy_surface_for_native(conv_dir.name),
                    "project_scope": scope or "unresolved",
                    "project_label": agy_project_label(project, scope),
                    "project_id": summary.get("project_id"),
                    "workspace_uris": summary.get("project_folders") or [],
                    "project_metadata_confidence": (
                        "authoritative" if summary else "unresolved"
                    ),
                    "project_metadata_source": (
                        "conversation_summaries_db" if summary else "unresolved"
                    ),
                    "parent_native_id": parent_map.get(conv_dir.name),
                },
            ))
    except Exception:
        return out
    return _agy_reconcile_logical_threads(out)


def index_claude_threads(limit: int = 30) -> List[Dict[str, Any]]:
    """Light index of Claude sessions (projects-first). Cursor includes parser epoch."""
    out: List[Dict[str, Any]] = []
    try:
        for path in _list_claude_jsonl_files(limit):
            if len(out) >= limit:
                break
            try:
                st = path.stat()
            except Exception:
                continue
            # Cheap cwd peek: first lines only (old sync needs correct project_path).
            project_path = str(path.parent)
            title = "Claude Code session"
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f):
                        if i > 40:
                            break
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                        except Exception:
                            continue
                        if data.get("cwd") and project_path == str(path.parent):
                            project_path = str(data.get("cwd") or project_path)
                        nested = data.get("message") if isinstance(data.get("message"), dict) else None
                        top_type = str(data.get("type") or "").lower()
                        if top_type in _CLAUDE_SKIP_TYPES:
                            continue
                        role = ""
                        content = None
                        if nested:
                            role = str(nested.get("role") or top_type or "").lower()
                            content = nested.get("content")
                        else:
                            role = str(data.get("role") or top_type or "").lower()
                            content = data.get("content") or data.get("text")
                        if role not in ("user", "human") and top_type != "user":
                            continue
                        if isinstance(content, list):
                            for item in content:
                                if isinstance(item, dict) and item.get("type") == "text":
                                    t = _sanitize_provider_text(str(item.get("text") or ""))
                                    if t:
                                        title = t[:80]
                                        break
                                elif isinstance(item, str) and item.strip():
                                    title = _sanitize_provider_text(item)[:80]
                                    break
                        elif content:
                            title = _sanitize_provider_text(str(content))[:80] or title
                        if title != "Claude Code session":
                            break
            except Exception:
                pass
            out.append(
                _index_row(
                    native_id=path.stem,
                    agent_type="claude_code",
                    title=title,
                    project_path=_normalize_project_path(project_path) or project_path,
                    sync_cursor=_cursor_with_epoch(f"{int(st.st_mtime)}|{int(st.st_size)}"),
                )
            )
    except Exception:
        return out
    return out


def index_grok_threads(limit: int = 30) -> List[Dict[str, Any]]:
    """Light index of Grok sessions from official session dirs.

    Cursor = mtime|size of updates.jsonl + chat_history + summary so any change
    advances the delta. Title/cwd from summary.json (not FTS alone).
    """
    limit = max(1, int(limit or 30))
    out: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for session_dir in _list_grok_session_dirs(limit * 2):
        if len(out) >= limit:
            break
        sid = session_dir.name
        if not sid or sid in seen:
            continue
        # Skills-only / brand-new shells have summary+history but no user chat —
        # listing them creates thr_ "Grok session" that open as parser_error.
        if not _grok_session_has_user_chat(session_dir):
            continue
        summary = _read_grok_summary(session_dir)
        fts = _grok_meta_from_sqlite(sid)
        title = _sanitize_provider_text(
            str(summary.get("generated_title") or summary.get("session_summary") or "")
            or str(fts.get("title") or "")
        ) or "Grok session"
        project_path = str(summary.get("git_root_dir") or fts.get("cwd") or "").strip()
        if not project_path:
            cwd_file = session_dir.parent / ".cwd"
            if cwd_file.is_file():
                try:
                    project_path = cwd_file.read_text(encoding="utf-8", errors="replace").strip()
                except Exception:
                    project_path = ""
            if not project_path:
                project_path = _decode_grok_cwd_segment(session_dir.parent.name)
        cursor_parts: List[str] = []
        for name in ("updates.jsonl", "chat_history.jsonl", "summary.json"):
            p = session_dir / name
            try:
                if p.is_file():
                    st = p.stat()
                    cursor_parts.append(f"{int(st.st_mtime)}|{int(st.st_size)}")
            except Exception:
                pass
        if not cursor_parts:
            continue
        seen.add(sid)
        out.append(
            _index_row(
                native_id=sid,
                agent_type="grok_build",
                title=title[:80],
                project_path=_normalize_project_path(project_path) if project_path else project_path,
                sync_cursor=_cursor_with_epoch(";".join(cursor_parts)),
            )
        )
    return out[:limit]


def index_jsonl_agent_roots(
    roots: List[Path],
    *,
    agent_type: str,
    limit: int = 30,
) -> List[Dict[str, Any]]:
    """Light index of *.jsonl session files (mtime|size cursor — no full parse)."""
    files: List[Path] = []
    for root in roots:
        if not root.exists():
            continue
        try:
            files.extend([p for p in root.rglob("*.jsonl") if p.is_file()])
        except Exception:
            continue
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    out: List[Dict[str, Any]] = []
    for path in files:
        if len(out) >= limit:
            break
        if "antigravity" in str(path).lower():
            continue
        try:
            st = path.stat()
        except Exception:
            continue
        out.append(
            _index_row(
                native_id=path.stem,
                agent_type=agent_type,
                title=f"{agent_type} session",
                project_path=str(path.parent),
                sync_cursor=_cursor_with_epoch(f"{int(st.st_mtime)}|{int(st.st_size)}"),
            )
        )
    return out


def index_sqlite_agent_stores(
    roots: List[Path],
    *,
    agent_type: str,
    db_names: tuple[str, ...],
    limit: int = 30,
) -> List[Dict[str, Any]]:
    """Light index from OpenCode/Kilo SQLite session tables only (no message parse)."""
    out: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for db in _find_sqlite_under(roots, db_names):
        if len(out) >= limit:
            break
        try:
            st = db.stat()
            db_cursor = f"{int(st.st_mtime)}|{int(st.st_size)}"
        except Exception:
            db_cursor = "0"
        try:
            _sql = _require_sqlite3()
            conn = _sql.connect(f"file:{db}?mode=ro", uri=True)
            conn.row_factory = _sql.Row
            tables = {t.lower(): t for t in _sqlite_table_names(conn)}
            session_t = (
                tables.get("session")
                or tables.get("sessions")
                or tables.get("chat")
                or tables.get("threads")
            )
            if not session_t:
                conn.close()
                continue
            cur = conn.cursor()
            cur.execute(f"PRAGMA table_info({session_t})")
            sess_cols = {str(r[1]).lower(): str(r[1]) for r in cur.fetchall()}
            id_col = sess_cols.get("id") or sess_cols.get("session_id")
            if not id_col:
                conn.close()
                continue
            title_col = sess_cols.get("title") or sess_cols.get("name") or sess_cols.get("summary")
            cwd_col = (
                sess_cols.get("directory")
                or sess_cols.get("cwd")
                or sess_cols.get("path")
                or sess_cols.get("project_path")
                or sess_cols.get("workspace")
            )
            updated_col = (
                sess_cols.get("time_updated")
                or sess_cols.get("updated_at")
                or sess_cols.get("updated")
                or sess_cols.get("time_created")
                or sess_cols.get("created_at")
            )
            order_sql = f" ORDER BY {updated_col} DESC" if updated_col else ""
            cur.execute(f"SELECT * FROM {session_t}{order_sql} LIMIT ?", (limit,))
            for sess in cur.fetchall():
                if len(out) >= limit:
                    break
                sid = str(sess[id_col] or "").strip()
                if not sid or sid in seen:
                    continue
                title = f"{agent_type} session"
                if title_col:
                    title = _sanitize_provider_text(str(sess[title_col] or "")) or title
                cwd = None
                if cwd_col:
                    cwd = str(sess[cwd_col] or "").strip() or None
                upd = str(sess[updated_col] or "") if updated_col else ""
                seen.add(sid)
                out.append(
                    _index_row(
                        native_id=sid,
                        agent_type=agent_type,
                        title=title[:80],
                        project_path=_normalize_project_path(cwd) or cwd,
                        sync_cursor=_cursor_with_epoch(f"{db_cursor}|{upd}|{sid}"),
                    )
                )
            conn.close()
        except Exception:
            continue
    return out


def list_native_thread_index(limit_per_agent: int = _DEFAULT_LIMIT_PER_AGENT) -> List[Dict[str, Any]]:
    """Product index plane: metadata + sync_cursor only for CORE coding agents.

    This is **not** a Google Drive backup. Full transcripts load only when:
      - native cursor advanced (delta sync), or
      - client opens thr_ → exact native_thread_read.

    All index cursors include ``_NATIVE_PARSER_EPOCH`` so parser upgrades force
    re-full-sync of existing thr_ history (old sync first priority).

    External-v1: Kilo is not indexed (Tier 4 until Phase-0). Each row is stamped
    with provider_installation_id in metadata_json.

    One provider indexer must never abort the whole thr_ index (authority + old sync).
    """
    raw: List[Dict[str, Any]] = []

    def _safe_index(label: str, fn, *args, **kwargs) -> None:
        try:
            rows = fn(*args, **kwargs) or []
            if isinstance(rows, list):
                raw.extend(rows)
        except Exception as exc:  # noqa: BLE001 — isolate provider scanners
            detail = str(exc).strip() or repr(exc)
            fname = getattr(exc, "filename", None)
            if fname:
                detail = f"{detail} path={fname}"
            print(
                f"[THREAD_SYNC] index {label} failed: {type(exc).__name__}: {detail[:240]}",
                flush=True,
            )

    _safe_index("codex", index_codex_threads, limit_per_agent)
    _safe_index("claude", index_claude_threads, limit_per_agent)
    _safe_index("antigravity", index_agy_threads, limit_per_agent)
    _safe_index("grok", index_grok_threads, limit_per_agent)
    # gemini_cli abandoned — do not index as a peer of antigravity
    _safe_index(
        "opencode_sqlite",
        index_sqlite_agent_stores,
        _opencode_roots(),
        agent_type="opencode",
        db_names=("opencode.db", "store.db", "data.db"),
        limit=limit_per_agent,
    )
    _safe_index(
        "opencode_jsonl",
        index_jsonl_agent_roots,
        _opencode_roots(),
        agent_type="opencode",
        limit=limit_per_agent,
    )
    # kilo_code intentionally omitted — external-v1 Tier 4
    # Dedupe agent_type:native_id (sqlite + jsonl may overlap).
    seen: set[str] = set()
    out: List[Dict[str, Any]] = []
    root_by_agent = {
        "codex_cli": _codex_data_roots(),
        "claude_code": [Path.home() / ".claude"],
        "antigravity": [
            Path.home() / ".gemini" / "antigravity-cli",
            Path.home() / ".gemini" / "antigravity",
        ],
        "grok_build": [_grok_home()],
        "opencode": _opencode_roots(),
    }
    for row in raw:
        agent = str(row.get("agent_type") or "")
        if agent not in CORE_SYNC_AGENTS:
            continue
        # Megas' own health probes and smoke tests are not the owner's chats.
        if is_megas_internal_session(
            row.get("title"),
            row.get("preview"),
            row.get("first_user_message"),
        ):
            continue
        key = f"{agent}:{row.get('native_id')}"
        if key in seen:
            continue
        seen.add(key)
        stamped = _stamp_provider_installation(
            row,
            provider_id=agent,
            data_roots=list(root_by_agent.get(agent) or [Path.home()]),
        )
        out.append(stamped)
    return out


def read_all_native_threads(limit_per_agent: int = _DEFAULT_LIMIT_PER_AGENT) -> List[Dict[str, Any]]:
    """Full transcripts for CORE agents only (used by exact paths / tests).

    Periodic worker sync must use ``list_native_thread_index`` + cursor deltas,
    not this bulk reader. Kilo excluded (external-v1 Tier 4).
    """
    return (
        read_agy_threads(limit_per_agent)
        + read_claude_threads(limit_per_agent)
        + read_codex_threads(limit_per_agent)
        + read_grok_threads(limit_per_agent)
        + read_opencode_threads(limit_per_agent)
    )


def threads_needing_full_sync(
    index_rows: List[Dict[str, Any]],
    known_cursors: Dict[str, str],
    *,
    max_full: int = _MAX_FULL_SYNCS_PER_CYCLE,
) -> List[Dict[str, Any]]:
    """Return index rows whose native cursor moved (or never synced). Cap burst size."""
    need: List[Dict[str, Any]] = []
    for row in index_rows or []:
        agent = str(row.get("agent_type") or "")
        if agent not in CORE_SYNC_AGENTS:
            continue
        native = str(row.get("native_id") or "")
        if not native:
            continue
        key = f"{agent}:{native}"
        cursor = str(row.get("sync_cursor") or "")
        if known_cursors.get(key) == cursor and cursor:
            continue
        need.append(row)
        if len(need) >= max_full:
            break
    return need
