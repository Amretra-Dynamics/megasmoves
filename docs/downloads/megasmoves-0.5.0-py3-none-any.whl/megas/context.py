from __future__ import annotations

from pathlib import Path
from typing import Any


def write_megas_context(workdir: Path, command: dict[str, Any], repo_state: dict | None = None) -> Path:
    context_pack = command.get("context_pack") if isinstance(command.get("context_pack"), dict) else {}
    
    if repo_state is None:
        import subprocess

        from megas.adapters.base import (
            prefer_console_free_tool_path,
            subprocess_hide_window_kwargs,
        )

        try:
            hide = subprocess_hide_window_kwargs()
            git_env = prefer_console_free_tool_path()
            branch = subprocess.run(
                ["git", "branch", "--show-current"],
                cwd=str(workdir),
                capture_output=True,
                text=True,
                check=True,
                env=git_env,
                **hide,
            ).stdout.strip() or "HEAD detached"
            head_commit = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=str(workdir),
                capture_output=True,
                text=True,
                check=True,
                env=git_env,
                **hide,
            ).stdout.strip()
            head_subject = subprocess.run(
                ["git", "log", "-1", "--format=%s"],
                cwd=str(workdir),
                capture_output=True,
                text=True,
                check=True,
                env=git_env,
                **hide,
            ).stdout.strip()
            status_raw = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=str(workdir),
                capture_output=True,
                text=True,
                check=True,
                env=git_env,
                **hide,
            ).stdout.strip()
            dirty = bool(status_raw)
        except Exception:
            branch, head_commit, head_subject, dirty = "main", "unknown", "Not a git repository", False
        repo_state = {
            "branch": branch,
            "head_commit": head_commit,
            "head_subject": head_subject,
            "dirty": dirty
        }

    lines = [
        "# Megas Task Pack",
        "",
        "## Task",
        str(command.get("instruction") or context_pack.get("instruction") or "").strip(),
        "",
        "## Repository State",
        f"Branch: {repo_state.get('branch', 'main')}",
        f"HEAD: {repo_state.get('head_commit', 'unknown')} {repo_state.get('head_subject', 'unknown')}",
        f"Workspace state: {'dirty' if repo_state.get('dirty') else 'clean'}",
        "",
        "## Protected Paths",
        "Do not modify:",
        "- .github/workflows/",
        "- runtime/ops/",
        "- runtime/nginx/",
        "- runtime/env/",
        "- app/keystores/",
        "- .env, *.pem, *.key, credentials.*, secrets.*",
        "",
        "## Expected Evidence",
    ]
    
    expected_evidence = context_pack.get("expected_evidence") or ["terminal_result"]
    for ev in expected_evidence:
        lines.append(f"- {ev}")
    
    lines.append("")

    recent_memories = context_pack.get("recent_memories", [])
    if recent_memories:
        lines.extend([
            "",
            "## Relevant Megas Memories",
            "",
        ])
        for idx, mem in enumerate(recent_memories, 1):
            mtype = (mem.get("type") or "successful_pattern").replace("_", " ")
            trust = mem.get("trust_level") or "evidence_backed"
            why = mem.get("why_included") or "same repo, same agent type"
            body = mem.get("body") or ""
            
            # Parse body to extract changed files and reusable note
            body_lines = body.split("\n")
            changed_files_lines = []
            reusable_note_lines = []
            
            in_files = False
            in_note = False
            for line in body_lines:
                if line.startswith("Changed files:") or line.startswith("Failed files/area:"):
                    in_files = True
                    in_note = False
                    continue
                elif line.startswith("Reusable note:"):
                    in_files = False
                    in_note = True
                    continue
                elif line.startswith("Outcome:") or line.startswith("Repo:") or line.startswith("Agent:"):
                    in_files = False
                    in_note = False
                    continue
                
                if in_files:
                    if line.strip():
                        changed_files_lines.append(line)
                elif in_note:
                    if line.strip():
                        reusable_note_lines.append(line)
            
            if changed_files_lines:
                files_block = "Changed files:\n" + "\n".join(changed_files_lines)
            else:
                files_block = "Changed files:\n- docs/"
                
            memory_content = "\n".join(reusable_note_lines) if reusable_note_lines else body
            
            lines.extend([
                f"### {idx}. {mtype}",
                f"Trust: {trust}",
                f"Source: verified session",
                f"Why included: {why.replace('Why included: ', '')}",
                files_block,
                "",
                "Memory:",
                memory_content,
                "",
            ])

    task_plan_summary = context_pack.get("task_plan_summary") or "Before editing, briefly plan the change. Keep changes minimal. Do not commit, push, delete files, deploy, or modify protected paths."
    lines.extend([
        "## Task Plan",
        task_plan_summary,
        ""
    ])

    target = (workdir / "MEGAS.md").resolve()
    try:
        target.relative_to(workdir.resolve())
    except ValueError:
        raise PermissionError("Access denied: MEGAS.md path escapes allowed workspace.")

    target.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    return target
