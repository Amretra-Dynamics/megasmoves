from __future__ import annotations

import json
from typing import Any

from jsonschema import Draft202012Validator

from .chitraagni_operator import _tool, _uuid
from .chitraagni_operator_complete import CompleteChitraagniOperatorCatalog


MAX_SEARCH_NODES = 200_000
MAX_SEARCH_VALUE_CHARS = 20_000


CONTEXT_TOOLS: list[dict[str, Any]] = [
    _tool(
        "chitraagni_account_snapshot",
        "Read a bounded account-wide AI snapshot of every authorized Chitraagni Project, including Product memory, screens, schemas, workflows, versions, design system and R5 state. Heavy optional history/codegen are opt-in.",
        {
            "include_quality": {"type": "boolean", "default": False},
            "include_codegen": {"type": "boolean", "default": False},
            "include_version_snapshots": {"type": "boolean", "default": False},
            "max_projects": {"type": "integer", "minimum": 1, "maximum": 100, "default": 20},
            "max_products_per_project": {"type": "integer", "minimum": 1, "maximum": 100, "default": 50},
            "max_versions_per_project": {"type": "integer", "minimum": 1, "maximum": 100, "default": 50},
        },
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_find",
        "Deterministically search the linked user's authorized Chitraagni structured state and Product memory. Returns bounded JSON paths and excerpts; performs no model inference.",
        {
            "query": {"type": "string", "minLength": 1, "maxLength": 500},
            "project_id": {"type": ["string", "null"]},
            "product_id": {"type": ["string", "null"]},
            "max_results": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
            "max_projects": {"type": "integer", "minimum": 1, "maximum": 100, "default": 20},
        },
        ["query"],
        read_only=True,
    ),
]


def _result(value: Any) -> dict[str, Any]:
    text = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str)
    return {
        "content": [{"type": "text", "text": text}],
        "structuredContent": value,
        "isError": False,
    }


def _excerpt(text: str, query: str, *, width: int = 240) -> str:
    folded = text.casefold()
    needle = query.casefold()
    position = folded.find(needle)
    if position < 0:
        return text[:width]
    half = max(20, width // 2)
    start = max(0, position - half)
    end = min(len(text), position + len(query) + half)
    prefix = "…" if start else ""
    suffix = "…" if end < len(text) else ""
    return prefix + text[start:end] + suffix


class AccountChitraagniOperatorCatalog(CompleteChitraagniOperatorCatalog):
    """Complete user data surface plus bounded context/search helpers for AI clients."""

    def tools(self) -> list[dict[str, Any]]:
        tools = [*super().tools(), *json.loads(json.dumps(CONTEXT_TOOLS))]
        seen: set[str] = set()
        for tool in tools:
            name = str(tool.get("name") or "")
            if not name or name in seen:
                raise ValueError(f"duplicate or empty Chitraagni operator tool: {name}")
            seen.add(name)
        return sorted(tools, key=lambda row: str(row["name"]))

    @staticmethod
    def _context_tool(name: str) -> dict[str, Any] | None:
        return next((row for row in CONTEXT_TOOLS if row["name"] == name), None)

    def account_snapshot(
        self,
        *,
        include_quality: bool = False,
        include_codegen: bool = False,
        include_version_snapshots: bool = False,
        max_projects: int = 20,
        max_products_per_project: int = 50,
        max_versions_per_project: int = 50,
    ) -> dict[str, Any]:
        account = self.account_context()
        project_index = [row for row in (account.get("projects") or []) if isinstance(row, dict)]
        selected = project_index[:max_projects]
        contexts: list[dict[str, Any]] = []
        for row in selected:
            if not row.get("id"):
                continue
            contexts.append(
                self.project_context(
                    _uuid(row["id"], "project_id"),
                    include_quality=include_quality,
                    include_codegen=include_codegen,
                    include_version_snapshots=include_version_snapshots,
                    max_products=max_products_per_project,
                    max_versions=max_versions_per_project,
                )
            )
        return {
            "user": account.get("user"),
            "workspaces": account.get("workspaces") or [],
            "project_index": project_index,
            "product_index": account.get("products") or [],
            "projects": contexts,
            "bounds": {
                "max_projects": max_projects,
                "max_products_per_project": max_products_per_project,
                "max_versions_per_project": max_versions_per_project,
                "project_count_available": len(project_index),
                "project_count_included": len(contexts),
                "projects_truncated": len(project_index) > len(selected),
                "include_quality": include_quality,
                "include_codegen": include_codegen,
                "include_version_snapshots": include_version_snapshots,
            },
        }

    @staticmethod
    def _search_value(value: Any, query: str, *, max_results: int) -> dict[str, Any]:
        needle = query.casefold()
        results: list[dict[str, Any]] = []
        nodes_scanned = 0
        search_truncated = False

        def walk(current: Any, path: str) -> None:
            nonlocal nodes_scanned, search_truncated
            if len(results) >= max_results or nodes_scanned >= MAX_SEARCH_NODES:
                search_truncated = True
                return
            nodes_scanned += 1
            if isinstance(current, dict):
                for key, child in current.items():
                    key_text = str(key)
                    child_path = f"{path}.{key_text}" if path else key_text
                    if needle in key_text.casefold() and len(results) < max_results:
                        results.append(
                            {
                                "path": child_path,
                                "match": "key",
                                "excerpt": key_text[:240],
                            }
                        )
                    walk(child, child_path)
                    if search_truncated and len(results) >= max_results:
                        return
                return
            if isinstance(current, list):
                for index, child in enumerate(current):
                    walk(child, f"{path}[{index}]")
                    if search_truncated and len(results) >= max_results:
                        return
                return
            if current is None:
                return
            if not isinstance(current, (str, int, float, bool)):
                return
            text = str(current)
            searchable = text[:MAX_SEARCH_VALUE_CHARS]
            if needle in searchable.casefold():
                results.append(
                    {
                        "path": path,
                        "match": "value",
                        "type": type(current).__name__,
                        "excerpt": _excerpt(searchable, query),
                    }
                )

        walk(value, "")
        return {
            "query": query,
            "results": results[:max_results],
            "result_count": min(len(results), max_results),
            "nodes_scanned": nodes_scanned,
            "truncated": search_truncated or len(results) > max_results,
        }

    def find(
        self,
        query: str,
        *,
        project_id: str | None = None,
        product_id: str | None = None,
        max_results: int = 50,
        max_projects: int = 20,
    ) -> dict[str, Any]:
        text = str(query or "").strip()
        if not text:
            raise ValueError("query must be non-empty")
        if project_id and product_id:
            raise ValueError("supply at most one of project_id or product_id")
        if product_id:
            scope = "product"
            target_id = _uuid(product_id, "product_id")
            value = self.product_context(target_id, include_quality=False, include_codegen=False)
        elif project_id:
            scope = "project"
            target_id = _uuid(project_id, "project_id")
            value = self.project_context(
                target_id,
                include_quality=False,
                include_codegen=False,
                include_version_snapshots=False,
            )
        else:
            scope = "account"
            target_id = None
            value = self.account_snapshot(
                include_quality=False,
                include_codegen=False,
                include_version_snapshots=False,
                max_projects=max_projects,
                max_products_per_project=50,
                max_versions_per_project=50,
            )
        result = self._search_value(value, text, max_results=max_results)
        result["scope"] = scope
        result["scope_id"] = target_id
        result["max_results"] = max_results
        return result

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        tool = self._context_tool(name)
        if tool is None:
            return super().call(name, arguments)
        if not isinstance(arguments, dict):
            raise ValueError("Chitraagni tool arguments must be a JSON object")
        errors = sorted(
            Draft202012Validator(tool["inputSchema"]).iter_errors(arguments),
            key=lambda row: list(row.path),
        )
        if errors:
            raise ValueError("invalid Chitraagni tool input: " + errors[0].message)
        if name == "chitraagni_account_snapshot":
            value = self.account_snapshot(
                include_quality=arguments.get("include_quality", False),
                include_codegen=arguments.get("include_codegen", False),
                include_version_snapshots=arguments.get("include_version_snapshots", False),
                max_projects=arguments.get("max_projects", 20),
                max_products_per_project=arguments.get("max_products_per_project", 50),
                max_versions_per_project=arguments.get("max_versions_per_project", 50),
            )
        elif name == "chitraagni_find":
            value = self.find(
                arguments["query"],
                project_id=arguments.get("project_id"),
                product_id=arguments.get("product_id"),
                max_results=arguments.get("max_results", 50),
                max_projects=arguments.get("max_projects", 20),
            )
        else:
            raise KeyError(name)
        return _result(value)


__all__ = ["AccountChitraagniOperatorCatalog", "CONTEXT_TOOLS"]
