from __future__ import annotations

import ctypes
import hmac
import json
import os
import re
import sys
import threading
from pathlib import Path
from typing import Any, Callable

from . import agent_management, local_testing
from .activity_subscription import serve_activity_pipe
from .mcp.activity import ACTIVITY_SOURCES, build_activity_feed
from .mcp.service import MegasCoreService
from .operator_account import DEFAULT_CHITRAAGNI_API_BASE, OperatorAccountStore

MAX_REQUEST_BYTES = 256 * 1024
MAX_ACTIVITY_ROWS = 500
MAX_NATIVE_EVENT_BYTES = 64 * 1024
MAX_IPC_TOKEN_CHARS = 256
MAX_TASK_TITLE_CHARS = 4000
MAX_PROJECT_CHARS = 256
MAX_ACTIVITY_VIEW_BYTES = 128 * 1024
MAX_TERMINAL_VIEW_BYTES = 96 * 1024
PIPE_NAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
CLIENT_RE = re.compile(r"^[a-z0-9._-]{1,64}$")
TASK_ID_RE = re.compile(r"^task_[a-f0-9]{32}$")
NATIVE_EVENT_TYPES = frozenset(
    {
        "native.runtime.started",
        "native.runtime.stopped",
        "native.process.contained",
    }
)


def _account_relay_status() -> dict[str, Any]:
    """Return cached account-relay status; never block a UI snapshot."""
    if os.environ.get("MEGAS_DESKTOP_ACCOUNT_RELAY", "").strip() != "1":
        return {
            "started": False,
            "account_authenticated": False,
            "relay_device_count": 0,
            "route": "account_websocket_relay",
            "relay_configured": True,
            "relay_connected": False,
            "vpn_service": False,
            "status": "disabled",
        }

    from megas.local.peer_mesh.runtime import peer_mesh_status

    return peer_mesh_status()


class NativeDesktopBridge:
    """Narrow typed command surface shared by the native WinUI shell and tests.

    This object is the contract. Carriers such as the authenticated Windows named
    pipe or the development-only stdio loop may dispatch only these reviewed
    methods; neither transport is an arbitrary process/shell bridge.
    """

    def __init__(self) -> None:
        self.core = MegasCoreService()
        self.account = OperatorAccountStore()
        from megas.chatgpt_connection import ChatGPTConnection
        self.chatgpt = ChatGPTConnection()
        self.chatgpt.resume()
        from megas.local.peer_mesh.human_pairing import HumanDevicePairing
        self.device_pairing = HumanDevicePairing()
        _account_relay_status()
        self._handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "system.snapshot": self._system_snapshot,
            "workspace.add_folder": self._workspace_add_folder,
            "workspace.action": self._workspace_action,
            "target.action": self._target_action,
            "adb.snapshot": self._adb_snapshot,
            "adb.pair": self._adb_pair,
            "adb.connect": self._adb_connect,
            "account.status": self._account_status,
            "account.login": self._account_login,
            "account.logout": self._account_logout,
            "chatgpt.status": lambda params: self.chatgpt.status(),
            "chatgpt.configure": self._chatgpt_configure,
            "chatgpt.connect": self._chatgpt_connect,
            "chatgpt.disconnect": lambda params: self.chatgpt.disconnect(),
            "chatgpt.forget": lambda params: self.chatgpt.disconnect(forget=True),
            "telegram.status": lambda params: self._telegram_call("status", params),
            "telegram.connect": lambda params: self._telegram_call("connect", params),
            "telegram.auth_status": lambda params: self._telegram_call("auth_status", params),
            "telegram.password": lambda params: self._telegram_call("password", params),
            "telegram.disconnect": lambda params: self._telegram_call("disconnect", params),
            "agents.status": self._agents_status,
            "agent.install": self._agent_install,
            "agent.connect": self._agent_connect,
            "agent.disconnect": self._agent_disconnect,
            "agent.uninstall": self._agent_uninstall,
            "agent.download_and_assign": self._agent_download_and_assign,
            "tasks.list": self._tasks_list,
            "continuity.read": lambda params: self._continuity_call("read", params),
            "continuity.save": lambda params: self._continuity_call("save", params),
            "continuity.resume": lambda params: self._continuity_call("resume", params),
            "planning.projects": lambda params: self._planning_call("megas_project_list", params),
            "planning.board": lambda params: self._planning_call("megas_project_board", params),
            "planning.link": lambda params: self._planning_call("megas_project_link", params),
            "planning.todo_create": lambda params: self._planning_call("megas_todo_create", params),
            "planning.todo_update": lambda params: self._planning_call("megas_todo_update", params),
            "task.create": self._task_create,
            "task.assign": self._task_assign,
            "task.unassign": self._task_unassign,
            "activity.list": self._activity_list,
            "native.event.record": self._native_event_record,
            "update.preflight": self._update_preflight,
            "terminal.list": self._terminal_list,
            "terminal.create": self._terminal_create,
            "terminal.read": self._terminal_read,
            "terminal.input": self._terminal_input,
            "terminal.terminate": self._terminal_terminate,
            "ping": self._ping,
        }
        for action in ("status", "offer", "preview", "pin", "revoke"):
            self._handlers["device_pairing." + action] = lambda params, action=action: self.device_pairing.call(action, params)
        for action in ("list", "get", "local_tasks", "create", "update", "task_create", "task_move"):
            self._handlers["actions." + action] = lambda params, action=action: self._planning_call("megas_action_" + action, params)

    @property
    def methods(self) -> tuple[str, ...]:
        return tuple(sorted(self._handlers))

    @staticmethod
    def _telegram_call(operation: str, params: dict[str, Any]) -> Any:
        """Native Windows Telegram onboarding, scoped to this local user."""
        from .telegram_native import TelegramOperator
        operator = TelegramOperator()
        if operation == "status":
            return operator.status()
        if operation == "connect":
            return operator.auth_begin()
        if operation == "auth_status":
            return operator.auth_status()
        if operation == "password":
            password = str(params.get("password") or "")
            if not password:
                raise ValueError("Telegram verification password is required")
            return operator.auth_password(password)
        if operation == "disconnect":
            return operator.disconnect()
        raise ValueError("Unsupported Telegram action")

    def _planning_call(self, tool: str, params: dict[str, Any]) -> Any:
        from .mcp.operator_runtime import OperatorCapabilityCatalog
        return OperatorCapabilityCatalog(account_store=self.account).call(tool, params)["structuredContent"]

    def _continuity_call(self, action: str, params: dict[str, Any]) -> Any:
        from .mcp.operator_runtime import OperatorCapabilityCatalog
        return OperatorCapabilityCatalog(account_store=self.account).call("development_checkpoint_" + action, params)["structuredContent"]

    def dispatch(self, method: str, params: dict[str, Any] | None = None) -> Any:
        selected = str(method or "").strip()
        handler = self._handlers.get(selected)
        if handler is None:
            raise ValueError(f"unsupported native desktop method: {selected}")
        values = params or {}
        if not isinstance(values, dict):
            raise TypeError("native desktop params must be an object")
        return handler(values)

    @staticmethod
    def _client(params: dict[str, Any]) -> str:
        client = str(params.get("client") or "").strip().lower()
        if CLIENT_RE.fullmatch(client) is None:
            raise ValueError("client is missing or invalid")
        return client

    @staticmethod
    def _task_id(params: dict[str, Any]) -> str:
        task_id = str(params.get("task_id") or "").strip()
        if TASK_ID_RE.fullmatch(task_id) is None:
            raise ValueError("task_id is missing or invalid")
        return task_id

    @staticmethod
    def _confirmation(params: dict[str, Any]) -> bool:
        if params.get("confirm") is not True:
            raise PermissionError("this agent operation requires explicit confirmation")
        return True

    def _record_agent_event(self, event: str, **payload: Any) -> None:
        safe: dict[str, Any] = {"source": "Agent", "severity": "info"}
        for key, value in payload.items():
            if value is None or isinstance(value, (bool, int, float)):
                safe[key] = value
            else:
                safe[key] = str(value)[:4000]
        self.core.store.record(event, **safe)

    def _system_snapshot(self, _params: dict[str, Any]) -> dict[str, Any]:
        account = self._account_status({})
        machine = self.core.health_snapshot()
        account_relay = _account_relay_status()
        from megas.terminal import get_session_manager
        term_mgr = get_session_manager()
        return {
            "local_testing": local_testing.local_testing_snapshot(),
            "account": account,
            "account_relay": account_relay,
            "machine": machine,
            "agents": agent_management.status(),
            "tasks": agent_management.list_tasks(include_terminal=False),
            "actions": self._planning_call("megas_action_list", {})["actions"],
            "terminals": [s.to_dict() for s in term_mgr.list_sessions()],
            "activity": _bounded_activity_rows(build_activity_feed(self.core.store, self.core.timeline, limit=80)),
            "storage": {
                "authority": "Megas MCP",
                "ready": True,
                "current_kind": "versioned-local-files",
                "target_kind": "sqlite",
                "home": machine.get("home"),
            },
        }

    def _workspace_add_folder(self, params: dict[str, Any]) -> Any:
        folder = str(params.get("folder") or "").strip()
        if not folder:
            raise ValueError("folder is required")
        return local_testing.add_workspace_folder(folder)

    def _workspace_action(self, params: dict[str, Any]) -> Any:
        action = str(params.get("action") or "").strip()
        project = str(params.get("project") or "").strip()
        service = str(params.get("service") or "").strip() or None
        lines = int(params.get("lines") or 120)
        return local_testing.workspace_action(action, project, service=service, lines=lines)

    def _target_action(self, params: dict[str, Any]) -> Any:
        project = str(params.get("project") or "").strip()
        target_id = str(params.get("target_id") or "").strip()
        action = str(params.get("action") or "").strip()
        device_serial = str(params.get("device_serial") or "").strip() or None
        if not project or not target_id:
            raise ValueError("project and target_id are required")
        return local_testing.project_target_action(
            project,
            target_id,
            action,
            device_serial=device_serial,
        )

    def _adb_snapshot(self, _params: dict[str, Any]) -> Any:
        return local_testing.adb_snapshot()

    def _adb_pair(self, params: dict[str, Any]) -> Any:
        return local_testing.adb_pair_wireless(
            str(params.get("endpoint") or ""),
            str(params.get("pairing_code") or ""),
        )

    def _adb_connect(self, params: dict[str, Any]) -> Any:
        return local_testing.adb_connect_wireless(str(params.get("endpoint") or ""))

    def _account_status(self, params: dict[str, Any]) -> Any:
        from megas.firebase_account import status
        value = self.account.status(verify=bool(params.get("verify", False)))
        value.update(status())
        value["amretra_authenticated"] = value["firebase_authenticated"]
        if value["firebase_authenticated"]:
            identity = value["identity"]
            # Project the verified Firebase identity into the existing WinUI
            # account presentation contract without persisting another binding.
            value["user"] = {"user_id": identity["user_id"],
                             "email": identity.get("email"),
                             "full_name": identity.get("name")}
        return value

    def _account_login(self, params: dict[str, Any]) -> Any:
        from megas.firebase_account import interactive_login
        interactive_login()
        return self._account_status({})

    def _account_logout(self, _params: dict[str, Any]) -> Any:
        self.chatgpt.disconnect()
        from megas.firebase_account import logout
        logout()
        self.account.logout_amretra()
        return self._account_status({})

    def _chatgpt_connect(self, params: dict[str, Any]) -> Any:
        result = self.chatgpt.connect()
        self.chatgpt.resume()
        return result

    def _chatgpt_configure(self, params: dict[str, Any]) -> Any:
        if set(params) - {"tunnel_id", "runtime_key"}:
            raise ValueError("Unsupported ChatGPT connection setting")
        return self.chatgpt.configure(params.get("tunnel_id"), params.get("runtime_key", ""))

    def _agents_status(self, _params: dict[str, Any]) -> Any:
        return agent_management.status()

    def _agent_install(self, params: dict[str, Any]) -> Any:
        client = self._client(params)
        result = agent_management.install(client, confirm=self._confirmation(params), connect=True)
        self._record_agent_event("agent.install.completed", client=client, connected=True)
        return result

    def _agent_connect(self, params: dict[str, Any]) -> Any:
        client = self._client(params)
        result = agent_management.connect(client, confirm=self._confirmation(params), verify=True)
        self._record_agent_event("agent.connected", client=client)
        return result

    def _agent_disconnect(self, params: dict[str, Any]) -> Any:
        client = self._client(params)
        result = agent_management.disconnect(client, confirm=self._confirmation(params))
        self._record_agent_event("agent.disconnected", client=client)
        return result

    def _agent_uninstall(self, params: dict[str, Any]) -> Any:
        client = self._client(params)
        result = agent_management.uninstall(client, confirm=self._confirmation(params))
        self._record_agent_event("agent.uninstalled", client=client)
        return result

    def _tasks_list(self, params: dict[str, Any]) -> Any:
        return agent_management.list_tasks(include_terminal=bool(params.get("include_terminal", True)))

    def _task_create(self, params: dict[str, Any]) -> Any:
        title = str(params.get("title") or "").strip()
        project = str(params.get("project") or "").strip() or None
        if not title or len(title) > MAX_TASK_TITLE_CHARS:
            raise ValueError("task title must be between 1 and 4000 characters")
        if project is not None and len(project) > MAX_PROJECT_CHARS:
            raise ValueError("task project exceeds 256 characters")
        task = self._planning_call("megas_todo_create", {"title": title, "project_id": project}) if project else agent_management.create_task(title)
        self._record_agent_event(
            "task.created",
            task_id=task.get("id"),
            project=task.get("project"),
            title=task.get("title"),
        )
        return task

    def _task_assign(self, params: dict[str, Any]) -> Any:
        task_id = self._task_id(params)
        client = self._client(params)
        task = agent_management.assign_task(task_id, client)
        self._record_agent_event(
            "task.agent.assigned",
            task_id=task_id,
            client=client,
            assignment_generation=task.get("assignment_generation"),
        )
        return task

    def _task_unassign(self, params: dict[str, Any]) -> Any:
        task_id = self._task_id(params)
        task = agent_management.unassign_task(task_id)
        self._record_agent_event(
            "task.agent.unassigned",
            task_id=task_id,
            assignment_generation=task.get("assignment_generation"),
        )
        return task

    def _agent_download_and_assign(self, params: dict[str, Any]) -> Any:
        client = self._client(params)
        task_id = str(params.get("task_id") or "").strip() or None
        title = str(params.get("title") or "").strip() or None
        project = str(params.get("project") or "").strip() or None
        if task_id is not None and TASK_ID_RE.fullmatch(task_id) is None:
            raise ValueError("task_id is invalid")
        if task_id is None and (title is None or len(title) > MAX_TASK_TITLE_CHARS):
            raise ValueError("title is required when task_id is not supplied")
        if project is not None and len(project) > MAX_PROJECT_CHARS:
            raise ValueError("task project exceeds 256 characters")
        confirmed = self._confirmation(params)
        if task_id is None and project:
            task_id = self._planning_call("megas_todo_create", {"title": title, "project_id": project})["id"]
        result = agent_management.download_and_assign(
            client,
            task_id=task_id,
            title=title,
            project=project,
            confirm=confirmed,
        )
        task = result.get("task") if isinstance(result, dict) else {}
        self._record_agent_event(
            "agent.download_assigned",
            client=client,
            task_id=task.get("id") if isinstance(task, dict) else None,
            project=task.get("project") if isinstance(task, dict) else project,
        )
        return result

    def _activity_list(self, params: dict[str, Any]) -> Any:
        limit = max(1, min(MAX_ACTIVITY_ROWS, int(params.get("limit") or 200)))
        source = str(params.get("source") or "").strip()
        if source and source not in ACTIVITY_SOURCES:
            raise ValueError("unknown activity source")
        return _bounded_activity_rows(build_activity_feed(
            self.core.store,
            self.core.timeline,
            limit=limit,
            sources={source} if source else None,
            errors_only=bool(params.get("errors_only", False)),
            query=str(params.get("query") or ""),
        ))

    def _native_event_record(self, params: dict[str, Any]) -> dict[str, Any]:
        raw = str(params.get("json") or "")
        encoded = raw.encode("utf-8")
        if not raw or len(encoded) > MAX_NATIVE_EVENT_BYTES:
            raise ValueError("native event must be non-empty and <= 64 KiB")
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise TypeError("native event must be an object")
        if int(value.get("protocol_version") or 0) != 1:
            raise ValueError("unsupported native event protocol version")
        if str(value.get("source") or "") != "Native":
            raise ValueError("native event source must be Native")
        event_type = str(value.get("type") or "").strip()
        if event_type not in NATIVE_EVENT_TYPES:
            raise ValueError("unsupported native event type")
        severity = str(value.get("severity") or "info").strip().lower()
        if severity not in {"info", "warning", "error"}:
            raise ValueError("unsupported native event severity")
        reason = str(value.get("reason") or "").strip()
        if len(reason) > 256:
            raise ValueError("native event reason exceeds 256 characters")

        process_id: int | None = None
        if event_type == "native.process.contained":
            process_id = int(value.get("process_id") or 0)
            if not 1 <= process_id <= 0xFFFFFFFF:
                raise ValueError("native process event requires a valid process_id")

        record: dict[str, Any] = {
            "source": "Native",
            "severity": severity,
            "reason": reason or None,
            "native_abi_version": 1,
        }
        if process_id is not None:
            record["process_id"] = process_id
        self.core.store.record(event_type, **record)
        return {"recorded": True, "event": event_type}

    def _update_preflight(self, _params: dict[str, Any]) -> dict[str, Any]:
        workspace = local_testing.workspace_snapshot()
        machine = self.core.health_snapshot()
        running_local_services = int(workspace.get("running_service_count") or 0)
        running_mcp_servers = int(machine.get("running_servers") or 0)
        active_session_id = str(machine.get("active_session_id") or "").strip() or None

        blockers: list[dict[str, Any]] = []
        if running_local_services:
            blockers.append(
                {
                    "code": "local-runtimes-active",
                    "count": running_local_services,
                    "message": "Local testing runtimes are still active.",
                }
            )
        if running_mcp_servers:
            blockers.append(
                {
                    "code": "mcp-runtimes-active",
                    "count": running_mcp_servers,
                    "message": "Managed MCP server runtimes are still active.",
                }
            )
        if active_session_id:
            blockers.append(
                {
                    "code": "mcp-session-active",
                    "count": 1,
                    "message": "An MCP operation session is active.",
                }
            )

        return {
            "safe": not blockers,
            "blockers": blockers,
            "running_local_services": running_local_services,
            "running_mcp_servers": running_mcp_servers,
            "active_session": bool(active_session_id),
        }

    def _terminal_list(self, _params: dict[str, Any]) -> dict[str, Any]:
        from megas.terminal import get_session_manager

        mgr = get_session_manager()
        return {"terminals": [s.to_dict() for s in mgr.list_sessions()]}

    def _terminal_create(self, params: dict[str, Any]) -> dict[str, Any]:
        from megas.terminal import get_session_manager

        mgr = get_session_manager()
        cmd = params.get("command")
        if not cmd:
            raise ValueError("command is required")
        cwd = params.get("cwd")
        if not isinstance(cwd, str) or not Path(cwd).is_absolute() or not Path(cwd).is_dir():
            raise ValueError("terminal working folder must be an existing absolute directory")
        title = params.get("title")
        env = params.get("env")
        metadata = {"interactive": os.name == "nt"}
        task_id = str(params.get("task_id") or "").strip()
        if task_id:
            from megas.agent_tasks import AgentTaskStore
            task = AgentTaskStore().get(task_id)
            metadata.update({"task_id": task.id, "action_id": task.action_id,
                        "assignment_generation": task.assignment_generation}
            )
        session = mgr.create_session(command=cmd, cwd=cwd, title=title, env=env, metadata=metadata)
        return {"terminal": session.to_dict()}

    def _terminal_read(self, params: dict[str, Any]) -> dict[str, Any]:
        from megas.terminal import get_session_manager

        mgr = get_session_manager()
        session_id = str(params.get("session_id") or "").strip()
        if not session_id:
            raise ValueError("session_id is required")
        after_seq = int(params.get("after_seq", -1))
        limit = max(1, min(500, int(params.get("limit", 200))))
        events = mgr.read_output(session_id, after_seq=after_seq, limit=limit)
        rows = []
        size = 2
        truncated = False
        for event in events:
            row = event.to_dict()
            text = row.get("text")
            if isinstance(text, str) and len(text.encode("utf-8")) > 8192:
                row["text"] = text.encode("utf-8")[:8192].decode("utf-8", errors="ignore") + "\n[Event text truncated in this bounded view]\n"
                row["text_truncated"] = True
                truncated = True
            encoded = json.dumps(row, separators=(",", ":"), default=str).encode()
            if size + len(encoded) + 1 > MAX_TERMINAL_VIEW_BYTES:
                truncated = True
                break
            rows.append(row)
            size += len(encoded) + 1
        return {"events": rows, "truncated": truncated, "after_seq": rows[-1].get("seq", after_seq) if rows else after_seq}

    def _terminal_input(self, params: dict[str, Any]) -> dict[str, Any]:
        from megas.terminal import get_session_manager

        mgr = get_session_manager()
        session_id = str(params.get("session_id") or "").strip()
        text = str(params.get("text") or "")
        ok = mgr.send_input(session_id, text)
        return {"ok": ok, "session_id": session_id}

    def _terminal_terminate(self, params: dict[str, Any]) -> dict[str, Any]:
        from megas.terminal import get_session_manager

        mgr = get_session_manager()
        session_id = str(params.get("session_id") or "").strip()
        ok = mgr.terminate_session(session_id)
        return {"ok": ok, "session_id": session_id}

    def _ping(self, _params: dict[str, Any]) -> dict[str, Any]:
        return {
            "ok": True,
            "product": "MegasMoves",
            "transport": "typed-local-ipc",
            "methods": list(self.methods),
        }


def _bounded_activity_rows(rows):
    """Bound the UI projection; leave canonical history and evidence untouched."""
    selected = []
    size = 2
    omitted = False
    for original in rows:
        row = dict(original)
        encoded = json.dumps(row, separators=(",", ":"), default=str).encode()
        if len(encoded) > 16 * 1024:
            row["details"] = {"truncated": True, "reason": "Details exceed the bounded desktop view; canonical history is retained."}
            encoded = json.dumps(row, separators=(",", ":"), default=str).encode()
        if size + len(encoded) + 1 > MAX_ACTIVITY_VIEW_BYTES - 1024:
            omitted = True
            break
        selected.append(row)
        size += len(encoded) + 1
    if omitted:
        selected.append({"id": "desktop-activity-view-truncated", "source": "Runtime", "severity": "warning",
            "event": "desktop.view.truncated", "message": "More activity is retained in canonical history. Narrow the filters to inspect it.",
            "details": {"truncated": True}, "stream": "desktop-view"})
    return selected


def _encode_response(payload):
    encoded = json.dumps(payload, separators=(",", ":"), default=str).encode("utf-8")
    if len(encoded) <= MAX_REQUEST_BYTES:
        return encoded
    # A large result must fail its request, not kill the capability core or pipe.
    response = _response(payload.get("id"), error=ValueError("desktop response exceeds the bounded view; narrow the request"))
    encoded = json.dumps(response, separators=(",", ":")).encode()
    if len(encoded) > MAX_REQUEST_BYTES:
        response["id"] = None
        encoded = json.dumps(response, separators=(",", ":")).encode()
    return encoded


def _response(request_id: Any, *, result: Any = None, error: BaseException | None = None) -> dict[str, Any]:
    if error is None:
        return {"id": request_id, "ok": True, "result": result}
    return {
        "id": request_id,
        "ok": False,
        "error": {"type": type(error).__name__, "message": str(error)},
    }


def _handle_request(
    bridge: NativeDesktopBridge,
    raw: bytes,
    *,
    expected_token: str | None,
) -> dict[str, Any]:
    if not raw or len(raw) > MAX_REQUEST_BYTES:
        raise ValueError("native desktop request must be non-empty and <= 256 KiB")
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise TypeError("native desktop request must be an object")
    request_id = value.get("id")

    if expected_token is not None:
        supplied = str(value.get("auth") or "")
        if not supplied or not hmac.compare_digest(supplied, expected_token):
            raise PermissionError("native desktop IPC authentication failed")

    method = str(value.get("method") or "")
    params = value.get("params") or {}
    result = bridge.dispatch(method, params)
    return _response(request_id, result=result)


def _pipe_name(value: str) -> str:
    name = str(value or "").strip()
    if PIPE_NAME_RE.fullmatch(name) is None:
        raise ValueError("native desktop pipe name is invalid")
    return name


def _pipe_token() -> str:
    token = os.environ.get("MEGAS_DESKTOP_IPC_TOKEN", "").strip()
    if not 32 <= len(token) <= MAX_IPC_TOKEN_CHARS:
        raise RuntimeError("native desktop IPC token is missing or invalid")
    return token


def _read_pipe_frame(kernel32: Any, handle: Any) -> bytes | None:
    from ctypes import wintypes

    def read_exact(length: int) -> bytes | None:
        result = bytearray()
        while len(result) < length:
            chunk_size = min(length - len(result), 64 * 1024)
            buffer = ctypes.create_string_buffer(chunk_size)
            read = wintypes.DWORD()
            ok = kernel32.ReadFile(handle, buffer, chunk_size, ctypes.byref(read), None)
            if not ok:
                error = ctypes.get_last_error()
                if error in {109, 232}:
                    return None
                raise ctypes.WinError(error)
            if read.value == 0:
                return None
            result.extend(buffer.raw[: read.value])
        return bytes(result)

    header = read_exact(4)
    if header is None:
        return None
    length = int.from_bytes(header, "little", signed=False)
    if length <= 0 or length > MAX_REQUEST_BYTES:
        raise ValueError("native desktop IPC frame length is invalid")
    return read_exact(length)


def _write_pipe_frame(kernel32: Any, handle: Any, payload: bytes) -> None:
    from ctypes import wintypes

    if len(payload) > MAX_REQUEST_BYTES:
        raise ValueError("native desktop IPC response exceeds 256 KiB")
    framed = len(payload).to_bytes(4, "little", signed=False) + payload
    offset = 0
    while offset < len(framed):
        chunk = framed[offset : offset + 64 * 1024]
        written = wintypes.DWORD()
        buffer = ctypes.create_string_buffer(chunk)
        ok = kernel32.WriteFile(handle, buffer, len(chunk), ctypes.byref(written), None)
        if not ok:
            raise ctypes.WinError(ctypes.get_last_error())
        if written.value <= 0:
            raise OSError("native desktop IPC pipe wrote zero bytes")
        offset += written.value


def serve_named_pipe(pipe_name: str, *, bridge: NativeDesktopBridge | None = None) -> int:
    """Serve one authenticated local WinUI command connection."""

    if os.name != "nt":
        raise RuntimeError("named-pipe desktop transport is available only on Windows")
    from ctypes import wintypes

    name = _pipe_name(pipe_name)
    token = _pipe_token()
    full_name = rf"\\.\pipe\{name}"
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.CreateNamedPipeW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.LPVOID,
    ]
    kernel32.CreateNamedPipeW.restype = wintypes.HANDLE
    kernel32.ConnectNamedPipe.argtypes = [wintypes.HANDLE, wintypes.LPVOID]
    kernel32.ConnectNamedPipe.restype = wintypes.BOOL
    kernel32.ReadFile.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID]
    kernel32.ReadFile.restype = wintypes.BOOL
    kernel32.WriteFile.argtypes = [wintypes.HANDLE, wintypes.LPCVOID, wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID]
    kernel32.WriteFile.restype = wintypes.BOOL
    kernel32.FlushFileBuffers.argtypes = [wintypes.HANDLE]
    kernel32.DisconnectNamedPipe.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

    pipe_access_duplex = 0x00000003
    file_flag_first_pipe_instance = 0x00080000
    pipe_type_byte = 0x00000000
    pipe_readmode_byte = 0x00000000
    pipe_wait = 0x00000000
    pipe_reject_remote_clients = 0x00000008
    invalid_handle_value = ctypes.c_void_p(-1).value

    handle = kernel32.CreateNamedPipeW(
        full_name,
        pipe_access_duplex | file_flag_first_pipe_instance,
        pipe_type_byte | pipe_readmode_byte | pipe_wait | pipe_reject_remote_clients,
        1,
        MAX_REQUEST_BYTES + 4,
        MAX_REQUEST_BYTES + 4,
        0,
        None,
    )
    if handle == invalid_handle_value:
        raise ctypes.WinError(ctypes.get_last_error())

    active_bridge = bridge or NativeDesktopBridge()
    try:
        connected = kernel32.ConnectNamedPipe(handle, None)
        if not connected:
            error = ctypes.get_last_error()
            if error != 535:
                raise ctypes.WinError(error)

        while True:
            raw = _read_pipe_frame(kernel32, handle)
            if raw is None:
                break
            request_id: Any = None
            try:
                try:
                    decoded = json.loads(raw.decode("utf-8"))
                    request_id = decoded.get("id") if isinstance(decoded, dict) else None
                except Exception:
                    request_id = None
                payload = _handle_request(active_bridge, raw, expected_token=token)
            except Exception as exc:
                payload = _response(request_id, error=exc)
            encoded = _encode_response(payload)
            _write_pipe_frame(kernel32, handle, encoded)
        kernel32.FlushFileBuffers(handle)
        return 0
    finally:
        try:
            kernel32.DisconnectNamedPipe(handle)
        finally:
            kernel32.CloseHandle(handle)


def serve_named_pipes(command_pipe_name: str, activity_pipe_name: str) -> int:
    """Run command and resumable Activity transports over one shared operator."""

    bridge = NativeDesktopBridge()

    def activity_worker() -> None:
        try:
            serve_activity_pipe(activity_pipe_name, bridge)
        except Exception as exc:
            bridge.core.store.record(
                "activity.subscription.failed",
                source="Runtime",
                severity="error",
                error_type=type(exc).__name__,
            )

    thread = threading.Thread(
        target=activity_worker,
        name="MegasMoves-ActivityPipe",
        daemon=True,
    )
    thread.start()
    return serve_named_pipe(command_pipe_name, bridge=bridge)


def serve_stdio() -> int:
    """Headless/development carrier; not the production WinUI transport."""

    bridge = NativeDesktopBridge()
    for raw in sys.stdin.buffer:
        request_id: Any = None
        try:
            try:
                decoded = json.loads(raw.decode("utf-8"))
                request_id = decoded.get("id") if isinstance(decoded, dict) else None
            except Exception:
                request_id = None
            payload = _handle_request(bridge, raw.rstrip(b"\r\n"), expected_token=None)
        except Exception as exc:
            payload = _response(request_id, error=exc)
        sys.stdout.write(json.dumps(payload, separators=(",", ":"), default=str) + "\n")
        sys.stdout.flush()
    return 0


__all__ = [
    "MAX_ACTIVITY_ROWS",
    "MAX_NATIVE_EVENT_BYTES",
    "MAX_REQUEST_BYTES",
    "NATIVE_EVENT_TYPES",
    "NativeDesktopBridge",
    "serve_named_pipe",
    "serve_named_pipes",
    "serve_stdio",
]
