"""Megas Worker agent adapters."""

