from __future__ import annotations

import asyncio
import os
import time
from pathlib import Path
from typing import AsyncIterator

from ..adapters.base import WorkerEvent, BaseAgentAdapter
from ..evidence.git import get_head_commit, validate_changed_paths
from ..policy import resolve_allowed_workdir
from ..runtime.git_branch import prepare_session_branch
from megas.adapters.base import (
    prefer_console_free_tool_path,
    windows_subprocess_kwargs,
)


class CommitGateAdapter(BaseAgentAdapter):
    name = "commit_gate"
    adapter_id = "commit_gate"
    contract_version = "1.0"
    status = "discovered"
    supported_range = ">=0.0.0"

    def __init__(self, allowed_folders: list[str]) -> None:
        super().__init__(allowed_folders)

    def supports(self, command: dict) -> bool:
        return command.get("command_type") == "create_commit"

    def prepare_context(self, context_pack: dict, workspace: Path, command: dict | None = None) -> Path:
        return workspace / "MEGAS.md"

    async def launch(self, command: dict) -> AsyncIterator[WorkerEvent]:
        session_id = str(command.get("session_id") or "")
        command_id = str(command.get("command_id") or "")
        lease_id = str(command.get("lease_id") or "")
        workdir = resolve_allowed_workdir(command.get("workdir"), self.allowed_folders)

        started = time.time()
        # 1. Yield start event
        yield WorkerEvent("command_started", {
            "command_id": command_id,
            "command": ["create_commit"],
            "workdir": str(workdir),
            "session_id": session_id
        })

        try:
            change_package_id = command.get("change_package_id")
            expected_files = command.get("expected_files") or []
            commit_message = command.get("commit_message")
            base_commit = command.get("base_commit")

            if not change_package_id or not commit_message:
                raise ValueError("Missing change_package_id or commit_message")

            # Prepare safe session branch
            working_branch = command.get("working_branch") or (command.get("context_pack") or {}).get("working_branch")
            async for event in prepare_session_branch(workdir, session_id, working_branch=working_branch):
                yield event

            # Independent branch validation check
            from ..evidence.git import get_repo_state
            repo_st = await get_repo_state(workdir)
            curr_b = repo_st["branch"]
            if curr_b in {"main", "master", "release"} or curr_b.startswith("release/") or not curr_b.startswith("megas/session-"):
                raise ValueError(f"Commits are not allowed directly on branch '{curr_b}'. Switch to a Megas session branch first.")

            # 2. Get current HEAD and run duplicate detection
            if not (workdir / ".git").exists():
                raise ValueError("Not a git repository")

            current_head = await get_head_commit(workdir)

            # Check if the latest commit already contains Megas trailers for this package/session
            log_proc = await asyncio.create_subprocess_exec(
                "git", "log", "-1", "--format=%B",
                cwd=str(workdir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=prefer_console_free_tool_path(),
                **windows_subprocess_kwargs(new_group=False),
            )
            stdout_log, _ = await log_proc.communicate()
            last_commit_msg = stdout_log.decode(errors="replace")

            if f"Megas-Session: {session_id}" in last_commit_msg and f"Megas-Change-Package: {change_package_id}" in last_commit_msg:
                yield WorkerEvent("evidence", {
                    "evidence_type": "evidence_commit_created",
                    "summary": f"Local commit already created: {current_head[:7]}",
                    "payload": {
                        "kind": "commit_created",
                        "commit_sha": current_head,
                        "commit_subject": last_commit_msg.splitlines()[0] if last_commit_msg.strip() else "",
                        "files": expected_files,
                        "session_id": session_id,
                        "change_package_id": change_package_id,
                        "already_created": True
                    }
                })
                yield WorkerEvent("command_finished", {
                    "command_id": command_id,
                    "exit_code": 0,
                    "duration_ms": 0
                })
                return

            # 3. HEAD matches the package base/apply state
            if base_commit and current_head != base_commit:
                raise ValueError(f"HEAD commit {current_head} does not match package commit state {base_commit}")

            # 4. Check workspace is clean except expected package files
            proc_status = await asyncio.create_subprocess_exec(
                "git", "status", "--porcelain=v1", "--untracked-files=all",
                cwd=str(workdir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=prefer_console_free_tool_path(),
                **windows_subprocess_kwargs(new_group=False),
            )
            stdout_s, _ = await proc_status.communicate()
            lines = stdout_s.decode(errors="replace").splitlines()

            modified_or_untracked = []
            for line in lines:
                if not line.strip():
                    continue
                file_path = line[3:].strip()
                if file_path.startswith('"') and file_path.endswith('"'):
                    file_path = file_path[1:-1]
                file_path = file_path.replace("\\", "/")
                modified_or_untracked.append(file_path)

            normalized_expected = [ef.replace("\\", "/") for ef in expected_files]
            for f in modified_or_untracked:
                if f not in normalized_expected:
                    raise ValueError(f"Workspace contains dirty file '{f}' not in change package expected files.")

            # 5. Check no protected paths are included
            validate_entries = [{"path": f, "status": "M"} for f in expected_files]
            validate_changed_paths(validate_entries, workdir)

            # 6. Stage exact files only
            add_proc = await asyncio.create_subprocess_exec(
                "git", "add", "--", *expected_files,
                cwd=str(workdir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=prefer_console_free_tool_path(),
                **windows_subprocess_kwargs(new_group=False),
            )
            stdout_a, stderr_a = await add_proc.communicate()
            if add_proc.returncode != 0:
                raise ValueError(f"git add failed: {stderr_a.decode(errors='replace')}")

            # 7. Check git diff --cached --check passes
            check_proc = await asyncio.create_subprocess_exec(
                "git", "diff", "--cached", "--check",
                cwd=str(workdir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=prefer_console_free_tool_path(),
                **windows_subprocess_kwargs(new_group=False),
            )
            _, stderr_check = await check_proc.communicate()
            if check_proc.returncode != 0:
                # Reset staged files before failing
                reset_proc = await asyncio.create_subprocess_exec(
                    "git", "reset", "--",
                    cwd=str(workdir),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    env=prefer_console_free_tool_path(),
                    **windows_subprocess_kwargs(new_group=False),
                )
                await reset_proc.communicate()
                raise ValueError(f"git diff --cached --check failed: {stderr_check.decode(errors='replace')}")

            # 8. Commit message generated/sanitized using local fallback config
            commit_proc = await asyncio.create_subprocess_exec(
                "git",
                "-c", "user.name=Megas Worker",
                "-c", "user.email=worker@megasmoves.io",
                "commit", "-m", commit_message,
                cwd=str(workdir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=prefer_console_free_tool_path(),
                **windows_subprocess_kwargs(new_group=False),
            )
            stdout_c, stderr_c = await commit_proc.communicate()
            if commit_proc.returncode != 0:
                # Reset staged files on failure
                reset_proc = await asyncio.create_subprocess_exec(
                    "git", "reset", "--",
                    cwd=str(workdir),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    env=prefer_console_free_tool_path(),
                    **windows_subprocess_kwargs(new_group=False),
                )
                await reset_proc.communicate()
                raise ValueError(f"git commit failed: {stderr_c.decode(errors='replace')}")

            new_head = await get_head_commit(workdir)
            subject = commit_message.splitlines()[0] if commit_message else ""

            # 9. Yield evidence of commit created
            yield WorkerEvent("evidence", {
                "evidence_type": "evidence_commit_created",
                "summary": f"Local commit created: {new_head[:7]} {subject}",
                "payload": {
                    "kind": "commit_created",
                    "commit_sha": new_head,
                    "commit_subject": subject,
                    "files": expected_files,
                    "session_id": session_id,
                    "change_package_id": change_package_id
                }
            })

            # Yield success command finished
            yield WorkerEvent("command_finished", {
                "command_id": command_id,
                "exit_code": 0,
                "duration_ms": int((time.time() - started) * 1000)
            })

            # Yield terminal result
            terminal_payload = {
                "adapter": "commit_gate",
                "command": "git commit",
                "workdir": str(workdir),
                "exit_code": 0,
                "duration_ms": 0,
                "output_tail": [{"stream": "stdout", "line": stdout_c.decode(errors="replace")}],
                "git": {"is_git_repo": True, "branch": "", "status_short": "", "diff_stat": ""},
            }
            yield WorkerEvent("evidence", {
                "evidence_type": "terminal_result",
                "summary": "Commit succeeded",
                "payload": terminal_payload
            })

        except Exception as exc:
            err_msg = str(exc)
            yield WorkerEvent("commit_failed", {
                "session_id": session_id,
                "command_id": command_id,
                "error": err_msg
            })
            terminal_payload = {
                "adapter": "commit_gate",
                "command": "git commit",
                "workdir": str(workdir),
                "exit_code": 1,
                "duration_ms": 0,
                "output_tail": [{"stream": "stderr", "line": err_msg}],
                "git": {},
                "error": err_msg,
            }
            yield WorkerEvent("evidence", {
                "evidence_type": "terminal_result",
                "summary": f"Commit failed: {err_msg}",
                "payload": terminal_payload
            })
            yield WorkerEvent("command_finished", {
                "command_id": command_id,
                "exit_code": 1,
                "duration_ms": 0
            })
