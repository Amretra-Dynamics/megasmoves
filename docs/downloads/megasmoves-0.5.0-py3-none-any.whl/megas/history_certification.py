"""Issue partial certificates from authoritative provider-native history.

This path never executes a new provider prompt. It proves only list/read,
identity stability, persistence, and reconciliation against the provider's
actual history authority. Exact resume, streaming, cancellation, and limits
remain unavailable until their own live probes pass.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
from pathlib import Path
from typing import Any

from .adapter_certification import (
    CHECK_FAILED,
    CHECK_PASSED,
    adapter_authentication_identity,
    build_certificate,
    evaluate_certificate,
    installation_identity,
    write_certificate,
)
from .provider_certification_probes import (
    negative_nonconversation_sources_rejected,
    secret_redaction_proved,
)
from .runtime_manifest import _agent_adapter_classes, _auth_mode
# Importing the public module installs the strict OpenCode, Kilo, Cursor, and
# Cline readers before the registry is consumed below.
from . import thread_sync as _strict_reader_installation  # noqa: F401
from . import certified_thread_sync as registry
from . import thread_sync_legacy as legacy


@dataclass(frozen=True)
class HistoryCertificationResult:
    provider_id: str
    certified: bool
    certificate_path: str
    status: str
    reason: str
    checks: dict[str, str]
    verified_capabilities: tuple[str, ...]
    evidence: dict[str, Any]


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _message_signature(
    thread: dict[str, Any] | None,
) -> tuple[str, ...]:
    if not isinstance(thread, dict):
        return ()
    values: list[str] = []
    for item in thread.get("messages") or []:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "")
        kind = str(item.get("kind") or "")
        native_item_id = str(item.get("native_item_id") or "")
        content = str(item.get("content") or item.get("text") or "")
        if not role or not content:
            continue
        values.append(
            _hash(f"{role}|{kind}|{native_item_id}|{content}")
        )
    return tuple(values)


def _prove_history_subset(
    provider_id: str,
    adapter: object,
    reader: registry.ProviderReader,
) -> tuple[dict[str, str], dict[str, Any], set[str]]:
    checks: dict[str, str] = {}
    evidence: dict[str, Any] = {"provider_id": provider_id}
    capabilities: set[str] = set()

    negative_ok, negative_reason = negative_nonconversation_sources_rejected(
        provider_id
    )
    checks["negative_nonconversation_sources_rejected"] = (
        CHECK_PASSED if negative_ok else CHECK_FAILED
    )
    evidence["negative_probe"] = negative_reason

    redaction_ok, redaction_reason = secret_redaction_proved(adapter)
    checks["secret_redaction"] = (
        CHECK_PASSED if redaction_ok else CHECK_FAILED
    )
    evidence["redaction_probe"] = redaction_reason

    try:
        rows = reader.index(200)
    except Exception as exc:
        rows = []
        evidence["index_error"] = type(exc).__name__

    candidates: list[str] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        native_id = str(row.get("native_id") or "").strip()
        if (
            not native_id
            or str(row.get("agent_type") or "") != provider_id
        ):
            continue
        if legacy.is_megas_internal_session(
            row.get("title"),
            row.get("preview"),
            row.get("first_user_message"),
        ):
            continue
        candidates.append(native_id)

    checks["thread_list"] = (
        CHECK_PASSED if candidates else CHECK_FAILED
    )
    evidence["indexed_thread_count"] = len(candidates)

    selected_native_id: str | None = None
    first_read: dict[str, Any] | None = None
    for native_id in candidates[:20]:
        try:
            thread = reader.read(native_id)
        except Exception:
            continue
        if not isinstance(thread, dict):
            continue
        if str(thread.get("agent_type") or "") != provider_id:
            continue
        if str(thread.get("native_id") or "") != native_id:
            continue
        if not _message_signature(thread):
            continue
        selected_native_id = native_id
        first_read = thread
        break

    checks["thread_read"] = (
        CHECK_PASSED if first_read is not None else CHECK_FAILED
    )

    stable = False
    if first_read is not None and selected_native_id:
        try:
            second_read = reader.read(selected_native_id)
        except Exception:
            second_read = None
        first_signature = _message_signature(first_read)
        second_signature = _message_signature(second_read)
        # An actively running native conversation may append messages between
        # reads. The already-observed prefix must remain byte-stable and the
        # exact provider/native identity must remain unchanged.
        stable = bool(
            first_signature
            and second_signature
            and len(second_signature) >= len(first_signature)
            and second_signature[: len(first_signature)] == first_signature
            and str((second_read or {}).get("native_id") or "")
            == selected_native_id
            and str((second_read or {}).get("agent_type") or "")
            == provider_id
        )

    checks["native_persistence"] = (
        CHECK_PASSED if stable else CHECK_FAILED
    )
    checks["post_turn_reconciliation"] = (
        CHECK_PASSED if stable else CHECK_FAILED
    )
    if selected_native_id:
        evidence["native_id_hash"] = _hash(selected_native_id)
    evidence["message_count"] = len(_message_signature(first_read))

    required = (
        "thread_list",
        "thread_read",
        "native_persistence",
        "post_turn_reconciliation",
        "negative_nonconversation_sources_rejected",
        "secret_redaction",
    )
    if all(checks.get(name) == CHECK_PASSED for name in required):
        capabilities.update(
            {
                "thread_list",
                "thread_read",
                "native_persistence",
                "reconciliation",
                "offline_replica",
            }
        )
    return checks, evidence, capabilities


def certify_history_installation(
    provider_id: str,
    *,
    expires_days: int = 30,
) -> HistoryCertificationResult:
    provider = str(provider_id or "").strip().lower()
    adapter_class = _agent_adapter_classes().get(provider)
    if adapter_class is None:
        raise ValueError(f"No adapter is registered for {provider}")

    adapter = adapter_class([])
    executable = adapter.discover_executable()
    if executable is None:
        raise FileNotFoundError(f"{provider} executable was not found")
    version = adapter.detect_version()
    if not version:
        raise RuntimeError(f"{provider} version could not be verified")
    health = str(adapter.health_status())
    if health not in {"available", "unauthenticated"}:
        raise RuntimeError(
            f"{provider} is not ready for history certification: {health}"
        )

    auth_mode = _auth_mode(provider, adapter)
    identity = installation_identity(
        provider_id=provider,
        executable=Path(executable),
        provider_version=str(version),
        adapter_contract_version=str(
            getattr(adapter, "contract_version", "unknown")
        ),
        auth_mode=auth_mode,
        execution_mode="inspect",
        authentication_identity=adapter_authentication_identity(adapter),
    )
    authentication_proved = bool(identity.get("authentication_identity"))
    checks: dict[str, str] = {
        "binary_identity": CHECK_PASSED,
        "provider_version": CHECK_PASSED,
        "authentication": (
            CHECK_PASSED if authentication_proved else CHECK_FAILED
        ),
    }
    evidence: dict[str, Any] = {
        "provider_id": provider,
        "authentication_identity_proved": authentication_proved,
    }
    capabilities: set[str] = set()

    reader = registry._READERS.get(provider)
    if reader is None:
        evidence["history_reader"] = "missing"
    elif authentication_proved:
        history_checks, history_evidence, capabilities = (
            _prove_history_subset(provider, adapter, reader)
        )
        checks.update(history_checks)
        evidence.update(history_evidence)

    issued = datetime.now(timezone.utc)
    certificate = build_certificate(
        identity=identity,
        checks=checks,
        verified_capabilities=capabilities,
        evidence=evidence,
        issued_at=issued,
        expires_at=issued
        + timedelta(days=min(max(int(expires_days), 1), 90)),
    )
    path = write_certificate(certificate)
    decision = evaluate_certificate(
        identity=identity,
        certificate=certificate,
    )

    # History certification intentionally proves a capability subset. Preserve
    # that granular result even though full execution remains uncertified, and
    # give missing account identity precedence over a generic failed check.
    if not authentication_proved:
        status = "failed"
        reason = "authentication_identity_unverified"
        verified_capabilities: tuple[str, ...] = ()
    elif certificate.get("status") == "partial" and certificate.get(
        "verified_capabilities"
    ):
        status = "partial"
        reason = "verified_capability_subset"
        verified_capabilities = tuple(
            str(item)
            for item in certificate.get("verified_capabilities") or []
        )
    else:
        status = decision.status
        reason = decision.reason
        verified_capabilities = decision.verified_capabilities

    return HistoryCertificationResult(
        provider_id=provider,
        certified=False,
        certificate_path=str(path),
        status=status,
        reason=reason,
        checks=dict(certificate.get("checks") or {}),
        verified_capabilities=verified_capabilities,
        evidence=dict(certificate.get("evidence") or {}),
    )
