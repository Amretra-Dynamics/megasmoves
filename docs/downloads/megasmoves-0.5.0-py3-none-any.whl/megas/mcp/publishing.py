from __future__ import annotations

import hashlib
import ipaddress
import json
import urllib.parse
import urllib.request
from typing import Any

from .model import MCPServer
from .protocol import HTTPMCPClient, _client_for, _summarize_resource, _summarize_tool


TARGET = "openai-plugin-2026"
REQUIRED_ANNOTATIONS = ("readOnlyHint", "openWorldHint", "destructiveHint")
OPENAI_SECURITY_SCHEME_TYPES = {"noauth", "oauth2"}
OPENAI_CIMD_TOKEN_AUTH_METHODS = {"none", "private_key_jwt"}
TEMPORARY_TUNNEL_SUFFIXES = (
    ".ngrok-free.app",
    ".ngrok.io",
    ".trycloudflare.com",
    ".loca.lt",
    ".localhost.run",
)
REDACTED = "[REDACTED]"
MAX_METADATA_BYTES = 1024 * 1024


class _PublicationHTTPClient(HTTPMCPClient):
    """Transient authenticated inspection client. The bearer token is never serialized."""

    def __init__(self, server: MCPServer, *, timeout: float, bearer_token: str) -> None:
        super().__init__(server, timeout=timeout)
        self._bearer_token = bearer_token

    def _headers(self) -> dict[str, str]:
        headers = super()._headers()
        headers["Authorization"] = f"Bearer {self._bearer_token}"
        return headers


def _redact_secret(value: Any, secret: str | None) -> Any:
    if not secret:
        return value
    if isinstance(value, str):
        return value.replace(secret, REDACTED)
    if isinstance(value, dict):
        return {str(key): _redact_secret(item, secret) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_secret(item, secret) for item in value]
    if isinstance(value, tuple):
        return [_redact_secret(item, secret) for item in value]
    return value


def _finding(
    requirement_id: str,
    message: str,
    *,
    tool: str | None = None,
    resource_uri: str | None = None,
) -> dict[str, Any]:
    row: dict[str, Any] = {"id": requirement_id, "message": message}
    if tool:
        row["tool"] = tool
    if resource_uri:
        row["resource_uri"] = resource_uri
    return row


def _is_public_host(host: str) -> bool:
    normalized = host.strip().lower().rstrip(".")
    if not normalized or normalized == "localhost" or normalized.endswith(".local"):
        return False
    try:
        address = ipaddress.ip_address(normalized)
    except ValueError:
        return True
    return not (
        address.is_private
        or address.is_loopback
        or address.is_link_local
        or address.is_reserved
        or address.is_unspecified
    )


def _is_https_url(value: Any) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    parsed = urllib.parse.urlparse(value)
    return parsed.scheme == "https" and bool(parsed.netloc)


def _normalized_url(value: str) -> str:
    return value.rstrip("/")


def _read_json_url(url: str, *, timeout: float) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"Accept": "application/json"}, method="GET")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read(MAX_METADATA_BYTES + 1)
    if len(raw) > MAX_METADATA_BYTES:
        raise ValueError("metadata document exceeds 1 MiB")
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("metadata document must be a JSON object")
    return value


def _authorization_metadata_urls(issuer: str) -> list[str]:
    """Return RFC 8414 and OIDC discovery candidates for an HTTPS issuer."""

    parsed = urllib.parse.urlparse(issuer)
    if parsed.scheme != "https" or not parsed.netloc:
        return []
    issuer_path = parsed.path.rstrip("/")
    origin = f"{parsed.scheme}://{parsed.netloc}"
    oauth_path = "/.well-known/oauth-authorization-server" + issuer_path
    oidc_path = issuer_path + "/.well-known/openid-configuration"
    return [origin + oauth_path, origin + oidc_path]


def _ui_resource_uri(tool: dict[str, Any]) -> tuple[str | None, str | None]:
    meta = tool.get("_meta")
    if not isinstance(meta, dict):
        return None, None
    ui = meta.get("ui")
    if isinstance(ui, dict) and isinstance(ui.get("resourceUri"), str) and ui["resourceUri"].strip():
        return ui["resourceUri"].strip(), "mcp-app"
    legacy = meta.get("openai/outputTemplate")
    if isinstance(legacy, str) and legacy.strip():
        return legacy.strip(), "openai-compat"
    return None, None


def _resource_evidence(client: Any, uri: str, *, timeout: float) -> dict[str, Any]:
    try:
        result = client.request("resources/read", {"uri": uri}, timeout=timeout)
    except Exception as exc:
        return {
            "uri": uri,
            "readable": False,
            "error": {"type": type(exc).__name__, "message": str(exc)},
        }
    contents = [row for row in (result.get("contents") or []) if isinstance(row, dict)]
    selected = next((row for row in contents if str(row.get("uri") or "") == uri), None)
    if selected is None and contents:
        selected = contents[0]
    if selected is None:
        return {
            "uri": uri,
            "readable": False,
            "error": {"type": "EmptyResource", "message": "resources/read returned no content"},
        }
    text = selected.get("text")
    blob = selected.get("blob")
    raw = text.encode("utf-8") if isinstance(text, str) else str(blob or "").encode("utf-8")
    meta = selected.get("_meta") if isinstance(selected.get("_meta"), dict) else {}
    return {
        "uri": uri,
        "readable": True,
        "mime_type": str(selected.get("mimeType") or ""),
        "_meta": dict(meta),
        "content_bytes": len(raw),
        "content_sha256": hashlib.sha256(raw).hexdigest(),
    }


def live_publication_probe(
    server: MCPServer,
    *,
    timeout: float = 10.0,
    bearer_token: str | None = None,
) -> dict[str, Any]:
    """Inspect submission-relevant MCP metadata without calling any model or OpenAI API."""

    if bearer_token and server.transport in {"http", "streamable-http"}:
        client_context: Any = _PublicationHTTPClient(
            server,
            timeout=timeout,
            bearer_token=bearer_token,
        )
    else:
        client_context = _client_for(server, timeout=timeout)

    with client_context as client:
        listed_tools = client.request("tools/list", {}, timeout=timeout)
        tools = [
            _summarize_tool(row)
            for row in (listed_tools.get("tools") or [])
            if isinstance(row, dict)
        ]
        try:
            listed_resources = client.request("resources/list", {}, timeout=timeout)
            resources = [
                _summarize_resource(row)
                for row in (listed_resources.get("resources") or [])
                if isinstance(row, dict)
            ]
        except (RuntimeError, TimeoutError):
            resources = []

        linked_uris: list[str] = []
        for tool in tools:
            uri, _source = _ui_resource_uri(tool)
            if uri and uri not in linked_uris:
                linked_uris.append(uri)
        ui_resources = [_resource_evidence(client, uri, timeout=timeout) for uri in linked_uris]
        probe = {
            "protocol_version": client.protocol_version,
            "server_info": dict(client.server_info),
            "capabilities": dict(client.capabilities),
            "instructions": client.instructions,
            "tools": tools,
            "resources": resources,
            "ui_resources": ui_resources,
        }
        clean = _redact_secret(probe, bearer_token)
        assert isinstance(clean, dict)
        return clean


def _check_transport(
    server: MCPServer,
    blockers: list[dict[str, Any]],
    warnings: list[dict[str, Any]],
    passed: list[dict[str, Any]],
) -> None:
    if server.transport != "streamable-http":
        blockers.append(_finding("OA-PUB-001", "Public OpenAI plugin submission requires MCP streamable HTTP transport."))
    else:
        passed.append(_finding("OA-PUB-001", "Server uses streamable HTTP."))

    if not server.url:
        blockers.append(_finding("OA-PUB-002", "Public submission requires a stable public HTTPS MCP URL."))
        return
    parsed = urllib.parse.urlparse(server.url)
    if parsed.scheme != "https":
        blockers.append(_finding("OA-PUB-002", "Production MCP URL must use HTTPS."))
    else:
        passed.append(_finding("OA-PUB-002", "MCP URL uses HTTPS."))

    host = (parsed.hostname or "").lower()
    if not _is_public_host(host):
        blockers.append(_finding("OA-PUB-003", "MCP URL is local/private; public review requires a publicly reachable endpoint."))
    elif any(host.endswith(suffix) for suffix in TEMPORARY_TUNNEL_SUFFIXES):
        blockers.append(_finding("OA-PUB-003", "MCP URL appears to use a temporary tunnel, which is not suitable for public submission."))
    else:
        passed.append(_finding("OA-PUB-003", "MCP host is syntactically public and not a recognized temporary tunnel."))

    if not parsed.path.rstrip("/").endswith("/mcp"):
        warnings.append(_finding("OA-PUB-004", "OpenAI recommends a stable MCP endpoint typically ending in /mcp."))


def _check_security_schemes(
    tool: dict[str, Any],
    blockers: list[dict[str, Any]],
) -> tuple[bool, set[str]]:
    name = str(tool.get("name") or "")
    schemes = tool.get("security_schemes")
    has_oauth = False
    oauth_scopes: set[str] = set()
    if not schemes:
        return False, oauth_scopes
    if not isinstance(schemes, list):
        blockers.append(_finding("OA-AUTH-001", "Tool securitySchemes must be an array.", tool=name))
        return False, oauth_scopes
    for scheme in schemes:
        if not isinstance(scheme, dict):
            blockers.append(_finding("OA-AUTH-001", "Tool securitySchemes contains a non-object entry.", tool=name))
            continue
        scheme_type = str(scheme.get("type") or "").strip()
        if scheme_type not in OPENAI_SECURITY_SCHEME_TYPES:
            blockers.append(
                _finding(
                    "OA-AUTH-001",
                    f"Unsupported OpenAI tool security scheme type: {scheme_type or '(missing)'}. Current documented types are noauth and oauth2.",
                    tool=name,
                )
            )
            continue
        if scheme_type == "oauth2":
            has_oauth = True
            scopes = scheme.get("scopes")
            if not isinstance(scopes, list) or not scopes or any(not isinstance(scope, str) or not scope.strip() for scope in scopes):
                blockers.append(_finding("OA-AUTH-001", "oauth2 security scheme must advertise a nonempty string scope list.", tool=name))
            else:
                oauth_scopes.update(scope.strip() for scope in scopes)
    return has_oauth, oauth_scopes


def _check_tools(
    probe: dict[str, Any],
    blockers: list[dict[str, Any]],
    warnings: list[dict[str, Any]],
    passed: list[dict[str, Any]],
) -> tuple[bool, set[str]]:
    tools = probe.get("tools") or []
    if not isinstance(tools, list) or not tools:
        blockers.append(_finding("OA-TOOL-000", "The live server did not advertise any MCP tools."))
        return False, set()
    names = [str(tool.get("name") or "") for tool in tools if isinstance(tool, dict)]
    duplicates = sorted({name for name in names if name and names.count(name) > 1})
    if duplicates:
        blockers.append(_finding("OA-TOOL-001", "Tool names must be unique: " + ", ".join(duplicates)))
    else:
        passed.append(_finding("OA-TOOL-001", "Tool names are unique."))

    ui_evidence = {
        str(row.get("uri") or ""): row
        for row in (probe.get("ui_resources") or [])
        if isinstance(row, dict)
    }
    has_oauth = False
    oauth_scopes: set[str] = set()
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        name = str(tool.get("name") or "")
        if not name:
            blockers.append(_finding("OA-TOOL-002", "Every tool needs a non-empty action-oriented name."))
            continue
        if not str(tool.get("title") or "").strip():
            blockers.append(_finding("OA-TOOL-003", "Tool is missing a human-readable title.", tool=name))
        if not str(tool.get("description") or "").strip():
            blockers.append(_finding("OA-TOOL-004", "Tool is missing an explicit description.", tool=name))
        schema = tool.get("input_schema")
        if not isinstance(schema, dict) or not schema:
            blockers.append(_finding("OA-TOOL-005", "Tool is missing an explicit input schema.", tool=name))
        output_schema = tool.get("output_schema")
        if not isinstance(output_schema, dict) or not output_schema:
            warnings.append(_finding("OA-TOOL-006", "No output schema is advertised; add one when the tool returns structured data.", tool=name))

        annotations = tool.get("annotations")
        if not isinstance(annotations, dict):
            annotations = {}
        for key in REQUIRED_ANNOTATIONS:
            if type(annotations.get(key)) is not bool:
                blockers.append(_finding("OA-TOOL-007", f"Tool must advertise explicit boolean {key}.", tool=name))

        tool_has_oauth, tool_scopes = _check_security_schemes(tool, blockers)
        has_oauth = tool_has_oauth or has_oauth
        oauth_scopes.update(tool_scopes)

        uri, source = _ui_resource_uri(tool)
        if not uri:
            continue
        if source == "openai-compat":
            warnings.append(_finding("OA-UI-001", "Tool uses legacy openai/outputTemplate without shared _meta.ui.resourceUri.", tool=name, resource_uri=uri))
        evidence = ui_evidence.get(uri)
        if evidence is None or not evidence.get("readable"):
            blockers.append(_finding("OA-UI-002", "Linked UI resource could not be verified with resources/read.", tool=name, resource_uri=uri))
            continue
        meta = evidence.get("_meta") if isinstance(evidence.get("_meta"), dict) else {}
        ui_meta = meta.get("ui") if isinstance(meta.get("ui"), dict) else {}
        csp = ui_meta.get("csp") if isinstance(ui_meta, dict) else None
        if not isinstance(csp, dict):
            blockers.append(_finding("OA-UI-003", "Linked UI resource is missing _meta.ui.csp.", tool=name, resource_uri=uri))
        domain = ui_meta.get("domain") if isinstance(ui_meta, dict) else None
        if not isinstance(domain, str) or not domain.strip():
            warnings.append(_finding("OA-UI-004", "Submission-ready UI should declare a stable _meta.ui.domain.", tool=name, resource_uri=uri))
    return has_oauth, oauth_scopes


def _check_authorization_server(
    issuer: str,
    *,
    required_scopes: set[str],
    timeout: float,
    blockers: list[dict[str, Any]],
    warnings: list[dict[str, Any]],
    passed: list[dict[str, Any]],
) -> dict[str, Any]:
    attempts: list[dict[str, str]] = []
    metadata: dict[str, Any] | None = None
    metadata_url: str | None = None
    for candidate in _authorization_metadata_urls(issuer):
        try:
            metadata = _read_json_url(candidate, timeout=timeout)
            metadata_url = candidate
            break
        except Exception as exc:
            attempts.append({"url": candidate, "error": f"{type(exc).__name__}: {exc}"})

    if metadata is None or metadata_url is None:
        blockers.append(
            _finding(
                "OA-AUTH-003",
                f"Authorization server {issuer} did not expose usable OAuth 2.0 or OpenID discovery metadata.",
            )
        )
        return {"issuer": issuer, "verified": False, "attempts": attempts}

    advertised_issuer = metadata.get("issuer")
    if not isinstance(advertised_issuer, str) or _normalized_url(advertised_issuer) != _normalized_url(issuer):
        blockers.append(_finding("OA-AUTH-003", f"Authorization metadata issuer does not match protected-resource authorization server: {issuer}."))

    for field, requirement_id in (
        ("authorization_endpoint", "OA-AUTH-004"),
        ("token_endpoint", "OA-AUTH-004"),
    ):
        if not _is_https_url(metadata.get(field)):
            blockers.append(_finding(requirement_id, f"Authorization server {issuer} must publish an HTTPS {field}."))

    pkce_methods = metadata.get("code_challenge_methods_supported")
    if not isinstance(pkce_methods, list) or "S256" not in pkce_methods:
        blockers.append(_finding("OA-AUTH-005", f"Authorization server {issuer} must advertise PKCE S256 support for ChatGPT's authorization-code flow."))
    else:
        passed.append(_finding("OA-AUTH-005", f"Authorization server {issuer} advertises PKCE S256."))

    token_auth = metadata.get("token_endpoint_auth_methods_supported")
    if not isinstance(token_auth, list) or not token_auth or any(not isinstance(item, str) for item in token_auth):
        blockers.append(_finding("OA-AUTH-006", f"Authorization server {issuer} must publish token_endpoint_auth_methods_supported."))
    else:
        cimd = metadata.get("client_id_metadata_document_supported") is True
        registration = metadata.get("registration_endpoint")
        if cimd:
            if not OPENAI_CIMD_TOKEN_AUTH_METHODS.intersection(token_auth):
                blockers.append(_finding("OA-AUTH-006", f"Authorization server {issuer} enables CIMD but does not accept OpenAI-supported token auth methods none or private_key_jwt."))
            else:
                passed.append(_finding("OA-AUTH-006", f"Authorization server {issuer} has a ChatGPT-compatible CIMD token authentication method."))
        elif _is_https_url(registration):
            passed.append(_finding("OA-AUTH-008", f"Authorization server {issuer} exposes HTTPS dynamic client registration."))
        else:
            warnings.append(_finding("OA-AUTH-008", f"Authorization server {issuer} advertises neither CIMD nor DCR; publication must use a correctly configured predefined OAuth client."))

    supported_scopes = metadata.get("scopes_supported")
    if isinstance(supported_scopes, list) and all(isinstance(scope, str) for scope in supported_scopes):
        missing = sorted(required_scopes - set(supported_scopes))
        if missing:
            blockers.append(_finding("OA-AUTH-007", f"Authorization server {issuer} does not advertise required tool scopes: {', '.join(missing)}."))
        elif required_scopes:
            passed.append(_finding("OA-AUTH-007", f"Authorization server {issuer} advertises all OAuth scopes required by the MCP tools."))
    elif required_scopes:
        warnings.append(_finding("OA-AUTH-007", f"Authorization server {issuer} does not publish scopes_supported, so required tool scopes could not be cross-checked."))

    return {
        "issuer": issuer,
        "verified": not any(row["id"] in {"OA-AUTH-003", "OA-AUTH-004", "OA-AUTH-005", "OA-AUTH-006", "OA-AUTH-007"} and issuer in row["message"] for row in blockers),
        "metadata_url": metadata_url,
        "metadata": metadata,
        "attempts": attempts,
    }


def _check_oauth_metadata(
    server: MCPServer,
    *,
    required_scopes: set[str],
    timeout: float,
    blockers: list[dict[str, Any]],
    warnings: list[dict[str, Any]],
    passed: list[dict[str, Any]],
) -> dict[str, Any]:
    if not server.url:
        return {"verified": False, "authorization_servers": []}
    parsed = urllib.parse.urlparse(server.url)
    if parsed.scheme != "https" or not parsed.netloc:
        return {"verified": False, "authorization_servers": []}
    metadata_url = f"{parsed.scheme}://{parsed.netloc}/.well-known/oauth-protected-resource"
    try:
        metadata = _read_json_url(metadata_url, timeout=timeout)
    except Exception as exc:
        blockers.append(
            _finding(
                "OA-AUTH-002",
                f"OAuth is advertised by a tool but protected-resource metadata could not be verified at {metadata_url}: {type(exc).__name__}: {exc}",
            )
        )
        return {
            "verified": False,
            "protected_resource_metadata_url": metadata_url,
            "authorization_servers": [],
        }

    resource = metadata.get("resource")
    authorization_servers = metadata.get("authorization_servers")
    if not _is_https_url(resource):
        blockers.append(_finding("OA-AUTH-002", "Protected-resource metadata must advertise an HTTPS resource identifier."))
    if not isinstance(authorization_servers, list) or not authorization_servers:
        blockers.append(_finding("OA-AUTH-002", "Protected-resource metadata must advertise at least one authorization server."))
        authorization_servers = []
    elif any(not _is_https_url(value) for value in authorization_servers):
        blockers.append(_finding("OA-AUTH-002", "Authorization server identifiers must use HTTPS."))
        authorization_servers = [value for value in authorization_servers if _is_https_url(value)]

    resource_scopes = metadata.get("scopes_supported")
    if isinstance(resource_scopes, list) and all(isinstance(scope, str) for scope in resource_scopes):
        missing = sorted(required_scopes - set(resource_scopes))
        if missing:
            blockers.append(_finding("OA-AUTH-009", "Protected-resource metadata does not advertise required tool scopes: " + ", ".join(missing)))
        elif required_scopes:
            passed.append(_finding("OA-AUTH-009", "Protected-resource metadata advertises all OAuth scopes required by tools."))
    elif required_scopes:
        warnings.append(_finding("OA-AUTH-009", "Protected-resource metadata omits scopes_supported; scope explanation cannot be fully preflighted."))

    if _is_https_url(resource) and authorization_servers:
        passed.append(_finding("OA-AUTH-002", "OAuth protected-resource metadata is reachable and structurally valid."))

    auth_evidence = [
        _check_authorization_server(
            str(issuer),
            required_scopes=required_scopes,
            timeout=timeout,
            blockers=blockers,
            warnings=warnings,
            passed=passed,
        )
        for issuer in authorization_servers
    ]
    return {
        "verified": bool(auth_evidence) and all(bool(item.get("verified")) for item in auth_evidence),
        "protected_resource_metadata_url": metadata_url,
        "protected_resource_metadata": metadata,
        "authorization_servers": auth_evidence,
    }


def openai_plugin_readiness(
    server: MCPServer,
    *,
    timeout: float = 10.0,
    live: bool = True,
    bearer_token: str | None = None,
) -> dict[str, Any]:
    blockers: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    passed: list[dict[str, Any]] = []
    _check_transport(server, blockers, warnings, passed)

    probe: dict[str, Any] | None = None
    has_oauth = False
    oauth_scopes: set[str] = set()
    oauth_evidence: dict[str, Any] | None = None
    if live:
        try:
            probe = live_publication_probe(
                server,
                timeout=timeout,
                bearer_token=bearer_token,
            )
        except Exception as exc:
            clean_message = _redact_secret(str(exc), bearer_token)
            blockers.append(
                _finding(
                    "OA-SCAN-001",
                    f"Live MCP publication scan failed: {type(exc).__name__}: {clean_message}",
                )
            )
    if probe is not None:
        has_oauth, oauth_scopes = _check_tools(probe, blockers, warnings, passed)
        instructions = str(probe.get("instructions") or "")
        if len(instructions) > 512:
            warnings.append(_finding("OA-META-001", "Server instructions exceed 512 characters; keep the most important guidance first."))
        elif instructions:
            passed.append(_finding("OA-META-001", "Server instructions are present and concise."))
    if live and has_oauth:
        oauth_evidence = _check_oauth_metadata(
            server,
            required_scopes=oauth_scopes,
            timeout=timeout,
            blockers=blockers,
            warnings=warnings,
            passed=passed,
        )

    manual_remaining = [
        _finding("OA-MANUAL-001", "Verify the developer or business identity in the OpenAI Platform."),
        _finding("OA-MANUAL-002", "Prepare plugin name, descriptions, logo, category, website, support, privacy, and terms URLs."),
        _finding("OA-MANUAL-003", "Ensure the submitter has Apps Management Write permission."),
        _finding("OA-MANUAL-004", "Complete MCP domain verification via /.well-known/openai-apps-challenge when requested."),
        _finding("OA-MANUAL-005", "Prepare reviewer authentication/demo credentials when sign-in is required; never place them in Megas evidence files."),
        _finding("OA-MANUAL-006", "Prepare at least five positive and three negative test cases with expected behavior."),
        _finding("OA-MANUAL-007", "Prepare starter prompts, country/region availability, policy attestations, and release notes."),
        _finding("OA-MANUAL-008", "If OAuth metadata exposes neither CIMD nor DCR, configure and verify the predefined OAuth client used for the submission."),
    ]

    report: dict[str, Any] = {
        "target": TARGET,
        "server_id": server.id,
        "server": server.name,
        "transport": server.transport,
        "url": server.url,
        "technical_ready": not blockers,
        "blockers": blockers,
        "warnings": warnings,
        "passed": passed,
        "manual_remaining": manual_remaining,
        "live_probe": probe,
        "oauth": oauth_evidence,
        "oauth_required_scopes": sorted(oauth_scopes),
        "authenticated_scan": bool(bearer_token),
        "evidence_sha256": hashlib.sha256(
            json.dumps(
                {"probe": probe or {}, "oauth": oauth_evidence or {}},
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            ).encode("utf-8")
        ).hexdigest(),
    }
    clean_report = _redact_secret(report, bearer_token)
    assert isinstance(clean_report, dict)
    return clean_report


__all__ = [
    "TARGET",
    "live_publication_probe",
    "openai_plugin_readiness",
]
