from __future__ import annotations

from typing import Any

from .. import local_testing
from . import desktop_observability as observability


LOCAL_TESTING_SURFACE = "Local Testing"
LOCAL_TESTING_PRIMARY_SURFACES = (
    LOCAL_TESTING_SURFACE,
    "Agent",
    "Logs",
    "Tests",
    "Chitraagni Bridge",
    "Local Runtime",
)


def project_service_names(project: dict[str, Any]) -> list[str]:
    return [
        str(service.get("service") or "").strip()
        for service in project.get("services") or []
        if isinstance(service, dict) and str(service.get("service") or "").strip()
    ]


def project_open_urls(project: dict[str, Any]) -> list[str]:
    urls: list[str] = []
    seen: set[str] = set()
    for service in project.get("services") or []:
        if not isinstance(service, dict):
            continue
        for key in ("open_url", "health_url"):
            value = str(service.get(key) or "").strip()
            if value and value not in seen:
                seen.add(value)
                urls.append(value)
    return urls


def service_display_state(service: dict[str, Any]) -> str:
    if bool(service.get("ready")):
        return "ready"
    if bool(service.get("process_alive")):
        return "starting/degraded"
    return "stopped"


def service_ports_text(service: dict[str, Any]) -> str:
    values: list[str] = []
    for port in service.get("ports") or []:
        if not isinstance(port, dict) or port.get("port") is None:
            continue
        host = str(port.get("host") or "127.0.0.1")
        marker = "open" if port.get("open") else "closed"
        values.append(f"{host}:{port['port']} {marker}")
    return ", ".join(values)


def adb_device_display_state(device: dict[str, Any]) -> str:
    """Return a stable human-facing ADB state for the Windows Local Testing UI."""

    raw = str(device.get("state") or "").strip().lower()
    if bool(device.get("ready")) or raw == "device":
        return "Ready"
    if raw == "unauthorized":
        return "Authorization required"
    if raw == "offline":
        return "Offline"
    if raw == "bootloader":
        return "Bootloader"
    if raw == "recovery":
        return "Recovery"
    if not raw:
        return "Unknown"
    return raw.replace("-", " ").replace("_", " ").title()


def adb_device_state_tag(device: dict[str, Any]) -> str:
    """Return a bounded Treeview tag for dedicated ADB state treatment."""

    display = adb_device_display_state(device)
    if display == "Ready":
        return "adb-ready"
    if display == "Authorization required":
        return "adb-unauthorized"
    if display == "Offline":
        return "adb-offline"
    if display in {"Bootloader", "Recovery"}:
        return "adb-special"
    return "adb-other"


def service_target_rows(project: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for service in project.get("services") or []:
        if not isinstance(service, dict):
            continue
        name = str(service.get("service") or "").strip()
        if not name:
            continue
        rows.append(
            {
                "service": name,
                "state": service_display_state(service),
                "pid": service.get("pid"),
                "ports": service_ports_text(service),
                "open_url": str(service.get("open_url") or "").strip(),
                "health_url": str(service.get("health_url") or "").strip(),
            }
        )
    return rows


def project_target_rows(project: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for target in project.get("targets") or []:
        if not isinstance(target, dict) or not str(target.get("id") or "").strip():
            continue
        rows.append(
            {
                "id": str(target["id"]),
                "label": str(target.get("label") or target["id"]),
                "kind": str(target.get("kind") or "unknown"),
                "runtime": str(target.get("runtime") or ""),
                "build_label": str(target.get("build_label") or "Build target"),
                "open_label": str(target.get("open_label") or "Open / Run"),
                "evidence": str(target.get("evidence") or ""),
                "service": str(target.get("service") or "").strip() or None,
            }
        )
    return rows


class MegasMovesLocalTestingApp(observability.MegasDesktopObservabilityApp):
    """MegasMoves desktop led by multi-target local application testing."""

    def __init__(self, root: Any, controller: Any = None) -> None:
        observability.PRIMARY_SURFACES = LOCAL_TESTING_PRIMARY_SURFACES
        super().__init__(root, controller=controller)
        self.root.title("MegasMoves — Local Testing")
        self.show_surface(LOCAL_TESTING_SURFACE)

    def show_surface(self, surface: str) -> None:
        if surface != LOCAL_TESTING_SURFACE:
            super().show_surface(surface)
            return
        self.current_surface = surface
        self.surface_var.set(surface)
        self._set_nav(surface)
        self._clear()
        self._logs_refresh_hook = None
        try:
            self._render_local_testing()
            self.status_var.set("Ready — local testing")
        except Exception as exc:
            self._render_error(exc)

    def _render_local_testing(self) -> None:
        self._heading(
            "Local Testing",
            "One trusted repo can contain many runnable targets. Build and open websites, Windows apps and Android apps independently from the same project.",
        )

        holder = self.tk.Frame(self.content, bg=self.BG)
        holder.pack(fill="both", expand=True)

        def load() -> None:
            self._background("Refreshing local testing state…", local_testing.local_testing_snapshot, render)

        def render(snapshot: dict[str, Any]) -> None:
            for child in holder.winfo_children():
                child.destroy()

            workspace = snapshot.get("workspace") or {}
            adb = snapshot.get("adb") or {}
            projects = list(workspace.get("projects") or [])
            ready_devices = [row for row in adb.get("devices") or [] if isinstance(row, dict) and row.get("ready")]

            metrics = self.tk.Frame(holder, bg=self.BG)
            metrics.pack(fill="x", pady=(0, 14))
            self._metric_card(metrics, "Trusted projects", workspace.get("project_count", 0))
            self._metric_card(metrics, "Runnable targets", workspace.get("local_target_count", 0))
            self._metric_card(
                metrics,
                "Web / Windows / Android",
                f"{workspace.get('web_target_count', 0)} / {workspace.get('windows_target_count', 0)} / {workspace.get('android_target_count', 0)}",
            )
            self._metric_card(
                metrics,
                "ADB ready",
                f"{adb.get('ready_count', 0)}/{len(adb.get('devices') or [])}",
            )

            project_title = self.tk.Frame(holder, bg=self.BG)
            project_title.pack(fill="x", pady=(0, 6))
            self.tk.Label(
                project_title,
                text="Trusted repositories",
                bg=self.BG,
                fg=self.TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left")
            self.tk.Label(
                project_title,
                text="One repo may expose multiple independent opens",
                bg=self.BG,
                fg=self.MUTED,
                font=("Segoe UI", 9),
            ).pack(side="right")

            project_tree = self._tree(
                holder,
                [
                    ("project", "Project", 190),
                    ("state", "State", 145),
                    ("targets", "Targets", 90),
                    ("services", "Services", 210),
                    ("root", "Folder", 420),
                ],
            )
            mapping: dict[str, dict[str, Any]] = {}
            for index, project in enumerate(projects):
                iid = f"project-{index}"
                mapping[iid] = project
                services = project_service_names(project)
                project_tree.insert(
                    "",
                    "end",
                    iid=iid,
                    values=(
                        project.get("project") or "",
                        project.get("state") or "",
                        len(project.get("targets") or []),
                        ", ".join(services),
                        project.get("root") or "",
                    ),
                )

            target_title = self.tk.Frame(holder, bg=self.BG)
            target_title.pack(fill="x", pady=(12, 6))
            self.tk.Label(
                target_title,
                text="Runnable targets",
                bg=self.BG,
                fg=self.TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left")
            self.tk.Label(
                target_title,
                text="Browser · Windows process · real ADB-connected Android device",
                bg=self.BG,
                fg=self.MUTED,
                font=("Segoe UI", 9),
            ).pack(side="right")

            target_tree = self._tree(
                holder,
                [
                    ("target", "Target", 210),
                    ("type", "Type", 105),
                    ("runtime", "Runtime", 180),
                    ("open", "Open / Run", 180),
                    ("evidence", "Detected from", 330),
                ],
            )
            target_mapping: dict[str, dict[str, Any]] = {}

            service_title = self.tk.Frame(holder, bg=self.BG)
            service_title.pack(fill="x", pady=(12, 6))
            self.tk.Label(
                service_title,
                text="Runtime services",
                bg=self.BG,
                fg=self.TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left")
            self.tk.Label(
                service_title,
                text="PID, loopback ports, readiness and declared URLs",
                bg=self.BG,
                fg=self.MUTED,
                font=("Segoe UI", 9),
            ).pack(side="right")

            service_tree = self._tree(
                holder,
                [
                    ("service", "Service", 150),
                    ("state", "State", 140),
                    ("pid", "PID", 80),
                    ("ports", "Loopback ports", 220),
                    ("open_url", "Open URL", 240),
                    ("health_url", "Health URL", 240),
                ],
            )
            service_mapping: dict[str, str] = {}

            def selected_project() -> dict[str, Any]:
                selection = project_tree.selection()
                if not selection:
                    raise ValueError("select a project first")
                project = mapping.get(str(selection[0]))
                if project is None:
                    raise ValueError("selected project is unavailable")
                return project

            def populate_services(project: dict[str, Any]) -> None:
                for iid in service_tree.get_children():
                    service_tree.delete(iid)
                service_mapping.clear()
                for index, row in enumerate(service_target_rows(project)):
                    iid = f"service-{index}"
                    service_mapping[iid] = str(row["service"])
                    service_tree.insert(
                        "",
                        "end",
                        iid=iid,
                        values=(row["service"], row["state"], row["pid"] or "", row["ports"], row["open_url"], row["health_url"]),
                    )

            build_label_var = self.tk.StringVar(value="Build target")
            open_label_var = self.tk.StringVar(value="Open / Run")

            def populate_targets(project: dict[str, Any]) -> None:
                for iid in target_tree.get_children():
                    target_tree.delete(iid)
                target_mapping.clear()
                rows = project_target_rows(project)
                for index, row in enumerate(rows):
                    iid = f"target-{index}"
                    target_mapping[iid] = row
                    target_tree.insert(
                        "",
                        "end",
                        iid=iid,
                        values=(row["label"], row["kind"], row["runtime"], row["open_label"], row["evidence"]),
                    )
                if rows:
                    first = "target-0"
                    target_tree.selection_set(first)
                    target_tree.focus(first)
                    build_label_var.set(rows[0]["build_label"])
                    open_label_var.set(rows[0]["open_label"])
                else:
                    build_label_var.set("Build target")
                    open_label_var.set("Open / Run")

            def on_project_selected(_event: Any = None) -> None:
                try:
                    project = selected_project()
                except ValueError:
                    return
                populate_targets(project)
                populate_services(project)
                self.status_var.set(f"Selected {project.get('project') or 'project'}")

            def selected_target() -> dict[str, Any]:
                selection = target_tree.selection()
                if not selection:
                    raise ValueError("select a runnable target first")
                target = target_mapping.get(str(selection[0]))
                if target is None:
                    raise ValueError("selected target is unavailable")
                return target

            def on_target_selected(_event: Any = None) -> None:
                try:
                    target = selected_target()
                except ValueError:
                    return
                build_label_var.set(target["build_label"])
                open_label_var.set(target["open_label"])
                self.status_var.set(f"Selected {target['kind']} target · {target['label']}")

            project_tree.bind("<<TreeviewSelect>>", on_project_selected)
            target_tree.bind("<<TreeviewSelect>>", on_target_selected)

            device_header = self.tk.Frame(holder, bg=self.BG)
            device_header.pack(fill="x", pady=(12, 6))
            self.tk.Label(
                device_header,
                text="Android devices",
                bg=self.BG,
                fg=self.TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left")
            self.tk.Label(
                device_header,
                text=f"{adb.get('status') or 'unknown'} · {adb.get('ready_count', 0)} ready",
                bg=self.BG,
                fg=self.SUCCESS if adb.get("status") == "ready" else self.MUTED,
                font=("Segoe UI", 9, "bold"),
            ).pack(side="right")

            device_tree = self._tree(
                holder,
                [
                    ("serial", "Serial", 190),
                    ("state", "State", 120),
                    ("model", "Model", 190),
                    ("product", "Product", 190),
                    ("device", "Device", 170),
                ],
            )
            try:
                device_tree.tag_configure("adb-ready", foreground=self.SUCCESS)
                device_tree.tag_configure("adb-unauthorized", foreground=self.WARNING)
                device_tree.tag_configure("adb-offline", foreground=self.MUTED)
                device_tree.tag_configure("adb-special", foreground=self.DANGER)
            except Exception:
                pass

            device_mapping: dict[str, dict[str, Any]] = {}
            for index, device in enumerate(adb.get("devices") or []):
                iid = f"device-{index}"
                device_mapping[iid] = device
                device_tree.insert(
                    "",
                    "end",
                    iid=iid,
                    values=(
                        device.get("serial") or "",
                        adb_device_display_state(device),
                        device.get("model") or "",
                        device.get("product") or "",
                        device.get("device") or "",
                    ),
                    tags=(adb_device_state_tag(device),),
                )
            if len(ready_devices) == 1:
                for iid, row in device_mapping.items():
                    if row.get("ready"):
                        device_tree.selection_set(iid)
                        device_tree.focus(iid)
                        break

            controls = self.tk.Frame(holder, bg=self.BG)
            controls.pack(fill="x", pady=(9, 14))

            def selected_service() -> str | None:
                selection = service_tree.selection()
                if not selection:
                    return None
                return service_mapping.get(str(selection[0]))

            def selected_device_serial() -> str | None:
                selection = device_tree.selection()
                if selection:
                    device = device_mapping.get(str(selection[0]))
                    if device and device.get("ready"):
                        return str(device.get("serial") or "") or None
                    if device:
                        raise ValueError("selected Android device is not ready")
                if len(ready_devices) == 1:
                    return str(ready_devices[0].get("serial") or "") or None
                return None

            def run_project_action(action: str) -> None:
                project = selected_project()
                name = str(project.get("project") or "")
                service = selected_service() if action in {"check", "start", "stop", "restart"} else None
                label_target = f"{name}/{service}" if service else name
                self._background(
                    f"{action.title()} {label_target}…",
                    lambda: local_testing.workspace_action(action, name, service=service),
                    lambda result: action_done(action, label_target, result),
                )

            def action_done(action: str, label_target: str, result: Any) -> None:
                if action == "check":
                    self._show_result(f"{label_target} preflight", result)
                load()

            def run_target_action(action: str) -> None:
                project = selected_project()
                target = selected_target()
                name = str(project.get("project") or "")
                target_label = str(target.get("label") or target.get("id") or "target")
                if target.get("kind") == "web" and action == "build":
                    service = str(target.get("service") or "").strip()
                    if not service:
                        raise ValueError("web target has no declared service")
                    operation = lambda: local_testing.workspace_action("start", name, service=service)
                else:
                    serial = selected_device_serial() if target.get("kind") == "android" and action == "open" else None
                    operation = lambda: local_testing.project_target_action(
                        name,
                        str(target["id"]),
                        action,
                        device_serial=serial,
                    )

                def finished(result: Any) -> None:
                    if isinstance(result, dict) and result.get("ok") is False:
                        self._show_result(f"{name} · {target_label}", result)
                    elif action == "build":
                        self._show_result(f"{name} · {target_label} build", result)
                    load()

                self._background(
                    f"{target.get('build_label') if action == 'build' else target.get('open_label')} · {target_label}…",
                    operation,
                    finished,
                )

            def show_logs() -> None:
                project = selected_project()
                name = str(project.get("project") or "")
                services = project_service_names(project)
                if not services:
                    raise ValueError("selected project has no declared services")
                service = selected_service()
                if service is None and len(services) == 1:
                    service = services[0]
                if service is None:
                    service = str(
                        self.simpledialog.askstring(
                            "Service logs",
                            "Select a runtime service or enter one of:\n" + ", ".join(services),
                            parent=self.root,
                        )
                        or ""
                    ).strip()
                    if not service:
                        return
                    if service not in services:
                        raise ValueError("choose one of the declared services")
                self._background(
                    f"Reading {name}/{service} logs…",
                    lambda: local_testing.workspace_action("logs", name, service=service),
                    lambda result: self._show_result(f"{name} · {service} logs", result),
                )

            def add_folder() -> None:
                folder = self.filedialog.askdirectory(title="Trust local software folder")
                if not folder:
                    return
                if not self.messagebox.askyesno(
                    "Trust software folder",
                    "Add this folder to MegasMoves local testing? This creates machine-local trusted workspace configuration; it does not start the app.",
                    parent=self.root,
                ):
                    return
                self._background(
                    "Inspecting and adding software folder…",
                    lambda: local_testing.add_workspace_folder(folder),
                    lambda _result: load(),
                )

            self._button(controls, "Add folder", add_folder)
            build_button = self._secondary_button(controls, "Build target", lambda: run_target_action("build"))
            open_button = self._secondary_button(controls, "Open / Run", lambda: run_target_action("open"))
            try:
                build_button.configure(textvariable=build_label_var)
                open_button.configure(textvariable=open_label_var)
            except Exception:
                pass
            self._secondary_button(controls, "Check service", lambda: run_project_action("check"))
            self._secondary_button(controls, "Stop service", lambda: run_project_action("stop"))
            self._secondary_button(controls, "Restart service", lambda: run_project_action("restart"))
            self._secondary_button(controls, "Service logs", show_logs)
            self._secondary_button(controls, "Refresh", load)

            if projects:
                first = "project-0"
                project_tree.selection_set(first)
                project_tree.focus(first)
                populate_targets(mapping[first])
                populate_services(mapping[first])
            else:
                self.tk.Label(
                    holder,
                    text="No trusted software folders yet. Add a folder; MegasMoves will inspect repository evidence and refuse to invent a runnable command.",
                    bg=self.BG,
                    fg=self.MUTED,
                    font=("Segoe UI", 10),
                    wraplength=900,
                    justify="left",
                ).pack(anchor="w", pady=(0, 16))

            if not adb.get("available"):
                self.tk.Label(
                    holder,
                    text="ADB was not found. Web and Windows targets remain available; Android targets can still be built, but Run on device requires ADB.",
                    bg=self.BG,
                    fg=self.MUTED,
                    font=("Segoe UI", 9),
                ).pack(anchor="w", pady=(6, 0))
            elif adb.get("status") == "device-unauthorized":
                self.tk.Label(
                    holder,
                    text="An Android target is waiting for USB debugging authorization on the device.",
                    bg=self.BG,
                    fg=self.MUTED,
                    font=("Segoe UI", 9),
                ).pack(anchor="w", pady=(6, 0))
            elif adb.get("status") == "device-offline":
                self.tk.Label(
                    holder,
                    text="An Android target is offline. MegasMoves will not run an APK there until ADB reports device state.",
                    bg=self.BG,
                    fg=self.MUTED,
                    font=("Segoe UI", 9),
                ).pack(anchor="w", pady=(6, 0))

            self.status_var.set("Local testing state loaded")

        load()


__all__ = [
    "adb_device_display_state",
    "adb_device_state_tag",
    "LOCAL_TESTING_PRIMARY_SURFACES",
    "LOCAL_TESTING_SURFACE",
    "MegasMovesLocalTestingApp",
    "project_open_urls",
    "project_service_names",
    "project_target_rows",
    "service_display_state",
    "service_ports_text",
    "service_target_rows",
]
