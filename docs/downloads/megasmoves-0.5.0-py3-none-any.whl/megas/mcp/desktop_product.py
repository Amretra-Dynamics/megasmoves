from __future__ import annotations

from typing import Any, Callable
from urllib.parse import urlparse

from .. import local_testing
from ..operator_account import OperatorAccountStore
from .activity import build_activity_feed
from .desktop_local_testing import MegasMovesLocalTestingApp


# Product-facing navigation is intentionally narrow. The lower-level MCP registry
# remains available under Advanced, but it does not define the MegasMoves product.
PRODUCT_BRAND = "MEGAS"
PRODUCT_FONT = "Segoe UI"
PRODUCT_NAVIGATION = (
    "Local Testing",
    "Agent",
    "Logs",
    "Tests",
    "Chitraagni Bridge",
    "Local Runtime",
    "Devices / Sync",
    "Machine",
    "Settings / Export",
)
ADVANCED_SURFACES = (
    "Machine",
    "Servers",
    "Capabilities",
    "Permissions",
    "Sessions",
    "Tool Console",
    "Profiles",
    "Diagnostics",
    "Secrets",
    "History",
)


def classify_chitraagni_environment(api_base: str | None) -> str:
    """Return a human-facing Chitraagni environment label without contacting it."""

    value = str(api_base or "").strip()
    if not value:
        return "Not linked"
    try:
        hostname = (urlparse(value).hostname or "").lower()
    except ValueError:
        hostname = ""
    if hostname in {"127.0.0.1", "localhost", "::1"}:
        return "Local developer testing"
    return "Production / remote API"


ADVANCED_DESCRIPTIONS = {
    "Servers": "Registered MCP endpoints and lifecycle controls.",
    "Capabilities": "Protocol-reported tools, resources and prompts.",
    "Permissions": "Explicit local tool grants and capability authority.",
    "Sessions": "Recorded MCP sessions and correlated evidence.",
    "Tool Console": "Reviewed manual tool invocation for local debugging.",
    "Profiles": "Grouped runtime profiles and requirements.",
    "Diagnostics": "Health checks and runtime diagnostics.",
    "Secrets": "Secure binding metadata; secret values are never shown.",
    "History": "Bounded local control and runtime history.",
}


class MegasMovesProductApp(MegasMovesLocalTestingApp):
    """Complete MegasMoves.exe desktop surface over the shared local capability core."""

    def __init__(self, root: Any, controller: Any = None) -> None:
        super().__init__(root, controller=controller)

    def show_surface(self, surface: str) -> None:
        super().show_surface(surface)
        display_labels = {
            "Devices / Sync": "Devices",
            "Machine": "Advanced",
            "Settings / Export": "Settings",
        }
        self.surface_var.set(display_labels.get(surface, surface))

    def _build_style(self) -> None:
        # Preserve the established Windows typography. The UI work here is layout
        # and information-architecture work, not a new logo/font redesign.
        super()._build_style()
        style = self.ttk.Style(self.root)
        style.configure(
            "Megas.Treeview",
            rowheight=32,
            font=(PRODUCT_FONT, 9),
        )
        style.configure(
            "Megas.Treeview.Heading",
            font=(PRODUCT_FONT, 9, "bold"),
            padding=(8, 8),
        )
        style.configure(
            "Megas.TCombobox",
            font=(PRODUCT_FONT, 9),
        )

    def _build_shell(self) -> None:
        self.root.title("MegasMoves — Local Testing")
        self.root.geometry("1380x860")
        self.root.minsize(1040, 680)
        self.root.configure(bg=self.BG)

        shell = self.tk.Frame(self.root, bg=self.BG)
        shell.pack(fill="both", expand=True)

        sidebar = self.tk.Frame(
            shell,
            bg=self.PANEL,
            width=238,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand = self.tk.Frame(sidebar, bg=self.PANEL)
        brand.pack(fill="x", padx=20, pady=(22, 16))
        # Keep the original text mark. Do not synthesize or substitute a fake logo.
        self.tk.Label(
            brand,
            text=PRODUCT_BRAND,
            bg=self.PANEL,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 18, "bold"),
        ).pack(anchor="w")
        self.tk.Label(
            brand,
            text="Local testing & runtime",
            bg=self.PANEL,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
        ).pack(anchor="w", pady=(2, 0))

        self.nav_buttons: dict[str, Any] = {}
        display_labels = {
            "Devices / Sync": "Devices",
            "Machine": "Advanced",
            "Settings / Export": "Settings",
        }
        for surface in PRODUCT_NAVIGATION:
            button = self.tk.Button(
                sidebar,
                text=display_labels.get(surface, surface),
                anchor="w",
                relief="flat",
                borderwidth=0,
                bg=self.PANEL,
                fg=self.TEXT,
                activebackground="#E7F3F4",
                activeforeground=self.TEXT,
                padx=18,
                pady=8,
                font=(PRODUCT_FONT, 10),
                command=lambda value=surface: self.show_surface(value),
            )
            button.pack(fill="x", padx=8, pady=1)
            self.nav_buttons[surface] = button

        trust = self.tk.Frame(sidebar, bg=self.PANEL)
        trust.pack(side="bottom", fill="x", padx=18, pady=18)
        self.tk.Label(
            trust,
            text="LOCAL / TRUSTED",
            bg=self.PANEL,
            fg=self.SUCCESS,
            font=(PRODUCT_FONT, 9, "bold"),
        ).pack(anchor="w")
        self.tk.Label(
            trust,
            text="Megas MCP embedded",
            bg=self.PANEL,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 8),
        ).pack(anchor="w", pady=(2, 0))

        main = self.tk.Frame(shell, bg=self.BG)
        main.pack(side="left", fill="both", expand=True)

        header = self.tk.Frame(
            main,
            bg=self.BG,
            height=76,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        header.pack(fill="x")
        header.pack_propagate(False)
        self.tk.Label(
            header,
            textvariable=self.surface_var,
            bg=self.BG,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 18, "bold"),
        ).pack(side="left", padx=28)

        state = self.tk.Frame(header, bg=self.BG)
        state.pack(side="right", padx=26)
        self.tk.Label(
            state,
            text="LOCAL MACHINE",
            bg=self.BG,
            fg=self.SUCCESS,
            font=(PRODUCT_FONT, 8, "bold"),
        ).pack(anchor="e")
        self.tk.Label(
            state,
            text="Folder trust stays human-controlled",
            bg=self.BG,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
        ).pack(anchor="e", pady=(2, 0))

        self.content = self.tk.Frame(main, bg=self.BG)
        self.content.pack(fill="both", expand=True, padx=28, pady=22)

        status = self.tk.Frame(
            main,
            bg=self.PANEL,
            height=32,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        status.pack(fill="x", side="bottom")
        status.pack_propagate(False)
        self.tk.Label(
            status,
            textvariable=self.status_var,
            bg=self.PANEL,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
        ).pack(side="left", padx=14)

    def _set_nav(self, surface: str) -> None:
        active_surface = "Machine" if surface in ADVANCED_SURFACES else surface
        for name, button in self.nav_buttons.items():
            active = name == active_surface
            button.configure(
                bg="#DDF4F5" if active else self.PANEL,
                fg=self.PRIMARY_DARK if active else self.TEXT,
                font=(PRODUCT_FONT, 10, "bold" if active else "normal"),
            )

    def _heading(self, title: str, subtitle: str = "") -> Any:
        frame = self.tk.Frame(self.content, bg=self.BG)
        frame.pack(fill="x", pady=(0, 16))
        self.tk.Label(
            frame,
            text=title,
            bg=self.BG,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 16, "bold"),
        ).pack(anchor="w")
        if subtitle:
            self.tk.Label(
                frame,
                text=subtitle,
                bg=self.BG,
                fg=self.MUTED,
                font=(PRODUCT_FONT, 10),
                wraplength=980,
                justify="left",
            ).pack(anchor="w", pady=(5, 0))
        return frame

    def _metric_card(self, parent: Any, label: str, value: Any) -> None:
        card = self.tk.Frame(
            parent,
            bg="#FBFCFC",
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        card.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.tk.Label(
            card,
            text=str(value),
            bg="#FBFCFC",
            fg=self.TEXT,
            font=(PRODUCT_FONT, 21, "bold"),
        ).pack(anchor="w", padx=16, pady=(14, 2))
        self.tk.Label(
            card,
            text=label,
            bg="#FBFCFC",
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
        ).pack(anchor="w", padx=16, pady=(0, 13))

    def _button(
        self,
        parent: Any,
        text: str,
        command: Callable[[], None],
        *,
        destructive: bool = False,
    ) -> Any:
        button = self.tk.Button(
            parent,
            text=text,
            command=command,
            bg=self.DANGER if destructive else self.PRIMARY,
            fg="white",
            activebackground=self.DANGER if destructive else self.PRIMARY_DARK,
            activeforeground="white",
            relief="flat",
            borderwidth=0,
            padx=15,
            pady=8,
            font=(PRODUCT_FONT, 9, "bold"),
            cursor="hand2",
        )
        button.pack(side="left", padx=(0, 8))
        return button

    def _secondary_button(
        self,
        parent: Any,
        text: str,
        command: Callable[[], None],
    ) -> Any:
        button = self.tk.Button(
            parent,
            text=text,
            command=command,
            bg=self.BG,
            fg=self.TEXT,
            activebackground=self.PANEL,
            activeforeground=self.TEXT,
            relief="solid",
            borderwidth=1,
            highlightbackground=self.BORDER,
            padx=13,
            pady=7,
            font=(PRODUCT_FONT, 9),
            cursor="hand2",
        )
        button.pack(side="left", padx=(0, 8))
        return button

    def _render_machine(self) -> None:
        self._heading(
            "Advanced",
            "Supporting MCP registry and diagnostic tools stay available here without competing with the primary Local Testing workflow.",
        )
        snapshot = self.controller.machine()
        summary = self.tk.Frame(
            self.content,
            bg=self.PANEL,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        summary.pack(fill="x", pady=(0, 16))
        self.tk.Label(
            summary,
            text="Shared local capability core",
            bg=self.PANEL,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 11, "bold"),
        ).pack(anchor="w", padx=16, pady=(14, 4))
        self.tk.Label(
            summary,
            text=(
                f"{snapshot.get('configured_servers', 0)} registered runtime(s) · "
                f"{snapshot.get('tool_permissions', 0)} tool grant(s) · "
                f"{snapshot.get('secret_bindings', 0)} secure binding(s)"
            ),
            bg=self.PANEL,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
        ).pack(anchor="w", padx=16, pady=(0, 14))

        grid = self.tk.Frame(self.content, bg=self.BG)
        grid.pack(fill="both", expand=True)
        surfaces = tuple(value for value in ADVANCED_SURFACES if value != "Machine")
        for index, surface in enumerate(surfaces):
            card = self.tk.Frame(
                grid,
                bg=self.BG,
                highlightbackground=self.BORDER,
                highlightthickness=1,
            )
            row = index // 2
            column = index % 2
            card.grid(
                row=row,
                column=column,
                sticky="nsew",
                padx=(0, 10) if column == 0 else (10, 0),
                pady=(0, 12),
            )
            grid.grid_columnconfigure(column, weight=1)
            self.tk.Label(
                card,
                text=surface,
                bg=self.BG,
                fg=self.TEXT,
                font=(PRODUCT_FONT, 11, "bold"),
            ).pack(anchor="w", padx=14, pady=(12, 3))
            self.tk.Label(
                card,
                text=ADVANCED_DESCRIPTIONS.get(surface, ""),
                bg=self.BG,
                fg=self.MUTED,
                font=(PRODUCT_FONT, 9),
                wraplength=430,
                justify="left",
            ).pack(anchor="w", padx=14, pady=(0, 10))
            self._secondary_button(
                card,
                f"Open {surface}",
                lambda value=surface: self.show_surface(value),
            )

    def _render_chitraagni_bridge(self) -> None:
        self._heading(
            "Chitraagni Bridge",
            "Megas uses Chitraagni's authenticated API boundary. Loopback is the developer-only local test state; production remains separate hosted Chitraagni infrastructure.",
        )
        account = OperatorAccountStore()
        status = account.status(verify=False)
        environment = classify_chitraagni_environment(status.get("api_base"))

        summary = self.tk.Frame(
            self.content,
            bg=self.PANEL,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        summary.pack(fill="x", pady=(0, 12))
        values = [
            ("Environment", environment),
            ("Linked", "Yes" if status.get("chitraagni_linked") else "No"),
            ("API", status.get("api_base") or "Not linked"),
            ("Credential", status.get("credential_kind") or "None"),
            ("Credential available", "Yes" if status.get("token_available") else "No"),
        ]
        for label, value in values:
            row = self.tk.Frame(summary, bg=self.PANEL)
            row.pack(fill="x", padx=14, pady=5)
            self.tk.Label(
                row,
                text=label,
                width=22,
                anchor="w",
                bg=self.PANEL,
                fg=self.MUTED,
                font=(PRODUCT_FONT, 9),
            ).pack(side="left")
            value_color = (
                self.SUCCESS
                if label == "Environment" and environment == "Local developer testing"
                else self.TEXT
            )
            self.tk.Label(
                row,
                text=str(value),
                anchor="w",
                bg=self.PANEL,
                fg=value_color,
                font=(PRODUCT_FONT, 9, "bold"),
            ).pack(side="left", fill="x", expand=True)

        if environment == "Local developer testing":
            note = (
                "Developer mode: this loopback Chitraagni state exists only for local product testing. "
                "It does not replace or mirror production hosting automatically."
            )
        elif environment == "Production / remote API":
            note = (
                "Remote mode: this installation is pointed at hosted Chitraagni. "
                "Megas still enforces the locally linked identity and capability grants."
            )
        else:
            note = (
                "No Chitraagni account/API is linked. Local MegasMoves testing remains available independently."
            )
        self.tk.Label(
            self.content,
            text=note,
            bg=self.BG,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
            wraplength=980,
            justify="left",
        ).pack(anchor="w", pady=(0, 12))

        controls = self.tk.Frame(self.content, bg=self.BG)
        controls.pack(fill="x", pady=(0, 10))
        if status.get("chitraagni_linked"):
            self._button(
                controls,
                "Verify identity",
                lambda: self._background(
                    "Verifying linked Chitraagni identity…",
                    lambda: account.status(verify=True),
                    lambda result: self._show_result("Chitraagni identity", result),
                ),
            )
        self._secondary_button(
            controls,
            "Refresh",
            lambda: self.show_surface("Chitraagni Bridge"),
        )

        rows = build_activity_feed(
            self.controller.core.store,
            self.controller.core.timeline,
            limit=150,
            sources={"Chitraagni"},
        )
        self.tk.Label(
            self.content,
            text="Recent Chitraagni operations",
            bg=self.BG,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 11, "bold"),
        ).pack(anchor="w", pady=(6, 6))
        if rows:
            self._activity_table(self.content, rows, detail_height=8)
        else:
            self.tk.Label(
                self.content,
                text="No Chitraagni operations have been observed in the local Megas timeline yet.",
                bg=self.BG,
                fg=self.MUTED,
                font=(PRODUCT_FONT, 10),
            ).pack(anchor="w", pady=8)

    def _render_settings(self) -> None:
        data = self.controller.settings()
        preferences = local_testing.local_testing_settings()
        self._heading(
            "Settings",
            "Local-testing behavior stays machine-local. Multiple concurrent runs are opt-in so MegasMoves keeps normal CPU, RAM and device load low by default.",
        )

        testing = self.tk.Frame(
            self.content,
            bg=self.PANEL,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        testing.pack(fill="x", pady=(0, 14))
        self.tk.Label(
            testing,
            text="Local Testing",
            bg=self.PANEL,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 11, "bold"),
        ).pack(anchor="w", padx=14, pady=(12, 4))

        allow_multiple = self.tk.BooleanVar(
            value=bool(preferences.get("allow_multiple_local_runs", False))
        )

        def save_multiple_runs() -> None:
            saved = local_testing.set_allow_multiple_local_runs(bool(allow_multiple.get()))
            if saved["allow_multiple_local_runs"]:
                self.status_var.set("Multiple local runs enabled — auto-stop disabled")
            else:
                self.status_var.set("Single local run enabled — previous Megas-owned run auto-stops")

        self.tk.Checkbutton(
            testing,
            text="Allow multiple local runs at the same time",
            variable=allow_multiple,
            command=save_multiple_runs,
            bg=self.PANEL,
            fg=self.TEXT,
            activebackground=self.PANEL,
            activeforeground=self.TEXT,
            selectcolor=self.BG,
            anchor="w",
            font=(PRODUCT_FONT, 10, "bold"),
        ).pack(anchor="w", padx=14, pady=(6, 2))
        self.tk.Label(
            testing,
            text=(
                "Off by default. When off, starting another local test session auto-stops the previous "
                "MegasMoves-managed run. Turn it on when you intentionally want several local apps/services "
                "running together."
            ),
            bg=self.PANEL,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
            wraplength=920,
            justify="left",
        ).pack(anchor="w", padx=34, pady=(0, 12))

        info = self.tk.Frame(
            self.content,
            bg=self.PANEL,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        info.pack(fill="x", pady=(0, 14))
        self.tk.Label(
            info,
            text=f"Local home: {data['home']}",
            bg=self.PANEL,
            fg=self.TEXT,
            font=(PRODUCT_FONT, 10, "bold"),
        ).pack(anchor="w", padx=14, pady=(12, 4))
        self.tk.Label(
            info,
            text=f"Unresolved imported secret bindings: {len(data['rebinding_requirements'])}",
            bg=self.PANEL,
            fg=self.MUTED,
            font=(PRODUCT_FONT, 9),
        ).pack(anchor="w", padx=14, pady=(0, 12))

        actions = self.tk.Frame(self.content, bg=self.BG)
        actions.pack(fill="x")
        self._button(actions, "Export workspace", self._export_workspace)
        self._secondary_button(actions, "Import dry-run", lambda: self._import_workspace(dry_run=True))
        self._secondary_button(actions, "Import and apply", lambda: self._import_workspace(dry_run=False))
        self._json_text(
            self.content,
            {"rebinding_requirements": data["rebinding_requirements"]},
            height=10,
        )

    def _render_devices(self) -> None:
        self._heading(
            "Android devices",
            "USB and wireless ADB are the same deployment target once the device is authorized. Wireless pairing is human-initiated and restricted to private/local network addresses.",
        )
        holder = self.tk.Frame(self.content, bg=self.BG)
        holder.pack(fill="both", expand=True)

        def load() -> None:
            self._background("Refreshing Android devices…", local_testing.adb_snapshot, render)

        def render(snapshot: dict[str, Any]) -> None:
            for child in holder.winfo_children():
                child.destroy()

            status = self.tk.Frame(
                holder,
                bg=self.PANEL,
                highlightbackground=self.BORDER,
                highlightthickness=1,
            )
            status.pack(fill="x", pady=(0, 12))
            self.tk.Label(
                status,
                text=f"ADB: {snapshot.get('status') or 'unknown'}",
                bg=self.PANEL,
                fg=self.SUCCESS if snapshot.get("status") == "ready" else self.TEXT,
                font=(PRODUCT_FONT, 11, "bold"),
            ).pack(side="left", padx=14, pady=12)
            self.tk.Label(
                status,
                text=f"{snapshot.get('ready_count', 0)} ready",
                bg=self.PANEL,
                fg=self.MUTED,
                font=(PRODUCT_FONT, 9),
            ).pack(side="right", padx=14, pady=12)

            tree = self._tree(
                holder,
                [
                    ("serial", "Device", 230),
                    ("connection", "Connection", 120),
                    ("state", "ADB state", 120),
                    ("model", "Model", 210),
                    ("product", "Product", 190),
                ],
            )
            for index, device in enumerate(snapshot.get("devices") or []):
                if not isinstance(device, dict):
                    continue
                connection = str(device.get("transport") or "unknown")
                tree.insert(
                    "",
                    "end",
                    iid=f"device-{index}",
                    values=(
                        device.get("serial") or "",
                        connection.title(),
                        device.get("state") or "",
                        device.get("model") or "",
                        device.get("product") or "",
                    ),
                )

            controls = self.tk.Frame(holder, bg=self.BG)
            controls.pack(fill="x", pady=(10, 0))

            def pair_wireless() -> None:
                endpoint = self.simpledialog.askstring(
                    "Pair Android device",
                    "Pairing address shown under Wireless debugging → Pair device with pairing code (IP:port):",
                    parent=self.root,
                )
                if not endpoint:
                    return
                code = self.simpledialog.askstring(
                    "Pair Android device",
                    "Six-digit pairing code shown on the phone:",
                    parent=self.root,
                )
                if not code:
                    return

                def done(result: dict[str, Any]) -> None:
                    if not result.get("ok"):
                        self._show_result("Wireless ADB pairing", result)
                    load()

                self._background(
                    "Pairing Android device…",
                    lambda: local_testing.adb_pair_wireless(endpoint, code),
                    done,
                )

            def connect_wireless() -> None:
                endpoint = self.simpledialog.askstring(
                    "Connect Android device",
                    "Connection address shown under Wireless debugging (IP:port):",
                    parent=self.root,
                )
                if not endpoint:
                    return

                def done(result: dict[str, Any]) -> None:
                    if not result.get("ok"):
                        self._show_result("Wireless ADB connection", result)
                    load()

                self._background(
                    "Connecting Android device…",
                    lambda: local_testing.adb_connect_wireless(endpoint),
                    done,
                )

            self._button(controls, "Pair wireless device", pair_wireless)
            self._secondary_button(controls, "Connect paired device", connect_wireless)
            self._secondary_button(controls, "Refresh", load)

            if not snapshot.get("available"):
                self.tk.Label(
                    holder,
                    text="ADB is not installed or discoverable yet. Web and Windows local testing remain available.",
                    bg=self.BG,
                    fg=self.MUTED,
                    font=(PRODUCT_FONT, 9),
                ).pack(anchor="w", pady=(12, 0))
            elif snapshot.get("status") == "device-unauthorized":
                self.tk.Label(
                    holder,
                    text="Authorization is waiting on the phone. Approve the computer in the Android debugging prompt, then refresh.",
                    bg=self.BG,
                    fg=self.WARNING,
                    font=(PRODUCT_FONT, 9),
                ).pack(anchor="w", pady=(12, 0))

            self.status_var.set("Android device state loaded")

        load()


__all__ = [
    "ADVANCED_SURFACES",
    "MegasMovesProductApp",
    "classify_chitraagni_environment",
    "PRODUCT_BRAND",
    "PRODUCT_FONT",
    "PRODUCT_NAVIGATION",
]
