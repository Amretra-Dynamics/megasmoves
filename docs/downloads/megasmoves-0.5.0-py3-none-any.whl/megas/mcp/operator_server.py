from __future__ import annotations

import json
import os
import sys
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, TextIO
from urllib.parse import quote, unquote, urlsplit

from megas.chitraagni_operator_context import AccountChitraagniOperatorCatalog
from megas.operator_account import OperatorAccountStore
from megas.firebase_account import token_request_scope

from .workspace_server import WorkspaceCapabilityCatalog


SERVER_VERSION = "0.5.0"
MODERN_PROTOCOL = "2026-07-28"
LEGACY_PROTOCOLS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")
SUPPORTED_PROTOCOLS = (MODERN_PROTOCOL, *LEGACY_PROTOCOLS)
PROTOCOL_META_KEY = "io.modelcontextprotocol/protocolVersion"
CLIENT_CAPABILITIES_META_KEY = "io.modelcontextprotocol/clientCapabilities"
CLIENT_INFO_META_KEY = "io.modelcontextprotocol/clientInfo"
SERVER_INFO_META_KEY = "io.modelcontextprotocol/serverInfo"
PRIVATE_CACHE_TTL_MS = 2_000
REMOTE_NOTIFICATION_TYPES = frozenset(
    {
        "approval_required",
        "task_completed",
        "task_failed",
        "test_suite_failed",
        "agent_unexpectedly_stopped",
        "machine_disconnected",
        "production_action_requested",
        "publish_completed",
    }
)


def _server_info() -> dict[str, str]:
    return {"name": "MegasMCP", "version": SERVER_VERSION}


def _error(code: int, message: str, data: Any | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        payload["data"] = data
    return payload


def _response(request_id: Any, *, result: Any = None, error: Any = None) -> dict[str, Any]:
    payload: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id}
    if error is None:
        payload["result"] = result
    else:
        payload["error"] = error
    return payload


def _modern_request_meta(params: dict[str, Any], *, required: bool = False) -> dict[str, Any] | None:
    raw = params.get("_meta")
    if raw is None:
        if required:
            raise ValueError("modern MCP request requires params._meta")
        return None
    if not isinstance(raw, dict):
        raise ValueError("MCP params._meta must be an object")
    version = raw.get(PROTOCOL_META_KEY)
    if version is None:
        if required:
            raise ValueError(f"modern MCP request is missing _meta[{PROTOCOL_META_KEY!r}]")
        return None
    if str(version) != MODERN_PROTOCOL:
        raise ValueError(f"unsupported modern MCP protocol version: {version}")
    capabilities = raw.get(CLIENT_CAPABILITIES_META_KEY)
    if not isinstance(capabilities, dict):
        raise ValueError(
            f"modern MCP request requires _meta[{CLIENT_CAPABILITIES_META_KEY!r}] as an object"
        )
    client_info = raw.get(CLIENT_INFO_META_KEY)
    if client_info is not None and not isinstance(client_info, dict):
        raise ValueError(f"_meta[{CLIENT_INFO_META_KEY!r}] must be an object when supplied")
    return raw


def _modern_result(
    value: dict[str, Any] | None,
    *,
    cache_private: bool = False,
    ttl_ms: int = PRIVATE_CACHE_TTL_MS,
) -> dict[str, Any]:
    result = dict(value or {})
    result["resultType"] = "complete"
    meta = result.get("_meta")
    if not isinstance(meta, dict):
        meta = {}
    meta[SERVER_INFO_META_KEY] = _server_info()
    result["_meta"] = meta
    if cache_private:
        result["ttlMs"] = max(0, int(ttl_ms))
        result["cacheScope"] = "private"
    return result


def _status_tool() -> dict[str, Any]:
    return {
        "name": "operator_status",
        "title": "Operator Status",
        "description": "Show which MegasMoves local capabilities and Chitraagni user account are available to MegasMCP. Never returns credential values.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        "annotations": {
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        },
    }


def _windows_screen_read_tool() -> dict[str, Any]:
    return {
        "name": "windows_screen_read",
        "title": "Windows Screen Read",
        "description": (
            "Read the current foreground Windows app through UI Automation, with Windows-native OCR fallback when accessibility text is empty. "
            "Returns bounded visible text and active-window identity without clicking or typing."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "max_nodes": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 500,
                    "default": 240,
                    "description": "Maximum accessibility nodes to inspect.",
                },
                "max_chars": {
                    "type": "integer",
                    "minimum": 256,
                    "maximum": 24000,
                    "default": 12000,
                    "description": "Maximum visible-text characters to return.",
                },
            },
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        },
    }



def _windows_screen_capture_tool() -> dict[str, Any]:
    return {
        "name": "windows_screen_capture",
        "title": "Windows Screen Capture",
        "description": (
            "Capture bounded PNG evidence of the current foreground Windows app. "
            "Read-only; refuses locked sessions, secure desktop and UAC."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "max_width": {
                    "type": "integer",
                    "minimum": 320,
                    "maximum": 1600,
                    "default": 1024,
                    "description": "Maximum capture width in pixels.",
                },
                "max_height": {
                    "type": "integer",
                    "minimum": 240,
                    "maximum": 1200,
                    "default": 768,
                    "description": "Maximum capture height in pixels.",
                },
            },
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        },
    }



def _windows_screen_goal_read_tool() -> dict[str, Any]:
    return {
        "name": "windows_screen_goal_read",
        "title": "Windows Target Screen Read",
        "description": (
            "Read a specific visible Windows application. If the wrong app is foreground, "
            "Megas may locate one unique matching window, focus it, verify foreground identity, "
            "then reuse the bounded UIA/OCR reader. Recovery is limited to two attempts."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "target": {
                    "type": "object",
                    "properties": {
                        "title_contains": {
                            "type": "string",
                            "maxLength": 128,
                            "description": "Case-insensitive substring required in the window title.",
                        },
                        "executable": {
                            "type": "string",
                            "maxLength": 128,
                            "description": "Exact executable basename such as Codex.exe.",
                        },
                    },
                    "additionalProperties": False,
                },
                "max_nodes": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 500,
                    "default": 240,
                },
                "max_chars": {
                    "type": "integer",
                    "minimum": 256,
                    "maximum": 24000,
                    "default": 12000,
                },
            },
            "required": ["target"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": False,
            "destructiveHint": False,
            "openWorldHint": False,
            "idempotentHint": True,
        },
    }


def _notify_user_tool() -> dict[str, Any]:
    return {
        "name": "notify_user",
        "title": "Notify User",
        "description": "Request a high-signal notification to the signed-in Android app over Megas' authenticated direct peer transport. This tool reports not_delivered unless a real peer transport accepts it; local history is never represented as phone delivery. It does not use a website, cloud relay, FCM, ADB, Bluetooth, or a system VPN.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Short label kept in local notification history; Android shows its privacy-safe event category.",
                    "maxLength": 120,
                },
                "message": {
                    "type": "string",
                    "description": "Notification text sent only over the authenticated direct peer channel when one is active.",
                    "maxLength": 2000,
                },
                "level": {
                    "type": "string",
                    "description": "Severity level: 'info', 'success', 'warning', 'error'.",
                    "enum": ["info", "success", "warning", "error"],
                },
                "event_type": {
                    "type": "string",
                    "description": "Privacy-safe event category delivered to the Android app.",
                    "enum": sorted(REMOTE_NOTIFICATION_TYPES),
                },
            },
            "required": ["message"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": False,
            "destructiveHint": False,
            "openWorldHint": False,
        },
    }


def _terminal_tools() -> list[dict[str, Any]]:
    return [
        {
            "name": "terminal_list_sessions",
            "title": "Terminal List Sessions",
            "description": "List all active and recent terminal sessions running on this machine via MegasMoves.",
            "inputSchema": {
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": True,
                "destructiveHint": False,
                "openWorldHint": False,
            },
        },
        {
            "name": "terminal_create_session",
            "title": "Terminal Create Session",
            "description": "Spawn a new background terminal session on the local host with unbounded streaming stdout/stderr.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "command": {
                        "description": "Command string or list of argument strings to execute.",
                        "oneOf": [
                            {"type": "string"},
                            {"type": "array", "items": {"type": "string"}},
                        ],
                    },
                    "cwd": {
                        "type": "string",
                        "description": "Working directory for the process. Optional.",
                    },
                    "title": {
                        "type": "string",
                        "description": "Human-readable label for the terminal session. Optional.",
                    },
                    "env": {
                        "type": "object",
                        "description": "Optional environment variables for the process.",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": ["command"],
                "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": False,
                "destructiveHint": False,
                "openWorldHint": False,
            },
        },
        {
            "name": "terminal_read_output",
            "title": "Terminal Read Output",
            "description": "Read sequence-tracked output events (stdout, stderr, system) from an active or completed terminal session.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "session_id": {
                        "type": "string",
                        "description": "Terminal session identifier (e.g. term_...).",
                    },
                    "after_seq": {
                        "type": "integer",
                        "description": "Read events strictly after this sequence number (-1 to read from start). Default -1.",
                        "default": -1,
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of events to return. Default 200.",
                        "default": 200,
                    },
                },
                "required": ["session_id"],
                "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": True,
                "destructiveHint": False,
                "openWorldHint": False,
            },
        },
        {
            "name": "terminal_send_input",
            "title": "Terminal Send Input",
            "description": "Send text or commands to stdin of a running terminal session.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "session_id": {
                        "type": "string",
                        "description": "Terminal session identifier.",
                    },
                    "text": {
                        "type": "string",
                        "description": "Text to write to the terminal session's standard input.",
                    },
                },
                "required": ["session_id", "text"],
                "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": False,
                "destructiveHint": False,
                "openWorldHint": False,
            },
        },
        {
            "name": "terminal_terminate_session",
            "title": "Terminal Terminate Session",
            "description": "Terminate a running terminal session process.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "session_id": {
                        "type": "string",
                        "description": "Terminal session identifier.",
                    },
                },
                "required": ["session_id"],
                "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": False,
                "destructiveHint": True,
                "openWorldHint": False,
            },
        },
    ]


def _resource(uri: str, name: str, description: str) -> dict[str, Any]:
    return {"uri": uri, "name": name, "description": description, "mimeType": "application/json"}


def _resource_text(uri: str, value: Any) -> dict[str, Any]:
    return {
        "contents": [
            {
                "uri": uri,
                "mimeType": "application/json",
                "text": json.dumps(value, sort_keys=True, ensure_ascii=False, default=str),
            }
        ]
    }


@dataclass(slots=True)
class OperatorCapabilityCatalog:
    account_store: OperatorAccountStore = field(default_factory=OperatorAccountStore)
    workspace: WorkspaceCapabilityCatalog = field(default_factory=WorkspaceCapabilityCatalog)

    def __post_init__(self) -> None:
        # The local MCP process is the Windows peer endpoint. Start it from
        # the Firebase identity already stored by Megas CLI; no Account-site
        # login or remote rendezvous service is needed.
        self._direct_peer_status()

    def _direct_peer_status(self) -> dict[str, Any]:
        from megas.local.peer_mesh.identity import PeerPairingRequired
        try:
            from megas.local.peer_mesh.controller import (
                current_peer_mesh,
                start_peer_mesh,
                stop_peer_mesh,
            )
            from megas.firebase_account import current_token
            from megas.local.peer_mesh.auth import firebase_uid_from_local_token

            token = current_token()
            if not token:
                stop_peer_mesh()
                return {
                    "status": "not_connected",
                    "started": False,
                    "account_authenticated": False,
                    "direct_peer_count": 0,
                    "route": "direct_webrtc_only",
                    "relay_configured": False,
                    "vpn_service": False,
                    "state": "firebase_auth_required",
                }
            firebase_uid = firebase_uid_from_local_token(token, require_fresh_token=True)

            controller = current_peer_mesh()
            if controller is not None and controller.matches_subject(firebase_uid):
                status = controller.status
                status["local_firebase_identity_verified"] = True
                status["status"] = (
                    "connected"
                    if status.get("direct_peer_count", 0) > 0
                    else "discovering"
                    if status.get("started")
                    else "not_connected"
                )
                return status

            if controller is not None:
                stop_peer_mesh()
            controller = start_peer_mesh(firebase_uid)
            status = controller.status
            status["local_firebase_identity_verified"] = True
            status["status"] = (
                "connected"
                if status.get("direct_peer_count", 0) > 0
                else "discovering"
                if status.get("started")
                else "not_connected"
            )
            return status
        except Exception as exc:
            return {
                "status": "not_connected",
                "started": False,
                "account_authenticated": False,
                "direct_peer_count": 0,
                "route": "direct_webrtc_only",
                "relay_configured": False,
                "vpn_service": False,
                "state": "secure_device_pairing_required" if isinstance(exc, PeerPairingRequired) else "firebase_credential_unavailable",
                "error_type": type(exc).__name__,
            }

    def _chitraagni_catalog(self, *, require_verified: bool) -> AccountChitraagniOperatorCatalog | None:
        binding = self.account_store.load().chitraagni
        if binding is None:
            return None
        if require_verified:
            binding.verify_current_identity()
        return AccountChitraagniOperatorCatalog(binding)

    @token_request_scope()
    def status(self) -> dict[str, Any]:
        from megas.firebase_account import status as firebase_status
        value = self.account_store.status(verify=False)
        value["firebase_account"] = firebase_status()
        value["direct_peer"] = self._direct_peer_status()
        value["megas_moves"] = {
            "available": True,
            "workspace_tools": [tool["name"] for tool in self.workspace.tools()],
        }
        if value.get("chitraagni_linked"):
            try:
                verified = self.account_store.status(verify=True)
                value["chitraagni_identity_verified"] = True
                value["current_user"] = verified.get("current_user")
                catalog = self._chitraagni_catalog(require_verified=False)
                value["chitraagni_tool_count"] = len(catalog.tools()) if catalog else 0
                value["chitraagni_data_access"] = "complete mounted deterministic account surface"
                value["chitraagni_context_access"] = "account/project/product snapshot + deterministic search"
            except Exception as exc:
                value["chitraagni_identity_verified"] = False
                value["chitraagni_error"] = str(exc)
        else:
            value["chitraagni_identity_verified"] = False
        return value

    def tools(self) -> list[dict[str, Any]]:
        from megas.work_planning import tools as planning_tools
        from megas.development_continuity import tools as continuity_tools
        from megas.shared_context import tools as context_tools
        from megas.actions import tools as action_tools
        from megas.chrome_bridge import chrome_tools
        from megas.agent_coordination import tools as coordination_tools
        from megas.telegram_native import tools as telegram_native_tools
        tools = [_status_tool(), _windows_screen_read_tool(), _windows_screen_capture_tool(), _windows_screen_goal_read_tool(), _notify_user_tool(), *_terminal_tools(), *self.workspace.tools()]
        tools.extend(planning_tools())
        tools.extend(continuity_tools())
        tools.extend(context_tools())
        tools.extend(action_tools())
        tools.extend(coordination_tools())
        tools.extend(chrome_tools())
        tools.extend(telegram_native_tools())
        if os.environ.get("MEGAS_ENABLE_TELEGRAM_DESKTOP_TOOLS", "").strip().lower() in {"1", "true", "yes", "on"}:
            from megas.telegram_desktop import tools as telegram_desktop_tools
            tools.extend(telegram_desktop_tools())
        try:
            chitraagni = self._chitraagni_catalog(require_verified=True)
        except Exception:
            chitraagni = None
        if chitraagni is not None:
            tools.extend(chitraagni.tools())
        seen: set[str] = set()
        for tool in tools:
            name = str(tool.get("name") or "")
            if not name or name in seen:
                raise ValueError(f"operator tool collision or empty name: {name}")
            seen.add(name)
        return sorted(tools, key=lambda row: str(row["name"]))

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if name in {"chrome_status", "chrome_control"}:
            from megas.chrome_bridge import chrome_tool_call
            return chrome_tool_call(name, arguments)
        if name.startswith("agent_coordination_"):
            from megas.agent_coordination import AgentCoordination
            return AgentCoordination().call(name, arguments)
        if name.startswith("telegram_desktop_"):
            if os.environ.get("MEGAS_ENABLE_TELEGRAM_DESKTOP_TOOLS", "").strip().lower() not in {"1", "true", "yes", "on"}:
                raise ValueError("unknown operator tool")
            from megas.telegram_desktop import TelegramDesktopIntegration
            return TelegramDesktopIntegration().call(name, arguments)
        if name.startswith("megas_action_"):
            from megas.actions import MegasActions
            return MegasActions().call(name, arguments)
        if name.startswith("megas_task_context_"):
            from megas.shared_context import SharedTaskContext
            return SharedTaskContext().call(name, arguments)
        if name.startswith("development_checkpoint_"):
            from megas.development_continuity import DevelopmentContinuity
            return DevelopmentContinuity().call(name, arguments)
        if name.startswith("megas_project_") or name.startswith("megas_todo_"):
            from megas.work_planning import WorkPlanning
            return WorkPlanning().call(name, arguments)
        if name.startswith("telegram_"):
            from megas.telegram_native import TelegramOperator
            return TelegramOperator().call(name, arguments)
        if not isinstance(arguments, dict):
            raise ValueError("tools/call arguments must be a JSON object")
        if name == "operator_status":
            if arguments:
                raise ValueError("operator_status does not accept arguments")
            value = self.status()
            return {
                "content": [{"type": "text", "text": json.dumps(value, sort_keys=True, default=str)}],
                "structuredContent": value,
                "isError": False,
            }
        if name == "windows_screen_read":
            allowed = {"max_nodes", "max_chars"}
            unexpected = sorted(set(arguments) - allowed)
            if unexpected:
                raise ValueError(f"windows_screen_read received unsupported arguments: {', '.join(unexpected)}")
            from megas.operate.windows.screen_read import read_current_screen

            value = read_current_screen(
                max_nodes=arguments.get("max_nodes", 240),
                max_chars=arguments.get("max_chars", 12000),
            )
            return {
                "content": [{"type": "text", "text": json.dumps(value, indent=2, default=str)}],
                "structuredContent": value,
                "isError": False,
            }
        if name == "windows_screen_capture":
            allowed = {"max_width", "max_height"}
            unexpected = sorted(set(arguments) - allowed)
            if unexpected:
                raise ValueError(
                    f"windows_screen_capture received unsupported arguments: {', '.join(unexpected)}"
                )
            from megas.operate.windows.screen_capture import capture_current_screen

            value = capture_current_screen(
                max_width=arguments.get("max_width", 1024),
                max_height=arguments.get("max_height", 768),
            )
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(value, sort_keys=True, ensure_ascii=False, default=str),
                    }
                ],
                "structuredContent": value,
                "isError": False,
            }
        if name == "windows_screen_goal_read":
            allowed = {"target", "max_nodes", "max_chars"}
            unexpected = sorted(set(arguments) - allowed)
            if unexpected:
                raise ValueError(
                    f"windows_screen_goal_read received unsupported arguments: {', '.join(unexpected)}"
                )
            target = arguments.get("target")
            if not isinstance(target, dict):
                raise ValueError("windows_screen_goal_read requires target object")
            from megas.operate.windows.screen_goal import read_target_screen

            value = read_target_screen(
                target=target,
                max_nodes=arguments.get("max_nodes", 240),
                max_chars=arguments.get("max_chars", 12000),
            )
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(value, sort_keys=True, ensure_ascii=False, default=str),
                    }
                ],
                "structuredContent": value,
                "isError": value.get("goal_status") != "completed",
            }
        if name == "notify_user":
            title = str(arguments.get("title") or "Megas Moves Alert").strip()
            message = str(arguments.get("message") or "").strip()
            if not message:
                raise ValueError("notify_user requires a non-empty 'message'")
            title = title[:120]
            message = message[:2000]
            level = str(arguments.get("level") or "info").strip()
            if level not in {"info", "success", "warning", "error"}:
                level = "info"
            raw_event_type = str(arguments.get("event_type") or "").strip().lower()
            if not raw_event_type:
                raw_event_type = {
                    "warning": "approval_required",
                    "error": "task_failed",
                }.get(level, "task_completed")
            event_type = {
                "session_agent_done": "task_completed",
                "session_failed": "task_failed",
                "session_verified": "task_completed",
                "waiting_for_approval": "approval_required",
            }.get(raw_event_type, raw_event_type)
            if event_type not in REMOTE_NOTIFICATION_TYPES:
                raise ValueError("notify_user event_type is not an approved Megas notification category")

            peer_status = self._direct_peer_status()
            from megas.local.peer_mesh.controller import current_peer_mesh

            controller = current_peer_mesh()
            peer_result = (
                controller.send_notification(
                    title=title,
                    message=message,
                    level=level,
                    event_type=event_type,
                )
                if controller is not None
                else {
                    "delivered": False,
                    "reason": peer_status.get("state", "peer_mesh_not_running"),
                    "peer_acknowledged": False,
                }
            )
            delivered = bool(peer_result.get("delivered") and peer_result.get("peer_acknowledged"))
            channels = ["direct_peer"] if delivered else []
            delivery_status = "peer_acknowledged" if delivered else "not_delivered"
            details: dict[str, Any] = {"direct_peer": {**peer_status, **peer_result}}
            result_payload = {
                "ok": delivered,
                "delivery_status": delivery_status,
                "title": title,
                "message": message,
                "level": level,
                "event_type": event_type,
                "dispatched_channels": channels,
                "details": details,
            }
            return {
                "content": [{"type": "text", "text": json.dumps(result_payload, indent=2)}],
                "structuredContent": result_payload,
                "isError": not delivered,
            }
        if name.startswith("terminal_"):
            from megas.terminal import get_session_manager

            mgr = get_session_manager()
            if name == "terminal_list_sessions":
                sessions = [s.to_dict() for s in mgr.list_sessions()]
                return {
                    "content": [{"type": "text", "text": json.dumps({"terminals": sessions}, indent=2)}],
                    "structuredContent": {"terminals": sessions},
                    "isError": False,
                }
            if name == "terminal_create_session":
                cmd = arguments.get("command")
                if not cmd:
                    raise ValueError("command is required")
                cwd = arguments.get("cwd")
                title = arguments.get("title")
                env = arguments.get("env")
                session = mgr.create_session(command=cmd, cwd=cwd, title=title, env=env)
                return {
                    "content": [{"type": "text", "text": json.dumps({"terminal": session.to_dict()}, indent=2)}],
                    "structuredContent": {"terminal": session.to_dict()},
                    "isError": False,
                }
            if name == "terminal_read_output":
                session_id = str(arguments.get("session_id") or "")
                if not session_id:
                    raise ValueError("session_id is required")
                after_seq = int(arguments.get("after_seq", -1))
                limit = int(arguments.get("limit", 200))
                events = mgr.read_output(session_id, after_seq=after_seq, limit=limit)
                ev_dicts = [ev.to_dict() for ev in events]
                return {
                    "content": [{"type": "text", "text": json.dumps({"events": ev_dicts}, indent=2)}],
                    "structuredContent": {"events": ev_dicts},
                    "isError": False,
                }
            if name == "terminal_send_input":
                session_id = str(arguments.get("session_id") or "")
                text = str(arguments.get("text") or "")
                ok = mgr.send_input(session_id, text)
                return {
                    "content": [{"type": "text", "text": json.dumps({"ok": ok, "session_id": session_id}, indent=2)}],
                    "structuredContent": {"ok": ok, "session_id": session_id},
                    "isError": not ok,
                }
            if name == "terminal_terminate_session":
                session_id = str(arguments.get("session_id") or "")
                ok = mgr.terminate_session(session_id)
                return {
                    "content": [{"type": "text", "text": json.dumps({"ok": ok, "session_id": session_id}, indent=2)}],
                    "structuredContent": {"ok": ok, "session_id": session_id},
                    "isError": False,
                }
            raise KeyError(name)
        if name.startswith("workspace_"):
            return self.workspace.call(name, arguments)
        if name.startswith("chitraagni_"):
            chitraagni = self._chitraagni_catalog(require_verified=True)
            if chitraagni is None:
                raise PermissionError(
                    "Chitraagni is not linked to this MegasMoves installation; link the user's account before using Chitraagni operator tools"
                )
            return chitraagni.call(name, arguments)
        raise KeyError(name)

    def resources(self) -> list[dict[str, Any]]:
        resources = [
            _resource(
                "megas://operator/status",
                "MegasMCP operator status",
                "Current local/operator/account availability without credential values.",
            ),
            _resource(
                "megas://workspace/projects",
                "MegasMoves local projects",
                "Software folders already trusted by the human on this machine.",
            ),
        ]
        try:
            chitraagni = self._chitraagni_catalog(require_verified=True)
        except Exception:
            chitraagni = None
        if chitraagni is None:
            return resources
        resources.extend(
            [
                _resource(
                    "chitraagni://account/context",
                    "Chitraagni account context",
                    "Linked user's identity plus authorized workspace/project/product index.",
                ),
                _resource(
                    "chitraagni://account/snapshot",
                    "Chitraagni account snapshot",
                    "Bounded account-wide AI snapshot of authorized Product memory, screens, schemas, workflows, versions, design system and R5 state.",
                ),
                _resource(
                    "chitraagni://projects",
                    "Chitraagni projects",
                    "All Projects currently authorized for the linked Chitraagni user.",
                ),
                _resource(
                    "chitraagni://products",
                    "Chitraagni products",
                    "All Product surfaces currently authorized for the linked Chitraagni user.",
                ),
            ]
        )
        # Dynamic discovery is best-effort; Chitraagni downtime must not remove
        # local MegasMoves resources or the stable Chitraagni templates above.
        try:
            account = chitraagni.account_context()
        except Exception:
            return resources
        for project in account.get("projects") or []:
            if isinstance(project, dict) and project.get("id"):
                pid = str(project["id"])
                resources.append(
                    _resource(
                        f"chitraagni://project/{quote(pid, safe='')}/context",
                        f"Chitraagni Project: {project.get('name') or pid}",
                        "Broad AI-ready Project context including products, screens, schemas, workflows, versions and design system.",
                    )
                )
        for product in account.get("products") or []:
            if isinstance(product, dict) and product.get("id"):
                product_id = str(product["id"])
                resources.append(
                    _resource(
                        f"chitraagni://product/{quote(product_id, safe='')}/context",
                        f"Chitraagni Product: {product.get('name') or product_id}",
                        "AI-ready Product context including memory, Product-owned screens, R5 state and parent Project design data.",
                    )
                )
        return resources

    @staticmethod
    def resource_templates() -> list[dict[str, Any]]:
        return [
            {
                "uriTemplate": "chitraagni://project/{project_id}/context",
                "name": "Chitraagni Project context",
                "description": "Read an authorized Project's broad AI-ready context by UUID.",
                "mimeType": "application/json",
            },
            {
                "uriTemplate": "chitraagni://product/{product_id}/context",
                "name": "Chitraagni Product context",
                "description": "Read an authorized Product's broad AI-ready context by UUID.",
                "mimeType": "application/json",
            },
            {
                "uriTemplate": "chitraagni://version/{version_id}/snapshot",
                "name": "Chitraagni version snapshot",
                "description": "Read the complete authorized structured snapshot for one Project version UUID.",
                "mimeType": "application/json",
            },
        ]

    def read_resource(self, uri: str) -> dict[str, Any]:
        parsed = urlsplit(uri)
        if parsed.scheme == "megas" and parsed.netloc == "operator" and parsed.path == "/status":
            return _resource_text(uri, self.status())
        if parsed.scheme == "megas" and parsed.netloc == "workspace" and parsed.path == "/projects":
            return _resource_text(
                uri,
                self.workspace.call("workspace_projects", {})["structuredContent"],
            )
        if parsed.scheme != "chitraagni":
            raise KeyError(uri)
        chitraagni = self._chitraagni_catalog(require_verified=True)
        if chitraagni is None:
            raise PermissionError("Chitraagni is not linked to this MegasMoves installation")
        if parsed.netloc == "account" and parsed.path == "/context":
            return _resource_text(uri, chitraagni.account_context())
        if parsed.netloc == "account" and parsed.path == "/snapshot":
            return _resource_text(uri, chitraagni.account_snapshot())
        if parsed.netloc == "projects" and parsed.path in {"", "/"}:
            return _resource_text(
                uri,
                chitraagni.call("chitraagni_projects_list", {})["structuredContent"],
            )
        if parsed.netloc == "products" and parsed.path in {"", "/"}:
            return _resource_text(
                uri,
                chitraagni.call("chitraagni_read", {"path": "/products"})["structuredContent"],
            )
        parts = [unquote(part) for part in parsed.path.split("/") if part]
        if parsed.netloc == "project" and len(parts) == 2 and parts[1] == "context":
            return _resource_text(uri, chitraagni.project_context(parts[0]))
        if parsed.netloc == "product" and len(parts) == 2 and parts[1] == "context":
            return _resource_text(uri, chitraagni.product_context(parts[0]))
        if parsed.netloc == "version" and len(parts) == 2 and parts[1] == "snapshot":
            value = chitraagni.call(
                "chitraagni_version_snapshot_get",
                {"version_id": parts[0]},
            )["structuredContent"]
            return _resource_text(uri, value)
        raise KeyError(uri)


@dataclass(slots=True)
class MegasOperatorMCPServer:
    catalog: OperatorCapabilityCatalog = field(default_factory=OperatorCapabilityCatalog)

    def instructions(self) -> str:
        status = self.catalog.status()
        return (
            "MegasMCP operates the local MegasMoves software workspace and, when linked and identity-verified, "
            "the same user's complete mounted deterministic Chitraagni data/action surface. Folder trust is human-controlled; "
            "credentials stay inside MegasMoves.exe. Prefer Chitraagni account/project/product context resources, "
            "chitraagni_find, and typed read tools before mutations. "
            "For local testing, read operator_status and workspace_projects, then workspace_check, workspace_status "
            "and workspace_ports for the selected project. Use workspace_select_folder to map a new project folder into the shared Windows list. Start only the requested service slice; use bounded "
            "workspace_logs to explain failures and never infer readiness from a start acknowledgement. "
            "Planning projects and trusted software folders are different records. Device discovery is not proof that "
            "a device is usable; secure_device_pairing_required means remote phone operation is unavailable. "
            "For work planning, use megas_project_list to resolve authorized Chitraagni ecosystem projects. "
            "Use their Chitraagni UUIDs for Megas operational todos; never create a separate Megas project identity. "
            "Legacy local plans require explicit megas_project_link migration. If Chitraagni is unlinked or denied, report that boundary. "
            "Break requests into actionable todos, preserve the original intent in descriptions, and link dependencies by returned task IDs. "
            "Read megas_project_board to select ready next actions. Dates must come from the user; do not invent deadlines. "
            "Agent coordination is a primary workflow: start with agent_coordination_board, claim work using its generation, "
            "inspect dependencies and retained context, and preserve progress with development_checkpoint_save. "
            "Use agent_coordination_handoff before interruption and agent_coordination_complete with evidence after verification. "
            "Claims never start execution. Do not confuse assigned, running, waiting_capacity, detached and completed states. "
            "Native coding-agent resume must retain the same provider conversation ID; if unavailable, report that limit rather than silently creating a replacement. "
            "Saving a todo does not execute it. Mark work completed only after it is done and include evidence in completion_note. "
            f"Chitraagni linked={bool(status.get('chitraagni_linked'))}, "
            f"identity_verified={bool(status.get('chitraagni_identity_verified'))}."
        )

    def initialize(self, params: dict[str, Any]) -> dict[str, Any]:
        requested = str(params.get("protocolVersion") or "")
        if requested == MODERN_PROTOCOL:
            raise ValueError(f"MCP {MODERN_PROTOCOL} uses stateless server/discover instead of initialize")
        protocol = requested if requested in LEGACY_PROTOCOLS else LEGACY_PROTOCOLS[0]
        return {
            "protocolVersion": protocol,
            "serverInfo": _server_info(),
            "capabilities": {
                "tools": {"listChanged": False},
                "resources": {"subscribe": False, "listChanged": False},
            },
            "instructions": self.instructions(),
        }

    def discover(self, params: dict[str, Any]) -> dict[str, Any]:
        _modern_request_meta(params, required=True)
        return _modern_result(
            {
                "supportedVersions": [MODERN_PROTOCOL],
                "capabilities": {"tools": {}, "resources": {}},
                "instructions": self.instructions(),
            },
            cache_private=True,
            ttl_ms=30_000,
        )

    def dispatch(self, method: str, params: dict[str, Any] | None) -> dict[str, Any] | None:
        actual = params or {}
        if method == "server/discover":
            return self.discover(actual)
        if method == "initialize":
            return self.initialize(actual)
        modern = _modern_request_meta(actual, required=False) is not None
        if method == "tools/list":
            result = {"tools": self.catalog.tools()}
            return _modern_result(result, cache_private=True) if modern else result
        if method == "tools/call":
            name = str(actual.get("name") or "").strip()
            arguments = actual.get("arguments") or {}
            if not name:
                raise ValueError("tools/call requires a non-empty tool name")
            if not isinstance(arguments, dict):
                raise ValueError("tools/call arguments must be a JSON object")
            result = self.catalog.call(name, arguments)
            return _modern_result(result) if modern else result
        if method == "resources/list":
            result = {"resources": self.catalog.resources()}
            return _modern_result(result, cache_private=True) if modern else result
        if method == "resources/templates/list":
            result = {"resourceTemplates": self.catalog.resource_templates()}
            return _modern_result(result, cache_private=True, ttl_ms=30_000) if modern else result
        if method == "resources/read":
            uri = str(actual.get("uri") or "").strip()
            if not uri:
                raise ValueError("resources/read requires a non-empty uri")
            result = self.catalog.read_resource(uri)
            return _modern_result(result, cache_private=True, ttl_ms=1_000) if modern else result
        if method == "ping":
            return _modern_result({}) if modern else {}
        if method == "prompts/list":
            result = {"prompts": []}
            return _modern_result(result, cache_private=True, ttl_ms=30_000) if modern else result
        if method in {"notifications/initialized", "notifications/cancelled"}:
            return None
        raise KeyError(method)


def serve_operator_stdio(
    *,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> None:
    input_stream = stdin or sys.stdin
    output_stream = stdout or sys.stdout
    error_stream = stderr or sys.stderr
    server = MegasOperatorMCPServer()
    for line in input_stream:
        text = line.strip()
        if not text:
            continue
        request_id: Any = None
        try:
            message = json.loads(text)
            if not isinstance(message, dict):
                raise ValueError("MCP message must be a JSON object")
            if message.get("jsonrpc") != "2.0":
                raise ValueError("MCP message must use jsonrpc 2.0")
            request_id = message.get("id")
            method = str(message.get("method") or "")
            if not method:
                raise ValueError("MCP message is missing method")
            params = message.get("params")
            if params is not None and not isinstance(params, dict):
                raise ValueError("MCP params must be a JSON object")
            result = server.dispatch(method, params)
            if request_id is None or result is None:
                continue
            response = _response(request_id, result=result)
        except KeyError as exc:
            if request_id is None:
                continue
            response = _response(
                request_id,
                error=_error(-32601, f"method not found or operator capability unavailable: {exc.args[0]}"),
            )
        except (ValueError, RuntimeError, TimeoutError, PermissionError, OSError) as exc:
            if request_id is None:
                print(f"MegasMCP operator request error: {type(exc).__name__}", file=error_stream, flush=True)
                continue
            response = _response(
                request_id,
                error=_error(-32602, str(exc), {"type": type(exc).__name__}),
            )
        except Exception as exc:
            if request_id is None:
                print(f"MegasMCP operator internal error: {type(exc).__name__}", file=error_stream, flush=True)
                continue
            response = _response(
                request_id,
                error=_error(-32603, "internal operator error", {"type": type(exc).__name__}),
            )
            print(
                "MegasMCP operator internal error:\n" + "".join(traceback.format_exception(exc)),
                file=error_stream,
                flush=True,
            )
        output_stream.write(json.dumps(response, separators=(",", ":"), ensure_ascii=False) + "\n")
        output_stream.flush()


__all__ = [
    "CLIENT_CAPABILITIES_META_KEY",
    "CLIENT_INFO_META_KEY",
    "LEGACY_PROTOCOLS",
    "MODERN_PROTOCOL",
    "MegasOperatorMCPServer",
    "OperatorCapabilityCatalog",
    "PROTOCOL_META_KEY",
    "SERVER_INFO_META_KEY",
    "SUPPORTED_PROTOCOLS",
    "serve_operator_stdio",
]
