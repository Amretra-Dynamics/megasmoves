from __future__ import annotations

import json
import sys
import traceback
from dataclasses import dataclass, field
from typing import Any, TextIO
from urllib.parse import unquote, urlsplit

from megas.chitraagni_authority import ChitraagniAuthorityStore, chitraagni_authority_scope
from megas.chitraagni_operator_runtime import RuntimeChitraagniOperatorCatalog
from megas.chitraagni_surface_contract import installed_surface_map
from megas.firebase_account import token_request_scope

from .agent_presence import summarize_agent_presence
from .browser_operator import BROWSER_STATUS_URI, BrowserOperatorCatalog
from .operator_activity import (
    OperatorOperation,
    attach_operation_metadata,
    operator_request_context,
    reconcile_operator_activity_once,
)
from .operator_server import (
    CLIENT_INFO_META_KEY,
    PROTOCOL_META_KEY,
    MegasOperatorMCPServer as _BaseServer,
    OperatorCapabilityCatalog as _BaseCatalog,
    _error,
    _resource,
    _resource_text,
    _response,
)
from .store import MCPStore


SURFACE_MAP_URI = "megas://chitraagni/surfaces"
AGENT_ACTIVITY_URI = "megas://operator/agents"

_ENTITY_RESOURCE_TEMPLATES: tuple[dict[str, Any], ...] = (
    {
        "uriTemplate": "chitraagni://workspace/{workspace_id}",
        "name": "Chitraagni workspace",
        "description": "Read one workspace authorized for the linked user.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://project/{project_id}",
        "name": "Chitraagni project",
        "description": "Read one Project authorized for the linked user.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://product/{product_id}",
        "name": "Chitraagni product",
        "description": "Read one Product surface, including Product memory, authorized for the linked user.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://screen/{screen_id}",
        "name": "Chitraagni screen",
        "description": "Read one authorized structured screen revision.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://schema/{schema_id}",
        "name": "Chitraagni schema",
        "description": "Read one authorized structured schema/entity.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://workflow/{workflow_id}",
        "name": "Chitraagni workflow",
        "description": "Read one authorized structured workflow.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://design-token-set/{token_set_id}",
        "name": "Chitraagni design token set",
        "description": "Read one authorized design-token set.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://component-definition/{component_definition_id}",
        "name": "Chitraagni component definition",
        "description": "Read one authorized reusable component definition.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://version/{version_id}",
        "name": "Chitraagni version",
        "description": "Read metadata for one authorized Project version.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://project/{project_id}/quality",
        "name": "Chitraagni project quality",
        "description": "Read the deterministic quality report for an authorized Project.",
        "mimeType": "application/json",
    },
    {
        "uriTemplate": "chitraagni://product/{product_id}/r5",
        "name": "Chitraagni Product R5 state",
        "description": "Read server-authoritative visual review/library collaboration state for an authorized Product.",
        "mimeType": "application/json",
    },
)


def _agent_activity_tool() -> dict[str, Any]:
    return {
        "name": "operator_agents",
        "title": "Agent Activity",
        "description": (
            "Show bounded recent MCP client activity observed by Megas MCP. "
            "Active means recent protocol/tool activity, not an authenticated identity or persistent HTTP connection."
        ),
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        "annotations": {
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        },
    }


@dataclass(slots=True)
class OperatorCapabilityCatalog(_BaseCatalog):
    """Production operator catalog.

    Chitraagni identity and Chitraagni invocation authority are intentionally
    separate. Account linking proves which Chitraagni user a credential belongs
    to; it never grants an AI client authority to invoke a Chitraagni tool.
    Exact machine-local tool grants are fingerprint-bound and scoped to the
    linked Chitraagni user + API target. Remote hosted writes require separate
    remote-access + production.write approval before a credential or network
    request is used.

    Megas Browser is another capability of this same operator. Playwright and
    browser processes remain private behind BrowserOperatorCatalog; there is no
    second public browser-agent control plane.
    """

    activity_store: MCPStore = field(default_factory=MCPStore)
    chitraagni_authority: ChitraagniAuthorityStore = field(default_factory=ChitraagniAuthorityStore)
    browser: BrowserOperatorCatalog = field(default_factory=BrowserOperatorCatalog)

    def __post_init__(self) -> None:
        # Startup reconciliation is evidence-only: it never retries external
        # work. Cross-process locking and live-owner checks in operator_activity
        # keep simultaneous stdio/HTTP operators from interrupting each other.
        reconcile_operator_activity_once(self.activity_store)

    @staticmethod
    def _authority_scope(binding: Any) -> str:
        return chitraagni_authority_scope(
            api_base=binding.api_base,
            user_id=binding.user_id,
        )

    def _chitraagni_catalog(self, *, require_verified: bool) -> RuntimeChitraagniOperatorCatalog | None:
        account = self.account_store.load()
        binding = account.chitraagni
        if binding is None:
            return None
        catalog = RuntimeChitraagniOperatorCatalog(binding)
        if require_verified:
            catalog.verify_identity()
        return catalog

    def _authorize_chitraagni_tool(self, name: str) -> RuntimeChitraagniOperatorCatalog:
        binding = self.account_store.load().chitraagni
        if binding is None:
            raise PermissionError("Chitraagni is not linked to this Megas MCP installation")
        catalog = RuntimeChitraagniOperatorCatalog(binding)
        tool = next((row for row in catalog.tools() if row.get("name") == name), None)
        if tool is None:
            raise KeyError(name)
        scope = self._authority_scope(binding)
        # Local authority is checked before credential verification/network I/O.
        self.chitraagni_authority.assert_tool_allowed(tool, scope=scope)
        annotations = tool.get("annotations")
        read_only = bool(annotations.get("readOnlyHint", False)) if isinstance(annotations, dict) else False
        self.chitraagni_authority.assert_target_allowed(
            api_base=binding.api_base,
            mutating=not read_only,
            scope=scope,
        )
        return catalog

    def agent_presence(self) -> dict[str, Any]:
        return summarize_agent_presence(self.activity_store)

    def _work_planning(self):
        from megas.work_planning import WorkPlanning

        binding = self.account_store.load().chitraagni
        if binding is None:
            raise PermissionError("Link Chitraagni before using ecosystem projects and todos")
        scope = self._authority_scope(binding)

        def authorized_call(name, arguments):
            catalog = self._authorize_chitraagni_tool(name)
            if self._authority_scope(catalog.binding) != scope:
                raise PermissionError("Chitraagni identity changed during planning; retry after explicit relink")
            return catalog.call(name, arguments)

        def owned_projects():
            from megas import workspace_cli
            parser = workspace_cli.build_parser()
            return workspace_cli.run(parser.parse_args(["projects"]))

        return WorkPlanning(
            chitraagni_call=authorized_call,
            authority_scope=scope,
            owned_projects_call=owned_projects,
        )

    def tools(self) -> list[dict[str, Any]]:
        tools = list(_BaseCatalog.tools(self))
        if not any(row.get("name") == "operator_agents" for row in tools):
            tools.append(_agent_activity_tool())
        existing = {str(row.get("name") or "") for row in tools}
        for tool in self.browser.tools():
            name = str(tool.get("name") or "")
            if not name or name in existing:
                raise ValueError(f"operator/browser tool collision or empty name: {name}")
            existing.add(name)
            tools.append(tool)
        return sorted(tools, key=lambda row: str(row.get("name") or ""))

    @token_request_scope()
    def status(self) -> dict[str, Any]:
        value = _BaseCatalog.status(self)
        binding = self.account_store.load().chitraagni
        # `chitraagni_linked` remains a compatibility status field for existing
        # MCP/desktop consumers. The authoritative account model is Amretra:
        # presence of a bound Chitraagni target means linked, and identity is
        # separately re-verified against the current Amretra credential.
        value["chitraagni_linked"] = binding is not None
        # The base status already performed this request's identity check.
        # Keep its verified/error evidence rather than probing a second time.
        if binding is None:
            value["chitraagni_identity_verified"] = False
            value.pop("current_user", None)

        presence = self.agent_presence()
        value["agent_activity"] = {
            "active": presence["counts"]["active"],
            "observed": presence["counts"]["observed"],
            "activity_window_seconds": presence["activity_window_seconds"],
            "resource": AGENT_ACTIVITY_URI,
        }
        value["browser"] = self.browser.status()
        value["browser"]["resource"] = BROWSER_STATUS_URI
        surface = installed_surface_map()
        value["chitraagni_surface_contract"] = {
            "version": surface["version"],
            "complete_for_mounted_domains": surface["complete_for_mounted_domains"],
            "missing_operator_tools": surface["missing_operator_tools"],
            "resource": SURFACE_MAP_URI,
        }
        if binding is None:
            value["chitraagni_local_authority"] = self.chitraagni_authority.status()
        else:
            catalog = RuntimeChitraagniOperatorCatalog(binding)
            value["chitraagni_local_authority"] = self.chitraagni_authority.status(
                catalog.tools(),
                api_base=binding.api_base,
                scope=self._authority_scope(binding),
            )
        return value

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(arguments, dict):
            # Preserve the base catalog's canonical validation/error semantics.
            return _BaseCatalog.call(self, name, arguments)

        if name.startswith("chitraagni_"):
            # Do not let the base catalog verify/use a credential until Megas MCP
            # has proved that the exact current tool contract is locally granted.
            self._authorize_chitraagni_tool(name)

        operation = OperatorOperation(self.activity_store, name, arguments)
        with operation:
            try:
                if name == "operator_agents":
                    if arguments:
                        raise ValueError("operator_agents does not accept arguments")
                    value = self.agent_presence()
                    result = {
                        "content": [
                            {
                                "type": "text",
                                "text": json.dumps(value, sort_keys=True, default=str),
                            }
                        ],
                        "structuredContent": value,
                        "isError": False,
                    }
                elif name.startswith("browser_"):
                    result = self.browser.call(name, arguments)
                elif name.startswith("agent_coordination_"):
                    from megas.agent_coordination import AgentCoordination
                    def authorize_coordination(task):
                        planning = self._work_planning()
                        if planning.authority_scope != task.project_authority_scope:
                            raise PermissionError("coordination belongs to another linked account")
                        planning._project(task.project)
                    result = AgentCoordination(authorize=authorize_coordination).call(name, arguments)
                elif name.startswith("development_checkpoint_"):
                    from megas.development_continuity import DevelopmentContinuity
                    def authorize_checkpoint(task):
                        planning = self._work_planning()
                        if planning.authority_scope != task.project_authority_scope:
                            raise PermissionError("checkpoint belongs to another linked account")
                        planning._project(task.project)
                    result = DevelopmentContinuity(authorize=authorize_checkpoint).call(name, arguments)
                elif name.startswith("megas_action_"):
                    from megas.actions import MegasActions
                    def authorize_action_task(task):
                        planning = self._work_planning()
                        if planning.authority_scope != task.project_authority_scope:
                            raise PermissionError("task belongs to another linked account")
                        planning._project(task.project)
                    result = MegasActions(authorize=authorize_action_task).call(name, arguments)
                elif name.startswith("megas_task_context_"):
                    from megas.shared_context import SharedTaskContext
                    def authorize_context(task):
                        planning = self._work_planning()
                        if planning.authority_scope != task.project_authority_scope:
                            raise PermissionError("shared context belongs to another linked account")
                        planning._project(task.project)
                    result = SharedTaskContext(authorize=authorize_context).call(name, arguments)
                elif name.startswith("megas_project_") or name.startswith("megas_todo_"):
                    result = self._work_planning().call(name, arguments)
                else:
                    result = _BaseCatalog.call(self, name, arguments)
            except Exception as exc:
                operation.fail(exc)
                raise
            operation.complete(result)
            return attach_operation_metadata(result, operation.operation_id)

    def resources(self) -> list[dict[str, Any]]:
        # Do not call the base dynamic Chitraagni discovery here: it resolves
        # account context and project/product names before a resource grant is
        # checked. Resource listing is intentionally descriptor-only and never
        # reads Chitraagni user data or uses a linked credential.
        resources = [
            _resource(
                "megas://operator/status",
                "Megas MCP operator status",
                "Current local/operator/account availability without credential values.",
            ),
            _resource(
                AGENT_ACTIVITY_URI,
                "Megas MCP agent activity",
                "Bounded recent MCP client activity with explicit stateless/freshness semantics.",
            ),
            _resource(
                BROWSER_STATUS_URI,
                "Megas Browser status",
                "Dedicated browser capability and task-scoped browser sessions behind the Megas MCP control plane.",
            ),
            _resource(
                "megas://workspace/projects",
                "MegasMoves local projects",
                "Software folders already trusted by the human on this machine.",
            ),
            _resource(
                SURFACE_MAP_URI,
                "Chitraagni frontend control surface map",
                "Machine-readable mapping from Chitraagni human-facing areas to mounted deterministic domains and the typed Megas MCP capabilities that operate them. Contains no user data or credentials.",
            ),
        ]
        if self.account_store.load().chitraagni is not None:
            resources.extend(
                [
                    _resource(
                        "chitraagni://account/context",
                        "Chitraagni account context",
                        "Linked account context. Reading it requires the matching local Chitraagni tool grant.",
                    ),
                    _resource(
                        "chitraagni://account/snapshot",
                        "Chitraagni account snapshot",
                        "Bounded account snapshot. Reading it requires the matching local Chitraagni tool grant.",
                    ),
                    _resource(
                        "chitraagni://projects",
                        "Chitraagni projects",
                        "Authorized Chitraagni Projects. Reading it requires the matching local Chitraagni tool grant.",
                    ),
                    _resource(
                        "chitraagni://products",
                        "Chitraagni products",
                        "Authorized Chitraagni Products. Reading it requires the matching local Chitraagni tool grant.",
                    ),
                ]
            )
        return resources

    @staticmethod
    def resource_templates() -> list[dict[str, Any]]:
        base = list(_BaseCatalog.resource_templates())
        existing = {str(row.get("uriTemplate") or "") for row in base}
        for row in _ENTITY_RESOURCE_TEMPLATES:
            if row["uriTemplate"] not in existing:
                base.append(dict(row))
        return base

    @staticmethod
    def _entity_tool(uri: str) -> tuple[str, dict[str, Any]]:
        parsed = urlsplit(uri)
        if parsed.scheme != "chitraagni":
            raise KeyError(uri)
        parts = [unquote(part) for part in parsed.path.split("/") if part]
        if parsed.netloc == "account" and parts == ["context"]:
            return "chitraagni_account_context", {}
        if parsed.netloc == "account" and parts == ["snapshot"]:
            return "chitraagni_account_snapshot", {}
        if parsed.netloc == "projects" and not parts:
            return "chitraagni_projects_list", {}
        if parsed.netloc == "products" and not parts:
            return "chitraagni_products_list", {}
        if parsed.netloc == "workspace" and len(parts) == 1:
            return "chitraagni_workspace_get", {"workspace_id": parts[0]}
        if parsed.netloc == "project" and len(parts) == 1:
            return "chitraagni_project_get", {"project_id": parts[0]}
        if parsed.netloc == "project" and len(parts) == 2 and parts[1] == "context":
            return "chitraagni_project_context", {"project_id": parts[0]}
        if parsed.netloc == "project" and len(parts) == 2 and parts[1] == "quality":
            return "chitraagni_project_quality", {"project_id": parts[0]}
        if parsed.netloc == "product" and len(parts) == 1:
            return "chitraagni_product_get", {"product_id": parts[0]}
        if parsed.netloc == "product" and len(parts) == 2 and parts[1] == "context":
            return "chitraagni_product_context", {"product_id": parts[0]}
        if parsed.netloc == "product" and len(parts) == 2 and parts[1] == "r5":
            return "chitraagni_r5_state", {"product_id": parts[0]}
        if parsed.netloc == "screen" and len(parts) == 1:
            return "chitraagni_screen_get", {"screen_id": parts[0]}
        if parsed.netloc == "schema" and len(parts) == 1:
            return "chitraagni_schema_get", {"schema_id": parts[0]}
        if parsed.netloc == "workflow" and len(parts) == 1:
            return "chitraagni_workflow_get", {"workflow_id": parts[0]}
        if parsed.netloc == "design-token-set" and len(parts) == 1:
            return "chitraagni_design_token_set_get", {"token_set_id": parts[0]}
        if parsed.netloc == "component-definition" and len(parts) == 1:
            return "chitraagni_component_definition_get", {
                "component_definition_id": parts[0]
            }
        if parsed.netloc == "version" and len(parts) == 1:
            return "chitraagni_version_get", {"version_id": parts[0]}
        if parsed.netloc == "version" and len(parts) == 2 and parts[1] == "snapshot":
            return "chitraagni_version_snapshot_get", {"version_id": parts[0]}
        raise KeyError(uri)

    def _entity_resource(self, uri: str) -> Any:
        tool, arguments = self._entity_tool(uri)
        chitraagni = self._authorize_chitraagni_tool(tool)
        value = chitraagni.call(tool, arguments)
        return value["structuredContent"]

    def read_resource(self, uri: str) -> dict[str, Any]:
        if uri == SURFACE_MAP_URI:
            return _resource_text(uri, installed_surface_map())
        if uri == AGENT_ACTIVITY_URI:
            return _resource_text(uri, self.agent_presence())
        if uri == BROWSER_STATUS_URI:
            return _resource_text(uri, self.browser.status())
        parsed = urlsplit(uri)
        if parsed.scheme != "chitraagni":
            return _BaseCatalog.read_resource(self, uri)
        tool, arguments = self._entity_tool(uri)
        chitraagni = self._authorize_chitraagni_tool(tool)
        value = chitraagni.call(tool, arguments)["structuredContent"]
        return _resource_text(uri, value)


@dataclass(slots=True)
class MegasOperatorMCPServer(_BaseServer):
    catalog: OperatorCapabilityCatalog = field(default_factory=OperatorCapabilityCatalog)
    transport: str = "stdio"
    legacy_client_info: dict[str, Any] = field(default_factory=dict, repr=False)
    last_stdio_agent: str | None = field(default=None, repr=False)
    last_stdio_agent_version: str | None = field(default=None, repr=False)
    last_stdio_protocol_version: str | None = field(default=None, repr=False)

    def initialize(self, params: dict[str, Any]) -> dict[str, Any]:
        if self.transport == "stdio":
            client = params.get("clientInfo")
            self.legacy_client_info = dict(client) if isinstance(client, dict) else {}
        return _BaseServer.initialize(self, params)

    def dispatch(self, method: str, params: dict[str, Any] | None) -> dict[str, Any] | None:
        actual = params or {}
        client_info: dict[str, Any] | None = None
        meta = actual.get("_meta")
        if isinstance(meta, dict):
            candidate = meta.get(CLIENT_INFO_META_KEY)
            if isinstance(candidate, dict):
                client_info = candidate
        if client_info is None and method == "initialize":
            candidate = actual.get("clientInfo")
            if isinstance(candidate, dict):
                client_info = candidate
        if client_info is None and self.transport == "stdio" and method != "initialize":
            client_info = self.legacy_client_info or None
        with operator_request_context(transport=self.transport, client_info=client_info) as request_context:
            result = _BaseServer.dispatch(self, method, params)
            if method in {"server/discover", "initialize"}:
                protocol_version = ""
                if method == "initialize" and isinstance(result, dict):
                    protocol_version = str(result.get("protocolVersion") or "").strip()
                elif isinstance(meta, dict):
                    protocol_version = str(meta.get(PROTOCOL_META_KEY) or "").strip()
                observation: dict[str, Any] = {
                    "transport": request_context.transport,
                    "handshake": "discover" if method == "server/discover" else "initialize",
                }
                if protocol_version:
                    observation["protocol_version"] = protocol_version
                if request_context.agent:
                    observation["agent"] = request_context.agent
                if request_context.agent_version:
                    observation["agent_version"] = request_context.agent_version
                self.catalog.activity_store.record("agent.client.observed", **observation)
                if self.transport == "stdio" and request_context.agent:
                    self.last_stdio_agent = request_context.agent
                    self.last_stdio_agent_version = request_context.agent_version
                    self.last_stdio_protocol_version = protocol_version or None
            return result

    def record_stdio_disconnect(self) -> None:
        if self.transport != "stdio" or not self.last_stdio_agent:
            return
        row: dict[str, Any] = {
            "transport": "stdio",
            "agent": self.last_stdio_agent,
        }
        if self.last_stdio_agent_version:
            row["agent_version"] = self.last_stdio_agent_version
        if self.last_stdio_protocol_version:
            row["protocol_version"] = self.last_stdio_protocol_version
        self.catalog.activity_store.record("agent.client.disconnected", **row)
        self.last_stdio_agent = None
        self.last_stdio_agent_version = None
        self.last_stdio_protocol_version = None


def serve_operator_stdio(
    *,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> None:
    input_stream = stdin or sys.stdin
    output_stream = stdout or sys.stdout
    error_stream = stderr or sys.stderr
    server = MegasOperatorMCPServer(transport="stdio")

    for line in input_stream:
        text = line.strip()
        if not text:
            continue
        request_id: Any = None
        try:
            message = json.loads(text)
            if not isinstance(message, dict):
                raise ValueError("MCP message must be a JSON object")
            if message.get("jsonrpc") != "2.0":
                raise ValueError("MCP message must use jsonrpc 2.0")
            request_id = message.get("id")
            method = str(message.get("method") or "")
            if not method:
                raise ValueError("MCP message is missing method")
            params = message.get("params")
            if params is not None and not isinstance(params, dict):
                raise ValueError("MCP params must be a JSON object")
            result = server.dispatch(method, params)
            if request_id is None or result is None:
                continue
            response = _response(request_id, result=result)
        except KeyError as exc:
            if request_id is None:
                continue
            response = _response(
                request_id,
                error=_error(-32601, f"method not found or operator capability unavailable: {exc.args[0]}"),
            )
        except (ValueError, RuntimeError, TimeoutError, PermissionError, OSError) as exc:
            if request_id is None:
                print(f"Megas MCP operator request error: {type(exc).__name__}", file=error_stream, flush=True)
                continue
            response = _response(
                request_id,
                error=_error(-32602, str(exc), {"type": type(exc).__name__}),
            )
        except Exception as exc:
            if request_id is None:
                print(f"Megas MCP operator internal error: {type(exc).__name__}", file=error_stream, flush=True)
                continue
            response = _response(
                request_id,
                error=_error(-32603, "internal operator error", {"type": type(exc).__name__}),
            )
            print(
                "Megas MCP operator internal error:\n" + "".join(traceback.format_exception(exc)),
                file=error_stream,
                flush=True,
            )
        output_stream.write(json.dumps(response, separators=(",", ":"), ensure_ascii=False) + "\n")
        output_stream.flush()

    server.record_stdio_disconnect()


__all__ = [
    "AGENT_ACTIVITY_URI",
    "BROWSER_STATUS_URI",
    "MegasOperatorMCPServer",
    "OperatorCapabilityCatalog",
    "SURFACE_MAP_URI",
    "serve_operator_stdio",
]
