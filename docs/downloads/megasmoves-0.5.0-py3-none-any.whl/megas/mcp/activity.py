from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from ..bounded_io import read_bounded_bytes
from .activity_index import ActivityIndex
from .store import MCPStore
from .timeline import TimelineStore, ToolCall, redact


MAX_ACTIVITY_TAIL_BYTES = 8 * 1024 * 1024
MAX_ACTIVITY_RECORD_BYTES = 4 * 1024 * 1024
MAX_ACTIVITY_CALL_FILES = 512
ACTIVITY_SOURCES = (
    "Agent",
    "MCP",
    "Chitraagni",
    "Runtime",
    "Test",
    "Network",
)


def _clean(value: Any) -> Any:
    cleaned, _paths = redact(value)
    return cleaned


def _bounded_tail_lines(path: Path, *, max_bytes: int = MAX_ACTIVITY_TAIL_BYTES) -> list[bytes]:
    if not path.exists():
        return []
    if not path.is_file():
        raise ValueError(f"activity source is not a regular file: {path}")
    size = path.stat().st_size
    with path.open("rb") as handle:
        if size > max_bytes:
            handle.seek(size - max_bytes)
            chunk = handle.read(max_bytes)
            first_newline = chunk.find(b"\n")
            chunk = chunk[first_newline + 1 :] if first_newline >= 0 else b""
        else:
            chunk = handle.read(max_bytes + 1)
    if len(chunk) > max_bytes:
        raise ValueError(f"activity source exceeds bounded read limit: {path}")
    return chunk.splitlines()


def _tail_jsonl(path: Path, *, max_rows: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for raw in _bounded_tail_lines(path):
        if not raw.strip():
            continue
        if len(raw) > MAX_ACTIVITY_RECORD_BYTES:
            continue
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(value, dict):
            cleaned = _clean(value)
            if isinstance(cleaned, dict):
                rows.append(cleaned)
    return rows[-max(1, max_rows) :]


def _source_for(event: str, data: dict[str, Any]) -> str:
    haystack = " ".join(
        str(value or "")
        for value in (
            event,
            data.get("source"),
            data.get("server"),
            data.get("tool"),
            data.get("agent"),
            data.get("client"),
        )
    ).lower()
    if "chitraagni" in haystack:
        return "Chitraagni"
    if event.startswith(("test.", "tests.", "certification.")) or ".test." in event:
        return "Test"
    if (
        event.startswith(("runtime.", "workspace.runtime.", "native."))
        or str(data.get("source") or "").strip().lower() == "native"
    ):
        return "Runtime"
    if event.startswith(("network.", "http.")) or "network" in event:
        return "Network"
    if event.startswith("agent.") or data.get("agent") or data.get("client"):
        return "Agent"
    return "MCP"


def _severity_for(event: str, data: dict[str, Any]) -> str:
    text = " ".join(
        str(value or "")
        for value in (
            event,
            data.get("state"),
            data.get("status"),
            data.get("error"),
            data.get("reason"),
        )
    ).lower()
    if any(word in text for word in ("crash", "failed", "failure", "error", "rejected", "denied")):
        return "error"
    if any(word in text for word in ("cancel", "revoked", "degraded", "timeout", "missing", "warning")):
        return "warning"
    if any(word in text for word in ("passed", "completed", "success", "healthy")):
        return "success"
    return "info"


def _operation_id(data: dict[str, Any]) -> str | None:
    for key in (
        "operation_id",
        "correlation_id",
        "tool_call_id",
        "change_set_id",
        "session_id",
        "request_id",
    ):
        value = str(data.get(key) or "").strip()
        if value:
            return value
    return None


def _message(event: str, data: dict[str, Any]) -> str:
    server = str(data.get("server") or "").strip()
    tool = str(data.get("tool") or "").strip()
    project = str(data.get("project") or data.get("project_id") or "").strip()
    state = str(data.get("state") or data.get("status") or "").strip()
    if tool:
        parts = [part for part in (server, tool, state) if part]
        return " · ".join(parts)
    if project:
        return f"{event.replace('.', ' · ')} · {project}"
    return event.replace(".", " · ")


def _history_row(
    *,
    row_id: str,
    at: str,
    source: str,
    event: str,
    data: dict[str, Any],
    message: str | None = None,
    stream: str = "history",
) -> dict[str, Any]:
    return {
        "id": row_id,
        "at": at,
        "source": source,
        "severity": _severity_for(event, data),
        "event": event,
        "operation_id": _operation_id(data),
        "project": data.get("project") or data.get("project_id"),
        "session_id": data.get("session_id"),
        "tool_call_id": data.get("tool_call_id"),
        "server": data.get("server"),
        "tool": data.get("tool"),
        "duration_ms": data.get("duration_ms"),
        "message": message or _message(event, data),
        "details": data,
        "stream": stream,
    }


def _project_history_record(row: dict[str, Any], byte_offset: int) -> list[dict[str, Any]]:
    cleaned = _clean(row)
    if not isinstance(cleaned, dict):
        return []
    event = str(cleaned.get("event") or "history")
    at = str(cleaned.get("at") or "")
    data = {key: value for key, value in cleaned.items() if key not in {"at", "event"}}
    row_id = f"history:{byte_offset}"
    result: list[dict[str, Any]] = []

    agent = str(data.get("agent") or "").strip()
    if agent and event.endswith(".operation.started"):
        tool = str(data.get("tool") or "operation")
        result.append(
            _history_row(
                row_id=f"agent:{row_id}",
                at=at,
                source="Agent",
                event="agent.operation.requested",
                data=data,
                message=f"{agent} requested {tool}",
                stream="agent-projection",
            )
        )

    result.append(
        _history_row(
            row_id=row_id,
            at=at,
            source=_source_for(event, data),
            event=event,
            data=data,
        )
    )
    return result


def _project_timeline_record(row: dict[str, Any], byte_offset: int) -> list[dict[str, Any]]:
    cleaned = _clean(row)
    if not isinstance(cleaned, dict):
        return []
    data = cleaned.get("data") if isinstance(cleaned.get("data"), dict) else {}
    assert isinstance(data, dict)
    event = str(cleaned.get("type") or "timeline.event")
    merged = {
        **data,
        "source": cleaned.get("source"),
        "correlation_id": cleaned.get("correlation_id"),
        "session_id": cleaned.get("session_id"),
    }
    return [
        {
            "id": str(
                cleaned.get("id")
                or f"event:{cleaned.get('session_id')}:{cleaned.get('sequence')}:{byte_offset}"
            ),
            "at": str(cleaned.get("at") or ""),
            "source": _source_for(event, merged),
            "severity": _severity_for(event, merged),
            "event": event,
            "operation_id": _operation_id(merged),
            "project": merged.get("project") or merged.get("project_id"),
            "session_id": cleaned.get("session_id"),
            "tool_call_id": data.get("tool_call_id"),
            "server": data.get("server"),
            "tool": data.get("tool"),
            "duration_ms": data.get("duration_ms"),
            "message": _message(event, merged),
            "details": {
                "sequence": cleaned.get("sequence"),
                "correlation_id": cleaned.get("correlation_id"),
                "causation_id": cleaned.get("causation_id"),
                "source": cleaned.get("source"),
                "redacted": cleaned.get("redacted", False),
                "data": data,
            },
            "stream": "timeline-event",
        }
    ]


def _history_activity(store: MCPStore, *, limit: int) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index, row in enumerate(_tail_jsonl(store.history_path, max_rows=max(limit * 2, 100))):
        result.extend(_project_history_record(row, index))
    return result


def _timeline_event_activity(timeline: TimelineStore, *, limit: int) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index, row in enumerate(_tail_jsonl(timeline.events_path, max_rows=max(limit * 3, 200))):
        result.extend(_project_timeline_record(row, index))
    return result


def _recent_call_paths(timeline: TimelineStore) -> list[Path]:
    candidates: list[tuple[int, str, Path]] = []
    for path in timeline.calls_dir.glob("call_*.json"):
        try:
            stat = path.stat()
        except OSError:
            continue
        if not path.is_file():
            continue
        candidates.append((stat.st_mtime_ns, path.name, path))
    candidates.sort()
    return [item[2] for item in candidates[-MAX_ACTIVITY_CALL_FILES:]]


def _tool_call_activity(timeline: TimelineStore) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for path in _recent_call_paths(timeline):
        try:
            raw = read_bounded_bytes(path, max_bytes=MAX_ACTIVITY_RECORD_BYTES)
            row = json.loads(raw.decode("utf-8"))
            if not isinstance(row, dict):
                continue
            call = ToolCall.from_dict(row)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError, KeyError):
            continue
        clean = _clean(call.to_dict())
        if not isinstance(clean, dict):
            continue
        event = f"tool.{call.status}"
        data = {
            **clean,
            "tool_call_id": call.id,
            "correlation_id": call.correlation_id,
        }
        result.append(
            {
                "id": f"call:{call.id}",
                "at": call.ended_at or call.started_at,
                "source": _source_for(event, data),
                "severity": _severity_for(event, data),
                "event": event,
                "operation_id": call.correlation_id or call.id,
                "project": None,
                "session_id": call.session_id,
                "tool_call_id": call.id,
                "server": call.server,
                "tool": call.tool,
                "duration_ms": call.duration_ms,
                "message": _message(event, data),
                "details": clean,
                "stream": "tool-call",
            }
        )
    return result


def _matches_filters(
    row: dict[str, Any],
    *,
    allowed_sources: set[str] | None,
    errors_only: bool,
    needle: str,
) -> bool:
    if allowed_sources is not None and row["source"] not in allowed_sources:
        return False
    if errors_only and row["severity"] != "error":
        return False
    if needle:
        searchable = " ".join(
            str(row.get(key) or "")
            for key in (
                "source",
                "severity",
                "event",
                "operation_id",
                "project",
                "session_id",
                "server",
                "tool",
                "message",
            )
        ).lower()
        if needle not in searchable:
            return False
    return True


def _indexed_activity(
    store: MCPStore,
    timeline: TimelineStore,
    *,
    limit: int,
    allowed_sources: set[str] | None,
    errors_only: bool,
    needle: str,
) -> list[dict[str, Any]]:
    index = ActivityIndex(store.mcp_dir)
    index.sync(
        history_path=store.history_path,
        timeline_path=timeline.events_path,
        history_projector=_project_history_record,
        timeline_projector=_project_timeline_record,
    )
    return index.query(
        limit=limit,
        sources=allowed_sources,
        errors_only=errors_only,
        query=needle,
    )


def build_activity_feed(
    store: MCPStore,
    timeline: TimelineStore | None = None,
    *,
    limit: int = 200,
    sources: Iterable[str] | None = None,
    errors_only: bool = False,
    query: str = "",
) -> list[dict[str, Any]]:
    """Return a bounded, redacted, newest-first local observability feed.

    Canonical JSONL files remain authoritative. A versioned SQLite projection is
    incrementally synchronized for large histories; if the rebuildable index is
    unavailable or corrupt, Activity falls back to the bounded tail reader.
    """

    if not (1 <= int(limit) <= 5000):
        raise ValueError("activity limit must be between 1 and 5000")
    timeline = timeline or TimelineStore(store.mcp_dir)
    allowed_sources = None
    if sources is not None:
        allowed_sources = {str(value).strip() for value in sources if str(value).strip()}
        unknown = sorted(allowed_sources - set(ACTIVITY_SOURCES))
        if unknown:
            raise ValueError("unknown activity source(s): " + ", ".join(unknown))
    needle = query.strip().lower()

    try:
        rows = _indexed_activity(
            store,
            timeline,
            limit=int(limit),
            allowed_sources=allowed_sources,
            errors_only=errors_only,
            needle=needle,
        )
    except (sqlite3.Error, OSError, ValueError):
        # This is a cache failure, not an operator-state failure. Keep the product
        # useful from bounded canonical tails and let a later index open rebuild it.
        rows = [
            *_history_activity(store, limit=limit),
            *_timeline_event_activity(timeline, limit=limit),
        ]
        rows = [
            row
            for row in rows
            if _matches_filters(
                row,
                allowed_sources=allowed_sources,
                errors_only=errors_only,
                needle=needle,
            )
        ]

    rows.extend(
        row
        for row in _tool_call_activity(timeline)
        if _matches_filters(
            row,
            allowed_sources=allowed_sources,
            errors_only=errors_only,
            needle=needle,
        )
    )

    filtered: list[dict[str, Any]] = []
    seen: set[tuple[Any, ...]] = set()
    for row in rows:
        signature = (row.get("stream"), row.get("id"))
        if signature in seen:
            continue
        seen.add(signature)
        filtered.append(row)

    filtered.sort(key=lambda row: (str(row.get("at") or ""), str(row.get("id") or "")), reverse=True)
    return filtered[: int(limit)]


def latest_activity_summary(store: MCPStore, timeline: TimelineStore | None = None) -> str:
    rows = build_activity_feed(store, timeline, limit=1)
    if not rows:
        return "No activity yet — local core ready"
    row = rows[0]
    operation = str(row.get("operation_id") or "").strip()
    suffix = f" · {operation}" if operation else ""
    return f"[{row['source']}] {row['message']}{suffix}"


__all__ = [
    "ACTIVITY_SOURCES",
    "MAX_ACTIVITY_CALL_FILES",
    "MAX_ACTIVITY_RECORD_BYTES",
    "MAX_ACTIVITY_TAIL_BYTES",
    "build_activity_feed",
    "latest_activity_summary",
]
