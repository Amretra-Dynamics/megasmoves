from __future__ import annotations

import json
from typing import Any, Callable

from ..agent_connections import all_status, connect, disconnect, verify_megas_server
from ..operator_account import OperatorAccountStore
from . import desktop as desktop_module
from .activity import ACTIVITY_SOURCES, build_activity_feed, latest_activity_summary
from .desktop import MegasDesktopApp


PRIMARY_SURFACES = (
    "Agent",
    "Local Runtime",
    "Tests",
    "Logs",
    "Chitraagni Bridge",
)


def _desktop_navigation() -> tuple[str, ...]:
    existing = tuple(desktop_module.NAVIGATION)
    return (*PRIMARY_SURFACES, *(value for value in existing if value not in PRIMARY_SURFACES))


def format_activity_strip(row: dict[str, Any] | None) -> str:
    if not row:
        return "No activity yet — local core ready"
    source = str(row.get("source") or "MCP")
    message = str(row.get("message") or row.get("event") or "activity")
    operation = str(row.get("operation_id") or "").strip()
    severity = str(row.get("severity") or "info")
    marker = "ERROR" if severity == "error" else "WARN" if severity == "warning" else "LIVE"
    suffix = f" · {operation}" if operation else ""
    return f"{marker}  [{source}] {message}{suffix}"


class MegasDesktopObservabilityApp(MegasDesktopApp):
    """Megas desktop with first-class developer control/observability surfaces.

    The Logs UI is a projection over the canonical local store + timeline. It
    deliberately does not introduce a parallel log database or a chatbot-first UI.
    """

    def __init__(self, root: Any, controller: Any = None) -> None:
        self._logs_refresh_hook: Callable[[], None] | None = None
        self._activity_paused = False
        self._activity_after_id: Any = None
        # Base shell reads this module global while constructing the sidebar.
        desktop_module.NAVIGATION = _desktop_navigation()
        super().__init__(root, controller=controller)
        self.activity_var = self.tk.StringVar(value="LIVE  Local observability ready")
        self._install_activity_strip()
        self.show_surface("Agent")
        self._schedule_activity_tick()

    def _install_activity_strip(self) -> None:
        strip = self.tk.Frame(
            self.root,
            bg="#F6F8FA",
            height=34,
            highlightbackground=self.BORDER,
            highlightthickness=1,
        )
        strip.pack(side="bottom", fill="x")
        strip.pack_propagate(False)
        self.tk.Label(
            strip,
            textvariable=self.activity_var,
            bg="#F6F8FA",
            fg=self.TEXT,
            font=("Segoe UI", 9),
            anchor="w",
        ).pack(side="left", fill="x", expand=True, padx=14)
        self.tk.Button(
            strip,
            text="Open Logs",
            command=lambda: self.show_surface("Logs"),
            bg="#F6F8FA",
            fg=self.PRIMARY_DARK,
            activebackground="#E7F3F4",
            relief="flat",
            borderwidth=0,
            padx=12,
            font=("Segoe UI", 9, "bold"),
        ).pack(side="right", padx=8)

    def _schedule_activity_tick(self) -> None:
        try:
            self._activity_after_id = self.root.after(1250, self._activity_tick)
        except Exception:
            self._activity_after_id = None

    def _activity_tick(self) -> None:
        try:
            rows = build_activity_feed(
                self.controller.core.store,
                self.controller.core.timeline,
                limit=1,
            )
            self.activity_var.set(format_activity_strip(rows[0] if rows else None))
            if self.current_surface == "Logs" and not self._activity_paused and self._logs_refresh_hook:
                self._logs_refresh_hook()
        except Exception as exc:
            # Never place third-party error text in the persistent strip.
            self.activity_var.set(f"WARN  [MCP] activity refresh unavailable · {type(exc).__name__}")
        finally:
            self._schedule_activity_tick()

    def show_surface(self, surface: str) -> None:
        if surface not in PRIMARY_SURFACES:
            self._logs_refresh_hook = None
            super().show_surface(surface)
            return
        self.current_surface = surface
        self.surface_var.set(surface)
        self._set_nav(surface)
        self._clear()
        self._logs_refresh_hook = None
        renderers: dict[str, Callable[[], None]] = {
            "Agent": self._render_agent,
            "Local Runtime": self._render_local_runtime,
            "Tests": self._render_tests,
            "Logs": self._render_logs,
            "Chitraagni Bridge": self._render_chitraagni_bridge,
        }
        try:
            renderers[surface]()
            self.status_var.set("Ready — local core")
        except Exception as exc:
            self._render_error(exc)

    def _render_agent(self) -> None:
        self._heading(
            "Agent connections",
            "Connect local MCP-capable coding agents to this installed Megas runtime. Config changes require an explicit confirmation and are backed up before mutation.",
        )
        holder = self.tk.Frame(self.content, bg=self.BG)
        holder.pack(fill="both", expand=True)

        def render(rows: list[dict[str, Any]]) -> None:
            for child in holder.winfo_children():
                child.destroy()
            tree = self._tree(
                holder,
                [
                    ("client", "Agent", 150),
                    ("detected", "Detected", 100),
                    ("configured", "Megas connected", 130),
                    ("path", "Configuration", 520),
                ],
            )
            for row in rows:
                configured = row.get("megas_configured")
                configured_text = "Unknown" if configured is None else "Yes" if configured else "No"
                tree.insert(
                    "",
                    "end",
                    iid=str(row["client"]),
                    values=(
                        row["client"],
                        "Yes" if row.get("detected") else "No",
                        configured_text,
                        row.get("config_path") or "",
                    ),
                )
            controls = self.tk.Frame(holder, bg=self.BG)
            controls.pack(fill="x", pady=(10, 0))

            def selected() -> str:
                return self._selected_id(tree)

            def connect_selected() -> None:
                client = selected()
                if not self.messagebox.askyesno(
                    "Connect agent",
                    f"Connect {client} to Megas MCP? Megas will back up the client configuration before changing it.",
                ):
                    return
                self._background(
                    f"Connecting {client}…",
                    lambda: connect(client, yes=True, verify=True),
                    lambda result: self._agent_action_done(result, render),
                )

            def disconnect_selected() -> None:
                client = selected()
                if not self.messagebox.askyesno(
                    "Disconnect agent",
                    f"Remove the Megas MCP registration from {client}? A backup is created first.",
                ):
                    return
                self._background(
                    f"Disconnecting {client}…",
                    lambda: disconnect(client, yes=True),
                    lambda result: self._agent_action_done(result, render),
                )

            self._button(controls, "Connect selected", connect_selected)
            self._secondary_button(controls, "Disconnect selected", disconnect_selected)
            self._secondary_button(
                controls,
                "Verify Megas MCP",
                lambda: self._background(
                    "Verifying initialize/tools/resources…",
                    verify_megas_server,
                    lambda result: self._show_result("Megas MCP verification", result),
                ),
            )
            self._secondary_button(
                controls,
                "Refresh",
                lambda: self._background("Refreshing agent status…", all_status, render),
            )
            self.status_var.set("Agent status loaded")

        self._background("Detecting local MCP agents…", all_status, render)

    def _agent_action_done(self, result: dict[str, Any], render: Callable[[list[dict[str, Any]]], None]) -> None:
        self._show_result("Agent connection result", result)
        self._background("Refreshing agent status…", all_status, render)

    def _render_local_runtime(self) -> None:
        self._heading(
            "Local runtime",
            "Live status and lifecycle controls for registered local/remote MCP runtimes. This view does not contact remote servers merely to render status.",
        )
        rows = self.controller.core.list_servers()
        metrics = self.tk.Frame(self.content, bg=self.BG)
        metrics.pack(fill="x", pady=(0, 14))
        self._metric_card(metrics, "Configured", len(rows))
        self._metric_card(metrics, "Running", sum(row["runtime"].get("state") == "running" for row in rows))
        self._metric_card(metrics, "Degraded", sum(row["runtime"].get("state") == "degraded" for row in rows))
        tree = self._tree(
            self.content,
            [
                ("name", "Runtime", 190),
                ("transport", "Transport", 130),
                ("state", "State", 120),
                ("target", "Target", 500),
            ],
        )
        for row in rows:
            target = row.get("command") if row["transport"] == "stdio" else row.get("url")
            tree.insert(
                "",
                "end",
                iid=str(row["id"]),
                values=(row["name"], row["transport"], row["runtime"].get("state") or "", target or ""),
            )
        controls = self.tk.Frame(self.content, bg=self.BG)
        controls.pack(fill="x", pady=(10, 0))

        def act(action: str) -> None:
            server_id = self._selected_id(tree)
            operation = {
                "start": lambda: self.controller.core.start_server(server_id),
                "stop": lambda: self.controller.core.stop_server(server_id),
                "restart": lambda: self.controller.core.restart_server(server_id),
            }[action]
            self._background(
                f"{action.title()}ing runtime…",
                operation,
                lambda _result: self.show_surface("Local Runtime"),
            )

        self._button(controls, "Start", lambda: act("start"))
        self._secondary_button(controls, "Stop", lambda: act("stop"))
        self._secondary_button(controls, "Restart", lambda: act("restart"))
        self._secondary_button(controls, "Refresh", lambda: self.show_surface("Local Runtime"))
        if not rows:
            self.tk.Label(
                self.content,
                text="No MCP runtimes are registered. Add a server from the Servers control surface.",
                bg=self.BG,
                fg=self.MUTED,
                font=("Segoe UI", 10),
            ).pack(anchor="w", pady=12)

    def _activity_table(self, parent: Any, rows: list[dict[str, Any]], *, detail_height: int = 10) -> Any:
        tree = self._tree(
            parent,
            [
                ("at", "Time", 175),
                ("source", "Source", 105),
                ("severity", "State", 85),
                ("operation", "Operation", 190),
                ("message", "Event", 430),
                ("duration", "ms", 70),
            ],
        )
        mapping: dict[str, dict[str, Any]] = {}
        for index, row in enumerate(rows):
            iid = f"activity-{index}"
            mapping[iid] = row
            tree.insert(
                "",
                "end",
                iid=iid,
                values=(
                    str(row.get("at") or ""),
                    row.get("source") or "",
                    row.get("severity") or "",
                    row.get("operation_id") or "",
                    row.get("message") or "",
                    row.get("duration_ms") if row.get("duration_ms") is not None else "",
                ),
            )
        detail = self.tk.Frame(parent, bg=self.BG)
        detail.pack(fill="both", expand=False, pady=(10, 0))

        def inspect(_event: Any = None) -> None:
            for child in detail.winfo_children():
                child.destroy()
            selection = tree.selection()
            if not selection:
                return
            row = mapping.get(str(selection[0]))
            if row is not None:
                self._json_text(detail, row, height=detail_height)

        tree.bind("<<TreeviewSelect>>", inspect)
        return tree

    def _render_tests(self) -> None:
        self._heading(
            "Tests",
            "Structured test/certification events captured by Megas. Test results stay linked to operation evidence rather than being reduced to terminal output.",
        )
        rows = build_activity_feed(
            self.controller.core.store,
            self.controller.core.timeline,
            limit=300,
            sources={"Test"},
        )
        if rows:
            self._activity_table(self.content, rows, detail_height=12)
        else:
            self.tk.Label(
                self.content,
                text="No structured test events have been recorded yet. Runtime/MCP activity remains available in Logs.",
                bg=self.BG,
                fg=self.MUTED,
                font=("Segoe UI", 10),
            ).pack(anchor="w", pady=12)
        controls = self.tk.Frame(self.content, bg=self.BG)
        controls.pack(fill="x", pady=(10, 0))
        self._secondary_button(controls, "Refresh", lambda: self.show_surface("Tests"))

    def _render_logs(self) -> None:
        self._heading(
            "Realtime logs",
            "Structured, redacted local activity correlated across agents, MCP calls, Chitraagni, runtimes, tests and network boundaries. Raw terminal spam is intentionally not the primary view.",
        )
        controls = self.tk.Frame(self.content, bg=self.BG)
        controls.pack(fill="x", pady=(0, 10))
        filter_box = self.ttk.Combobox(
            controls,
            values=("Live", "Errors", *ACTIVITY_SOURCES),
            state="readonly",
            width=18,
            style="Megas.TCombobox",
        )
        filter_box.set("Live")
        filter_box.pack(side="left", padx=(0, 8))
        search = self.tk.Entry(
            controls,
            bg=self.BG,
            fg=self.TEXT,
            relief="solid",
            borderwidth=1,
            font=("Segoe UI", 10),
        )
        search.pack(side="left", fill="x", expand=True, padx=(0, 8), ipady=5)
        search.insert(0, "")
        pause_button = self.tk.Button(
            controls,
            text="Pause",
            bg=self.BG,
            fg=self.TEXT,
            relief="solid",
            borderwidth=1,
            padx=12,
            pady=5,
            font=("Segoe UI", 9),
        )
        pause_button.pack(side="left")
        holder = self.tk.Frame(self.content, bg=self.BG)
        holder.pack(fill="both", expand=True)

        def refresh() -> None:
            if self.current_surface != "Logs":
                return
            selected = filter_box.get().strip() or "Live"
            sources = None if selected in {"Live", "Errors"} else {selected}
            rows = build_activity_feed(
                self.controller.core.store,
                self.controller.core.timeline,
                limit=500,
                sources=sources,
                errors_only=selected == "Errors",
                query=search.get(),
            )
            for child in holder.winfo_children():
                child.destroy()
            if rows:
                self._activity_table(holder, rows, detail_height=11)
            else:
                self.tk.Label(
                    holder,
                    text="No activity matches this filter.",
                    bg=self.BG,
                    fg=self.MUTED,
                    font=("Segoe UI", 10),
                ).pack(anchor="w", pady=12)
            self.status_var.set(f"Logs · {len(rows)} structured event(s)")

        def toggle_pause() -> None:
            self._activity_paused = not self._activity_paused
            pause_button.configure(text="Resume" if self._activity_paused else "Pause")
            self.status_var.set("Live log refresh paused" if self._activity_paused else "Live log refresh resumed")
            if not self._activity_paused:
                refresh()

        pause_button.configure(command=toggle_pause)
        filter_box.bind("<<ComboboxSelected>>", lambda _event: refresh())
        search.bind("<Return>", lambda _event: refresh())
        self._logs_refresh_hook = refresh
        refresh()

    def _render_chitraagni_bridge(self) -> None:
        self._heading(
            "Chitraagni Bridge",
            "Megas talks to Chitraagni through its service/API boundary. Chitraagni owns project/database semantics; Megas owns agent transport, permissions and observability.",
        )
        account = OperatorAccountStore()
        status = account.status(verify=False)
        summary = self.tk.Frame(self.content, bg=self.PANEL, highlightbackground=self.BORDER, highlightthickness=1)
        summary.pack(fill="x", pady=(0, 12))
        values = [
            ("Linked", "Yes" if status.get("chitraagni_linked") else "No"),
            ("API", status.get("api_base") or "Not linked"),
            ("Credential", status.get("credential_kind") or "None"),
            ("Credential available", "Yes" if status.get("token_available") else "No"),
        ]
        for label, value in values:
            row = self.tk.Frame(summary, bg=self.PANEL)
            row.pack(fill="x", padx=14, pady=5)
            self.tk.Label(row, text=label, width=22, anchor="w", bg=self.PANEL, fg=self.MUTED).pack(side="left")
            self.tk.Label(row, text=str(value), anchor="w", bg=self.PANEL, fg=self.TEXT, font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True)

        controls = self.tk.Frame(self.content, bg=self.BG)
        controls.pack(fill="x", pady=(0, 10))
        if status.get("chitraagni_linked"):
            self._button(
                controls,
                "Verify identity",
                lambda: self._background(
                    "Verifying linked Chitraagni identity…",
                    lambda: account.status(verify=True),
                    lambda result: self._show_result("Chitraagni identity", result),
                ),
            )
        self._secondary_button(controls, "Refresh", lambda: self.show_surface("Chitraagni Bridge"))

        rows = build_activity_feed(
            self.controller.core.store,
            self.controller.core.timeline,
            limit=150,
            sources={"Chitraagni"},
        )
        self.tk.Label(
            self.content,
            text="Recent Chitraagni operations",
            bg=self.BG,
            fg=self.TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", pady=(6, 6))
        if rows:
            self._activity_table(self.content, rows, detail_height=8)
        else:
            self.tk.Label(
                self.content,
                text="No Chitraagni operations have been observed in the local Megas timeline yet.",
                bg=self.BG,
                fg=self.MUTED,
                font=("Segoe UI", 10),
            ).pack(anchor="w", pady=8)


__all__ = [
    "MegasDesktopObservabilityApp",
    "PRIMARY_SURFACES",
    "format_activity_strip",
]
