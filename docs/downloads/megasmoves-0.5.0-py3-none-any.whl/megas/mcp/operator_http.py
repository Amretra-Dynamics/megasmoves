from __future__ import annotations

import argparse
import hmac
import json
import os
import ssl
import sys
from dataclasses import dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

from .operator_server import (
    LEGACY_PROTOCOLS,
    MODERN_PROTOCOL,
    PROTOCOL_META_KEY,
    MegasOperatorMCPServer,
    _error,
    _response,
)


MAX_HTTP_REQUEST_BYTES = 4 * 1024 * 1024
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
PRINCIPAL_METHODS = {
    "tools/call": "name",
    "resources/read": "uri",
    "prompts/get": "name",
}


def _is_loopback_host(value: str) -> bool:
    host = str(value or "").strip().lower()
    return host in LOOPBACK_HOSTS


def _host_from_header(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if text.startswith("["):
        end = text.find("]")
        return text[1:end].lower() if end > 0 else ""
    return text.split(":", 1)[0].lower()


def _origin_key(value: str) -> str:
    parsed = urlsplit(str(value or "").strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("allowed origin must be an absolute http(s) origin")
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise ValueError("allowed origin must not contain path, query, or fragment")
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    return f"{parsed.scheme.lower()}://{parsed.hostname.lower()}:{port}"


@dataclass(slots=True)
class OperatorHTTPConfig:
    host: str = "127.0.0.1"
    port: int = 8765
    bearer_env: str | None = None
    tls_cert: str | None = None
    tls_key: str | None = None
    allowed_origins: tuple[str, ...] = ()
    max_request_bytes: int = MAX_HTTP_REQUEST_BYTES
    _bearer_token: str | None = field(default=None, init=False, repr=False)
    _allowed_origin_keys: frozenset[str] = field(default_factory=frozenset, init=False, repr=False)

    def validate(self) -> None:
        self.host = str(self.host or "").strip()
        if not self.host:
            raise ValueError("HTTP host must be non-empty")
        self.port = int(self.port)
        if not (0 <= self.port <= 65535):
            raise ValueError("HTTP port must be between 0 and 65535")
        self.max_request_bytes = int(self.max_request_bytes)
        if not (1024 <= self.max_request_bytes <= 32 * 1024 * 1024):
            raise ValueError("max_request_bytes must be between 1 KiB and 32 MiB")

        if bool(self.tls_cert) != bool(self.tls_key):
            raise ValueError("TLS requires both --tls-cert and --tls-key")

        self._allowed_origin_keys = frozenset(_origin_key(value) for value in self.allowed_origins)
        token = None
        if self.bearer_env:
            env_name = str(self.bearer_env).strip()
            if not env_name:
                raise ValueError("bearer environment name must be non-empty")
            token = os.environ.get(env_name, "").strip()
            if not token:
                raise RuntimeError(f"required bearer environment variable is not set: {env_name}")
            self.bearer_env = env_name
        self._bearer_token = token

        if not _is_loopback_host(self.host):
            if not self.tls_cert or not self.tls_key:
                raise PermissionError("non-loopback MegasMCP HTTP requires TLS certificate and key")
            if not self._bearer_token:
                raise PermissionError("non-loopback MegasMCP HTTP requires bearer authentication")
            if not self._allowed_origin_keys:
                raise PermissionError("non-loopback MegasMCP HTTP requires at least one explicit allowed origin")

    @property
    def loopback(self) -> bool:
        return _is_loopback_host(self.host)

    @property
    def bearer_token(self) -> str | None:
        return self._bearer_token

    def origin_allowed(self, value: str | None) -> bool:
        if not value:
            return True
        try:
            key = _origin_key(value)
        except ValueError:
            return False
        if key in self._allowed_origin_keys:
            return True
        if self.loopback:
            parsed = urlsplit(value)
            return bool(parsed.hostname and _is_loopback_host(parsed.hostname))
        return False


class OperatorHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        server_address: tuple[str, int],
        handler_class: type[BaseHTTPRequestHandler],
        *,
        operator: MegasOperatorMCPServer,
        config: OperatorHTTPConfig,
    ) -> None:
        self.operator = operator
        self.config = config
        super().__init__(server_address, handler_class)


class OperatorHTTPHandler(BaseHTTPRequestHandler):
    server: OperatorHTTPServer
    protocol_version = "HTTP/1.1"
    server_version = "MegasMCP/0.5.0"
    sys_version = ""

    def log_message(self, format: str, *args: Any) -> None:
        # Avoid echoing request payloads, credentials, or Chitraagni data to an
        # implicit console log. Operational logging can be added explicitly.
        return

    def _json_headers(self, status: int, length: int) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()

    def _write_json(self, status: int, value: Any) -> None:
        encoded = json.dumps(value, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
        self._json_headers(status, len(encoded))
        self.wfile.write(encoded)

    def _write_empty(self, status: int) -> None:
        self.send_response(status)
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _request_error(self, request_id: Any, code: int, message: str, *, status: int = 400) -> None:
        self._write_json(status, _response(request_id, error=_error(code, message)))

    def _validate_network_boundary(self) -> bool:
        host = _host_from_header(self.headers.get("Host", ""))
        if self.server.config.loopback and host not in LOOPBACK_HOSTS:
            self._write_json(HTTPStatus.FORBIDDEN, {"error": "invalid Host header for loopback MegasMCP"})
            return False
        if not self.server.config.origin_allowed(self.headers.get("Origin")):
            self._write_json(HTTPStatus.FORBIDDEN, {"error": "Origin is not allowed"})
            return False
        token = self.server.config.bearer_token
        if token is not None:
            header = self.headers.get("Authorization", "")
            supplied = header[7:].strip() if header.lower().startswith("bearer ") else ""
            if not supplied or not hmac.compare_digest(supplied, token):
                self.send_response(HTTPStatus.UNAUTHORIZED)
                self.send_header("WWW-Authenticate", 'Bearer realm="MegasMCP"')
                self.send_header("Content-Length", "0")
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                return False
        return True

    def _modern_headers_match(self, message: dict[str, Any]) -> tuple[bool, str | None]:
        method = str(message.get("method") or "")
        params = message.get("params")
        if not isinstance(params, dict):
            params = {}
        meta = params.get("_meta")
        body_version = meta.get(PROTOCOL_META_KEY) if isinstance(meta, dict) else None
        header_version = (self.headers.get("MCP-Protocol-Version") or "").strip()
        modern = body_version == MODERN_PROTOCOL or header_version == MODERN_PROTOCOL or method == "server/discover"
        if not modern:
            if header_version and header_version not in LEGACY_PROTOCOLS:
                return False, f"unsupported MCP-Protocol-Version header: {header_version}"
            return True, None
        if header_version != MODERN_PROTOCOL:
            return False, f"modern MCP requires MCP-Protocol-Version: {MODERN_PROTOCOL}"
        if body_version != MODERN_PROTOCOL:
            return False, "modern MCP header/body protocol version mismatch"
        method_header = (self.headers.get("Mcp-Method") or "").strip()
        if method_header != method:
            return False, "Mcp-Method header does not match JSON-RPC method"
        principal_field = PRINCIPAL_METHODS.get(method)
        if principal_field:
            expected = str(params.get(principal_field) or "").strip()
            principal = (self.headers.get("Mcp-Name") or "").strip()
            if not expected or principal != expected:
                return False, f"Mcp-Name header does not match {principal_field}"
        return True, None

    def do_GET(self) -> None:
        if self.path == "/healthz":
            if not self._validate_network_boundary():
                return
            self._write_json(HTTPStatus.OK, {"status": "ok", "server": "MegasMCP"})
            return
        if self.path == "/mcp":
            self._write_empty(HTTPStatus.METHOD_NOT_ALLOWED)
            return
        self._write_empty(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        if self.path != "/mcp":
            self._write_empty(HTTPStatus.NOT_FOUND)
            return
        if not self._validate_network_boundary():
            return
        content_type = (self.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            self._write_json(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, {"error": "Content-Type must be application/json"})
            return
        try:
            content_length = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            self._write_json(HTTPStatus.BAD_REQUEST, {"error": "invalid Content-Length"})
            return
        if content_length <= 0 or content_length > self.server.config.max_request_bytes:
            status = HTTPStatus.REQUEST_ENTITY_TOO_LARGE if content_length > self.server.config.max_request_bytes else HTTPStatus.BAD_REQUEST
            self._write_json(status, {"error": "invalid or oversized request body"})
            return
        raw = self.rfile.read(content_length)
        request_id: Any = None
        try:
            message = json.loads(raw.decode("utf-8"))
            if not isinstance(message, dict):
                raise ValueError("MCP message must be a JSON object")
            request_id = message.get("id")
            if message.get("jsonrpc") != "2.0":
                raise ValueError("MCP message must use jsonrpc 2.0")
            method = str(message.get("method") or "").strip()
            if not method:
                raise ValueError("MCP message is missing method")
            params = message.get("params")
            if params is not None and not isinstance(params, dict):
                raise ValueError("MCP params must be a JSON object")
            matched, mismatch = self._modern_headers_match(message)
            if not matched:
                self._request_error(request_id, -32020, mismatch or "MCP header mismatch")
                return
            result = self.server.operator.dispatch(method, params)
            if request_id is None or result is None:
                self._write_empty(HTTPStatus.ACCEPTED)
                return
            self._write_json(HTTPStatus.OK, _response(request_id, result=result))
        except json.JSONDecodeError:
            self._request_error(None, -32700, "Parse error")
        except KeyError as exc:
            self._request_error(request_id, -32601, f"method not found or operator capability unavailable: {exc.args[0]}")
        except (ValueError, RuntimeError, TimeoutError, PermissionError, OSError) as exc:
            self._request_error(request_id, -32602, str(exc))
        except Exception:
            self._request_error(request_id, -32603, "internal operator error", status=500)


def create_operator_http_server(
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    bearer_env: str | None = None,
    tls_cert: str | None = None,
    tls_key: str | None = None,
    allowed_origins: tuple[str, ...] | list[str] = (),
    operator: MegasOperatorMCPServer | None = None,
) -> OperatorHTTPServer:
    config = OperatorHTTPConfig(
        host=host,
        port=port,
        bearer_env=bearer_env,
        tls_cert=tls_cert,
        tls_key=tls_key,
        allowed_origins=tuple(allowed_origins),
    )
    config.validate()
    server = OperatorHTTPServer(
        (config.host, config.port),
        OperatorHTTPHandler,
        operator=operator or MegasOperatorMCPServer(),
        config=config,
    )
    if config.tls_cert and config.tls_key:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(config.tls_cert, config.tls_key)
        server.socket = context.wrap_socket(server.socket, server_side=True)
    return server


def serve_operator_http(**kwargs: Any) -> None:
    server = create_operator_http_server(**kwargs)
    scheme = "https" if server.config.tls_cert else "http"
    host, port = server.server_address[:2]
    print(f"MegasMCP Streamable HTTP: {scheme}://{host}:{port}/mcp", file=sys.stderr, flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        server.server_close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="megas serve-http",
        description="Serve the account-scoped MegasMCP operator over stateless Streamable HTTP.",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--bearer-env", help="environment variable containing the HTTP bearer secret")
    parser.add_argument("--tls-cert", help="PEM TLS certificate path")
    parser.add_argument("--tls-key", help="PEM TLS private-key path")
    parser.add_argument("--allow-origin", action="append", default=[], help="explicit allowed browser origin; repeat as needed")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(list(sys.argv[1:] if argv is None else argv))
    try:
        serve_operator_http(
            host=args.host,
            port=args.port,
            bearer_env=args.bearer_env,
            tls_cert=args.tls_cert,
            tls_key=args.tls_key,
            allowed_origins=tuple(args.allow_origin),
        )
    except (ValueError, RuntimeError, PermissionError, OSError, ssl.SSLError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


__all__ = [
    "MAX_HTTP_REQUEST_BYTES",
    "OperatorHTTPConfig",
    "OperatorHTTPHandler",
    "OperatorHTTPServer",
    "build_parser",
    "create_operator_http_server",
    "main",
    "serve_operator_http",
]
