from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import time
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Event
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import Request

from .chitraagni_http import urlopen


AMRETRA_PLATFORM_BASE = os.environ.get(
    "MEGAS_AMRETRA_PLATFORM_BASE_URL",
    "https://account.amretra.com/api/platform",
).rstrip("/")
AMRETRA_CLIENT_ID = os.environ.get(
    "MEGAS_AMRETRA_CHITRAAGNI_CLIENT_ID",
    "chitraagni-megas-local",
).strip()
AMRETRA_REDIRECT_URI = os.environ.get(
    "MEGAS_AMRETRA_REDIRECT_URI",
    "http://127.0.0.1:38473/amretra/callback",
).strip()
AMRETRA_SCOPE = "openid profile email"
CREDENTIAL_FORMAT = "megas-amretra-chitraagni-oauth"
CREDENTIAL_VERSION = 1
DEFAULT_LOGIN_TIMEOUT_SECONDS = 180.0
REFRESH_EARLY_SECONDS = 60
MAX_TOKEN_RESPONSE_BYTES = 1024 * 1024
MAX_TOKEN_REQUEST_BYTES = 64 * 1024


@dataclass(frozen=True)
class OAuthCredentialBundle:
    access_token: str
    refresh_token: str
    expires_at: int
    client_id: str = AMRETRA_CLIENT_ID
    token_type: str = "Bearer"
    scope: str = AMRETRA_SCOPE

    def validate(self) -> None:
        if not self.access_token.strip():
            raise ValueError("Amretra access token is missing")
        if not self.refresh_token.strip():
            raise ValueError("Amretra refresh token is missing")
        if not self.client_id.strip():
            raise ValueError("Amretra OAuth client ID is missing")
        if self.expires_at <= 0:
            raise ValueError("Amretra access token expiry is invalid")

    def to_secret(self) -> str:
        self.validate()
        return json.dumps(
            {
                "format": CREDENTIAL_FORMAT,
                "version": CREDENTIAL_VERSION,
                "access_token": self.access_token,
                "refresh_token": self.refresh_token,
                "expires_at": self.expires_at,
                "client_id": self.client_id,
                "token_type": self.token_type,
                "scope": self.scope,
            },
            sort_keys=True,
            separators=(",", ":"),
        )

    @classmethod
    def from_secret(cls, secret: str) -> "OAuthCredentialBundle":
        try:
            payload = json.loads(str(secret or ""))
        except json.JSONDecodeError as exc:
            raise ValueError("stored Amretra credential bundle is malformed") from exc
        if not isinstance(payload, dict):
            raise ValueError("stored Amretra credential bundle must be an object")
        if payload.get("format") != CREDENTIAL_FORMAT:
            raise ValueError("stored credential is not an Amretra Chitraagni OAuth bundle")
        if int(payload.get("version") or 0) != CREDENTIAL_VERSION:
            raise ValueError("unsupported Amretra credential bundle version")
        bundle = cls(
            access_token=str(payload.get("access_token") or ""),
            refresh_token=str(payload.get("refresh_token") or ""),
            expires_at=int(payload.get("expires_at") or 0),
            client_id=str(payload.get("client_id") or ""),
            token_type=str(payload.get("token_type") or "Bearer"),
            scope=str(payload.get("scope") or ""),
        )
        bundle.validate()
        return bundle


def _pkce_verifier() -> str:
    return secrets.token_urlsafe(64)


def _pkce_challenge(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def _oauth_url(path: str) -> str:
    parsed = urlsplit(AMRETRA_PLATFORM_BASE)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in {"http", "https"} or not host:
        raise ValueError("Amretra platform URL must be absolute http(s)")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Amretra platform URL must not contain credentials, query or fragment")
    if parsed.scheme == "http" and host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("remote Amretra token traffic must use https")
    try:
        parsed.port
    except ValueError as exc:
        raise ValueError("Amretra platform URL has an invalid port") from exc
    return f"{AMRETRA_PLATFORM_BASE}/v1/oauth/{path.lstrip('/')}"


def _post_token(body: dict[str, Any], timeout: float = 15.0) -> dict[str, Any]:
    if not (0 < float(timeout) <= 120):
        raise ValueError("Amretra token timeout must be between 0 and 120 seconds")
    payload = json.dumps(body, separators=(",", ":")).encode("utf-8")
    if len(payload) > MAX_TOKEN_REQUEST_BYTES:
        raise ValueError("Amretra token request exceeded the size limit")
    request = Request(
        _oauth_url("token"),
        data=payload,
        method="POST",
        headers={"Accept": "application/json", "Content-Type": "application/json"},
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            raw = response.read(MAX_TOKEN_RESPONSE_BYTES + 1)
    except HTTPError as exc:
        # Upstream error bodies and redirect locations can reflect OAuth codes,
        # refresh tokens or user details. Only a bounded numeric status is safe
        # for the operator's visible diagnostics.
        try:
            exc.read(4096)
        except Exception:
            pass
        if 300 <= int(exc.code) < 400:
            raise RuntimeError("Amretra token endpoint redirect rejected") from exc
        raise RuntimeError(f"Amretra token exchange failed (HTTP {int(exc.code)})") from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise RuntimeError("Amretra token endpoint unavailable") from exc
    if len(raw) > MAX_TOKEN_RESPONSE_BYTES:
        raise RuntimeError("Amretra token response exceeded the size limit")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Amretra token endpoint returned invalid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError("Amretra token endpoint returned an invalid response")
    return value


def _bundle_from_token_response(payload: dict[str, Any], *, previous_refresh: str | None = None) -> OAuthCredentialBundle:
    access_token = str(payload.get("access_token") or "").strip()
    refresh_token = str(payload.get("refresh_token") or previous_refresh or "").strip()
    try:
        expires_in = int(payload.get("expires_in") or 0)
    except (ValueError, TypeError, OverflowError) as exc:
        raise RuntimeError("Amretra token response has invalid expiry") from exc
    if not access_token or not refresh_token or expires_in <= 0:
        raise RuntimeError("Amretra token response is incomplete")
    bundle = OAuthCredentialBundle(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_at=int(time.time()) + expires_in,
        client_id=AMRETRA_CLIENT_ID,
        token_type=str(payload.get("token_type") or "Bearer"),
        scope=str(payload.get("scope") or AMRETRA_SCOPE),
    )
    bundle.validate()
    return bundle


def refresh_credential(bundle: OAuthCredentialBundle, *, timeout: float = 15.0) -> OAuthCredentialBundle:
    bundle.validate()
    if bundle.client_id != AMRETRA_CLIENT_ID:
        raise PermissionError("stored Amretra credential belongs to a different OAuth client")
    payload = _post_token(
        {
            "grant_type": "refresh_token",
            "client_id": bundle.client_id,
            "refresh_token": bundle.refresh_token,
        },
        timeout=timeout,
    )
    return _bundle_from_token_response(payload, previous_refresh=bundle.refresh_token)


def current_access_token(credential_store: Any, *, timeout: float = 15.0) -> str:
    bundle = OAuthCredentialBundle.from_secret(credential_store.read())
    if bundle.expires_at <= int(time.time()) + REFRESH_EARLY_SECONDS:
        bundle = refresh_credential(bundle, timeout=timeout)
        credential_store.write(bundle.to_secret())
    return bundle.access_token


class _OAuthCallback:
    def __init__(self, *, expected_state: str) -> None:
        self.expected_state = expected_state
        self.code: str | None = None
        self.error: str | None = None
        self.completed = Event()


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    callback: _OAuthCallback

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlsplit(self.path)
        if parsed.path != "/amretra/callback":
            self.send_response(404)
            self.end_headers()
            return

        query = parse_qs(parsed.query)
        state = str((query.get("state") or [""])[0])
        if not secrets.compare_digest(state, self.callback.expected_state):
            self.callback.error = "state_mismatch"
            self._finish(400, "Megas rejected this sign-in response because its state did not match.")
            return

        error = str((query.get("error") or [""])[0]).strip()
        code = str((query.get("code") or [""])[0]).strip()
        if error:
            self.callback.error = error
            self._finish(400, "Amretra sign-in was not completed. You can close this tab.")
            return
        if not code:
            self.callback.error = "missing_code"
            self._finish(400, "Amretra returned no authorization code. You can close this tab.")
            return

        self.callback.code = code
        self._finish(200, "Amretra sign-in completed for Megas. You can close this tab.")

    def _finish(self, status_code: int, message: str) -> None:
        payload = (
            "<!doctype html><html><head><meta charset='utf-8'><title>Megas</title></head>"
            "<body style='font-family:system-ui;background:#fff;color:#171717;padding:48px'>"
            f"<h1>{message}</h1><p>Return to MegasMoves.</p></body></html>"
        ).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)
        self.callback.completed.set()

    def log_message(self, format: str, *args: Any) -> None:
        # OAuth codes/state must never be copied into normal local logs.
        return


def interactive_login(*, timeout: float = DEFAULT_LOGIN_TIMEOUT_SECONDS) -> OAuthCredentialBundle:
    redirect = urlsplit(AMRETRA_REDIRECT_URI)
    if redirect.scheme != "http" or redirect.hostname != "127.0.0.1" or not redirect.port:
        raise ValueError("Megas Amretra redirect URI must be fixed to an explicit 127.0.0.1 loopback port")
    if redirect.path != "/amretra/callback" or redirect.query or redirect.fragment:
        raise ValueError("Megas Amretra redirect URI must end at /amretra/callback without query or fragment")

    verifier = _pkce_verifier()
    state = secrets.token_urlsafe(32)
    nonce = secrets.token_urlsafe(32)
    callback = _OAuthCallback(expected_state=state)

    handler_type = type("MegasAmretraCallbackHandler", (_OAuthCallbackHandler,), {"callback": callback})
    try:
        server = HTTPServer(("127.0.0.1", redirect.port), handler_type)
    except OSError as exc:
        raise RuntimeError(
            f"Megas cannot open its Amretra callback on 127.0.0.1:{redirect.port}; close the process using that port and retry"
        ) from exc
    server.timeout = 0.25

    query = urlencode({
        'response_type': 'code',
        'client_id': AMRETRA_CLIENT_ID,
        'redirect_uri': AMRETRA_REDIRECT_URI,
        'code_challenge': _pkce_challenge(verifier),
        'code_challenge_method': 'S256',
        'state': state,
        'nonce': nonce,
        'scope': AMRETRA_SCOPE,
    })
    authorize_url = f"{_oauth_url('authorize')}?{query}"

    opened = webbrowser.open(authorize_url, new=1, autoraise=True)
    if not opened:
        server.server_close()
        raise RuntimeError("Megas could not open the system browser for Amretra sign-in")

    deadline = time.monotonic() + max(1.0, float(timeout))
    try:
        while not callback.completed.is_set() and time.monotonic() < deadline:
            server.handle_request()
    finally:
        server.server_close()

    if not callback.completed.is_set():
        raise TimeoutError("Amretra sign-in timed out before the loopback callback completed")
    if callback.error:
        raise PermissionError(f"Amretra sign-in failed: {callback.error}")
    if not callback.code:
        raise RuntimeError("Amretra sign-in completed without an authorization code")

    payload = _post_token(
        {
            "grant_type": "authorization_code",
            "client_id": AMRETRA_CLIENT_ID,
            "redirect_uri": AMRETRA_REDIRECT_URI,
            "code": callback.code,
            "code_verifier": verifier,
        },
        timeout=min(15.0, max(1.0, float(timeout))),
    )
    return _bundle_from_token_response(payload)


__all__ = [
    "AMRETRA_CLIENT_ID",
    "AMRETRA_PLATFORM_BASE",
    "AMRETRA_REDIRECT_URI",
    "CREDENTIAL_FORMAT",
    "CREDENTIAL_VERSION",
    "OAuthCredentialBundle",
    "current_access_token",
    "interactive_login",
    "refresh_credential",
]
