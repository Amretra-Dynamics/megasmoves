"""Detect host OS identity for product Worker listings and fleet analytics.

Reports privacy-safe platform facts only (no paths, users, or secrets):
Windows / macOS / Linux, WSL, distro id/name/version, default shell.
"""

from __future__ import annotations

import os
import platform
import re
import shutil
import sys
from pathlib import Path
from typing import Any


_OS_RELEASE_KEYS = (
    "ID",
    "ID_LIKE",
    "NAME",
    "PRETTY_NAME",
    "VERSION_ID",
    "VERSION",
    "VERSION_CODENAME",
)


def _read_os_release() -> dict[str, str]:
    path = Path("/etc/os-release")
    if not path.is_file():
        path = Path("/usr/lib/os-release")
    if not path.is_file():
        return {}
    data: dict[str, str] = {}
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key in _OS_RELEASE_KEYS and value:
                data[key] = value[:120]
    except OSError:
        return {}
    return data


def _is_wsl() -> bool:
    if os.environ.get("WSL_DISTRO_NAME") or os.environ.get("WSL_INTEROP"):
        return True
    try:
        version = Path("/proc/version").read_text(encoding="utf-8", errors="replace").lower()
    except OSError:
        return False
    return "microsoft" in version or "wsl" in version


def _detect_shell(system: str) -> tuple[str, str]:
    """Return (shell_id, shell_label) e.g. ('powershell', 'PowerShell')."""
    system_l = system.lower()
    if system_l.startswith("win"):
        # Prefer PowerShell 7, then Windows PowerShell, then cmd.
        if shutil.which("pwsh") or shutil.which("pwsh.exe"):
            return "pwsh", "PowerShell 7"
        if shutil.which("powershell") or shutil.which("powershell.exe"):
            return "powershell", "PowerShell"
        return "cmd", "cmd"
    shell_path = str(os.environ.get("SHELL") or "").strip()
    if shell_path:
        name = Path(shell_path).name.lower()
        labels = {
            "bash": "bash",
            "zsh": "zsh",
            "fish": "fish",
            "sh": "sh",
            "dash": "dash",
            "ksh": "ksh",
            "tcsh": "tcsh",
            "csh": "csh",
        }
        if name in labels:
            return name, labels[name]
        clean = re.sub(r"[^a-z0-9._+-]", "", name)[:32] or "shell"
        return clean, clean
    if system_l == "darwin":
        return "zsh", "zsh"
    return "bash", "bash"


def _windows_display(release: str) -> tuple[str, str]:
    # platform.release() is often "10" or "11" on modern Windows.
    rel = (release or "").strip()
    if rel.startswith("10.0"):
        # build-based 11 detection is unreliable without winreg; keep release text.
        label = f"Windows {rel}"
    elif rel in {"10", "11"}:
        label = f"Windows {rel}"
    elif rel:
        label = f"Windows {rel}"
    else:
        label = "Windows"
    return "windows", label


def _macos_display(release: str) -> tuple[str, str]:
    # Darwin release → approximate marketing version is optional; use macOS + release.
    mac_ver = platform.mac_ver()[0] if hasattr(platform, "mac_ver") else ""
    if mac_ver:
        return "macos", f"macOS {mac_ver}"
    if release:
        return "macos", f"macOS (Darwin {release})"
    return "macos", "macOS"


def _linux_display(release: str, os_release: dict[str, str], wsl: bool) -> tuple[str, str, str, str]:
    distro_id = (os_release.get("ID") or "").lower()[:64]
    distro_name = (
        os_release.get("PRETTY_NAME")
        or os_release.get("NAME")
        or "Linux"
    )[:120]
    distro_version = (os_release.get("VERSION_ID") or os_release.get("VERSION") or release or "")[
        :64
    ]
    if wsl:
        wsl_name = str(os.environ.get("WSL_DISTRO_NAME") or "").strip()[:64]
        if wsl_name and wsl_name.lower() not in distro_name.lower():
            label = f"{distro_name} (WSL · {wsl_name})"
        else:
            label = f"{distro_name} (WSL)"
    else:
        label = distro_name
    return distro_id or "linux", label, distro_name, distro_version


def build_host_platform() -> dict[str, Any]:
    """Platform block for runtime manifest + product Systems listing."""
    system = platform.system() or "Unknown"
    release = platform.release() or ""
    architecture = platform.machine() or ""
    wsl = False
    environment = "native"
    distro_id = ""
    distro_name = ""
    distro_version = ""

    system_l = system.lower()
    if system_l.startswith("win"):
        os_family, os_label = _windows_display(release)
    elif system_l == "darwin":
        os_family, os_label = _macos_display(release)
    elif system_l == "linux":
        wsl = _is_wsl()
        environment = "wsl" if wsl else "native"
        os_release = _read_os_release()
        distro_id, os_label, distro_name, distro_version = _linux_display(
            release, os_release, wsl
        )
        os_family = "linux"
    else:
        os_family = "unknown"
        os_label = system or "Unknown OS"

    shell_id, shell_label = _detect_shell(system)
    display = f"{os_label} · {shell_label}"

    # Keep core keys first (required by backend); extras are product analytics.
    return {
        "system": system,
        "release": release,
        "architecture": architecture,
        "os_family": os_family,
        "os_label": os_label[:120],
        "display": display[:160],
        "environment": environment,
        "wsl": bool(wsl),
        "distro_id": distro_id[:64],
        "distro_name": distro_name[:120],
        "distro_version": distro_version[:64],
        "shell": shell_id[:32],
        "shell_label": shell_label[:48],
        "python_implementation": platform.python_implementation()[:32],
    }


def summarize_platform_for_api(platform_block: dict[str, Any] | None) -> dict[str, Any]:
    """Normalize stored/manifest platform for list_workers Android UI + analytics."""
    p = platform_block if isinstance(platform_block, dict) else {}
    system = str(p.get("system") or "").strip()
    release = str(p.get("release") or "").strip()
    architecture = str(p.get("architecture") or "").strip()
    os_family = str(p.get("os_family") or "").strip().lower()
    if not os_family:
        sl = system.lower()
        if sl.startswith("win"):
            os_family = "windows"
        elif sl == "darwin":
            os_family = "macos"
        elif sl == "linux":
            os_family = "linux"
        else:
            os_family = "unknown"
    os_label = str(p.get("os_label") or "").strip()
    if not os_label:
        if os_family == "windows":
            os_label = f"Windows {release}".strip() if release else "Windows"
        elif os_family == "macos":
            os_label = "macOS"
        elif os_family == "linux":
            os_label = str(p.get("distro_name") or "Linux")
        else:
            os_label = system or "Unknown OS"
    shell_label = str(p.get("shell_label") or p.get("shell") or "").strip()
    display = str(p.get("display") or "").strip()
    if not display:
        display = f"{os_label} · {shell_label}" if shell_label else os_label
    return {
        "system": system,
        "release": release,
        "architecture": architecture,
        "os_family": os_family,
        "os_label": os_label,
        "display": display,
        "environment": str(p.get("environment") or "native"),
        "wsl": bool(p.get("wsl")),
        "distro_id": str(p.get("distro_id") or ""),
        "distro_name": str(p.get("distro_name") or ""),
        "distro_version": str(p.get("distro_version") or ""),
        "shell": str(p.get("shell") or ""),
        "shell_label": shell_label,
    }
