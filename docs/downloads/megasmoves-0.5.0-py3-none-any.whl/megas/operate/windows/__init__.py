"""Windows-native Computer Use Agent (UI Automation first).

Production capabilities:
  - desktop.windows.uia  (COM UI Automation via uiautomation + Win32 identity)
  - desktop.windows.input (Win32 SendInput, verified foreground only)

Health- and certification-gated. No silent mock fallback in production.
See docs/architecture/windows-computer-use.md.
"""

from __future__ import annotations

from megas.operate.windows.capability import (
    CAPABILITY_WINDOWS_INPUT,
    CAPABILITY_WINDOWS_UIA,
    CapabilityReport,
    build_capability_reports,
)
from megas.operate.windows.session import WindowsCuaSession, run_windows_cua_command

__all__ = [
    "CAPABILITY_WINDOWS_UIA",
    "CAPABILITY_WINDOWS_INPUT",
    "CapabilityReport",
    "build_capability_reports",
    "WindowsCuaSession",
    "run_windows_cua_command",
]
