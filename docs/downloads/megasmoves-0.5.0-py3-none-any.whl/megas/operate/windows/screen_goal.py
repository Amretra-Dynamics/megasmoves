"""Bounded recovery for reading a specific Windows application's visible screen."""

from __future__ import annotations

import ntpath
from typing import Any, Callable

from megas.operate.windows.discovery import DesktopBackend, create_backend
from megas.operate.windows.foreground_settling import verify_foreground_settled
from megas.operate.windows.models import WindowIdentity
from megas.operate.windows.screen_read import read_current_screen


MAX_TARGET_CHARS = 128
RECOVERY_BUDGET = 2


def _clean(value: Any, *, limit: int = MAX_TARGET_CHARS) -> str:
    return str(value or "").strip()[:limit]


def _matches(window: WindowIdentity, target: dict[str, Any]) -> bool:
    title_contains = _clean(target.get("title_contains")).casefold()
    executable = ntpath.basename(_clean(target.get("executable"))).casefold()
    if not title_contains and not executable:
        raise ValueError("target requires title_contains and/or executable")
    if not bool(window.is_visible):
        return False
    if title_contains and title_contains not in str(window.title or "").casefold():
        return False
    if executable:
        actual = ntpath.basename(str(window.executable or "")).casefold()
        if actual != executable:
            return False
    return True


def _window_hint(window: WindowIdentity | None) -> dict[str, Any] | None:
    if window is None:
        return None
    return {
        "hwnd": int(window.hwnd),
        "title": str(window.title or "")[:256],
        "executable": ntpath.basename(str(window.executable or "")) or None,
        "is_foreground": bool(window.is_foreground),
    }


def read_target_screen(
    *,
    target: dict[str, Any],
    backend: DesktopBackend | None = None,
    reader: Callable[..., dict[str, Any]] | None = None,
    max_nodes: int = 240,
    max_chars: int = 12000,
) -> dict[str, Any]:
    """Complete a screen-read goal despite one recoverable wrong-foreground attempt.

    This is deliberately separate from the strictly read-only current-screen tool.
    It may focus one uniquely matching visible top-level window, then verifies that
    exact HWND became foreground before reading. Recovery is bounded to one focus
    retry after the initial observation and never accepts arbitrary HWNDs.
    """

    if not isinstance(target, dict):
        raise ValueError("target must be an object")
    # Validate before touching desktop state.
    _matches(
        WindowIdentity(
            hwnd=0,
            process_id=0,
            title="",
            class_name="",
            executable="",
            is_visible=True,
        ),
        target,
    )

    actual = backend or create_backend()
    read = reader or read_current_screen
    attempts: list[dict[str, Any]] = []
    recovery_steps: list[str] = []

    # Security state is checked before any focus-changing recovery.
    if actual.is_session_locked():
        raise PermissionError("Windows session is locked; target-screen recovery is unavailable.")
    if actual.is_secure_desktop():
        raise PermissionError("Secure desktop is active; target-screen recovery is unavailable.")
    if actual.is_uac_prompt_present():
        raise PermissionError("A UAC prompt is active; target-screen recovery is unavailable.")

    foreground = actual.get_foreground()
    if foreground is not None and _matches(foreground, target):
        observation = read(
            backend=actual,
            max_nodes=max_nodes,
            max_chars=max_chars,
        )
        attempts.append(
            {
                "attempt": 1,
                "status": "completed",
                "path": "current_foreground",
            }
        )
        return {
            **observation,
            "goal_status": "completed",
            "human_required": False,
            "attempts": attempts,
            "attempt_count": 1,
            "recovery_budget": RECOVERY_BUDGET,
            "recovery_steps": recovery_steps,
            "target": {
                "title_contains": _clean(target.get("title_contains")) or None,
                "executable": ntpath.basename(_clean(target.get("executable"))) or None,
            },
        }

    attempts.append(
        {
            "attempt": 1,
            "status": "attempt_failed",
            "reason": "wrong_foreground",
            "observed_window": _window_hint(foreground),
        }
    )

    matches = [window for window in actual.list_windows() if _matches(window, target)]
    if not matches:
        return {
            "ok": False,
            "goal_status": "blocked",
            "human_required": True,
            "reason": "target_not_found",
            "attempts": attempts,
            "attempt_count": 1,
            "recovery_budget": RECOVERY_BUDGET,
            "recovery_steps": ["enumerate_top_level_windows"],
        }
    if len(matches) != 1:
        return {
            "ok": False,
            "goal_status": "blocked",
            "human_required": True,
            "reason": "target_ambiguous",
            "match_count": len(matches),
            "attempts": attempts,
            "attempt_count": 1,
            "recovery_budget": RECOVERY_BUDGET,
            "recovery_steps": ["enumerate_top_level_windows"],
        }

    target_window = matches[0]
    recovery_steps.extend(["enumerate_top_level_windows", "unique_target_match", "focus_target"])

    # A Windows SetForegroundWindow request can settle asynchronously. Only
    # the exact selected HWND, not the focus call return value, proves success.
    actual.focus_window(target_window)
    verified = verify_foreground_settled(actual.get_foreground, target_window.hwnd)
    if verified is None or int(verified.hwnd) != int(target_window.hwnd):
        attempts.append(
            {
                "attempt": 2,
                "status": "attempt_failed",
                "reason": "foreground_verification_failed",
                "target_window": _window_hint(target_window),
                "observed_window": _window_hint(verified),
            }
        )
        return {
            "ok": False,
            "goal_status": "blocked",
            "human_required": True,
            "reason": "foreground_verification_failed",
            "attempts": attempts,
            "attempt_count": 2,
            "recovery_budget": RECOVERY_BUDGET,
            "recovery_steps": recovery_steps + ["verify_foreground"],
        }

    recovery_steps.append("verify_foreground")
    # The session can lock or switch to a secure desktop during the bounded
    # focus-settling period. Never read the screen after such a transition.
    if actual.is_session_locked():
        raise PermissionError("Windows session locked before the target could be read.")
    if actual.is_secure_desktop():
        raise PermissionError("Secure desktop became active before the target could be read.")
    if actual.is_uac_prompt_present():
        raise PermissionError("UAC prompt became active before the target could be read.")
    try:
        observation = read(
            backend=actual,
            max_nodes=max_nodes,
            max_chars=max_chars,
        )
    except Exception as exc:
        attempts.append(
            {
                "attempt": 2,
                "status": "attempt_failed",
                "reason": "target_read_failed",
                "error_type": type(exc).__name__,
            }
        )
        return {
            "ok": False,
            "goal_status": "blocked",
            "human_required": False,
            "reason": "target_read_failed",
            "attempts": attempts,
            "attempt_count": 2,
            "recovery_budget": RECOVERY_BUDGET,
            "recovery_steps": recovery_steps,
        }

    attempts.append(
        {
            "attempt": 2,
            "status": "completed",
            "path": "locate_focus_verify_read",
            "target_window": _window_hint(target_window),
        }
    )
    return {
        **observation,
        "goal_status": "completed",
        "human_required": False,
        "attempts": attempts,
        "attempt_count": 2,
        "recovery_budget": RECOVERY_BUDGET,
        "recovery_steps": recovery_steps,
        "target": {
            "title_contains": _clean(target.get("title_contains")) or None,
            "executable": ntpath.basename(_clean(target.get("executable"))) or None,
        },
    }


__all__ = ["RECOVERY_BUDGET", "read_target_screen"]
