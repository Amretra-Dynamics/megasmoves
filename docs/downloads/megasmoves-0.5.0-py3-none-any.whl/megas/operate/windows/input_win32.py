"""Production keyboard/pointer input via Win32 SendInput only."""

from __future__ import annotations

from typing import Any

from megas.operate.windows.models import ElementIdentity, WindowIdentity
from megas.operate.windows.targeting import translate_coordinates
from megas.operate.windows.win32_api import (
    is_windows,
    send_key_chord,
    send_mouse_click,
    send_mouse_move_absolute,
    send_unicode_text,
    set_foreground,
)


class ProductionInputError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class ProductionInputEngine:
    def __init__(self, *, scale_factor: float = 1.0) -> None:
        if not is_windows():
            raise ProductionInputError("not_windows", "Production input requires Windows.")
        self.scale_factor = scale_factor
        self._stopped = False
        self.history: list[dict[str, Any]] = []

    def emergency_stop(self) -> None:
        self._stopped = True

    def reset_after_stop(self) -> None:
        self._stopped = False
        self.history.clear()

    def _guard(self) -> None:
        if self._stopped:
            raise ProductionInputError("emergency_stopped", "Input path is emergency-stopped.")

    def ensure_foreground(self, window: WindowIdentity) -> None:
        if not set_foreground(window.hwnd):
            raise ProductionInputError(
                "foreground_failed",
                "Could not set target window foreground before input.",
            )

    def click(
        self,
        *,
        window: WindowIdentity,
        element: ElementIdentity | None,
        button: str = "left",
        clicks: int = 1,
        verified_foreground: bool,
    ) -> dict[str, Any]:
        self._guard()
        if not verified_foreground:
            raise ProductionInputError(
                "unverified_foreground",
                "Refusing coordinate input without foreground verification.",
            )
        if element is None or element.bounds is None:
            raise ProductionInputError("missing_bounds", "Element bounds required for click.")
        self.ensure_foreground(window)
        cx, cy = element.bounds.center()
        px, py = translate_coordinates(x=cx, y=cy, scale_factor=self.scale_factor)
        send_mouse_move_absolute(px, py)
        send_mouse_click(button=button, clicks=clicks)
        record = {
            "type": "click",
            "button": button,
            "clicks": clicks,
            "x": px,
            "y": py,
            "hwnd": window.hwnd,
            "process_id": window.process_id,
            "element_id": element.element_id,
            "engine": "sendinput",
        }
        self.history.append(record)
        return record

    def move_pointer(
        self,
        *,
        window: WindowIdentity,
        x: float,
        y: float,
        verified_foreground: bool,
    ) -> dict[str, Any]:
        self._guard()
        if not verified_foreground:
            raise ProductionInputError("unverified_foreground", "Refusing pointer move.")
        self.ensure_foreground(window)
        px, py = translate_coordinates(x=x, y=y, scale_factor=self.scale_factor)
        send_mouse_move_absolute(px, py)
        record = {"type": "move", "x": px, "y": py, "hwnd": window.hwnd, "engine": "sendinput"}
        self.history.append(record)
        return record

    def key_press(
        self,
        *,
        window: WindowIdentity,
        keys: list[str],
        verified_foreground: bool,
        is_secret: bool = False,
    ) -> dict[str, Any]:
        self._guard()
        if not verified_foreground:
            raise ProductionInputError("unverified_foreground", "Refusing key input.")
        self.ensure_foreground(window)
        send_key_chord(keys)
        record = {
            "type": "keys",
            "keys": ["[REDACTED]"] if is_secret else list(keys),
            "hwnd": window.hwnd,
            "secret": is_secret,
            "engine": "sendinput",
        }
        self.history.append(record)
        return record

    def type_text(
        self,
        *,
        window: WindowIdentity,
        text: str,
        verified_foreground: bool,
        is_secret: bool = False,
    ) -> dict[str, Any]:
        self._guard()
        if not verified_foreground:
            raise ProductionInputError("unverified_foreground", "Refusing type_text.")
        self.ensure_foreground(window)
        send_unicode_text(text or "")
        record = {
            "type": "type_text",
            "length": len(text or ""),
            "text": "[REDACTED]" if is_secret else "",
            "hwnd": window.hwnd,
            "secret": is_secret,
            "engine": "sendinput",
        }
        # Never retain raw secret or non-secret full text in history beyond length.
        self.history.append(record)
        return record
