"""Windows CUA health probes (fail closed; never invent success)."""

from __future__ import annotations

import os
import platform
import sys
from dataclasses import dataclass, field
from typing import Any, Callable

from megas.operate.windows.models import DisplayInfo, utc_now


@dataclass
class HealthSnapshot:
    os_name: str
    os_version: str
    architecture: str
    is_windows: bool
    uia_available: bool
    input_available: bool
    screenshot_available: bool
    secure_desktop: bool
    session_locked: bool
    uac_prompt_present: bool
    displays: list[DisplayInfo] = field(default_factory=list)
    dpi_scale: float = 1.0
    errors: list[str] = field(default_factory=list)
    checked_at: str = field(default_factory=utc_now)

    @property
    def healthy_for_uia(self) -> bool:
        return (
            self.is_windows
            and self.uia_available
            and not self.secure_desktop
            and not self.session_locked
            and not self.uac_prompt_present
            and not self.errors
        )

    @property
    def healthy_for_input(self) -> bool:
        return self.healthy_for_uia and self.input_available

    def to_dict(self) -> dict[str, Any]:
        return {
            "os_name": self.os_name,
            "os_version": self.os_version,
            "architecture": self.architecture,
            "is_windows": self.is_windows,
            "uia_available": self.uia_available,
            "input_available": self.input_available,
            "screenshot_available": self.screenshot_available,
            "secure_desktop": self.secure_desktop,
            "session_locked": self.session_locked,
            "uac_prompt_present": self.uac_prompt_present,
            "displays": [d.to_dict() for d in self.displays],
            "dpi_scale": self.dpi_scale,
            "errors": list(self.errors),
            "checked_at": self.checked_at,
            "healthy_for_uia": self.healthy_for_uia,
            "healthy_for_input": self.healthy_for_input,
        }


def _is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


def probe_health(
    *,
    force_windows: bool | None = None,
    uia_probe: Callable[[], bool] | None = None,
    input_probe: Callable[[], bool] | None = None,
    screenshot_probe: Callable[[], bool] | None = None,
    secure_desktop_probe: Callable[[], bool] | None = None,
    locked_probe: Callable[[], bool] | None = None,
    uac_probe: Callable[[], bool] | None = None,
    display_probe: Callable[[], list[DisplayInfo]] | None = None,
    allow_non_windows_simulation: bool = False,
) -> HealthSnapshot:
    """Collect production health. Non-Windows is unavailable unless test simulation is explicit."""
    is_win = _is_windows() if force_windows is None else force_windows
    errors: list[str] = []

    if not is_win and not allow_non_windows_simulation:
        return HealthSnapshot(
            os_name=platform.system() or "unknown",
            os_version=platform.version() or "",
            architecture=platform.machine() or "",
            is_windows=False,
            uia_available=False,
            input_available=False,
            screenshot_available=False,
            secure_desktop=False,
            session_locked=False,
            uac_prompt_present=False,
            displays=[],
            dpi_scale=1.0,
            errors=["windows_cua_requires_windows"],
        )

    def _safe(name: str, fn: Callable[[], Any], default: Any) -> Any:
        if fn is None:
            return default
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{name}_probe_failed:{type(exc).__name__}")
            return default

    # Wire production Win32 probes only on a real Windows host when not overridden.
    # force_windows=True in unit tests must not call user32 on Linux.
    live_win32 = _is_windows()
    if live_win32 and uia_probe is None:
        try:
            from megas.operate.windows.win32_api import uiautomation_available

            uia_probe = uiautomation_available
        except Exception:  # noqa: BLE001
            uia_probe = lambda: False  # noqa: E731
    if live_win32 and input_probe is None:
        input_probe = lambda: True  # noqa: E731
    if live_win32 and secure_desktop_probe is None:
        try:
            from megas.operate.windows.win32_api import is_secure_desktop as _isd

            secure_desktop_probe = _isd
        except Exception:  # noqa: BLE001
            secure_desktop_probe = lambda: False  # noqa: E731
    if live_win32 and locked_probe is None:
        try:
            from megas.operate.windows.win32_api import is_session_locked as _isl

            locked_probe = _isl
        except Exception:  # noqa: BLE001
            locked_probe = lambda: False  # noqa: E731
    if live_win32 and uac_probe is None:
        try:
            from megas.operate.windows.win32_api import is_uac_prompt_present as _uac

            uac_probe = _uac
        except Exception:  # noqa: BLE001
            uac_probe = lambda: False  # noqa: E731
    if live_win32 and display_probe is None:
        try:
            from megas.operate.windows.win32_api import list_displays as _ld

            display_probe = _ld
        except Exception:  # noqa: BLE001
            display_probe = None
    if live_win32 and screenshot_probe is None:
        try:
            from megas.operate.windows.win32_api import capture_screen_hash as _csh

            screenshot_probe = lambda: _csh() is not None  # noqa: E731
        except Exception:  # noqa: BLE001
            screenshot_probe = lambda: False  # noqa: E731

    uia_ok = bool(_safe("uia", uia_probe, default=bool(allow_non_windows_simulation)))
    input_ok = bool(
        _safe("input", input_probe, default=bool(is_win or allow_non_windows_simulation))
    )
    shot_ok = bool(
        _safe(
            "screenshot",
            screenshot_probe,
            default=bool(is_win or allow_non_windows_simulation),
        )
    )
    secure = bool(_safe("secure_desktop", secure_desktop_probe, default=False))
    locked = bool(_safe("locked", locked_probe, default=False))
    uac = bool(_safe("uac", uac_probe, default=False))
    displays = _safe(
        "display",
        display_probe,
        default=[
            DisplayInfo(
                display_id="primary",
                width=1920,
                height=1080,
                scale_factor=1.0,
                is_primary=True,
            )
        ],
    )
    if not isinstance(displays, list):
        displays = []
    scale = 1.0
    primary = next((d for d in displays if getattr(d, "is_primary", False)), None)
    if primary is not None:
        scale = float(getattr(primary, "scale_factor", 1.0) or 1.0)
    elif displays:
        scale = float(getattr(displays[0], "scale_factor", 1.0) or 1.0)

    if secure:
        errors.append("secure_desktop_active")
    if locked:
        errors.append("session_locked")
    if uac:
        errors.append("uac_prompt_present")

    return HealthSnapshot(
        os_name="Windows" if is_win else (platform.system() or "simulated"),
        os_version=platform.version() if is_win else "simulated",
        architecture=platform.machine() or "",
        is_windows=bool(is_win or allow_non_windows_simulation),
        uia_available=uia_ok and not secure and not locked and not uac,
        input_available=input_ok and not secure and not locked and not uac,
        screenshot_available=shot_ok,
        secure_desktop=secure,
        session_locked=locked,
        uac_prompt_present=uac,
        displays=list(displays),
        dpi_scale=scale,
        errors=errors,
    )
