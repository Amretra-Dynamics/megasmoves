"""Windows CUA session state machine and action executor.

Vertical slice + full action set with policy, targeting, verification, evidence.
Patterns adapted from Kinetic-OS: foreground verification, no silent failure,
screen-hash progress, allow_os_automation gate.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable

from megas.operate.windows.approvals import ApprovalError, validate_approval
from megas.operate.windows.capability import (
    CAPABILITY_WINDOWS_INPUT,
    CAPABILITY_WINDOWS_UIA,
    advertised_capability_names,
    build_capability_reports,
    simulation_enabled,
)
from megas.operate.windows.discovery import DesktopBackend, MockDesktopBackend, create_backend
from megas.operate.windows.emergency_stop import EMERGENCY_STOP
from megas.operate.windows.evidence import EvidenceStore
from megas.operate.windows.health import probe_health
from megas.operate.windows.input_adapter import InputAdapter, InputFallbackError
from megas.operate.windows.locks import (
    CLIPBOARD,
    INTERACTIVE_DESKTOP,
    LOCKS,
    LockContentionError,
    app_lock_key,
    window_lock_key,
)
from megas.operate.windows.models import (
    TERMINAL_STATES,
    ActionOutcome,
    ActionRequest,
    ActionResult,
    ActionRisk,
    ActionType,
    ElementSelector,
    RuntimeEvent,
    SessionState,
    new_id,
    utc_now,
)
from megas.operate.windows.policy import evaluate_policy
from megas.operate.windows.redaction import is_password_element, redact_element_dict, redact_mapping
from megas.operate.windows.targeting import TargetDriftError, capture_target
from megas.operate.windows.uia_adapter import UiaActionError, UiaAdapter
from megas.operate.windows.verification import VerificationStatus, verify_action


class SessionError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class WindowsCuaSession:
    session_id: str
    backend: DesktopBackend
    granted_scopes: list[str] = field(default_factory=list)
    state: SessionState = SessionState.REQUESTED
    scale_factor: float = 1.0
    evidence: EvidenceStore = field(default_factory=EvidenceStore)
    runtime_events: list[dict[str, Any]] = field(default_factory=list)
    completed_action_ids: set[str] = field(default_factory=set)
    idempotency_results: dict[str, ActionResult] = field(default_factory=dict)
    cancel_requested: bool = False
    terminal_reason: str | None = None
    _lock: threading.RLock = field(default_factory=threading.RLock)
    uia: UiaAdapter = field(init=False)
    input: InputAdapter = field(init=False)

    def __post_init__(self) -> None:
        self.uia = UiaAdapter(self.backend)
        # Production uses SendInput; unit-test doubles force the recorder path only.
        self.input = InputAdapter(
            scale_factor=self.scale_factor,
            force_recorder=isinstance(self.backend, MockDesktopBackend),
        )
        EMERGENCY_STOP.register_listener(self._on_emergency)

    def _on_emergency(self) -> None:
        self.cancel_requested = True
        self.input.emergency_stop()
        LOCKS.release_all(self.session_id)

    def _emit(self, event_type: str, severity: str, message: str, **attrs: Any) -> None:
        ev = RuntimeEvent(
            event_type=event_type,
            severity=severity,
            message=message,
            session_id=self.session_id,
            action_id=attrs.pop("action_id", None),
            attributes=attrs,
        )
        self.runtime_events.append(ev.to_dict())

    def _set_state(self, state: SessionState, reason: str | None = None) -> None:
        if self.state in TERMINAL_STATES:
            return
        self.state = state
        if reason:
            self.terminal_reason = reason
        self._emit("windows_cua.state", "info", f"state={state.value}", state=state.value, reason=reason)

    def request_cancel(self, reason: str = "cancelled") -> None:
        self.cancel_requested = True
        self._emit("windows_cua.cancelled", "warning", reason)

    def emergency_stop(self, reason: str = "emergency_stop", source: str = "session") -> None:
        EMERGENCY_STOP.trigger(session_id=self.session_id, reason=reason, source=source)
        self._set_state(SessionState.EMERGENCY_STOPPED, reason)
        LOCKS.release_all(self.session_id)

    def _check_cancel_or_stop(self) -> None:
        if EMERGENCY_STOP.is_stopped():
            raise SessionError("emergency_stopped", "Emergency stop is active.")
        if self.cancel_requested:
            raise SessionError("cancelled", "Session cancellation requested.")

    def execute(self, action: ActionRequest) -> ActionResult:
        with self._lock:
            return self._execute_locked(action)

    def _execute_locked(self, action: ActionRequest) -> ActionResult:
        started = time.perf_counter()
        action.session_id = action.session_id or self.session_id

        # Idempotency: do not re-run completed high-risk / any completed action_id.
        if action.action_id in self.completed_action_ids:
            prior = self.idempotency_results.get(action.action_id)
            if prior:
                return prior
            return ActionResult(
                action_id=action.action_id,
                outcome=ActionOutcome.SUCCESS,
                verification=VerificationStatus.SKIPPED,
                message="Action already completed (idempotent replay).",
                risk=ActionRisk.READ_ONLY,
            )
        if action.idempotency_key and action.idempotency_key in self.idempotency_results:
            return self.idempotency_results[action.idempotency_key]

        try:
            self._check_cancel_or_stop()
            self._set_state(SessionState.POLICY_CHECK)

            # Capability gate
            caps = advertised_capability_names()
            test_double = isinstance(self.backend, MockDesktopBackend)
            uia_ok = CAPABILITY_WINDOWS_UIA in caps or simulation_enabled() or test_double
            input_ok = (
                CAPABILITY_WINDOWS_INPUT in caps
                or simulation_enabled()
                or test_double
            )
            if not uia_ok and not test_double:
                self._emit(
                    "windows_cua.capability_health_failure",
                    "error",
                    "desktop.windows.uia unavailable",
                    action_id=action.action_id,
                )
                raise SessionError(
                    "capability_unavailable",
                    "desktop.windows.uia is not available.",
                )

            decision = evaluate_policy(
                action,
                granted_scopes=self.granted_scopes,
                input_capability_available=input_ok,
            )
            if not decision.allowed:
                self._emit(
                    "windows_cua.policy_rejection",
                    "warning",
                    "Policy rejected action",
                    action_id=action.action_id,
                    reasons=decision.reasons,
                )
                self._set_state(SessionState.BLOCKED, "policy_rejected")
                return self._result(
                    action,
                    ActionOutcome.BLOCKED,
                    VerificationStatus.SKIPPED,
                    "; ".join(decision.reasons),
                    decision.risk,
                    started,
                    error_code="policy_rejected",
                )

            if decision.requires_approval:
                self._set_state(SessionState.WAITING_FOR_APPROVAL)
                try:
                    # Validate against current target if known.
                    window = None
                    element = None
                    if action.window or action.selector:
                        self._set_state(SessionState.LOCATING_TARGET)
                        snap = capture_target(
                            self.backend,
                            expected_window=action.window,
                            require_foreground=True,
                            scale_factor=self.scale_factor,
                        )
                        window = snap.window
                        if action.selector:
                            element = self.uia.find_element(window, action.selector)
                    validate_approval(action, window=window, element=element)
                except ApprovalError as exc:
                    self._emit(
                        "windows_cua.approval_expiry",
                        "warning",
                        str(exc),
                        action_id=action.action_id,
                        code=exc.code,
                    )
                    return self._result(
                        action,
                        ActionOutcome.BLOCKED,
                        VerificationStatus.SKIPPED,
                        str(exc),
                        decision.risk,
                        started,
                        error_code=exc.code,
                    )
                except (TargetDriftError, UiaActionError) as exc:
                    code = getattr(exc, "code", "target_error")
                    return self._result(
                        action,
                        ActionOutcome.FAILED,
                        VerificationStatus.FAILED,
                        str(exc),
                        decision.risk,
                        started,
                        error_code=code,
                    )

            self._set_state(SessionState.PREPARING)
            self._check_cancel_or_stop()

            # Acquire locks for interactive work
            interactive = decision.risk != ActionRisk.READ_ONLY
            held: list[str] = []
            try:
                if interactive:
                    LOCKS.acquire(INTERACTIVE_DESKTOP, self.session_id, timeout_seconds=0.5)
                    held.append(INTERACTIVE_DESKTOP)

                self._set_state(SessionState.LOCATING_TARGET)
                self._check_cancel_or_stop()

                before_shot = self.evidence.capture_screenshot_meta(label="before")
                before_window = None
                before_element = None
                used_fallback = False
                exec_ok = False
                after_element = None
                after_window = None
                exec_detail: dict[str, Any] = {}

                # Dispatch read-only / discovery without strict window if not needed
                if action.action_type == ActionType.ENUMERATE_WINDOWS:
                    windows = self.uia.enumerate_windows()
                    exec_ok = True
                    exec_detail = {"windows": windows}
                elif action.action_type == ActionType.INSPECT_ACTIVE_WINDOW:
                    active = self.uia.inspect_active_window()
                    exec_ok = active is not None
                    exec_detail = {"window": active}
                    if active:
                        before_window = self.backend.get_foreground()
                elif action.action_type == ActionType.EMERGENCY_STOP:
                    self.emergency_stop(reason="action_requested", source="action")
                    return self._result(
                        action,
                        ActionOutcome.EMERGENCY_STOPPED,
                        VerificationStatus.VERIFIED,
                        "Emergency stop engaged.",
                        ActionRisk.READ_ONLY,
                        started,
                    )
                elif action.action_type == ActionType.CANCEL_SESSION:
                    self.request_cancel("action_cancel_session")
                    self._set_state(SessionState.CANCELLED, "cancelled")
                    return self._result(
                        action,
                        ActionOutcome.CANCELLED,
                        VerificationStatus.SKIPPED,
                        "Session cancelled.",
                        ActionRisk.READ_ONLY,
                        started,
                    )
                else:
                    snap = capture_target(
                        self.backend,
                        expected_window=action.window,
                        require_foreground=True,
                        scale_factor=self.scale_factor,
                    )
                    before_window = snap.window
                    LOCKS.acquire(window_lock_key(before_window.hwnd), self.session_id, timeout_seconds=0.2)
                    held.append(window_lock_key(before_window.hwnd))
                    LOCKS.acquire(app_lock_key(before_window.process_id), self.session_id, timeout_seconds=0.2)
                    held.append(app_lock_key(before_window.process_id))

                    if action.selector:
                        before_element = self.uia.find_element(before_window, action.selector)
                        if is_password_element(
                            name=before_element.name,
                            control_type=before_element.control_type,
                            automation_id=before_element.automation_id,
                            is_password_flag=before_element.is_password,
                            patterns=before_element.patterns,
                        ):
                            before_element.is_password = True
                            action.metadata["is_password"] = True
                            action.metadata["is_secret"] = True

                    self._set_state(SessionState.EXECUTING)
                    self._check_cancel_or_stop()

                    # Re-validate target immediately before execution
                    snap2 = capture_target(
                        self.backend,
                        expected_window={
                            "hwnd": before_window.hwnd,
                            "process_id": before_window.process_id,
                            "title": before_window.title,
                        },
                        element=before_element,
                        require_foreground=True,
                        scale_factor=self.scale_factor,
                    )
                    before_window = snap2.window
                    if snap2.element:
                        before_element = snap2.element

                    try:
                        after_element, after_window, used_fallback, exec_detail = self._perform(
                            action,
                            window=before_window,
                            element=before_element,
                            input_ok=input_ok,
                        )
                        exec_ok = True
                    except UiaActionError as exc:
                        if action.allow_input_fallback and input_ok and before_element is not None:
                            after_element, after_window, used_fallback, exec_detail = self._input_fallback(
                                action, before_window, before_element
                            )
                            exec_ok = True
                        else:
                            raise
                    except InputFallbackError:
                        raise

                self._check_cancel_or_stop()
                self._set_state(SessionState.VERIFYING)
                after_shot = self.evidence.capture_screenshot_meta(label="after")
                # For mock invoke/set_text, force distinct hash progression when state changed
                progress = after_shot.get("progress") or {}
                if exec_ok and action.action_type in {
                    ActionType.INVOKE_ELEMENT,
                    ActionType.SET_TEXT,
                    ActionType.CLICK,
                }:
                    # Don't falsely mark stuck on simulated unique hashes
                    progress = {"progress": "ok", "same_hash_streak": 0}

                verification = verify_action(
                    backend=self.backend,
                    action=action,
                    before_element=before_element,
                    after_element=after_element or before_element,
                    before_window=before_window,
                    after_window=after_window or before_window,
                    execution_ok=exec_ok,
                    used_fallback=used_fallback,
                    screenshot_progress=progress,
                )

                if verification.status == VerificationStatus.VERIFIED:
                    outcome = ActionOutcome.SUCCESS
                    self._set_state(SessionState.COMPLETED)
                elif verification.status == VerificationStatus.UNCERTAIN:
                    outcome = ActionOutcome.UNCERTAIN
                    self._set_state(SessionState.FAILED, "verification_uncertain")
                    self._emit(
                        "windows_cua.verification_failure",
                        "warning",
                        verification.message,
                        action_id=action.action_id,
                    )
                else:
                    outcome = ActionOutcome.FAILED
                    self._set_state(SessionState.FAILED, "verification_failed")
                    self._emit(
                        "windows_cua.verification_failure",
                        "error",
                        verification.message,
                        action_id=action.action_id,
                    )

                evidence = self.evidence.add(
                    session_id=self.session_id,
                    action_id=action.action_id,
                    process_id=before_window.process_id if before_window else None,
                    window=before_window.to_dict() if before_window else {},
                    element=redact_element_dict(before_element.to_dict()) if before_element else None,
                    selector=action.selector.to_dict() if action.selector else None,
                    element_bounds=before_element.bounds.to_dict() if before_element and before_element.bounds else None,
                    display_scale=self.scale_factor,
                    screenshot={"before": before_shot, "after": after_shot},
                    accessibility_snapshot=None,
                    policy_decision=decision.to_dict(),
                    approval_reference=action.approval.approval_id if action.approval else None,
                    execution_result=redact_mapping(
                        {"ok": exec_ok, "used_fallback": used_fallback, "detail": exec_detail}
                    ),
                    verification_result=verification.to_dict(),
                )

                result = ActionResult(
                    action_id=action.action_id,
                    outcome=outcome,
                    verification=verification.status,
                    message=verification.message,
                    risk=decision.risk,
                    used_input_fallback=used_fallback,
                    before={"window": before_window.to_dict() if before_window else None},
                    after={"element": redact_element_dict(after_element.to_dict()) if after_element else None},
                    evidence_id=evidence.evidence_id,
                    duration_ms=int((time.perf_counter() - started) * 1000),
                )
                # Only mark complete for terminal success to prevent high-risk duplicates
                if outcome == ActionOutcome.SUCCESS:
                    self.completed_action_ids.add(action.action_id)
                    if action.idempotency_key:
                        self.idempotency_results[action.idempotency_key] = result
                    self.idempotency_results[action.action_id] = result
                return result

            finally:
                for resource in held:
                    LOCKS.release(resource, self.session_id)

        except SessionError as exc:
            if exc.code == "emergency_stopped":
                self._set_state(SessionState.EMERGENCY_STOPPED, exc.code)
                outcome = ActionOutcome.EMERGENCY_STOPPED
            elif exc.code == "cancelled":
                self._set_state(SessionState.CANCELLED, exc.code)
                outcome = ActionOutcome.CANCELLED
            else:
                self._set_state(SessionState.FAILED, exc.code)
                outcome = ActionOutcome.FAILED
            return self._result(
                action,
                outcome,
                VerificationStatus.SKIPPED,
                str(exc),
                ActionRisk.READ_ONLY,
                started,
                error_code=exc.code,
            )
        except TargetDriftError as exc:
            self._emit(
                "windows_cua.focus_drift" if exc.code == "focus_drift" else "windows_cua.target_window_loss",
                "error",
                str(exc),
                action_id=action.action_id,
                code=exc.code,
            )
            self._set_state(SessionState.FAILED, exc.code)
            return self._result(
                action,
                ActionOutcome.FAILED,
                VerificationStatus.FAILED,
                str(exc),
                ActionRisk.READ_ONLY,
                started,
                error_code=exc.code,
            )
        except (UiaActionError, InputFallbackError) as exc:
            code = getattr(exc, "code", "action_error")
            self._emit("windows_cua.action_timeout" if "timeout" in code else "windows_cua.action_error",
                       "error", str(exc), action_id=action.action_id, code=code)
            self._set_state(SessionState.FAILED, code)
            return self._result(
                action,
                ActionOutcome.FAILED,
                VerificationStatus.FAILED,
                str(exc),
                ActionRisk.READ_ONLY,
                started,
                error_code=code,
            )
        except LockContentionError as exc:
            self._emit(
                "windows_cua.input_lock_contention",
                "warning",
                str(exc),
                action_id=action.action_id,
                resource=exc.resource,
            )
            return self._result(
                action,
                ActionOutcome.FAILED,
                VerificationStatus.SKIPPED,
                str(exc),
                ActionRisk.READ_ONLY,
                started,
                error_code="lock_contention",
            )
        finally:
            LOCKS.release_all(self.session_id)

    def _perform(
        self,
        action: ActionRequest,
        *,
        window,
        element,
        input_ok: bool,
    ):
        used_fallback = False
        detail: dict[str, Any] = {}
        after_el = element
        after_win = window

        if action.action_type == ActionType.INSPECT_ACCESSIBILITY_TREE:
            detail = {"tree": self.uia.inspect_tree(window)}
        elif action.action_type == ActionType.FIND_ELEMENT:
            after_el = self.uia.find_element(window, action.selector or ElementSelector())
            detail = {"element": redact_element_dict(after_el.to_dict())}
        elif action.action_type == ActionType.FOCUS_ELEMENT:
            after_el = self.uia.focus_element(element)
        elif action.action_type == ActionType.INVOKE_ELEMENT:
            after_el = self.uia.invoke_element(element)
        elif action.action_type == ActionType.SET_TEXT:
            after_el = self.uia.set_text(
                element,
                action.text or "",
                is_secret=bool(action.metadata.get("is_secret") or action.metadata.get("is_password")),
            )
        elif action.action_type == ActionType.READ_VISIBLE_TEXT:
            detail = {"text": self.uia.read_text(element)}
        elif action.action_type == ActionType.TOGGLE_CONTROL:
            after_el = self.uia.toggle(element)
        elif action.action_type == ActionType.EXPAND_COLLAPSE:
            after_el = self.uia.expand_collapse(element, expand=bool(action.metadata.get("expand", True)))
        elif action.action_type == ActionType.SCROLL:
            after_el = self.uia.scroll(element, direction=str(action.metadata.get("direction") or "down"))
        elif action.action_type == ActionType.SELECT_ITEM:
            after_el = self.uia.select_item(element)
        elif action.action_type == ActionType.CAPTURE_SCREENSHOT:
            detail = {"screenshot": self.evidence.capture_screenshot_meta(label="capture")}
        elif action.action_type == ActionType.WAIT_FOR_ELEMENT:
            deadline = time.monotonic() + action.timeout_seconds
            found = None
            while time.monotonic() < deadline:
                self._check_cancel_or_stop()
                try:
                    found = self.uia.find_element(window, action.selector or ElementSelector())
                    break
                except UiaActionError:
                    time.sleep(0.05)
            if found is None:
                raise UiaActionError("wait_timeout", "Timed out waiting for element.")
            after_el = found
        elif action.action_type == ActionType.WAIT_FOR_WINDOW:
            deadline = time.monotonic() + action.timeout_seconds
            while time.monotonic() < deadline:
                self._check_cancel_or_stop()
                try:
                    snap = capture_target(
                        self.backend,
                        expected_window=action.window,
                        require_foreground=False,
                        scale_factor=self.scale_factor,
                    )
                    after_win = snap.window
                    break
                except TargetDriftError:
                    time.sleep(0.05)
            else:
                raise UiaActionError("wait_timeout", "Timed out waiting for window.")
        elif action.action_type in {
            ActionType.CLICK,
            ActionType.DOUBLE_CLICK,
            ActionType.RIGHT_CLICK,
            ActionType.MOVE_POINTER,
            ActionType.KEY_PRESS,
            ActionType.KEY_CHORD,
            ActionType.TYPE_TEXT,
        }:
            if not action.allow_input_fallback and not input_ok:
                raise UiaActionError(
                    "input_not_permitted",
                    "Input actions require desktop.windows.input and policy allow_input_fallback.",
                )
            after_el, after_win, used_fallback, detail = self._input_fallback(action, window, element)
        elif action.action_type == ActionType.VERIFY_STATE:
            detail = {"ok": True}
        else:
            raise UiaActionError("unsupported_action", f"Unsupported action: {action.action_type.value}")

        return after_el, after_win, used_fallback, detail

    def _input_fallback(self, action: ActionRequest, window, element):
        # Reconfirm foreground immediately
        snap = capture_target(
            self.backend,
            expected_window={"hwnd": window.hwnd, "process_id": window.process_id},
            element=element,
            require_foreground=True,
            scale_factor=self.scale_factor,
        )
        verified = True
        detail: dict[str, Any] = {}
        if action.action_type == ActionType.CLICK:
            detail = self.input.click(
                window=snap.window, element=element, button="left", clicks=1, verified_foreground=verified
            )
        elif action.action_type == ActionType.DOUBLE_CLICK:
            detail = self.input.click(
                window=snap.window, element=element, button="left", clicks=2, verified_foreground=verified
            )
        elif action.action_type == ActionType.RIGHT_CLICK:
            detail = self.input.click(
                window=snap.window, element=element, button="right", clicks=1, verified_foreground=verified
            )
        elif action.action_type == ActionType.MOVE_POINTER:
            x, y = action.coordinates or (
                element.bounds.center() if element and element.bounds else (0.0, 0.0)
            )
            detail = self.input.move_pointer(
                window=snap.window, x=x, y=y, verified_foreground=verified
            )
        elif action.action_type in {ActionType.KEY_PRESS, ActionType.KEY_CHORD}:
            detail = self.input.key_press(
                window=snap.window,
                keys=action.keys or [],
                verified_foreground=verified,
                is_secret=bool(action.metadata.get("is_secret")),
            )
        elif action.action_type == ActionType.TYPE_TEXT:
            detail = self.input.type_text(
                window=snap.window,
                text=action.text or "",
                verified_foreground=verified,
                is_secret=bool(action.metadata.get("is_secret") or action.metadata.get("is_password")),
            )
        else:
            # Generic click fallback for invoke
            detail = self.input.click(
                window=snap.window, element=element, verified_foreground=verified
            )
            if element and isinstance(self.backend, MockDesktopBackend):
                self.backend.mark_invoked(element.element_id)
                element = self.backend.get_element(element.element_id) or element
        return element, snap.window, True, detail

    def _result(
        self,
        action: ActionRequest,
        outcome: ActionOutcome,
        verification: VerificationStatus,
        message: str,
        risk: ActionRisk,
        started: float,
        error_code: str | None = None,
    ) -> ActionResult:
        return ActionResult(
            action_id=action.action_id,
            outcome=outcome,
            verification=verification,
            message=message,
            risk=risk,
            error_code=error_code,
            duration_ms=int((time.perf_counter() - started) * 1000),
        )


def run_windows_cua_command(command: dict[str, Any]) -> list[dict[str, Any]]:
    """Synchronous helper used by the worker adapter (also for tests)."""
    context = command.get("context_pack") if isinstance(command.get("context_pack"), dict) else {}
    session_id = str(command.get("session_id") or new_id("sess"))
    scopes = list(context.get("policy_scopes") or command.get("policy_scopes") or [])
    # Production never selects a mock desktop unless explicitly in test simulation mode.
    sim = simulation_enabled() or bool(context.get("simulation"))
    try:
        backend = create_backend(simulation=sim)
    except Exception as exc:  # noqa: BLE001
        return [
            {
                "event_type": "command_started",
                "payload": {
                    "command_id": command.get("command_id"),
                    "session_id": session_id,
                    "adapter": "windows_cua",
                },
            },
            {
                "event_type": "evidence",
                "payload": {
                    "evidence_type": "terminal_result",
                    "summary": f"Windows CUA backend init failed: {exc}",
                    "payload": {
                        "adapter": "windows_cua",
                        "exit_code": 1,
                        "error": str(exc),
                        "error_code": "backend_init_failed",
                    },
                },
            },
            {
                "event_type": "command_finished",
                "payload": {
                    "command_id": command.get("command_id"),
                    "exit_code": 1,
                    "session_state": SessionState.FAILED.value,
                },
            },
        ]
    health = probe_health(allow_non_windows_simulation=sim)
    session = WindowsCuaSession(
        session_id=session_id,
        backend=backend,
        granted_scopes=scopes,
        scale_factor=health.dpi_scale or 1.0,
    )

    events: list[dict[str, Any]] = []
    events.append(
        {
            "event_type": "command_started",
            "payload": {
                "command_id": command.get("command_id"),
                "session_id": session_id,
                "adapter": "windows_cua",
                "capabilities": [r.to_dict() for r in build_capability_reports()],
            },
        }
    )

    actions_spec = context.get("actions") or command.get("actions") or []
    if not actions_spec:
        # Default vertical slice: enumerate + inspect
        actions_spec = [
            {"action_type": "enumerate_windows"},
            {"action_type": "inspect_active_window"},
        ]

    results = []
    exit_code = 0
    for raw in actions_spec:
        action = _parse_action(raw, session_id=session_id, scopes=scopes)
        result = session.execute(action)
        results.append(result.to_dict())
        for rev in session.runtime_events[-5:]:
            events.append({"event_type": "runtime_event", "payload": rev})
        if session.evidence.records:
            rec = session.evidence.records[-1]
            events.append(
                {
                    "event_type": "evidence",
                    "payload": {
                        "evidence_type": "windows_cua_action",
                        "summary": f"{action.action_type.value}: {result.outcome.value}",
                        "payload": rec.to_dict(),
                    },
                }
            )
        if result.outcome not in {ActionOutcome.SUCCESS}:
            exit_code = 1
            if result.outcome in {
                ActionOutcome.EMERGENCY_STOPPED,
                ActionOutcome.CANCELLED,
            }:
                break

    events.append(
        {
            "event_type": "command_finished",
            "payload": {
                "command_id": command.get("command_id"),
                "exit_code": exit_code,
                "results": results,
                "session_state": session.state.value,
            },
        }
    )
    events.append(
        {
            "event_type": "evidence",
            "payload": {
                "evidence_type": "terminal_result",
                "summary": f"Windows CUA finished with exit {exit_code}",
                "payload": {
                    "adapter": "windows_cua",
                    "exit_code": exit_code,
                    "session_id": session_id,
                    "state": session.state.value,
                    "results": results,
                    "runtime_events": session.runtime_events,
                },
            },
        }
    )
    return events


def _parse_action(raw: dict[str, Any], *, session_id: str, scopes: list[str]) -> ActionRequest:
    from megas.operate.windows.models import ApprovalGrant

    action_type = ActionType(str(raw.get("action_type") or raw.get("type") or "enumerate_windows"))
    selector = None
    if raw.get("selector"):
        sel = raw["selector"]
        selector = ElementSelector(
            automation_id=sel.get("automation_id"),
            name=sel.get("name"),
            control_type=sel.get("control_type"),
            class_name=sel.get("class_name"),
            process_id=sel.get("process_id"),
            hwnd=sel.get("hwnd"),
        )
    approval = None
    if raw.get("approval"):
        a = raw["approval"]
        approval = ApprovalGrant(
            approval_id=str(a.get("approval_id") or new_id("apr")),
            action_id=str(raw.get("action_id") or a.get("action_id") or ""),
            session_id=str(a.get("session_id") or session_id),
            expires_at=str(a["expires_at"]),
            application=a.get("application"),
            process_id=a.get("process_id"),
            window_fingerprint=a.get("window_fingerprint"),
            element_fingerprint=a.get("element_fingerprint"),
            proposed_values_hash=a.get("proposed_values_hash"),
            expected_effect=a.get("expected_effect"),
        )
    action_id = str(raw.get("action_id") or new_id("act"))
    if approval and not approval.action_id:
        approval.action_id = action_id
    return ActionRequest(
        action_type=action_type,
        action_id=action_id,
        session_id=session_id,
        selector=selector,
        window=raw.get("window"),
        text=raw.get("text"),
        keys=raw.get("keys"),
        coordinates=tuple(raw["coordinates"]) if raw.get("coordinates") else None,
        timeout_seconds=float(raw.get("timeout_seconds") or 10),
        allow_input_fallback=bool(raw.get("allow_input_fallback")),
        expected=raw.get("expected"),
        approval=approval,
        policy_scopes=list(raw.get("policy_scopes") or scopes),
        metadata=dict(raw.get("metadata") or {}),
        idempotency_key=raw.get("idempotency_key"),
    )
