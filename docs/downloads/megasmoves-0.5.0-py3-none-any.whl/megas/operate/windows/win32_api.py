"""Production Win32 helpers via ctypes (no pyautogui / no demos).

Used on Windows for window identity, desktop security state, DPI, input, capture.
"""

from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes
from dataclasses import dataclass
from typing import Any, Callable

from megas.operate.windows.models import DisplayInfo, Rect, WindowIdentity, new_id


def is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


if is_windows():
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    try:
        shcore = ctypes.windll.shcore
    except Exception:  # noqa: BLE001
        shcore = None
    try:
        gdi32 = ctypes.windll.gdi32
    except Exception:  # noqa: BLE001
        gdi32 = None

    # Ensure process is DPI-aware so coordinates match physical pixels.
    try:
        if shcore is not None:
            shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
        else:
            user32.SetProcessDPIAware()
    except Exception:  # noqa: BLE001
        try:
            user32.SetProcessDPIAware()
        except Exception:  # noqa: BLE001
            pass
else:
    user32 = None
    kernel32 = None
    shcore = None
    gdi32 = None


def require_windows() -> None:
    if not is_windows() or user32 is None:
        raise RuntimeError("Win32 APIs require Windows.")


@dataclass
class NativeWindow:
    hwnd: int
    title: str
    class_name: str
    process_id: int
    left: int
    top: int
    right: int
    bottom: int
    visible: bool
    minimized: bool


def _get_window_text(hwnd: int) -> str:
    length = user32.GetWindowTextLengthW(hwnd)
    if length <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, length + 1)
    return buf.value


def _get_class_name(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def _get_pid(hwnd: int) -> int:
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def _get_rect(hwnd: int) -> tuple[int, int, int, int]:
    rect = wintypes.RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return 0, 0, 0, 0
    return int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)


def process_executable(pid: int) -> str | None:
    require_windows()
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(size.value)
        # QueryFullProcessImageNameW
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            path = buf.value
            return path.rsplit("\\", 1)[-1] if path else None
        return None
    finally:
        kernel32.CloseHandle(handle)


def list_top_level_windows() -> list[NativeWindow]:
    require_windows()
    results: list[NativeWindow] = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def _enum(hwnd, _lparam):  # noqa: ANN001
        if not user32.IsWindowVisible(hwnd):
            return True
        title = _get_window_text(hwnd)
        if not title.strip():
            return True
        left, top, right, bottom = _get_rect(hwnd)
        pid = _get_pid(hwnd)
        minimized = bool(user32.IsIconic(hwnd))
        results.append(
            NativeWindow(
                hwnd=int(hwnd),
                title=title,
                class_name=_get_class_name(hwnd),
                process_id=pid,
                left=left,
                top=top,
                right=right,
                bottom=bottom,
                visible=True,
                minimized=minimized,
            )
        )
        return True

    user32.EnumWindows(_enum, 0)
    return results


def get_foreground_window() -> NativeWindow | None:
    require_windows()
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None
    left, top, right, bottom = _get_rect(hwnd)
    return NativeWindow(
        hwnd=int(hwnd),
        title=_get_window_text(hwnd),
        class_name=_get_class_name(hwnd),
        process_id=_get_pid(hwnd),
        left=left,
        top=top,
        right=right,
        bottom=bottom,
        visible=bool(user32.IsWindowVisible(hwnd)),
        minimized=bool(user32.IsIconic(hwnd)),
    )


def to_window_identity(native: NativeWindow, *, is_foreground: bool = False) -> WindowIdentity:
    return WindowIdentity(
        hwnd=native.hwnd,
        process_id=native.process_id,
        title=native.title,
        class_name=native.class_name,
        executable=process_executable(native.process_id),
        bounds=Rect(
            left=float(native.left),
            top=float(native.top),
            width=float(max(0, native.right - native.left)),
            height=float(max(0, native.bottom - native.top)),
        ),
        monitor_id=monitor_id_for_point(
            (native.left + native.right) // 2, (native.top + native.bottom) // 2
        ),
        is_foreground=is_foreground,
        is_minimized=native.minimized,
        is_visible=native.visible,
    )


def is_session_locked() -> bool:
    """True when the interactive desktop is not the user desktop (locked/secure)."""
    require_windows()
    # OpenInputDesktop fails or returns non-default when locked/secure.
    DESKTOP_READOBJECTS = 0x0001
    DESKTOP_SWITCHDESKTOP = 0x0100
    hdesk = user32.OpenInputDesktop(0, False, DESKTOP_READOBJECTS | DESKTOP_SWITCHDESKTOP)
    if not hdesk:
        return True
    try:
        # If SwitchDesktop fails, session is likely locked / secure.
        # We do not call SwitchDesktop (destructive); use GetUserObjectInformation name.
        UOI_NAME = 2
        needed = wintypes.DWORD()
        user32.GetUserObjectInformationW(hdesk, UOI_NAME, None, 0, ctypes.byref(needed))
        buf = ctypes.create_unicode_buffer(max(needed.value // 2, 32))
        if user32.GetUserObjectInformationW(
            hdesk, UOI_NAME, buf, ctypes.sizeof(buf), ctypes.byref(needed)
        ):
            name = (buf.value or "").lower()
            # Default user desktop is usually "default"; Winlogon is secure.
            if "winlogon" in name or "screensaver" in name:
                return True
            if name and name not in {"default", "desktop"}:
                # Unknown non-default desktops treated as locked/secure for fail-closed.
                if "default" not in name:
                    return True
        return False
    finally:
        user32.CloseDesktop(hdesk)


def is_secure_desktop() -> bool:
    require_windows()
    # Heuristic: input desktop name contains Winlogon, or System process owns foreground class.
    if is_session_locked():
        # Locked often implies secure-like state for automation purposes.
        fg = get_foreground_window()
        if fg and fg.class_name in {"#32770", "Credential Dialog Xaml Host"}:
            return True
    fg = get_foreground_window()
    if fg is None:
        return False
    secure_classes = {
        "Credential Dialog Xaml Host",
        "Windows.UI.Core.CoreWindow",  # sometimes used by consent UI
    }
    if fg.class_name in secure_classes and "credential" in (fg.title or "").lower():
        return True
    # UAC consent UI typically owned by consent.exe / high integrity
    exe = process_executable(fg.process_id) or ""
    if exe.lower() in {"consent.exe", "logonui.exe"}:
        return True
    return False


def is_uac_prompt_present() -> bool:
    require_windows()
    for win in list_top_level_windows():
        exe = (process_executable(win.process_id) or "").lower()
        title = (win.title or "").lower()
        if exe == "consent.exe":
            return True
        if "user account control" in title:
            return True
    return False


def primary_dpi_scale() -> float:
    require_windows()
    try:
        hdc = user32.GetDC(0)
        try:
            LOGPIXELSX = 88
            dpi = gdi32.GetDeviceCaps(hdc, LOGPIXELSX) if gdi32 else 96
            return float(dpi) / 96.0
        finally:
            user32.ReleaseDC(0, hdc)
    except Exception:  # noqa: BLE001
        return 1.0


def list_displays() -> list[DisplayInfo]:
    require_windows()
    displays: list[DisplayInfo] = []

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", ctypes.c_long),
            ("top", ctypes.c_long),
            ("right", ctypes.c_long),
            ("bottom", ctypes.c_long),
        ]

    class MONITORINFO(ctypes.Structure):
        _fields_ = [
            ("cbSize", ctypes.c_ulong),
            ("rcMonitor", RECT),
            ("rcWork", RECT),
            ("dwFlags", ctypes.c_ulong),
        ]

    MONITORINFOF_PRIMARY = 1

    @ctypes.WINFUNCTYPE(
        ctypes.c_int,
        ctypes.c_ulong,
        ctypes.c_ulong,
        ctypes.POINTER(RECT),
        ctypes.c_double,
    )
    def _monitor_enum(hmonitor, _hdc, lprect, _data):  # noqa: ANN001
        info = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        if user32.GetMonitorInfoW(hmonitor, ctypes.byref(info)):
            r = info.rcMonitor
            scale = 1.0
            try:
                if shcore is not None:
                    dpi_x = ctypes.c_uint()
                    dpi_y = ctypes.c_uint()
                    # MDT_EFFECTIVE_DPI = 0
                    shcore.GetDpiForMonitor(hmonitor, 0, ctypes.byref(dpi_x), ctypes.byref(dpi_y))
                    scale = float(dpi_x.value) / 96.0
            except Exception:  # noqa: BLE001
                scale = primary_dpi_scale()
            displays.append(
                DisplayInfo(
                    display_id=f"mon_{int(hmonitor)}",
                    width=int(r.right - r.left),
                    height=int(r.bottom - r.top),
                    scale_factor=scale,
                    is_primary=bool(info.dwFlags & MONITORINFOF_PRIMARY),
                    left=int(r.left),
                    top=int(r.top),
                )
            )
        return 1

    try:
        user32.EnumDisplayMonitors(0, 0, _monitor_enum, 0)
    except Exception:  # noqa: BLE001
        scale = primary_dpi_scale()
        width = user32.GetSystemMetrics(0)
        height = user32.GetSystemMetrics(1)
        displays.append(
            DisplayInfo(
                display_id="primary",
                width=int(width),
                height=int(height),
                scale_factor=scale,
                is_primary=True,
            )
        )
    return displays


def monitor_id_for_point(x: int, y: int) -> str | None:
    if not is_windows():
        return None
    try:
        for d in list_displays():
            if d.left <= x < d.left + d.width and d.top <= y < d.top + d.height:
                return d.display_id
    except Exception:  # noqa: BLE001
        return "primary"
    return "primary"


# --- SendInput ---

INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_ABSOLUTE = 0x8000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg", wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]


def _screen_size() -> tuple[int, int]:
    return int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))


def send_mouse_move_absolute(x: int, y: int) -> None:
    require_windows()
    sw, sh = _screen_size()
    # Absolute coords are 0..65535 across primary virtual screen.
    ax = int(x * 65535 / max(sw - 1, 1))
    ay = int(y * 65535 / max(sh - 1, 1))
    inp = INPUT()
    inp.type = INPUT_MOUSE
    inp.union.mi = MOUSEINPUT(ax, ay, 0, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, 0, None)
    if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT)) != 1:
        raise RuntimeError("SendInput mouse move failed.")


def send_mouse_click(*, button: str = "left", clicks: int = 1) -> None:
    require_windows()
    if button == "right":
        down, up = MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP
    else:
        down, up = MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP
    for _ in range(max(1, clicks)):
        for flag in (down, up):
            inp = INPUT()
            inp.type = INPUT_MOUSE
            inp.union.mi = MOUSEINPUT(0, 0, 0, flag, 0, None)
            if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT)) != 1:
                raise RuntimeError("SendInput mouse click failed.")


def send_unicode_text(text: str) -> None:
    """Type text via UNICODE key events (does not log secrets; caller must redact)."""
    require_windows()
    for ch in text:
        for flags in (KEYEVENTF_UNICODE, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP):
            inp = INPUT()
            inp.type = INPUT_KEYBOARD
            inp.union.ki = KEYBDINPUT(0, ord(ch), flags, 0, None)
            if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT)) != 1:
                raise RuntimeError("SendInput unicode key failed.")


_VK = {
    "enter": 0x0D,
    "tab": 0x09,
    "esc": 0x1B,
    "escape": 0x1B,
    "backspace": 0x08,
    "delete": 0x2E,
    "up": 0x26,
    "down": 0x28,
    "left": 0x25,
    "right": 0x27,
    "ctrl": 0x11,
    "control": 0x11,
    "alt": 0x12,
    "shift": 0x10,
    "win": 0x5B,
    "cmd": 0x5B,
}


def send_key_chord(keys: list[str]) -> None:
    require_windows()
    vks: list[int] = []
    for key in keys:
        k = key.lower().strip()
        if k in _VK:
            vks.append(_VK[k])
        elif len(k) == 1:
            code = user32.VkKeyScanW(ord(k))
            vks.append(code & 0xFF)
        else:
            raise RuntimeError(f"Unknown key: {key}")
    # press in order, release reverse
    for vk in vks:
        inp = INPUT()
        inp.type = INPUT_KEYBOARD
        inp.union.ki = KEYBDINPUT(vk, 0, 0, 0, None)
        user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
    for vk in reversed(vks):
        inp = INPUT()
        inp.type = INPUT_KEYBOARD
        inp.union.ki = KEYBDINPUT(vk, 0, KEYEVENTF_KEYUP, 0, None)
        user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def set_foreground(hwnd: int) -> bool:
    require_windows()
    if not user32.IsWindow(hwnd):
        return False
    # Restore user-authorized minimized windows before requesting focus.
    # No keyboard simulation, foreground-lock bypass or privilege escalation.
    user32.ShowWindow(hwnd, 9 if user32.IsIconic(hwnd) else 5)  # SW_RESTORE / SW_SHOW
    return bool(user32.SetForegroundWindow(hwnd))



def _png_chunk(kind: bytes, payload: bytes) -> bytes:
    """Encode one PNG chunk without external image dependencies."""
    import binascii
    import struct

    return (
        struct.pack(">I", len(payload))
        + kind
        + payload
        + struct.pack(">I", binascii.crc32(kind + payload) & 0xFFFFFFFF)
    )


def _encode_png_bgra(pixels: bytes, width: int, height: int) -> bytes:
    """Encode top-down 32-bit BGRA pixels as an RGBA PNG."""
    import struct
    import zlib

    if width <= 0 or height <= 0:
        raise ValueError("PNG dimensions must be positive")
    stride = width * 4
    expected = stride * height
    if len(pixels) != expected:
        raise ValueError(f"expected {expected} BGRA bytes, received {len(pixels)}")

    rgba = bytearray(pixels)
    # GDI returns B,G,R,A. Swap R/B in bulk and force opaque alpha because
    # compatible bitmaps commonly leave alpha at zero.
    rgba[0::4], rgba[2::4] = pixels[2::4], pixels[0::4]
    rgba[3::4] = b"\xff" * (width * height)

    filtered = bytearray((stride + 1) * height)
    for row in range(height):
        source = row * stride
        target = row * (stride + 1)
        # Filter type 0 keeps the encoder deterministic and cheap.
        filtered[target] = 0
        filtered[target + 1 : target + 1 + stride] = rgba[source : source + stride]

    signature = b"\x89PNG\r\n\x1a\n"
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    compressed = zlib.compress(bytes(filtered), level=9)
    return (
        signature
        + _png_chunk(b"IHDR", header)
        + _png_chunk(b"IDAT", compressed)
        + _png_chunk(b"IEND", b"")
    )


def _fit_capture_size(
    source_width: int,
    source_height: int,
    *,
    max_width: int,
    max_height: int,
) -> tuple[int, int]:
    if source_width <= 0 or source_height <= 0:
        return 0, 0
    scale = min(
        1.0,
        float(max_width) / float(source_width),
        float(max_height) / float(source_height),
    )
    return (
        max(1, int(round(source_width * scale))),
        max(1, int(round(source_height * scale))),
    )


def _capture_window_bgra(hwnd: int, target_width: int, target_height: int) -> bytes | None:
    """Capture a window DC into a bounded top-down BGRA buffer."""
    require_windows()
    if gdi32 is None or not user32.IsWindow(hwnd):
        return None

    left, top, right, bottom = _get_rect(hwnd)
    source_width = max(0, right - left)
    source_height = max(0, bottom - top)
    if source_width <= 0 or source_height <= 0:
        return None

    hdc = user32.GetWindowDC(hwnd)
    if not hdc:
        return None

    memdc = None
    bmp = None
    old_object = None
    try:
        memdc = gdi32.CreateCompatibleDC(hdc)
        if not memdc:
            return None
        bmp = gdi32.CreateCompatibleBitmap(hdc, target_width, target_height)
        if not bmp:
            return None
        old_object = gdi32.SelectObject(memdc, bmp)

        rop = 0x00CC0020 | 0x40000000  # SRCCOPY | CAPTUREBLT
        if target_width == source_width and target_height == source_height:
            copied = gdi32.BitBlt(
                memdc,
                0,
                0,
                target_width,
                target_height,
                hdc,
                0,
                0,
                rop,
            )
        else:
            # HALFTONE provides readable text when reducing large HiDPI windows.
            try:
                gdi32.SetStretchBltMode(memdc, 4)
            except Exception:  # noqa: BLE001
                pass
            copied = gdi32.StretchBlt(
                memdc,
                0,
                0,
                target_width,
                target_height,
                hdc,
                0,
                0,
                source_width,
                source_height,
                rop,
            )
        if not copied:
            return None

        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [
                ("biSize", wintypes.DWORD),
                ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD),
                ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG),
                ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD),
            ]

        bmi = BITMAPINFOHEADER()
        bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.biWidth = target_width
        bmi.biHeight = -target_height
        bmi.biPlanes = 1
        bmi.biBitCount = 32
        bmi.biCompression = 0

        size = target_width * target_height * 4
        buffer = (ctypes.c_ubyte * size)()
        rows = gdi32.GetDIBits(
            memdc,
            bmp,
            0,
            target_height,
            buffer,
            ctypes.byref(bmi),
            0,
        )
        if rows != target_height:
            return None
        return bytes(buffer)
    finally:
        if memdc and old_object:
            try:
                gdi32.SelectObject(memdc, old_object)
            except Exception:  # noqa: BLE001
                pass
        if bmp:
            gdi32.DeleteObject(bmp)
        if memdc:
            gdi32.DeleteDC(memdc)
        user32.ReleaseDC(hwnd, hdc)


def capture_window_png(
    hwnd: int,
    *,
    max_width: int = 1024,
    max_height: int = 768,
    max_bytes: int = 1_500_000,
) -> dict[str, Any] | None:
    """Capture one existing window as bounded PNG evidence.

    No pixels are written to disk. If a high-entropy 1024px capture exceeds the
    transport budget, the function retries at at most 640x480 so the returned
    PNG remains bounded without silently truncating bytes.
    """

    require_windows()
    if gdi32 is None or not user32.IsWindow(hwnd):
        return None

    left, top, right, bottom = _get_rect(hwnd)
    source_width = max(0, right - left)
    source_height = max(0, bottom - top)
    if source_width <= 0 or source_height <= 0:
        return None

    max_width = max(320, min(1600, int(max_width)))
    max_height = max(240, min(1200, int(max_height)))
    max_bytes = max(64_000, min(1_500_000, int(max_bytes)))

    primary = _fit_capture_size(
        source_width,
        source_height,
        max_width=max_width,
        max_height=max_height,
    )
    fallback = _fit_capture_size(
        source_width,
        source_height,
        max_width=min(max_width, 640),
        max_height=min(max_height, 480),
    )
    attempts: list[tuple[int, int]] = []
    for size in (primary, fallback):
        if size not in attempts:
            attempts.append(size)

    for target_width, target_height in attempts:
        pixels = _capture_window_bgra(hwnd, target_width, target_height)
        if pixels is None:
            continue
        png = _encode_png_bgra(pixels, target_width, target_height)
        if len(png) <= max_bytes:
            return {
                "png": png,
                "width": target_width,
                "height": target_height,
                "source_width": source_width,
                "source_height": source_height,
                "scaled": (target_width, target_height) != (source_width, source_height),
            }

    raise RuntimeError("Foreground capture exceeded the bounded image evidence limit.")

def capture_screen_hash() -> dict[str, Any] | None:
    """Capture primary screen pixels and return hash metadata only (no raw dump to logs)."""
    require_windows()
    if gdi32 is None:
        return None
    import hashlib

    width = user32.GetSystemMetrics(0)
    height = user32.GetSystemMetrics(1)
    hwnd = user32.GetDesktopWindow()
    hdc = user32.GetWindowDC(hwnd)
    if not hdc:
        return None
    try:
        memdc = gdi32.CreateCompatibleDC(hdc)
        bmp = gdi32.CreateCompatibleBitmap(hdc, width, height)
        gdi32.SelectObject(memdc, bmp)
        # CAPTUREBLT | SRCCOPY
        gdi32.BitBlt(memdc, 0, 0, width, height, hdc, 0, 0, 0x00CC0020 | 0x40000000)

        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [
                ("biSize", wintypes.DWORD),
                ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD),
                ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG),
                ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD),
            ]

        bmi = BITMAPINFOHEADER()
        bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.biWidth = width
        bmi.biHeight = -height
        bmi.biPlanes = 1
        bmi.biBitCount = 32
        bmi.biCompression = 0
        buf_size = width * height * 4
        buf = (ctypes.c_char * buf_size)()
        gdi32.GetDIBits(memdc, bmp, 0, height, buf, ctypes.byref(bmi), 0)
        digest = hashlib.sha256(bytes(buf)).hexdigest()[:32]
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(memdc)
        return {
            "hash": digest,
            "resolution": (width, height),
            "offset": (0, 0),
            "pixels_stored": False,
        }
    finally:
        user32.ReleaseDC(hwnd, hdc)


def uiautomation_available() -> bool:
    try:
        import uiautomation  # noqa: F401

        return True
    except ImportError:
        return False
