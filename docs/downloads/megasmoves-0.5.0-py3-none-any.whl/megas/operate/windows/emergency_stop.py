"""Emergency stop — halt control, release locks, emit immutable event."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any, Callable

from megas.operate.windows.models import RuntimeEvent, utc_now


@dataclass
class EmergencyStopController:
    """Process-wide stop latch for the interactive desktop."""

    _stopped: bool = False
    _lock: threading.RLock = field(default_factory=threading.RLock)
    _listeners: list[Callable[[], None]] = field(default_factory=list)
    last_event: dict[str, Any] | None = None
    reason: str | None = None

    def is_stopped(self) -> bool:
        with self._lock:
            return self._stopped

    def register_listener(self, callback: Callable[[], None]) -> None:
        with self._lock:
            self._listeners.append(callback)

    def trigger(self, *, session_id: str | None, reason: str, source: str) -> RuntimeEvent:
        with self._lock:
            self._stopped = True
            self.reason = reason
            event = RuntimeEvent(
                event_type="windows_cua.emergency_stop",
                severity="critical",
                message=f"Emergency stop: {reason}",
                session_id=session_id,
                attributes={
                    "source": source,
                    "reason": reason,
                    "immutable": True,
                    "occurred_at": utc_now(),
                },
            )
            self.last_event = event.to_dict()
            listeners = list(self._listeners)
        for listener in listeners:
            try:
                listener()
            except Exception:
                pass
        return event

    def clear_for_tests(self) -> None:
        with self._lock:
            self._stopped = False
            self.reason = None
            self.last_event = None
            self._listeners.clear()


# Module singleton for local keyboard escape + control channel.
EMERGENCY_STOP = EmergencyStopController()


def local_escape_triggered() -> bool:
    """Hook for configurable local keyboard escape (e.g. Ctrl+Shift+Alt+Esc).

    Actual OS hotkey registration is platform-specific; this flag can be set by
    the worker control channel or a native hook module.
    """
    return EMERGENCY_STOP.is_stopped()
