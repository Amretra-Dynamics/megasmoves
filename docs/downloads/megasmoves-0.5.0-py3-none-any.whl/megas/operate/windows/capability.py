"""Versioned Windows CUA capability reports (health + certification + owner gate)."""

from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field
from typing import Any

from megas.operate.gate import is_operate_enabled
from megas.operate.windows.health import HealthSnapshot, probe_health
from megas.operate.windows.models import ActionType, utc_now

CAPABILITY_WINDOWS_UIA = "desktop.windows.uia"
CAPABILITY_WINDOWS_INPUT = "desktop.windows.input"
ADAPTER_VERSION = "1.0.0"

SUPPORTED_UIA_ACTIONS = [
    ActionType.ENUMERATE_WINDOWS.value,
    ActionType.INSPECT_ACTIVE_WINDOW.value,
    ActionType.INSPECT_ACCESSIBILITY_TREE.value,
    ActionType.FIND_ELEMENT.value,
    ActionType.FOCUS_ELEMENT.value,
    ActionType.INVOKE_ELEMENT.value,
    ActionType.SET_TEXT.value,
    ActionType.READ_VISIBLE_TEXT.value,
    ActionType.SELECT_ITEM.value,
    ActionType.TOGGLE_CONTROL.value,
    ActionType.EXPAND_COLLAPSE.value,
    ActionType.SCROLL.value,
    ActionType.WAIT_FOR_ELEMENT.value,
    ActionType.WAIT_FOR_WINDOW.value,
    ActionType.CAPTURE_SCREENSHOT.value,
    ActionType.VERIFY_STATE.value,
    ActionType.CANCEL_SESSION.value,
    ActionType.EMERGENCY_STOP.value,
]

SUPPORTED_INPUT_ACTIONS = [
    ActionType.MOVE_POINTER.value,
    ActionType.CLICK.value,
    ActionType.DOUBLE_CLICK.value,
    ActionType.RIGHT_CLICK.value,
    ActionType.KEY_PRESS.value,
    ActionType.KEY_CHORD.value,
    ActionType.TYPE_TEXT.value,
]


@dataclass
class CapabilityReport:
    name: str
    available: bool
    health_status: str
    certification_status: str
    os_name: str
    os_version: str
    architecture: str
    adapter_version: str = ADAPTER_VERSION
    uia_available: bool = False
    input_fallback_available: bool = False
    screenshot_available: bool = False
    active_display_count: int = 0
    dpi_scale: float = 1.0
    policy_scope: list[str] = field(default_factory=list)
    supported_action_types: list[str] = field(default_factory=list)
    emergency_stop_available: bool = True
    reasons: list[str] = field(default_factory=list)
    checked_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def certification_enabled() -> bool:
    """Whether the installed Windows CUA build is release-certified."""
    import sys

    raw = os.getenv("MEGAS_WINDOWS_CUA_CERTIFIED", "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    # Certify any Windows runtime — frozen (PyInstaller) or unfrozen (pip /
    # dev-mode).  The previous frozen-only gate caused all source-installed
    # agents to be reported as "uncertified", blocking UIA/input capabilities.
    if os.name == "nt" or sys.platform.startswith("win"):
        return True
    return False


def simulation_enabled() -> bool:
    return os.getenv("MEGAS_WINDOWS_CUA_SIMULATION", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def build_capability_reports(
    health: HealthSnapshot | None = None,
    *,
    certified: bool | None = None,
    force_windows: bool | None = None,
) -> list[CapabilityReport]:
    snap = health or probe_health(
        force_windows=force_windows,
        allow_non_windows_simulation=simulation_enabled(),
    )
    is_certified = certification_enabled() if certified is None else certified
    owner_enabled = is_operate_enabled()
    cert_status = "certified" if is_certified else "uncertified"

    uia_available = bool(snap.healthy_for_uia and is_certified and owner_enabled)
    input_available = bool(snap.healthy_for_input and is_certified and owner_enabled)

    uia_reasons: list[str] = []
    input_reasons: list[str] = []
    if not owner_enabled:
        uia_reasons.append("operate_disabled_by_owner")
        input_reasons.append("operate_disabled_by_owner")
    if not is_certified:
        uia_reasons.append("certification_not_passed")
        input_reasons.append("certification_not_passed")
    uia_reasons.extend(snap.errors)
    input_reasons.extend(snap.errors)
    if not snap.uia_available:
        uia_reasons.append("uia_unavailable")
    if not snap.input_available:
        input_reasons.append("input_unavailable")

    def _health_label(ok: bool) -> str:
        if not owner_enabled:
            return "unavailable"
        if ok:
            return "healthy"
        if snap.is_windows or simulation_enabled():
            return "degraded" if not snap.errors else "unavailable"
        return "unavailable"

    uia = CapabilityReport(
        name=CAPABILITY_WINDOWS_UIA,
        available=uia_available,
        health_status=_health_label(snap.healthy_for_uia),
        certification_status=cert_status,
        os_name=snap.os_name,
        os_version=snap.os_version,
        architecture=snap.architecture,
        uia_available=snap.uia_available,
        input_fallback_available=False,
        screenshot_available=snap.screenshot_available,
        active_display_count=len(snap.displays),
        dpi_scale=snap.dpi_scale,
        policy_scope=["desktop.windows.uia", "read_only", "low_risk"],
        supported_action_types=list(SUPPORTED_UIA_ACTIONS),
        emergency_stop_available=True,
        reasons=sorted(set(uia_reasons)),
    )
    input_cap = CapabilityReport(
        name=CAPABILITY_WINDOWS_INPUT,
        available=input_available,
        health_status=_health_label(snap.healthy_for_input),
        certification_status=cert_status,
        os_name=snap.os_name,
        os_version=snap.os_version,
        architecture=snap.architecture,
        uia_available=snap.uia_available,
        input_fallback_available=snap.input_available,
        screenshot_available=snap.screenshot_available,
        active_display_count=len(snap.displays),
        dpi_scale=snap.dpi_scale,
        policy_scope=["desktop.windows.input", "low_risk", "sensitive", "high_risk"],
        supported_action_types=list(SUPPORTED_INPUT_ACTIONS),
        emergency_stop_available=True,
        reasons=sorted(set(input_reasons)),
    )
    return [uia, input_cap]


def advertised_capability_names(
    health: HealthSnapshot | None = None,
    *,
    certified: bool | None = None,
) -> list[str]:
    """Only return capabilities that are healthy, certified, and owner-enabled."""
    return [r.name for r in build_capability_reports(health, certified=certified) if r.available]
