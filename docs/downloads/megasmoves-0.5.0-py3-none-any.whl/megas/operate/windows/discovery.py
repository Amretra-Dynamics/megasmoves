"""Window/element discovery factory and test doubles.

Production always uses WindowsUiaBackend on Windows.
Test doubles are only constructed when explicitly requested (never as silent fallback).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from megas.operate.windows.models import (
    ElementIdentity,
    ElementSelector,
    Rect,
    WindowIdentity,
    new_id,
)


class DesktopBackend(Protocol):
    def list_windows(self) -> list[WindowIdentity]:
        ...

    def get_foreground(self) -> WindowIdentity | None:
        ...

    def focus_window(self, window: WindowIdentity) -> bool:
        ...

    def find_elements(
        self, window: WindowIdentity, selector: ElementSelector
    ) -> list[ElementIdentity]:
        ...

    def get_element(self, element_id: str) -> ElementIdentity | None:
        ...

    def accessibility_tree(self, window: WindowIdentity, *, max_nodes: int = 200) -> list[dict]:
        ...

    def is_secure_desktop(self) -> bool:
        ...

    def is_session_locked(self) -> bool:
        ...

    def is_uac_prompt_present(self) -> bool:
        ...


@dataclass
class MockDesktopBackend:
    """Injectable double for unit tests only — not a production path."""

    windows: list[WindowIdentity] = field(default_factory=list)
    elements: dict[int, list[ElementIdentity]] = field(default_factory=dict)
    foreground_hwnd: int | None = None
    secure_desktop: bool = False
    session_locked: bool = False
    uac_prompt: bool = False
    _element_index: dict[str, ElementIdentity] = field(default_factory=dict)

    def seed_basic_window(
        self,
        *,
        hwnd: int = 0x1001,
        pid: int = 4242,
        title: str = "Test Window",
        class_name: str = "TestWindowClass",
        executable: str = "testapp.exe",
    ) -> tuple[WindowIdentity, ElementIdentity, ElementIdentity]:
        """Seed a minimal controllable window for automated tests."""
        win = WindowIdentity(
            hwnd=hwnd,
            process_id=pid,
            title=title,
            class_name=class_name,
            executable=executable,
            bounds=Rect(100, 100, 800, 600),
            monitor_id="primary",
            is_foreground=True,
            is_visible=True,
        )
        edit = ElementIdentity(
            element_id=new_id("el"),
            selector=ElementSelector(
                automation_id="edit-1",
                name="Text Editor",
                control_type="Edit",
                class_name="Edit",
                process_id=win.process_id,
                hwnd=win.hwnd,
            ),
            name="Text Editor",
            control_type="Edit",
            automation_id="edit-1",
            class_name="Edit",
            bounds=Rect(120, 160, 760, 500),
            patterns=["Value", "Text", "Scroll"],
            value_preview="",
            process_id=win.process_id,
            hwnd=win.hwnd,
            is_enabled=True,
        )
        button = ElementIdentity(
            element_id=new_id("el"),
            selector=ElementSelector(
                automation_id="action-btn",
                name="OK",
                control_type="Button",
                process_id=win.process_id,
                hwnd=win.hwnd,
            ),
            name="OK",
            control_type="Button",
            automation_id="action-btn",
            bounds=Rect(700, 650, 80, 28),
            patterns=["Invoke"],
            process_id=win.process_id,
            hwnd=win.hwnd,
            is_enabled=True,
        )
        self.windows = [win]
        self.elements[win.hwnd] = [edit, button]
        self.foreground_hwnd = win.hwnd
        self._element_index = {edit.element_id: edit, button.element_id: button}
        return win, edit, button

    # Back-compat name used by existing tests
    def seed_notepad_fixture(self) -> tuple[WindowIdentity, ElementIdentity]:
        win, edit, _btn = self.seed_basic_window(
            title="Untitled - Notepad",
            class_name="Notepad",
            executable="notepad.exe",
        )
        # Preserve legacy automation id expected by older tests
        edit.automation_id = "15"
        edit.selector.automation_id = "15"
        btn = self.elements[win.hwnd][1]
        btn.automation_id = "ok-btn"
        btn.selector.automation_id = "ok-btn"
        return win, edit

    def list_windows(self) -> list[WindowIdentity]:
        return list(self.windows)

    def get_foreground(self) -> WindowIdentity | None:
        for w in self.windows:
            w.is_foreground = w.hwnd == self.foreground_hwnd
            if w.hwnd == self.foreground_hwnd:
                return w
        return None

    def focus_window(self, window: WindowIdentity) -> bool:
        if not any(item.hwnd == window.hwnd for item in self.windows):
            return False
        self.foreground_hwnd = window.hwnd
        for item in self.windows:
            item.is_foreground = item.hwnd == window.hwnd
        return True

    def find_elements(
        self, window: WindowIdentity, selector: ElementSelector
    ) -> list[ElementIdentity]:
        candidates = self.elements.get(window.hwnd, [])
        out: list[ElementIdentity] = []
        for el in candidates:
            if selector.automation_id and el.automation_id != selector.automation_id:
                continue
            if selector.name and (el.name or "") != selector.name:
                continue
            if selector.control_type and (el.control_type or "") != selector.control_type:
                continue
            if selector.class_name and (el.class_name or "") != selector.class_name:
                continue
            if selector.process_id and el.process_id != selector.process_id:
                continue
            out.append(el)
        return out

    def get_element(self, element_id: str) -> ElementIdentity | None:
        return self._element_index.get(element_id)

    def accessibility_tree(self, window: WindowIdentity, *, max_nodes: int = 200) -> list[dict]:
        nodes = []
        for el in self.elements.get(window.hwnd, [])[:max_nodes]:
            nodes.append(
                {
                    "element_id": el.element_id,
                    "name": el.name,
                    "control_type": el.control_type,
                    "automation_id": el.automation_id,
                    "patterns": list(el.patterns),
                    "is_password": el.is_password,
                }
            )
        return nodes

    def is_secure_desktop(self) -> bool:
        return self.secure_desktop

    def is_session_locked(self) -> bool:
        return self.session_locked

    def is_uac_prompt_present(self) -> bool:
        return self.uac_prompt

    def set_element_value(self, element_id: str, value: str) -> None:
        el = self._element_index.get(element_id)
        if el:
            el.value_preview = value

    def mark_invoked(self, element_id: str) -> None:
        el = self._element_index.get(element_id)
        if el and "Invoked" not in el.patterns:
            el.patterns = list(el.patterns) + ["Invoked"]


def os_is_non_windows() -> bool:
    import os
    import sys

    return not (os.name == "nt" or sys.platform.startswith("win"))


def create_backend(*, simulation: bool = False) -> DesktopBackend:
    """Create the desktop backend.

    Production: Windows + uiautomation only. No silent mock fallback.
    Tests: pass simulation=True or inject MockDesktopBackend directly.
    """
    if simulation:
        # Explicit test/sim only — still a double, never auto-selected in prod.
        backend = MockDesktopBackend()
        backend.seed_basic_window()
        return backend

    if os_is_non_windows():
        raise RuntimeError(
            "Windows Computer Use requires Windows. "
            "Set MEGAS_WINDOWS_CUA_SIMULATION=true only for automated tests."
        )

    from megas.operate.windows.uia_backend import NativeUiaError, WindowsUiaBackend

    try:
        return WindowsUiaBackend()
    except NativeUiaError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            f"Failed to initialize production UI Automation backend: {exc}"
        ) from exc
