"""Explicit locks for interactive desktop control.

Only one interactive input session per desktop; read-only UIA may share.
Adapted from Kinetic-OS concurrency needs + Local Worker isolation rules.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any


class LockContentionError(RuntimeError):
    def __init__(self, resource: str) -> None:
        super().__init__(f"Lock contention on {resource}")
        self.resource = resource


@dataclass
class _HeldLock:
    resource: str
    session_id: str
    acquired_at: float


@dataclass
class DesktopLockManager:
    _locks: dict[str, _HeldLock] = field(default_factory=dict)
    _mutex: threading.RLock = field(default_factory=threading.RLock)

    def acquire(
        self,
        resource: str,
        session_id: str,
        *,
        timeout_seconds: float = 0.0,
        exclusive: bool = True,
    ) -> None:
        deadline = time.monotonic() + max(0.0, timeout_seconds)
        while True:
            with self._mutex:
                held = self._locks.get(resource)
                if held is None or held.session_id == session_id:
                    self._locks[resource] = _HeldLock(resource, session_id, time.monotonic())
                    return
                if not exclusive and resource.startswith("read:"):
                    return
            if time.monotonic() >= deadline:
                raise LockContentionError(resource)
            time.sleep(0.01)

    def release(self, resource: str, session_id: str) -> None:
        with self._mutex:
            held = self._locks.get(resource)
            if held and held.session_id == session_id:
                del self._locks[resource]

    def release_all(self, session_id: str) -> None:
        with self._mutex:
            for key in [k for k, v in self._locks.items() if v.session_id == session_id]:
                del self._locks[key]

    def held_by(self, resource: str) -> str | None:
        with self._mutex:
            held = self._locks.get(resource)
            return held.session_id if held else None

    def snapshot(self) -> list[dict[str, Any]]:
        with self._mutex:
            return [
                {"resource": v.resource, "session_id": v.session_id, "acquired_at": v.acquired_at}
                for v in self._locks.values()
            ]


# Resources
INTERACTIVE_DESKTOP = "interactive_desktop"
CLIPBOARD = "clipboard"
SCREENSHOT = "screenshot"


def window_lock_key(hwnd: int) -> str:
    return f"window:{hwnd}"


def app_lock_key(process_id: int) -> str:
    return f"app:{process_id}"


LOCKS = DesktopLockManager()
