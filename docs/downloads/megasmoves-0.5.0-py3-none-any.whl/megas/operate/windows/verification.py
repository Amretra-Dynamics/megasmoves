"""Independent action verification — never fabricate success.

Inspired by Kinetic-OS progress/hash checks and property assertions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from megas.operate.windows.discovery import DesktopBackend, MockDesktopBackend
from megas.operate.windows.models import (
    ActionRequest,
    ActionType,
    ElementIdentity,
    VerificationStatus,
    WindowIdentity,
)


@dataclass
class VerificationResult:
    status: VerificationStatus
    message: str
    checks: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "message": self.message,
            "checks": list(self.checks),
        }


def verify_action(
    *,
    backend: DesktopBackend,
    action: ActionRequest,
    before_element: ElementIdentity | None,
    after_element: ElementIdentity | None,
    before_window: WindowIdentity | None,
    after_window: WindowIdentity | None,
    execution_ok: bool,
    used_fallback: bool,
    screenshot_progress: dict[str, Any] | None = None,
) -> VerificationResult:
    checks: list[dict[str, Any]] = []

    if not execution_ok:
        return VerificationResult(
            status=VerificationStatus.FAILED,
            message="Execution did not complete successfully.",
            checks=[{"check": "execution", "passed": False}],
        )

    expected = action.expected or {}

    # Read-only actions verify observation availability.
    if action.action_type in {
        ActionType.ENUMERATE_WINDOWS,
        ActionType.INSPECT_ACTIVE_WINDOW,
        ActionType.INSPECT_ACCESSIBILITY_TREE,
        ActionType.FIND_ELEMENT,
        ActionType.READ_VISIBLE_TEXT,
        ActionType.CAPTURE_SCREENSHOT,
    }:
        checks.append({"check": "observation", "passed": True})
        return VerificationResult(
            status=VerificationStatus.VERIFIED,
            message="Observation completed.",
            checks=checks,
        )

    if after_element is None and action.selector is not None:
        checks.append({"check": "element_present_after", "passed": False})
        return VerificationResult(
            status=VerificationStatus.FAILED,
            message="Target element missing after action.",
            checks=checks,
        )

    # Property changes
    if action.action_type == ActionType.SET_TEXT and after_element is not None:
        if after_element.is_password:
            # Cannot verify secret content; require control still enabled/focused patterns.
            checks.append({"check": "password_field_set_opaque", "passed": True})
        else:
            expected_text = expected.get("text")
            if expected_text is not None:
                ok = (after_element.value_preview or "") == str(expected_text)[:120]
                checks.append({"check": "text_value", "passed": ok, "expected": expected_text})
                if not ok:
                    return VerificationResult(
                        status=VerificationStatus.FAILED,
                        message="Text value did not match expected.",
                        checks=checks,
                    )
            elif before_element is not None:
                changed = (after_element.value_preview or "") != (before_element.value_preview or "")
                checks.append({"check": "text_changed", "passed": changed})
                if not changed:
                    return VerificationResult(
                        status=VerificationStatus.UNCERTAIN,
                        message="Text value did not observably change.",
                        checks=checks,
                    )

    if action.action_type == ActionType.INVOKE_ELEMENT and after_element is not None:
        invoked = "Invoked" in (after_element.patterns or [])
        if isinstance(backend, MockDesktopBackend):
            checks.append({"check": "invoke_marker", "passed": invoked})
            if not invoked:
                return VerificationResult(
                    status=VerificationStatus.FAILED,
                    message="Invoke marker missing after action.",
                    checks=checks,
                )
        else:
            # Production: element still present/enabled after Invoke is required;
            # optional expected control property can strengthen certainty.
            live_ok = after_element.is_enabled or after_element.control_type in {"Button", "MenuItem"}
            checks.append({"check": "element_live_after_invoke", "passed": live_ok})
            if expected.get("invoked_name_contains"):
                needle = str(expected["invoked_name_contains"]).lower()
                name_ok = needle in (after_element.name or "").lower()
                checks.append({"check": "expected_name", "passed": name_ok})
                if not name_ok:
                    return VerificationResult(
                        status=VerificationStatus.FAILED,
                        message="Post-invoke element name expectation failed.",
                        checks=checks,
                    )
            if not live_ok:
                return VerificationResult(
                    status=VerificationStatus.UNCERTAIN,
                    message="Could not confirm invoke effect.",
                    checks=checks,
                )

    if action.action_type in {ActionType.TOGGLE_CONTROL} and after_element is not None:
        toggled = "Toggled" in (after_element.patterns or [])
        checks.append({"check": "toggle_state", "passed": toggled or before_element is not None})

    if expected.get("window_title_contains") and after_window is not None:
        needle = str(expected["window_title_contains"])
        ok = needle.lower() in (after_window.title or "").lower()
        checks.append({"check": "window_title", "passed": ok})
        if not ok:
            return VerificationResult(
                status=VerificationStatus.FAILED,
                message="Expected window title not observed.",
                checks=checks,
            )

    if screenshot_progress and screenshot_progress.get("progress") == "stuck":
        # Kinetic-style no-progress signal for visual fallback paths.
        if used_fallback or action.action_type in {
            ActionType.CLICK,
            ActionType.DOUBLE_CLICK,
            ActionType.INVOKE_ELEMENT,
        }:
            checks.append({"check": "screenshot_progress", "passed": False})
            return VerificationResult(
                status=VerificationStatus.UNCERTAIN,
                message="No visual progress detected after action.",
                checks=checks,
            )

    if not checks:
        checks.append({"check": "default_execution_ok", "passed": True})

    if any(c.get("passed") is False for c in checks):
        return VerificationResult(
            status=VerificationStatus.FAILED,
            message="One or more verification checks failed.",
            checks=checks,
        )

    return VerificationResult(
        status=VerificationStatus.VERIFIED,
        message="Action effect verified.",
        checks=checks,
    )
