"""Secret and sensitive-field redaction for Windows CUA evidence/logs.

Adapted from Kinetic-OS governance principles + Megas worker policy patterns.
"""

from __future__ import annotations

import re
from typing import Any

from megas.policy import redact as policy_redact

REDACTED = "[REDACTED]"
PASSWORD_FIELD = "[REDACTED_PASSWORD_FIELD]"

_PASSWORD_NAME_HINTS = re.compile(
    r"(?i)\b(password|passwd|passcode|pin|otp|one[- ]?time|secret|api[-_]?key|token|cvv|ssn)\b"
)
_SENSITIVE_CONTROL_TYPES = frozenset({"Password", "Edit"})


def is_password_element(
    *,
    name: str | None = None,
    control_type: str | None = None,
    automation_id: str | None = None,
    is_password_flag: bool = False,
    patterns: list[str] | None = None,
) -> bool:
    if is_password_flag:
        return True
    if patterns and "Password" in patterns:
        return True
    blob = " ".join(x for x in (name, automation_id, control_type) if x)
    if _PASSWORD_NAME_HINTS.search(blob):
        return True
    return False


def redact_text(value: str | None) -> str:
    if value is None:
        return ""
    return policy_redact(str(value))


def redact_mapping(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            key_l = str(key).lower()
            if any(
                marker in key_l
                for marker in (
                    "password",
                    "secret",
                    "token",
                    "api_key",
                    "authorization",
                    "cookie",
                    "clipboard",
                    "otp",
                )
            ):
                out[key] = REDACTED if item not in (None, "") else item
            else:
                out[key] = redact_mapping(item)
        return out
    if isinstance(value, list):
        return [redact_mapping(item) for item in value]
    if isinstance(value, str):
        return redact_text(value)
    return value


def redact_element_dict(element: dict[str, Any]) -> dict[str, Any]:
    data = dict(element)
    if data.get("is_password") or is_password_element(
        name=data.get("name"),
        control_type=data.get("control_type"),
        automation_id=data.get("automation_id"),
        is_password_flag=bool(data.get("is_password")),
        patterns=data.get("patterns") if isinstance(data.get("patterns"), list) else None,
    ):
        data["value_preview"] = PASSWORD_FIELD
        data["is_password"] = True
    else:
        if isinstance(data.get("value_preview"), str):
            data["value_preview"] = redact_text(data["value_preview"])
    return redact_mapping(data)


def redact_screenshot_meta(meta: dict[str, Any], *, regions: list[dict] | None = None) -> dict[str, Any]:
    """Return metadata only — never embed raw pixel buffers in logs."""
    out = {
        "hash": meta.get("hash"),
        "resolution": meta.get("resolution"),
        "timestamp": meta.get("timestamp"),
        "offset": meta.get("offset"),
        "redacted_regions": regions or meta.get("redacted_regions") or [],
        "pixels_stored": False,
    }
    return out
