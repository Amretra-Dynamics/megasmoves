"""Bounded read-only foreground Windows image capture for Megas MCP."""

from __future__ import annotations

import base64
import hashlib
from typing import Any, Callable

from megas.operate.windows.discovery import DesktopBackend, create_backend
from megas.operate.windows.win32_api import capture_window_png


DEFAULT_MAX_WIDTH = 1024
DEFAULT_MAX_HEIGHT = 768
MAX_WIDTH = 1600
MAX_HEIGHT = 1200
MAX_IMAGE_BYTES = 1_500_000


def _bounded_int(value: Any, *, default: int, minimum: int, maximum: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(minimum, min(maximum, parsed))


def capture_current_screen(
    *,
    backend: DesktopBackend | None = None,
    capture: Callable[..., dict[str, Any] | None] | None = None,
    max_width: int = DEFAULT_MAX_WIDTH,
    max_height: int = DEFAULT_MAX_HEIGHT,
) -> dict[str, Any]:
    """Capture the current foreground app without changing desktop state.

    Only the foreground window is accepted. Secure desktop, UAC and locked
    sessions fail closed before any pixel capture occurs. Raw image bytes stay
    in memory and are returned only as bounded base64 evidence.
    """

    actual = backend or create_backend()
    width_limit = _bounded_int(
        max_width,
        default=DEFAULT_MAX_WIDTH,
        minimum=320,
        maximum=MAX_WIDTH,
    )
    height_limit = _bounded_int(
        max_height,
        default=DEFAULT_MAX_HEIGHT,
        minimum=240,
        maximum=MAX_HEIGHT,
    )

    if actual.is_session_locked():
        raise PermissionError("Windows session is locked; current-screen capture is unavailable.")
    if actual.is_secure_desktop():
        raise PermissionError("Secure desktop is active; current-screen capture is unavailable.")
    if actual.is_uac_prompt_present():
        raise PermissionError("A UAC prompt is active; current-screen capture is unavailable.")

    window = actual.get_foreground()
    if window is None:
        raise RuntimeError("No foreground Windows app is available.")
    if bool(window.is_minimized):
        raise RuntimeError("The foreground Windows app is minimized; capture is unavailable.")

    capture_fn = capture or capture_window_png
    evidence = capture_fn(
        int(window.hwnd),
        max_width=width_limit,
        max_height=height_limit,
        max_bytes=MAX_IMAGE_BYTES,
    )
    if not isinstance(evidence, dict):
        raise RuntimeError("Foreground Windows image capture failed.")

    raw = evidence.get("png")
    if not isinstance(raw, (bytes, bytearray)):
        raise RuntimeError("Foreground Windows capture produced no PNG evidence.")
    image = bytes(raw)
    if not image or len(image) > MAX_IMAGE_BYTES:
        raise RuntimeError("Foreground Windows capture exceeded the bounded image evidence limit.")

    image_base64 = base64.b64encode(image).decode("ascii")
    return {
        "ok": True,
        "scope": "foreground_window",
        "method": "win32_gdi",
        "window": window.to_dict(),
        "image_base64": image_base64,
        "media_type": "image/png",
        "sha256": hashlib.sha256(image).hexdigest(),
        "size_bytes": len(image),
        "width": int(evidence.get("width") or 0),
        "height": int(evidence.get("height") or 0),
        "source_width": int(evidence.get("source_width") or 0),
        "source_height": int(evidence.get("source_height") or 0),
        "scaled": bool(evidence.get("scaled")),
        "max_bytes": MAX_IMAGE_BYTES,
    }


__all__ = [
    "DEFAULT_MAX_HEIGHT",
    "DEFAULT_MAX_WIDTH",
    "MAX_HEIGHT",
    "MAX_IMAGE_BYTES",
    "MAX_WIDTH",
    "capture_current_screen",
]
