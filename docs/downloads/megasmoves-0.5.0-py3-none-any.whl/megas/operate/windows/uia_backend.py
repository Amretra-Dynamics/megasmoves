"""Production Windows UI Automation backend.

Primary path: `uiautomation` (COM wrapper) when installed.
Window identity/security always via Win32 ctypes.

Fail closed when native stack is incomplete — never silently switches to demos.
"""

from __future__ import annotations

import time
from typing import Any

from megas.operate.windows.models import (
    ElementIdentity,
    ElementSelector,
    Rect,
    WindowIdentity,
    new_id,
)
from megas.operate.windows.win32_api import (
    get_foreground_window,
    is_secure_desktop,
    is_session_locked,
    is_uac_prompt_present,
    is_windows,
    list_top_level_windows,
    set_foreground,
    to_window_identity,
    uiautomation_available,
)


class NativeUiaError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _control_type_name(control: Any) -> str:
    name = getattr(control, "ControlTypeName", None) or ""
    return str(name).replace("Control", "") if name else "Unknown"


def _patterns_for(control: Any) -> list[str]:
    patterns: list[str] = []
    checks = [
        ("GetInvokePattern", "Invoke"),
        ("GetValuePattern", "Value"),
        ("GetTogglePattern", "Toggle"),
        ("GetExpandCollapsePattern", "ExpandCollapse"),
        ("GetScrollPattern", "Scroll"),
        ("GetSelectionItemPattern", "SelectionItem"),
        ("GetTextPattern", "Text"),
        ("GetWindowPattern", "Window"),
    ]
    for method, label in checks:
        getter = getattr(control, method, None)
        if not callable(getter):
            continue
        try:
            if getter():
                patterns.append(label)
        except Exception:  # noqa: BLE001
            continue
    try:
        if getattr(control, "IsPassword", False):
            patterns.append("Password")
    except Exception:  # noqa: BLE001
        pass
    return patterns


def _bounds(control: Any) -> Rect | None:
    try:
        rect = control.BoundingRectangle
        w = int(rect.right - rect.left)
        h = int(rect.bottom - rect.top)
        if w <= 0 or h <= 0:
            return None
        return Rect(left=float(rect.left), top=float(rect.top), width=float(w), height=float(h))
    except Exception:  # noqa: BLE001
        return None


class WindowsUiaBackend:
    """Live desktop backend for production Windows workers."""

    def __init__(self) -> None:
        if not is_windows():
            raise NativeUiaError("not_windows", "WindowsUiaBackend requires Windows.")
        if not uiautomation_available():
            raise NativeUiaError(
                "uiautomation_missing",
                "Production UI Automation requires the 'uiautomation' package "
                "(pip install uiautomation). Refusing mock fallback in production.",
            )
        import uiautomation as auto

        self._auto = auto
        self._element_refs: dict[str, Any] = {}
        # Reduce default UIA timeouts for snappier fail-closed behavior.
        try:
            auto.SetGlobalSearchTimeout(5.0)
        except Exception:  # noqa: BLE001
            pass

    def list_windows(self) -> list[WindowIdentity]:
        fg = get_foreground_window()
        fg_hwnd = fg.hwnd if fg else None
        out: list[WindowIdentity] = []
        for native in list_top_level_windows():
            out.append(to_window_identity(native, is_foreground=native.hwnd == fg_hwnd))
        return out

    def get_foreground(self) -> WindowIdentity | None:
        native = get_foreground_window()
        if native is None:
            return None
        return to_window_identity(native, is_foreground=True)

    def _control_from_window(self, window: WindowIdentity) -> Any:
        ctrl = self._auto.ControlFromHandle(window.hwnd)
        if ctrl is None:
            raise NativeUiaError("window_control_missing", "UI Automation cannot attach to window handle.")
        return ctrl

    def _to_element(self, control: Any, window: WindowIdentity) -> ElementIdentity:
        element_id = new_id("el")
        try:
            automation_id = control.AutomationId or None
        except Exception:  # noqa: BLE001
            automation_id = None
        try:
            name = control.Name or None
        except Exception:  # noqa: BLE001
            name = None
        try:
            class_name = control.ClassName or None
        except Exception:  # noqa: BLE001
            class_name = None
        try:
            is_password = bool(control.IsPassword)
        except Exception:  # noqa: BLE001
            is_password = False
        try:
            is_enabled = bool(control.IsEnabled)
        except Exception:  # noqa: BLE001
            is_enabled = True
        try:
            is_offscreen = bool(control.IsOffscreen)
        except Exception:  # noqa: BLE001
            is_offscreen = False
        control_type = _control_type_name(control)
        patterns = _patterns_for(control)
        value_preview = None
        if "Value" in patterns and not is_password:
            try:
                vp = control.GetValuePattern()
                if vp:
                    value_preview = str(vp.Value)[:120]
            except Exception:  # noqa: BLE001
                value_preview = None
        el = ElementIdentity(
            element_id=element_id,
            selector=ElementSelector(
                automation_id=automation_id,
                name=name,
                control_type=control_type,
                class_name=class_name,
                process_id=window.process_id,
                hwnd=window.hwnd,
            ),
            name=name,
            control_type=control_type,
            automation_id=automation_id,
            class_name=class_name,
            bounds=_bounds(control),
            is_password=is_password,
            is_enabled=is_enabled,
            is_offscreen=is_offscreen,
            patterns=patterns,
            value_preview=value_preview,
            process_id=window.process_id,
            hwnd=window.hwnd,
        )
        self._element_refs[element_id] = control
        return el

    def find_elements(
        self, window: WindowIdentity, selector: ElementSelector
    ) -> list[ElementIdentity]:
        root = self._control_from_window(window)
        # Build search conditions from stable properties.
        kwargs: dict[str, Any] = {}
        if selector.automation_id:
            kwargs["AutomationId"] = selector.automation_id
        if selector.name:
            kwargs["Name"] = selector.name
        if selector.class_name:
            kwargs["ClassName"] = selector.class_name

        matches: list[ElementIdentity] = []
        deadline = time.perf_counter() + 5.0

        def walk(control: Any, depth: int = 0) -> None:
            if time.perf_counter() > deadline or len(matches) >= 50 or depth > 30:
                return
            try:
                ok = True
                if selector.automation_id and (control.AutomationId or "") != selector.automation_id:
                    ok = False
                if ok and selector.name and (control.Name or "") != selector.name:
                    ok = False
                if ok and selector.class_name and (control.ClassName or "") != selector.class_name:
                    ok = False
                if ok and selector.control_type:
                    if _control_type_name(control).lower() != selector.control_type.lower():
                        ok = False
                if ok:
                    matches.append(self._to_element(control, window))
            except Exception:  # noqa: BLE001
                pass
            try:
                child = control.GetFirstChildControl()
                while child is not None and len(matches) < 50 and time.perf_counter() < deadline:
                    walk(child, depth + 1)
                    child = child.GetNextSiblingControl()
            except Exception:  # noqa: BLE001
                return

        # Fast path: depth search via uiautomation helpers when automation id present.
        if selector.automation_id and not selector.name:
            try:
                found = root.Control(searchDepth=30, AutomationId=selector.automation_id)
                if found and found.Exists(0, 0):
                    return [self._to_element(found, window)]
            except Exception:  # noqa: BLE001
                pass
        walk(root)
        return matches

    def get_element(self, element_id: str) -> ElementIdentity | None:
        control = self._element_refs.get(element_id)
        if control is None:
            return None
        try:
            # Refresh identity from live control; rebuild with same element_id.
            window = self.get_foreground()
            if window is None:
                return None
            # Validate control still exists
            if hasattr(control, "Exists") and not control.Exists(0, 0):
                self._element_refs.pop(element_id, None)
                return None
            el = self._to_element(control, window)
            # Preserve stable id for session staleness tracking.
            self._element_refs.pop(el.element_id, None)
            el.element_id = element_id
            self._element_refs[element_id] = control
            return el
        except Exception:  # noqa: BLE001
            self._element_refs.pop(element_id, None)
            return None

    def accessibility_tree(self, window: WindowIdentity, *, max_nodes: int = 200) -> list[dict]:
        root = self._control_from_window(window)
        nodes: list[dict] = []
        deadline = time.perf_counter() + 3.0

        def walk(control: Any, depth: int = 0) -> None:
            if len(nodes) >= max_nodes or time.perf_counter() > deadline or depth > 25:
                return
            try:
                ctype = _control_type_name(control)
                interactable = ctype in {
                    "Button",
                    "Edit",
                    "Hyperlink",
                    "ListItem",
                    "MenuItem",
                    "TabItem",
                    "CheckBox",
                    "RadioButton",
                    "ComboBox",
                    "Text",
                    "TreeItem",
                    "DataItem",
                    "Document",
                }
                if interactable:
                    el = self._to_element(control, window)
                    nodes.append(
                        {
                            "element_id": el.element_id,
                            "name": el.name,
                            "control_type": el.control_type,
                            "automation_id": el.automation_id,
                            "patterns": list(el.patterns),
                            "is_password": el.is_password,
                            "bounds": el.bounds.to_dict() if el.bounds else None,
                        }
                    )
            except Exception:  # noqa: BLE001
                pass
            try:
                child = control.GetFirstChildControl()
                while child is not None and len(nodes) < max_nodes:
                    walk(child, depth + 1)
                    child = child.GetNextSiblingControl()
            except Exception:  # noqa: BLE001
                return

        walk(root)
        return nodes

    def is_secure_desktop(self) -> bool:
        return is_secure_desktop()

    def is_session_locked(self) -> bool:
        return is_session_locked()

    def is_uac_prompt_present(self) -> bool:
        return is_uac_prompt_present()

    # --- live actions ---

    def focus_window(self, window: WindowIdentity) -> bool:
        return set_foreground(window.hwnd)

    def invoke(self, element_id: str) -> None:
        control = self._require_control(element_id)
        pattern = control.GetInvokePattern()
        if not pattern:
            raise NativeUiaError("pattern_unsupported", "InvokePattern unavailable.")
        pattern.Invoke()

    def set_value(self, element_id: str, value: str) -> None:
        control = self._require_control(element_id)
        pattern = control.GetValuePattern()
        if not pattern:
            raise NativeUiaError("pattern_unsupported", "ValuePattern unavailable.")
        pattern.SetValue(value)

    def get_value(self, element_id: str) -> str:
        control = self._require_control(element_id)
        try:
            if getattr(control, "IsPassword", False):
                return ""
        except Exception:  # noqa: BLE001
            pass
        pattern = control.GetValuePattern()
        if pattern:
            return str(pattern.Value or "")
        try:
            return str(control.Name or "")
        except Exception:  # noqa: BLE001
            return ""

    def focus(self, element_id: str) -> None:
        control = self._require_control(element_id)
        try:
            control.SetFocus()
        except Exception as exc:  # noqa: BLE001
            raise NativeUiaError("focus_failed", f"SetFocus failed: {exc}") from exc

    def toggle(self, element_id: str) -> None:
        control = self._require_control(element_id)
        pattern = control.GetTogglePattern()
        if not pattern:
            raise NativeUiaError("pattern_unsupported", "TogglePattern unavailable.")
        pattern.Toggle()

    def expand_collapse(self, element_id: str, *, expand: bool = True) -> None:
        control = self._require_control(element_id)
        pattern = control.GetExpandCollapsePattern()
        if not pattern:
            raise NativeUiaError("pattern_unsupported", "ExpandCollapsePattern unavailable.")
        if expand:
            pattern.Expand()
        else:
            pattern.Collapse()

    def scroll(self, element_id: str, *, direction: str = "down") -> None:
        control = self._require_control(element_id)
        pattern = control.GetScrollPattern()
        if not pattern:
            raise NativeUiaError("pattern_unsupported", "ScrollPattern unavailable.")
        # Small vertical steps
        amount = 1 if direction == "down" else -1
        try:
            pattern.Scroll(0, amount)
        except Exception:
            pattern.SetScrollPercent(-1, min(100, max(0, 50 + amount * 10)))

    def select_item(self, element_id: str) -> None:
        control = self._require_control(element_id)
        pattern = control.GetSelectionItemPattern()
        if not pattern:
            raise NativeUiaError("pattern_unsupported", "SelectionItemPattern unavailable.")
        pattern.Select()

    def _require_control(self, element_id: str) -> Any:
        control = self._element_refs.get(element_id)
        if control is None:
            raise NativeUiaError("stale_element", "Element reference is not registered.")
        try:
            if hasattr(control, "Exists") and not control.Exists(0, 0):
                self._element_refs.pop(element_id, None)
                raise NativeUiaError("stale_element", "Element no longer exists.")
        except NativeUiaError:
            raise
        except Exception:  # noqa: BLE001
            pass
        return control
