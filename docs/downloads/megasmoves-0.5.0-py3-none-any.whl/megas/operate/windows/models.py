"""Windows CUA domain models and enums."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
import uuid


class ActionRisk(str, Enum):
    READ_ONLY = "read_only"
    LOW_RISK = "low_risk"
    SENSITIVE = "sensitive"
    HIGH_RISK = "high_risk"


class SessionState(str, Enum):
    REQUESTED = "requested"
    POLICY_CHECK = "policy_check"
    WAITING_FOR_APPROVAL = "waiting_for_approval"
    PREPARING = "preparing"
    LOCATING_TARGET = "locating_target"
    EXECUTING = "executing"
    VERIFYING = "verifying"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    BLOCKED = "blocked"
    FAILED = "failed"
    EMERGENCY_STOPPED = "emergency_stopped"


TERMINAL_STATES = frozenset(
    {
        SessionState.COMPLETED,
        SessionState.CANCELLED,
        SessionState.BLOCKED,
        SessionState.FAILED,
        SessionState.EMERGENCY_STOPPED,
    }
)


class ActionType(str, Enum):
    ENUMERATE_WINDOWS = "enumerate_windows"
    INSPECT_ACTIVE_WINDOW = "inspect_active_window"
    INSPECT_ACCESSIBILITY_TREE = "inspect_accessibility_tree"
    FIND_ELEMENT = "find_element"
    FOCUS_ELEMENT = "focus_element"
    INVOKE_ELEMENT = "invoke_element"
    SET_TEXT = "set_text"
    READ_VISIBLE_TEXT = "read_visible_text"
    SELECT_ITEM = "select_item"
    TOGGLE_CONTROL = "toggle_control"
    EXPAND_COLLAPSE = "expand_collapse"
    SCROLL = "scroll"
    MOVE_POINTER = "move_pointer"
    CLICK = "click"
    DOUBLE_CLICK = "double_click"
    RIGHT_CLICK = "right_click"
    KEY_PRESS = "key_press"
    KEY_CHORD = "key_chord"
    TYPE_TEXT = "type_text"
    WAIT_FOR_ELEMENT = "wait_for_element"
    WAIT_FOR_WINDOW = "wait_for_window"
    CAPTURE_SCREENSHOT = "capture_screenshot"
    VERIFY_STATE = "verify_state"
    CANCEL_SESSION = "cancel_session"
    EMERGENCY_STOP = "emergency_stop"


class VerificationStatus(str, Enum):
    VERIFIED = "verified"
    UNCERTAIN = "uncertain"
    FAILED = "failed"
    SKIPPED = "skipped"


class ActionOutcome(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"
    EMERGENCY_STOPPED = "emergency_stopped"
    UNCERTAIN = "uncertain"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


@dataclass
class Rect:
    left: float
    top: float
    width: float
    height: float

    def center(self) -> tuple[float, float]:
        return (self.left + self.width / 2.0, self.top + self.height / 2.0)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass
class DisplayInfo:
    display_id: str
    width: int
    height: int
    scale_factor: float = 1.0
    is_primary: bool = False
    left: int = 0
    top: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class WindowIdentity:
    hwnd: int
    process_id: int
    title: str
    class_name: str
    executable: str | None = None
    bounds: Rect | None = None
    monitor_id: str | None = None
    is_foreground: bool = False
    is_minimized: bool = False
    is_visible: bool = True

    def fingerprint(self) -> str:
        return f"{self.hwnd}:{self.process_id}:{self.class_name}:{self.executable or ''}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "hwnd": self.hwnd,
            "process_id": self.process_id,
            "title": self.title,
            "class_name": self.class_name,
            "executable": self.executable,
            "bounds": self.bounds.to_dict() if self.bounds else None,
            "monitor_id": self.monitor_id,
            "is_foreground": self.is_foreground,
            "is_minimized": self.is_minimized,
            "is_visible": self.is_visible,
            "fingerprint": self.fingerprint(),
        }


@dataclass
class ElementSelector:
    automation_id: str | None = None
    name: str | None = None
    control_type: str | None = None
    class_name: str | None = None
    process_id: int | None = None
    hwnd: int | None = None
    framework_id: str | None = None
    role: str | None = None
    path_hint: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class ElementIdentity:
    element_id: str
    selector: ElementSelector
    name: str | None = None
    control_type: str | None = None
    automation_id: str | None = None
    class_name: str | None = None
    bounds: Rect | None = None
    is_password: bool = False
    is_enabled: bool = True
    is_offscreen: bool = False
    patterns: list[str] = field(default_factory=list)
    value_preview: str | None = None  # never raw secrets
    process_id: int | None = None
    hwnd: int | None = None

    def fingerprint(self) -> str:
        return (
            f"{self.element_id}|{self.automation_id or ''}|"
            f"{self.control_type or ''}|{self.class_name or ''}|{self.process_id or 0}"
        )

    def to_dict(self, *, redact_values: bool = True) -> dict[str, Any]:
        value = self.value_preview
        if redact_values and self.is_password:
            value = "[REDACTED_PASSWORD_FIELD]"
        return {
            "element_id": self.element_id,
            "selector": self.selector.to_dict(),
            "name": self.name,
            "control_type": self.control_type,
            "automation_id": self.automation_id,
            "class_name": self.class_name,
            "bounds": self.bounds.to_dict() if self.bounds else None,
            "is_password": self.is_password,
            "is_enabled": self.is_enabled,
            "is_offscreen": self.is_offscreen,
            "patterns": list(self.patterns),
            "value_preview": value,
            "process_id": self.process_id,
            "hwnd": self.hwnd,
            "fingerprint": self.fingerprint(),
        }


@dataclass
class ApprovalGrant:
    approval_id: str
    action_id: str
    session_id: str
    expires_at: str
    application: str | None = None
    process_id: int | None = None
    window_fingerprint: str | None = None
    element_fingerprint: str | None = None
    proposed_values_hash: str | None = None
    expected_effect: str | None = None
    granted_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ActionRequest:
    action_type: ActionType
    action_id: str = field(default_factory=lambda: new_id("act"))
    session_id: str = ""
    selector: ElementSelector | None = None
    window: dict[str, Any] | None = None
    text: str | None = None
    keys: list[str] | None = None
    coordinates: tuple[float, float] | None = None
    timeout_seconds: float = 10.0
    allow_input_fallback: bool = False
    expected: dict[str, Any] | None = None
    approval: ApprovalGrant | None = None
    policy_scopes: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    idempotency_key: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_type": self.action_type.value,
            "action_id": self.action_id,
            "session_id": self.session_id,
            "selector": self.selector.to_dict() if self.selector else None,
            "window": self.window,
            "text": "[REDACTED]" if self.metadata.get("is_secret") else self.text,
            "keys": self.keys,
            "coordinates": self.coordinates,
            "timeout_seconds": self.timeout_seconds,
            "allow_input_fallback": self.allow_input_fallback,
            "expected": self.expected,
            "approval": self.approval.to_dict() if self.approval else None,
            "policy_scopes": list(self.policy_scopes),
            "metadata": dict(self.metadata),
            "idempotency_key": self.idempotency_key,
        }


@dataclass
class ActionResult:
    action_id: str
    outcome: ActionOutcome
    verification: VerificationStatus
    message: str
    risk: ActionRisk
    used_input_fallback: bool = False
    before: dict[str, Any] = field(default_factory=dict)
    after: dict[str, Any] = field(default_factory=dict)
    evidence_id: str | None = None
    error_code: str | None = None
    duration_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_id": self.action_id,
            "outcome": self.outcome.value,
            "verification": self.verification.value,
            "message": self.message,
            "risk": self.risk.value,
            "used_input_fallback": self.used_input_fallback,
            "before": self.before,
            "after": self.after,
            "evidence_id": self.evidence_id,
            "error_code": self.error_code,
            "duration_ms": self.duration_ms,
        }


@dataclass
class RuntimeEvent:
    """Shared structured event for Monitor (not Windows-class dependent)."""

    event_type: str
    severity: str
    message: str
    session_id: str | None = None
    action_id: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)
    occurred_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type,
            "signal_type": "worker",
            "source_type": "worker",
            "severity": self.severity,
            "message": self.message,
            "session_id": self.session_id,
            "action_id": self.action_id,
            "occurred_at": self.occurred_at,
            "event_attributes": {
                "runtime": "windows_cua",
                **self.attributes,
            },
        }
