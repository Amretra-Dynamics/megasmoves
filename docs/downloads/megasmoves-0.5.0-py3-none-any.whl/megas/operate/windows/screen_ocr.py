"""Windows-native OCR for bounded foreground capture evidence."""

from __future__ import annotations

import asyncio
from typing import Any


DEFAULT_MAX_CHARS = 12000
MAX_CHARS = 24000
OCR_TIMEOUT_SECONDS = 12.0


def _bounded_int(value: Any, *, default: int, minimum: int, maximum: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(minimum, min(maximum, parsed))


async def _recognize_png_async(png: bytes, *, max_chars: int) -> dict[str, Any]:
    try:
        from winrt.windows.graphics.imaging import BitmapDecoder
        from winrt.windows.media.ocr import OcrEngine
        from winrt.windows.storage.streams import DataWriter, InMemoryRandomAccessStream
    except ImportError as exc:
        raise RuntimeError("Windows native OCR dependencies are unavailable.") from exc

    if not isinstance(png, (bytes, bytearray)) or not png:
        raise ValueError("OCR requires non-empty PNG bytes.")

    stream = InMemoryRandomAccessStream()
    writer = DataWriter(stream.get_output_stream_at(0))
    writer.write_bytes(bytes(png))
    await asyncio.wait_for(writer.store_async(), timeout=5.0)
    try:
        writer.detach_stream()
    except Exception:
        pass

    stream.seek(0)
    decoder = await asyncio.wait_for(BitmapDecoder.create_async(stream), timeout=5.0)
    bitmap = await asyncio.wait_for(decoder.get_software_bitmap_async(), timeout=5.0)

    engine = OcrEngine.try_create_from_user_profile_languages()
    if engine is None:
        raise RuntimeError(
            "Windows OCR has no recognizer language available for the current user profile."
        )

    result = await asyncio.wait_for(engine.recognize_async(bitmap), timeout=10.0)
    char_limit = _bounded_int(
        max_chars,
        default=DEFAULT_MAX_CHARS,
        minimum=256,
        maximum=MAX_CHARS,
    )

    lines: list[dict[str, Any]] = []
    text_parts: list[str] = []
    used = 0
    truncated = False

    for line in result.lines:
        line_text = str(line.text or "").strip()
        if not line_text:
            continue
        remaining = char_limit - used
        if remaining <= 0:
            truncated = True
            break
        clipped = line_text[:remaining]
        if clipped != line_text:
            truncated = True
        words: list[dict[str, Any]] = []
        for word in line.words:
            bounds = word.bounding_rect
            words.append(
                {
                    "text": str(word.text or ""),
                    "bounds": {
                        "x": float(bounds.x),
                        "y": float(bounds.y),
                        "width": float(bounds.width),
                        "height": float(bounds.height),
                    },
                }
            )
        lines.append({"text": clipped, "words": words})
        text_parts.append(clipped)
        used += len(clipped) + 1
        if clipped != line_text:
            break

    language = None
    try:
        recognizer_language = engine.recognizer_language
        language = str(recognizer_language.language_tag or "") or None
    except Exception:
        language = None

    angle = None
    try:
        if result.text_angle is not None:
            angle = float(result.text_angle)
    except Exception:
        angle = None

    return {
        "text": "\n".join(text_parts),
        "lines": lines,
        "language": language,
        "text_angle": angle,
        "truncated": truncated,
        "source": "windows_media_ocr",
        "confidence": None,
        "confidence_available": False,
    }


def recognize_png(
    png: bytes,
    *,
    max_chars: int = DEFAULT_MAX_CHARS,
    timeout_seconds: float = OCR_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    """Recognize PNG text with a hard wall-clock bound around WinRT.

    WinRT OCR can block inside the OS in noninteractive or damaged language-pack
    sessions. Run the whole pipeline in a daemon thread so the caller can always
    recover even when the native operation itself cannot be cancelled cleanly.
    """

    import threading

    result: dict[str, Any] = {}
    failure: list[BaseException] = []

    def runner() -> None:
        try:
            value = asyncio.run(_recognize_png_async(png, max_chars=max_chars))
            result.update(value)
        except BaseException as exc:  # pragma: no cover - native boundary
            failure.append(exc)

    thread = threading.Thread(target=runner, name="megas-windows-ocr", daemon=True)
    thread.start()
    bounded = max(0.05, min(float(timeout_seconds), 30.0))
    thread.join(timeout=bounded)
    if thread.is_alive():
        raise TimeoutError("Windows native OCR timed out.")
    if failure:
        raise failure[0]
    return result


__all__ = [
    "DEFAULT_MAX_CHARS",
    "MAX_CHARS",
    "OCR_TIMEOUT_SECONDS",
    "recognize_png",
]
