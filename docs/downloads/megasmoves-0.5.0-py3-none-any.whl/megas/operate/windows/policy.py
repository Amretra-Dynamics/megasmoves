"""Action risk classification and policy gates."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from megas.operate.windows.models import ActionRequest, ActionRisk, ActionType

READ_ONLY = frozenset(
    {
        ActionType.ENUMERATE_WINDOWS,
        ActionType.INSPECT_ACTIVE_WINDOW,
        ActionType.INSPECT_ACCESSIBILITY_TREE,
        ActionType.FIND_ELEMENT,
        ActionType.READ_VISIBLE_TEXT,
        ActionType.CAPTURE_SCREENSHOT,
        ActionType.VERIFY_STATE,
        ActionType.WAIT_FOR_ELEMENT,
        ActionType.WAIT_FOR_WINDOW,
    }
)

LOW_RISK = frozenset(
    {
        ActionType.FOCUS_ELEMENT,
        ActionType.SCROLL,
        ActionType.EXPAND_COLLAPSE,
        ActionType.MOVE_POINTER,
    }
)

SENSITIVE = frozenset(
    {
        ActionType.SET_TEXT,
        ActionType.TYPE_TEXT,
        ActionType.KEY_PRESS,
        ActionType.KEY_CHORD,
        ActionType.SELECT_ITEM,
        ActionType.TOGGLE_CONTROL,
    }
)

HIGH_RISK = frozenset(
    {
        ActionType.INVOKE_ELEMENT,
        ActionType.CLICK,
        ActionType.DOUBLE_CLICK,
        ActionType.RIGHT_CLICK,
    }
)

# Explicit high-risk scopes required in request.policy_scopes
HIGH_RISK_SCOPES = frozenset(
    {
        "desktop.windows.high_risk",
        "submit_forms",
        "send_messages",
        "publish_content",
        "financial_ops",
        "delete_data",
        "security_settings",
        "deployments",
        "install_software",
        "system_config",
    }
)

SENSITIVE_SCOPES = frozenset(
    {
        "desktop.windows.sensitive",
        "authenticated_screens",
        "local_files",
        "clipboard",
        "personal_information",
    }
)


@dataclass
class PolicyDecision:
    allowed: bool
    risk: ActionRisk
    requires_approval: bool
    reasons: list[str]
    scopes_required: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "risk": self.risk.value,
            "requires_approval": self.requires_approval,
            "reasons": list(self.reasons),
            "scopes_required": list(self.scopes_required),
        }


def classify_risk(action: ActionRequest) -> ActionRisk:
    at = action.action_type
    if at in READ_ONLY or at in {ActionType.CANCEL_SESSION, ActionType.EMERGENCY_STOP}:
        return ActionRisk.READ_ONLY
    if at in LOW_RISK:
        return ActionRisk.LOW_RISK
    # Secret text entry is always sensitive+.
    if action.metadata.get("is_secret") or action.metadata.get("is_password"):
        return ActionRisk.SENSITIVE
    if at in HIGH_RISK:
        # Clicks that submit are high risk when marked.
        if action.metadata.get("submits_form") or action.metadata.get("external_effect"):
            return ActionRisk.HIGH_RISK
        # Default invoke/click treated as high risk for fail-closed safety unless tagged low.
        if action.metadata.get("risk_override") == "low_risk":
            return ActionRisk.LOW_RISK
        return ActionRisk.HIGH_RISK
    if at in SENSITIVE:
        return ActionRisk.SENSITIVE
    return ActionRisk.SENSITIVE


def evaluate_policy(
    action: ActionRequest,
    *,
    granted_scopes: list[str] | None = None,
    input_capability_available: bool = False,
) -> PolicyDecision:
    risk = classify_risk(action)
    scopes = set(action.policy_scopes or [])
    granted = set(granted_scopes or [])
    effective = scopes | granted
    reasons: list[str] = [f"risk={risk.value}"]
    requires_approval = False
    allowed = True
    required: list[str] = []

    if action.action_type in {
        ActionType.MOVE_POINTER,
        ActionType.CLICK,
        ActionType.DOUBLE_CLICK,
        ActionType.RIGHT_CLICK,
        ActionType.KEY_PRESS,
        ActionType.KEY_CHORD,
        ActionType.TYPE_TEXT,
    } or action.allow_input_fallback:
        if not input_capability_available and action.allow_input_fallback:
            allowed = False
            reasons.append("desktop.windows.input_unavailable")
        if action.allow_input_fallback:
            reasons.append("input_fallback_requested")

    if risk == ActionRisk.SENSITIVE:
        required = sorted(SENSITIVE_SCOPES & effective) or ["desktop.windows.sensitive"]
        if not (effective & SENSITIVE_SCOPES) and "desktop.windows.sensitive" not in effective:
            # Allow if explicit scope present on action
            if "desktop.windows.sensitive" not in scopes and not (scopes & SENSITIVE_SCOPES):
                allowed = False
                reasons.append("missing_sensitive_scope")
        requires_approval = False  # sensitive may use scoped policy without always needing human

    if risk == ActionRisk.HIGH_RISK:
        required = ["desktop.windows.high_risk"]
        if not (effective & HIGH_RISK_SCOPES) and "desktop.windows.high_risk" not in effective:
            allowed = False
            reasons.append("missing_high_risk_scope")
        requires_approval = True
        reasons.append("fresh_human_approval_required")

    if action.metadata.get("destructive") or action.metadata.get("purchase"):
        risk = ActionRisk.HIGH_RISK
        requires_approval = True
        if "desktop.windows.high_risk" not in effective and not (effective & HIGH_RISK_SCOPES):
            allowed = False
            reasons.append("destructive_requires_high_risk_scope")

    return PolicyDecision(
        allowed=allowed,
        risk=risk,
        requires_approval=requires_approval,
        reasons=reasons,
        scopes_required=required,
    )
