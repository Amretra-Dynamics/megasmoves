"""Target and foreground validation — fail closed on drift."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from megas.operate.windows.discovery import DesktopBackend
from megas.operate.windows.models import ElementIdentity, WindowIdentity


class TargetDriftError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class TargetSnapshot:
    window: WindowIdentity
    element: ElementIdentity | None = None
    scale_factor: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "window": self.window.to_dict(),
            "element": self.element.to_dict() if self.element else None,
            "scale_factor": self.scale_factor,
        }


def capture_target(
    backend: DesktopBackend,
    *,
    expected_window: dict[str, Any] | None = None,
    element: ElementIdentity | None = None,
    require_foreground: bool = True,
    scale_factor: float = 1.0,
) -> TargetSnapshot:
    if backend.is_secure_desktop():
        raise TargetDriftError("secure_desktop", "Secure desktop is active; Windows CUA is blocked.")
    if backend.is_session_locked():
        raise TargetDriftError("session_locked", "Windows session is locked; Windows CUA is blocked.")
    if backend.is_uac_prompt_present():
        raise TargetDriftError("uac_prompt", "UAC prompt is present; Windows CUA is blocked.")

    foreground = backend.get_foreground()
    windows = backend.list_windows()

    target: WindowIdentity | None = None
    if expected_window:
        hwnd = expected_window.get("hwnd")
        pid = expected_window.get("process_id")
        for w in windows:
            if hwnd is not None and w.hwnd == int(hwnd):
                target = w
                break
            if pid is not None and w.process_id == int(pid) and (
                not expected_window.get("title") or w.title == expected_window.get("title")
            ):
                target = w
                break
        if target is None:
            raise TargetDriftError("window_missing", "Target window not found.")
    else:
        target = foreground
        if target is None:
            raise TargetDriftError("no_foreground", "No foreground window available.")

    if not target.is_visible:
        raise TargetDriftError("window_not_visible", "Target window is not visible.")

    if require_foreground:
        if foreground is None or foreground.hwnd != target.hwnd:
            raise TargetDriftError(
                "focus_drift",
                "Foreground window does not match the authorized target.",
            )
        if foreground.process_id != target.process_id:
            raise TargetDriftError(
                "process_drift",
                "Foreground process identity does not match the authorized target.",
            )

    # Element staleness check
    live_element = None
    if element is not None:
        live_element = backend.get_element(element.element_id)
        if live_element is None:
            raise TargetDriftError("stale_element", "Target element is stale or disposed.")
        if live_element.process_id and live_element.process_id != target.process_id:
            raise TargetDriftError(
                "element_process_mismatch",
                "Element process does not match target window process.",
            )
        if live_element.is_offscreen:
            raise TargetDriftError("element_offscreen", "Target element is off-screen.")

    return TargetSnapshot(window=target, element=live_element, scale_factor=scale_factor)


def assert_target_unchanged(before: TargetSnapshot, after: TargetSnapshot) -> None:
    if before.window.fingerprint() != after.window.fingerprint():
        raise TargetDriftError(
            "window_identity_changed",
            "Window identity changed during action; aborting.",
        )
    if before.element and after.element:
        if before.element.fingerprint() != after.element.fingerprint():
            raise TargetDriftError(
                "element_identity_changed",
                "Element identity changed during action; aborting.",
            )
    if abs(before.scale_factor - after.scale_factor) > 0.01:
        raise TargetDriftError(
            "scale_changed",
            "Display scaling changed during sensitive action; aborting.",
        )


def translate_coordinates(
    *,
    x: float,
    y: float,
    scale_factor: float,
    display_origin: tuple[float, float] = (0.0, 0.0),
) -> tuple[int, int]:
    """Convert logical element coordinates to physical pixels for multi-monitor/DPI."""
    ox, oy = display_origin
    px = int(round((x + ox) * scale_factor))
    py = int(round((y + oy) * scale_factor))
    return px, py
