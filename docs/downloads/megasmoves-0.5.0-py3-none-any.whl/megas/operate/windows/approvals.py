"""Fresh human approval validation with expiry and target-binding."""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any

from megas.operate.windows.models import ActionRequest, ApprovalGrant, ElementIdentity, WindowIdentity, utc_now


class ApprovalError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _parse_ts(value: str) -> datetime:
    text = str(value).replace("Z", "+00:00")
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def hash_proposed_values(values: Any) -> str:
    raw = repr(values).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:32]


def validate_approval(
    action: ActionRequest,
    *,
    window: WindowIdentity | None,
    element: ElementIdentity | None,
    now: datetime | None = None,
) -> None:
    grant = action.approval
    if grant is None:
        raise ApprovalError("approval_missing", "High-risk action requires a fresh approval grant.")

    if grant.action_id and grant.action_id != action.action_id:
        raise ApprovalError("approval_action_mismatch", "Approval action_id does not match the action.")

    if grant.session_id and action.session_id and grant.session_id != action.session_id:
        raise ApprovalError("approval_session_mismatch", "Approval session_id does not match.")

    current = now or datetime.now(timezone.utc)
    try:
        expires = _parse_ts(grant.expires_at)
    except ValueError as exc:
        raise ApprovalError("approval_invalid_expiry", "Approval expiry timestamp is invalid.") from exc
    if current >= expires:
        raise ApprovalError("approval_expired", "Approval has expired.")

    if window is not None:
        if grant.process_id is not None and grant.process_id != window.process_id:
            raise ApprovalError("approval_target_changed", "Process identity changed after approval.")
        if grant.window_fingerprint and grant.window_fingerprint != window.fingerprint():
            raise ApprovalError("approval_target_changed", "Window identity changed after approval.")

    if element is not None and grant.element_fingerprint:
        if grant.element_fingerprint != element.fingerprint():
            raise ApprovalError("approval_target_changed", "Element identity changed after approval.")

    if grant.proposed_values_hash and action.text is not None:
        current_hash = hash_proposed_values(action.text)
        if current_hash != grant.proposed_values_hash:
            raise ApprovalError(
                "approval_values_changed",
                "Proposed values changed after approval; grant is invalid.",
            )


def build_approval(
    *,
    action_id: str,
    session_id: str,
    expires_at: str,
    window: WindowIdentity | None = None,
    element: ElementIdentity | None = None,
    proposed_values: Any = None,
    expected_effect: str | None = None,
    application: str | None = None,
) -> ApprovalGrant:
    return ApprovalGrant(
        approval_id=f"apr_{hashlib.sha256(f'{action_id}:{expires_at}'.encode()).hexdigest()[:16]}",
        action_id=action_id,
        session_id=session_id,
        expires_at=expires_at,
        application=application or (window.executable if window else None),
        process_id=window.process_id if window else None,
        window_fingerprint=window.fingerprint() if window else None,
        element_fingerprint=element.fingerprint() if element else None,
        proposed_values_hash=hash_proposed_values(proposed_values) if proposed_values is not None else None,
        expected_effect=expected_effect,
        granted_at=utc_now(),
    )
