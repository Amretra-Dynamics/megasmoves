"""UI Automation action layer — production backend first, injectable double for tests."""

from __future__ import annotations

from typing import Any, Protocol

from megas.operate.windows.models import ElementIdentity, ElementSelector, WindowIdentity


class UiaActionError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class DesktopBackend(Protocol):
    def list_windows(self) -> list[WindowIdentity]:
        ...

    def get_foreground(self) -> WindowIdentity | None:
        ...

    def find_elements(
        self, window: WindowIdentity, selector: ElementSelector
    ) -> list[ElementIdentity]:
        ...

    def get_element(self, element_id: str) -> ElementIdentity | None:
        ...

    def accessibility_tree(self, window: WindowIdentity, *, max_nodes: int = 200) -> list[dict]:
        ...

    def is_secure_desktop(self) -> bool:
        ...

    def is_session_locked(self) -> bool:
        ...

    def is_uac_prompt_present(self) -> bool:
        ...


class UiaAdapter:
    def __init__(self, backend: DesktopBackend) -> None:
        self.backend = backend

    def enumerate_windows(self) -> list[dict[str, Any]]:
        return [w.to_dict() for w in self.backend.list_windows()]

    def inspect_active_window(self) -> dict[str, Any] | None:
        fg = self.backend.get_foreground()
        return fg.to_dict() if fg else None

    def inspect_tree(self, window: WindowIdentity, *, max_nodes: int = 200) -> list[dict]:
        return self.backend.accessibility_tree(window, max_nodes=max_nodes)

    def find_element(
        self, window: WindowIdentity, selector: ElementSelector
    ) -> ElementIdentity:
        matches = self.backend.find_elements(window, selector)
        if not matches:
            raise UiaActionError("element_not_found", "No UI Automation element matched selector.")
        if len(matches) > 1:
            if selector.automation_id:
                exact = [m for m in matches if m.automation_id == selector.automation_id]
                if len(exact) == 1:
                    return exact[0]
            raise UiaActionError(
                "element_ambiguous",
                f"Selector matched {len(matches)} elements; refine AutomationId/Name.",
            )
        return matches[0]

    def focus_element(self, element: ElementIdentity) -> ElementIdentity:
        live = self._require_live(element)
        if not live.is_enabled:
            raise UiaActionError("element_disabled", "Cannot focus a disabled element.")
        if hasattr(self.backend, "focus"):
            try:
                self.backend.focus(live.element_id)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "focus_failed")
                raise UiaActionError(str(code), str(exc)) from exc
        return self._require_live(live)

    def invoke_element(self, element: ElementIdentity) -> ElementIdentity:
        live = self._require_live(element)
        if not live.is_enabled:
            raise UiaActionError("element_disabled", "Cannot invoke a disabled element.")
        if hasattr(self.backend, "invoke"):
            try:
                self.backend.invoke(live.element_id)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "invoke_failed")
                raise UiaActionError(str(code), str(exc)) from exc
            return self._require_live(live)
        # Test double path (MockDesktopBackend)
        if "Invoke" not in live.patterns and live.control_type not in {"Button", "MenuItem", "Hyperlink"}:
            raise UiaActionError(
                "pattern_unsupported",
                "InvokePattern is not supported on this element; input fallback may be required.",
            )
        mark = getattr(self.backend, "mark_invoked", None)
        if callable(mark):
            mark(live.element_id)
        return self._require_live(live)

    def set_text(self, element: ElementIdentity, text: str, *, is_secret: bool = False) -> ElementIdentity:
        live = self._require_live(element)
        if hasattr(self.backend, "set_value"):
            try:
                self.backend.set_value(live.element_id, text)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "set_value_failed")
                raise UiaActionError(str(code), str(exc)) from exc
            refreshed = self._require_live(live)
            if is_secret or refreshed.is_password:
                refreshed.value_preview = "[REDACTED]"
            return refreshed
        if "Value" not in live.patterns and live.control_type not in {"Edit", "Document"}:
            raise UiaActionError(
                "pattern_unsupported",
                "ValuePattern is not supported; cannot set text via UI Automation.",
            )
        preview = "[REDACTED]" if (live.is_password or is_secret) else text[:120]
        setter = getattr(self.backend, "set_element_value", None)
        if callable(setter):
            setter(live.element_id, "" if (live.is_password or is_secret) else preview)
        live = self._require_live(live)
        live.value_preview = preview
        return live

    def read_text(self, element: ElementIdentity) -> str:
        live = self._require_live(element)
        if live.is_password:
            return "[REDACTED_PASSWORD_FIELD]"
        if hasattr(self.backend, "get_value"):
            try:
                return str(self.backend.get_value(live.element_id))  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "get_value_failed")
                raise UiaActionError(str(code), str(exc)) from exc
        return live.value_preview or live.name or ""

    def toggle(self, element: ElementIdentity) -> ElementIdentity:
        live = self._require_live(element)
        if hasattr(self.backend, "toggle"):
            try:
                self.backend.toggle(live.element_id)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "toggle_failed")
                raise UiaActionError(str(code), str(exc)) from exc
            return self._require_live(live)
        if "Toggle" not in live.patterns and live.control_type not in {"CheckBox", "Button"}:
            raise UiaActionError("pattern_unsupported", "TogglePattern unsupported.")
        if "Toggled" in live.patterns:
            live.patterns = [p for p in live.patterns if p != "Toggled"]
        else:
            live.patterns = list(live.patterns) + ["Toggled"]
        return live

    def expand_collapse(self, element: ElementIdentity, *, expand: bool = True) -> ElementIdentity:
        live = self._require_live(element)
        if hasattr(self.backend, "expand_collapse"):
            try:
                self.backend.expand_collapse(live.element_id, expand=expand)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "expand_collapse_failed")
                raise UiaActionError(str(code), str(exc)) from exc
            return self._require_live(live)
        marker = "Expanded" if expand else "Collapsed"
        live.patterns = [p for p in live.patterns if p not in {"Expanded", "Collapsed"}] + [marker]
        return live

    def scroll(self, element: ElementIdentity, *, direction: str = "down") -> ElementIdentity:
        live = self._require_live(element)
        if hasattr(self.backend, "scroll"):
            try:
                self.backend.scroll(live.element_id, direction=direction)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "scroll_failed")
                raise UiaActionError(str(code), str(exc)) from exc
            return self._require_live(live)
        if "Scroll" not in live.patterns:
            raise UiaActionError("pattern_unsupported", "ScrollPattern unsupported.")
        return live

    def select_item(self, element: ElementIdentity) -> ElementIdentity:
        live = self._require_live(element)
        if hasattr(self.backend, "select_item"):
            try:
                self.backend.select_item(live.element_id)  # type: ignore[attr-defined]
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "select_failed")
                raise UiaActionError(str(code), str(exc)) from exc
            return self._require_live(live)
        if "SelectionItem" not in live.patterns and live.control_type not in {
            "ListItem",
            "TreeItem",
            "TabItem",
        }:
            raise UiaActionError("pattern_unsupported", "SelectionItemPattern unsupported.")
        if "Selected" not in live.patterns:
            live.patterns = list(live.patterns) + ["Selected"]
        return live

    def _require_live(self, element: ElementIdentity) -> ElementIdentity:
        live = self.backend.get_element(element.element_id)
        if live is None:
            raise UiaActionError("stale_element", "Element no longer exists in the accessibility tree.")
        return live
