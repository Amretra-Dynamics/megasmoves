"""Bounded read-only verification of the exact requested foreground HWND."""
from __future__ import annotations

import time
from typing import Any, Callable


def verify_foreground_settled(
    get_foreground: Callable[[], Any],
    expected_hwnd: int,
    *,
    polls: int = 3,
    interval_seconds: float = 0.075,
    sleeper: Callable[[float], None] = time.sleep,
) -> Any | None:
    """Return last observation after bounded verification; caller checks exact HWND.

    Foreground activation may be asynchronous. This helper never grants focus,
    synthesizes input, or declares a wrong HWND successful.
    """
    if not 1 <= polls <= 5 or not 0 <= interval_seconds <= 0.2:
        raise ValueError("foreground settle budget exceeded")
    last = None
    for index in range(polls):
        if index:
            sleeper(interval_seconds)
        last = get_foreground()
        if last is not None and int(last.hwnd) == int(expected_hwnd):
            break
    return last
