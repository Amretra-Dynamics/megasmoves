"""Fast read-only foreground Windows screen inspection for Megas MCP.

Windows UI Automation is the primary text source. When a foreground app exposes
no usable accessibility text, Megas captures that same foreground window in
memory and runs Windows.Media.Ocr. A window-title fallback is used only when both
text paths produce no text.
"""

from __future__ import annotations

from typing import Any, Callable

from megas.operate.windows.discovery import DesktopBackend, create_backend
from megas.operate.windows.win32_api import capture_window_png


DEFAULT_MAX_NODES = 240
MAX_NODES = 500
DEFAULT_MAX_CHARS = 12000
MAX_CHARS = 24000
OCR_CAPTURE_MAX_WIDTH = 1024
OCR_CAPTURE_MAX_HEIGHT = 768
OCR_CAPTURE_MAX_BYTES = 1_500_000


def _bounded_int(value: Any, *, default: int, minimum: int, maximum: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(minimum, min(maximum, parsed))


def read_current_screen(
    *,
    backend: DesktopBackend | None = None,
    max_nodes: int = DEFAULT_MAX_NODES,
    max_chars: int = DEFAULT_MAX_CHARS,
    capture: Callable[..., dict[str, Any] | None] | None = None,
    ocr: Callable[..., dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Read visible text from the current foreground Windows app.

    The function is read-only and fail-closed on secure desktop, lock screen, or
    UAC. Password UIA nodes are omitted. UIA is preferred; OCR is attempted only
    when UIA yields no visible text. Output remains bounded for MCP transport.
    """

    actual = backend or create_backend()
    node_limit = _bounded_int(
        max_nodes,
        default=DEFAULT_MAX_NODES,
        minimum=1,
        maximum=MAX_NODES,
    )
    char_limit = _bounded_int(
        max_chars,
        default=DEFAULT_MAX_CHARS,
        minimum=256,
        maximum=MAX_CHARS,
    )

    if actual.is_session_locked():
        raise PermissionError("Windows session is locked; current-screen read is unavailable.")
    if actual.is_secure_desktop():
        raise PermissionError("Secure desktop is active; current-screen read is unavailable.")
    if actual.is_uac_prompt_present():
        raise PermissionError("A UAC prompt is active; current-screen read is unavailable.")

    window = actual.get_foreground()
    if window is None:
        raise RuntimeError("No foreground Windows app is available.")

    nodes = actual.accessibility_tree(window, max_nodes=node_limit)
    visible: list[str] = []
    seen: set[str] = set()
    used_chars = 0

    for node in nodes:
        if not isinstance(node, dict) or bool(node.get("is_password")):
            continue
        value = str(node.get("name") or "").strip()
        if not value or value in seen:
            continue
        remaining = char_limit - used_chars
        if remaining <= 0:
            break
        if len(value) > remaining:
            value = value[:remaining]
        visible.append(value)
        seen.add(value)
        used_chars += len(value) + 1

    text = "\n".join(visible)
    method = "uia_accessibility_tree"
    fallback_used = False
    fallback_source = None
    fallback_error_type = None
    ocr_metadata: dict[str, Any] | None = None
    truncated = used_chars >= char_limit

    if not text:
        fallback_used = True
        capture_fn = capture or capture_window_png
        try:
            evidence = capture_fn(
                int(window.hwnd),
                max_width=OCR_CAPTURE_MAX_WIDTH,
                max_height=OCR_CAPTURE_MAX_HEIGHT,
                max_bytes=OCR_CAPTURE_MAX_BYTES,
            )
            png = evidence.get("png") if isinstance(evidence, dict) else None
            if isinstance(png, (bytes, bytearray)) and png:
                if ocr is None:
                    from megas.operate.windows.screen_ocr import recognize_png

                    ocr_fn = recognize_png
                else:
                    ocr_fn = ocr
                recognized = ocr_fn(bytes(png), max_chars=char_limit)
                recognized_text = str(recognized.get("text") or "").strip()
                if recognized_text:
                    text = recognized_text[:char_limit]
                    method = "uia_then_windows_ocr"
                    fallback_source = "windows_media_ocr"
                    truncated = bool(recognized.get("truncated")) or len(recognized_text) > char_limit
                    ocr_metadata = {
                        "source": recognized.get("source") or "windows_media_ocr",
                        "language": recognized.get("language"),
                        "text_angle": recognized.get("text_angle"),
                        "confidence": recognized.get("confidence"),
                        "confidence_available": bool(
                            recognized.get("confidence_available", False)
                        ),
                        "line_count": len(recognized.get("lines") or []),
                    }
        except Exception as exc:
            # Keep the screen-read call useful even when OCR is unavailable.
            # Expose only the exception type so implementation details, paths or
            # image-adjacent data never leak through fallback diagnostics.
            fallback_error_type = type(exc).__name__

    if not text:
        title = str(window.title or "").strip()
        text = title[:char_limit]
        method = "window_title"
        fallback_source = "window_title"
        truncated = len(title) > char_limit

    return {
        "ok": True,
        "scope": "foreground_window",
        "method": method,
        "fallback_used": fallback_used,
        "fallback_source": fallback_source,
        "fallback_error_type": fallback_error_type,
        "window": window.to_dict(),
        "text": text,
        "text_items": visible,
        "node_count": len(nodes),
        "max_nodes": node_limit,
        "truncated": truncated,
        "ocr": ocr_metadata,
    }


__all__ = [
    "DEFAULT_MAX_CHARS",
    "DEFAULT_MAX_NODES",
    "MAX_CHARS",
    "MAX_NODES",
    "OCR_CAPTURE_MAX_BYTES",
    "OCR_CAPTURE_MAX_HEIGHT",
    "OCR_CAPTURE_MAX_WIDTH",
    "read_current_screen",
]
