"""Input path: production SendInput on Windows; injectable recorder for tests."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from megas.operate.windows.models import ElementIdentity, WindowIdentity
from megas.operate.windows.targeting import translate_coordinates
from megas.operate.windows.win32_api import is_windows


class InputFallbackError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass
class InputAdapter:
    """Facade over production SendInput or an in-memory recorder for unit tests."""

    scale_factor: float = 1.0
    history: list[dict[str, Any]] = field(default_factory=list)
    _enabled: bool = True
    _stopped: bool = False
    _engine: Any = field(default=None, repr=False)
    force_recorder: bool = False

    def __post_init__(self) -> None:
        if self.force_recorder or not is_windows():
            self._engine = None
            return
        try:
            from megas.operate.windows.input_win32 import ProductionInputEngine

            self._engine = ProductionInputEngine(scale_factor=self.scale_factor)
        except Exception:  # noqa: BLE001
            # On Windows, fail closed rather than faking input.
            self._engine = None
            if is_windows():
                raise

    def emergency_stop(self) -> None:
        self._stopped = True
        self._enabled = False
        if self._engine is not None:
            self._engine.emergency_stop()

    def reset_after_stop(self) -> None:
        self._stopped = False
        self._enabled = True
        self.history.clear()
        if self._engine is not None:
            self._engine.reset_after_stop()

    def _guard(self) -> None:
        if self._stopped or not self._enabled:
            raise InputFallbackError("emergency_stopped", "Input path is emergency-stopped.")

    def click(
        self,
        *,
        window: WindowIdentity,
        element: ElementIdentity | None,
        button: str = "left",
        clicks: int = 1,
        verified_foreground: bool,
    ) -> dict[str, Any]:
        self._guard()
        if self._engine is not None:
            try:
                record = self._engine.click(
                    window=window,
                    element=element,
                    button=button,
                    clicks=clicks,
                    verified_foreground=verified_foreground,
                )
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "input_failed")
                raise InputFallbackError(str(code), str(exc)) from exc
            self.history.append(record)
            return record
        if not verified_foreground:
            raise InputFallbackError(
                "unverified_foreground",
                "Refusing coordinate input to an unverified foreground window.",
            )
        if element is None or element.bounds is None:
            raise InputFallbackError(
                "missing_bounds",
                "Coordinate fallback requires known element bounds.",
            )
        cx, cy = element.bounds.center()
        px, py = translate_coordinates(x=cx, y=cy, scale_factor=self.scale_factor)
        record = {
            "type": "click",
            "button": button,
            "clicks": clicks,
            "x": px,
            "y": py,
            "hwnd": window.hwnd,
            "process_id": window.process_id,
            "element_id": element.element_id,
            "engine": "recorder",
        }
        self.history.append(record)
        return record

    def move_pointer(
        self,
        *,
        window: WindowIdentity,
        x: float,
        y: float,
        verified_foreground: bool,
    ) -> dict[str, Any]:
        self._guard()
        if self._engine is not None:
            try:
                record = self._engine.move_pointer(
                    window=window, x=x, y=y, verified_foreground=verified_foreground
                )
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "input_failed")
                raise InputFallbackError(str(code), str(exc)) from exc
            self.history.append(record)
            return record
        if not verified_foreground:
            raise InputFallbackError("unverified_foreground", "Refusing pointer move without verification.")
        px, py = translate_coordinates(x=x, y=y, scale_factor=self.scale_factor)
        record = {"type": "move", "x": px, "y": py, "hwnd": window.hwnd, "engine": "recorder"}
        self.history.append(record)
        return record

    def key_press(
        self,
        *,
        window: WindowIdentity,
        keys: list[str],
        verified_foreground: bool,
        is_secret: bool = False,
    ) -> dict[str, Any]:
        self._guard()
        if self._engine is not None:
            try:
                record = self._engine.key_press(
                    window=window,
                    keys=keys,
                    verified_foreground=verified_foreground,
                    is_secret=is_secret,
                )
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "input_failed")
                raise InputFallbackError(str(code), str(exc)) from exc
            self.history.append(record)
            return record
        if not verified_foreground:
            raise InputFallbackError("unverified_foreground", "Refusing key input without verification.")
        record = {
            "type": "keys",
            "keys": ["[REDACTED]"] if is_secret else list(keys),
            "hwnd": window.hwnd,
            "process_id": window.process_id,
            "secret": is_secret,
            "engine": "recorder",
        }
        self.history.append(record)
        return record

    def type_text(
        self,
        *,
        window: WindowIdentity,
        text: str,
        verified_foreground: bool,
        is_secret: bool = False,
    ) -> dict[str, Any]:
        self._guard()
        if self._engine is not None:
            try:
                record = self._engine.type_text(
                    window=window,
                    text=text,
                    verified_foreground=verified_foreground,
                    is_secret=is_secret,
                )
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", "input_failed")
                raise InputFallbackError(str(code), str(exc)) from exc
            self.history.append(record)
            return record
        if not verified_foreground:
            raise InputFallbackError("unverified_foreground", "Refusing type_text without verification.")
        record = {
            "type": "type_text",
            "length": len(text or ""),
            "text": "[REDACTED]" if is_secret else (text[:80] if text else ""),
            "hwnd": window.hwnd,
            "secret": is_secret,
            "engine": "recorder",
        }
        self.history.append(record)
        return record
