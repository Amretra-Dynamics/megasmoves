"""Action evidence capture with redaction and size bounds.

Incorporates Kinetic-OS screen-hash progress signals without storing unbounded screenshots.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any

from megas.operate.windows.models import new_id, utc_now
from megas.operate.windows.redaction import redact_mapping, redact_screenshot_meta


@dataclass
class EvidenceRecord:
    evidence_id: str
    session_id: str
    action_id: str
    timestamp: str
    process_id: int | None
    window: dict[str, Any]
    element: dict[str, Any] | None
    selector: dict[str, Any] | None
    element_bounds: dict[str, Any] | None
    display_scale: float
    screenshot: dict[str, Any] | None
    accessibility_snapshot: list[dict[str, Any]] | None
    policy_decision: dict[str, Any] | None
    approval_reference: str | None
    execution_result: dict[str, Any]
    verification_result: dict[str, Any]
    cancellation_or_failure_reason: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return redact_mapping(
            {
                "evidence_id": self.evidence_id,
                "session_id": self.session_id,
                "action_id": self.action_id,
                "timestamp": self.timestamp,
                "process_id": self.process_id,
                "window": self.window,
                "element": self.element,
                "selector": self.selector,
                "element_bounds": self.element_bounds,
                "display_scale": self.display_scale,
                "screenshot": self.screenshot,
                "accessibility_snapshot": self.accessibility_snapshot,
                "policy_decision": self.policy_decision,
                "approval_reference": self.approval_reference,
                "execution_result": self.execution_result,
                "verification_result": self.verification_result,
                "cancellation_or_failure_reason": self.cancellation_or_failure_reason,
                "attributes": self.attributes,
            }
        )


class EvidenceStore:
    """Bounded in-memory evidence for a session (worker also emits externally)."""

    def __init__(self, *, max_records: int = 200, max_tree_nodes: int = 50) -> None:
        self.max_records = max_records
        self.max_tree_nodes = max_tree_nodes
        self.records: list[EvidenceRecord] = []
        self._last_screenshot_hash: str | None = None
        self._same_hash_streak: int = 0

    def note_screenshot_hash(self, frame_hash: str | None) -> dict[str, Any]:
        """Track progress like Kinetic-OS NO_PROGRESS detection."""
        if not frame_hash:
            return {"progress": "unknown", "same_hash_streak": self._same_hash_streak}
        if frame_hash == self._last_screenshot_hash:
            self._same_hash_streak += 1
        else:
            self._same_hash_streak = 0
            self._last_screenshot_hash = frame_hash
        stuck = self._same_hash_streak >= 3
        return {
            "progress": "stuck" if stuck else "ok",
            "same_hash_streak": self._same_hash_streak,
            "hash": frame_hash,
        }

    def capture_screenshot_meta(self, *, label: str = "frame") -> dict[str, Any]:
        """Capture screen hash metadata. Production uses BitBlt; never stores raw pixels in logs."""
        meta: dict[str, Any] | None = None
        try:
            from megas.operate.windows.win32_api import capture_screen_hash, is_windows

            if is_windows():
                meta = capture_screen_hash()
        except Exception:  # noqa: BLE001
            meta = None
        if meta is None:
            # Deterministic placeholder only when capture hardware/API is unavailable (tests).
            digest = hashlib.sha256(f"{label}:{len(self.records)}".encode()).hexdigest()[:16]
            meta = {
                "hash": digest,
                "resolution": (1920, 1080),
                "offset": (0, 0),
            }
        meta["timestamp"] = utc_now()
        meta["label"] = label
        progress = self.note_screenshot_hash(str(meta.get("hash") or ""))
        out = redact_screenshot_meta(meta)
        out["progress"] = progress
        return out

    def add(
        self,
        *,
        session_id: str,
        action_id: str,
        process_id: int | None,
        window: dict[str, Any] | None,
        element: dict[str, Any] | None,
        selector: dict[str, Any] | None,
        element_bounds: dict[str, Any] | None,
        display_scale: float,
        screenshot: dict[str, Any] | None,
        accessibility_snapshot: list[dict[str, Any]] | None,
        policy_decision: dict[str, Any] | None,
        approval_reference: str | None,
        execution_result: dict[str, Any],
        verification_result: dict[str, Any],
        cancellation_or_failure_reason: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> EvidenceRecord:
        if accessibility_snapshot is not None:
            accessibility_snapshot = accessibility_snapshot[: self.max_tree_nodes]
        record = EvidenceRecord(
            evidence_id=new_id("ev"),
            session_id=session_id,
            action_id=action_id,
            timestamp=utc_now(),
            process_id=process_id,
            window=window or {},
            element=element,
            selector=selector,
            element_bounds=element_bounds,
            display_scale=display_scale,
            screenshot=screenshot,
            accessibility_snapshot=accessibility_snapshot,
            policy_decision=policy_decision,
            approval_reference=approval_reference,
            execution_result=execution_result,
            verification_result=verification_result,
            cancellation_or_failure_reason=cancellation_or_failure_reason,
            attributes=attributes or {},
        )
        self.records.append(record)
        del self.records[: -self.max_records]
        return record
