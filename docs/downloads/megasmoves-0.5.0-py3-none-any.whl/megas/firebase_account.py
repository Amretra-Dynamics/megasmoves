"""Amretra Firebase sign-in for the local Windows product, without a Megas website."""
from __future__ import annotations

import base64
import json
import os
import secrets
import subprocess
import time
from contextlib import contextmanager
from contextvars import ContextVar
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from megas.cli.config_store import megas_home
from megas.cli.user_credentials import load_user_token, store_user_token, delete_user_token
from megas.credential_store import WindowsDPAPICredentialStore
from megas.adapters.base import windows_subprocess_kwargs
from megas.local.peer_mesh.auth import firebase_uid_from_local_token

PROJECT_ID = "amretradynamics"
API_KEY = "AIzaSyDJpSVDvXcZMc1NhBOfozxh1LJqzPsO87Q"  # Firebase public client config
MAX_BODY = 64 * 1024
_TOKEN_REQUEST = ContextVar('firebase_status_token_request', default=None)


@contextmanager
def token_request_scope():
    """Reuse renewal only within one synchronous status request, never globally."""
    if _TOKEN_REQUEST.get() is not None:
        yield
        return
    token = _TOKEN_REQUEST.set({})
    try:
        yield
    finally:
        _TOKEN_REQUEST.reset(token)


def _store():
    return WindowsDPAPICredentialStore(megas_home() / "firebase.session.json")


def _claims(token: str) -> dict:
    if not isinstance(token, str) or not token or len(token) > MAX_BODY:
        raise ValueError("Firebase ID credential is missing or too large")
    firebase_uid_from_local_token(token, project_id=PROJECT_ID, require_fresh_token=True)
    segment = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4)))


def save_session(id_token: str, refresh_token: str) -> dict:
    claims = _claims(id_token)
    if not isinstance(refresh_token, str) or not refresh_token or len(refresh_token) > 16384:
        raise ValueError("Firebase refresh credential is missing or too large")
    uid = claims["sub"]
    previous = _store()
    if previous.exists():
        current = json.loads(previous.read())
        if current.get("uid") != uid:
            raise PermissionError("Sign out before linking a different Firebase account")
    previous.write(json.dumps({"uid": uid, "refresh_token": refresh_token}))
    store_user_token(id_token, email=str(claims.get("email") or ""), source="amretra_firebase")
    return {"firebase_authenticated": True, "firebase_project": PROJECT_ID,
            "identity_authority": "firebase", "identity": {
                "user_id": uid, "email": claims.get("email"), "name": claims.get("name")}}


def current_token() -> str:
    request = _TOKEN_REQUEST.get()
    if request is None:
        return _current_token_uncached()
    if 'error' in request:
        raise request['error']
    if 'token' in request:
        return request['token']
    try:
        token = _current_token_uncached()
        request['token'] = token
        return token
    except Exception as error:
        request['error'] = error
        raise


def _current_token_uncached() -> str:
    token = load_user_token()
    try:
        claims = _claims(token)
        if claims["exp"] > time.time() + 60:
            return token
    except (ValueError, RuntimeError, OSError):
        pass
    store = _store()
    if not store.exists():
        raise PermissionError("Sign in to Amretra Firebase to renew this session")
    saved = json.loads(store.read())
    body = urlencode({"grant_type": "refresh_token", "refresh_token": saved["refresh_token"]}).encode()
    request = Request("https://securetoken.googleapis.com/v1/token?" + urlencode({"key": API_KEY}),
                      data=body, headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urlopen(request, timeout=10) as response:
            raw = response.read(MAX_BODY + 1)
        if len(raw) > MAX_BODY:
            raise ValueError("Firebase response exceeds the limit")
        refreshed = json.loads(raw)
        token = refreshed["id_token"]
        if _claims(token)["sub"] != saved["uid"]:
            raise PermissionError("Firebase refresh changed the linked identity")
        save_session(token, refreshed["refresh_token"])
        return token
    except Exception as exc:
        raise PermissionError("Firebase session renewal failed; sign in again") from exc


def status() -> dict:
    try:
        claims = _claims(current_token())
        return {"firebase_authenticated": True, "firebase_project": PROJECT_ID,
                "identity_authority": "firebase", "identity": {
                    "user_id": claims["sub"], "email": claims.get("email"), "name": claims.get("name")}}
    except Exception:
        return {"firebase_authenticated": False, "firebase_project": PROJECT_ID,
                "identity_authority": "firebase", "state": "sign_in_required"}


def logout() -> dict:
    delete_user_token()
    _store().delete()
    return {"firebase_authenticated": False}


def _page(state: str, remaining_seconds: float = 600) -> bytes:
    config = json.dumps({"apiKey": API_KEY, "authDomain": PROJECT_ID + ".firebaseapp.com", "projectId": PROJECT_ID})
    return ('''<!doctype html><html><head><meta charset="utf-8"><title>Megas Moves — Login</title>
<style>body{background:#fff;color:#182235;font:16px system-ui;margin:60px auto;max-width:440px;padding:24px}input,button{box-sizing:border-box;display:block;width:100%;padding:14px;margin:12px 0;border-radius:8px;border:1px solid #ccd3dd}button{background:#2455c7;color:#fff;cursor:pointer}p{line-height:1.5}#message{white-space:pre-wrap}</style></head>
<body><h1>Login to Megas Moves</h1><p>Use your Amretra Firebase account to connect this Windows installation.</p>
<button id="google" disabled>Continue with Google</button><form id="email"><input id="address" type="email" autocomplete="username" required placeholder="Email"><input id="password" type="password" autocomplete="current-password" required placeholder="Password"><button id="submit" disabled>Login with email</button></form><p id="message">Loading secure sign-in…</p>
<script type="module">
const config=CONFIG; const state=STATE; const message=document.getElementById('message');
const expiresAt=Date.now()+LIFETIME;
const expiredMessage='This sign-in session expired. Return to Megas Moves and click Sign in again.';
function expire(){document.getElementById('google').disabled=true;document.getElementById('submit').disabled=true;message.textContent=expiredMessage;}
const expirationTimer=setTimeout(expire,Math.max(0,expiresAt-Date.now()));
try{
const {initializeApp}=await import('https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js');
const {getAuth,setPersistence,inMemoryPersistence,signInWithPopup,GoogleAuthProvider,signInWithEmailAndPassword}=await import('https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js');
const auth=getAuth(initializeApp(config));
async function complete(user){if(Date.now()>=expiresAt)throw Error(expiredMessage);let response;try{response=await fetch('/complete',{method:'POST',headers:{'Content-Type':'application/json','X-Megas-State':state},body:JSON.stringify({id_token:await user.getIdToken(true),refresh_token:user.refreshToken})});}catch(e){throw Error('Megas Moves is no longer waiting for this sign-in. Return to the app and click Sign in again.');}if(!response.ok)throw Error('The local app could not verify this sign-in. Return to Megas Moves and retry.');clearTimeout(expirationTimer);message.textContent='Connected. You can close this tab and return to Megas Moves.';document.getElementById('email').remove();document.getElementById('google').remove();}
await setPersistence(auth,inMemoryPersistence);if(Date.now()>=expiresAt){expire();}else{document.getElementById('google').disabled=false;document.getElementById('submit').disabled=false;message.textContent='Choose your sign-in method. Complete sign-in within 10 minutes.';}
document.getElementById('google').onclick=async()=>{try{await complete((await signInWithPopup(auth,new GoogleAuthProvider())).user);}catch(e){message.textContent=e.code||e.message;}};
document.getElementById('email').onsubmit=async(e)=>{e.preventDefault();try{const password=document.getElementById('password');const result=await signInWithEmailAndPassword(auth,document.getElementById('address').value,password.value);password.value='';await complete(result.user);}catch(e){message.textContent=e.code||e.message;}};
}catch(e){message.textContent='Sign-in could not load. Check your internet connection and restart Sign in from Megas Moves.';}
</script></body></html>'''.replace("CONFIG", config).replace("STATE", json.dumps(state)).replace("LIFETIME", str(max(0, int(remaining_seconds * 1000))))).encode()


def interactive_login(*, timeout: float = 600, open_browser: bool = True) -> dict:
    if os.name != "nt":
        raise RuntimeError("This local sign-in requires Windows DPAPI")
    state = secrets.token_urlsafe(32)
    result: dict = {}
    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(10)
        def log_message(self, *_):
            pass
        def reply(self, code, body=b"", content_type="application/json"):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def valid_host(self):
            return self.headers.get("Host") == f"localhost:{self.server.server_port}"
        def do_GET(self):
            if not self.valid_host() or self.path != "/login/" + state:
                return self.reply(404)
            self.reply(200, _page(state, deadline - time.monotonic()), "text/html; charset=utf-8")
        def do_POST(self):
            if (not self.valid_host() or self.path != "/complete" or
                self.headers.get("Origin") != f"http://localhost:{self.server.server_port}" or
                not secrets.compare_digest(self.headers.get("X-Megas-State", ""), state)):
                return self.reply(403)
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= MAX_BODY:
                    return self.reply(413)
                value = json.loads(self.rfile.read(length))
                if not isinstance(value, dict) or set(value) != {"id_token", "refresh_token"}:
                    return self.reply(400)
                verified = save_session(value["id_token"], value["refresh_token"])
                self.reply(200, b'{"connected":true}')
                result.update(verified)
            except Exception:
                self.reply(400, b'{"error":"Sign-in verification failed"}')
    with HTTPServer(("127.0.0.1", 0), Handler) as server:
        server.timeout = 0.5
        deadline = time.monotonic() + min(max(timeout, 10), 600)
        url = f"http://localhost:{server.server_port}/login/{state}"
        print("Megas Firebase sign-in: " + url, flush=True)
        if open_browser:
            chrome = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Google/Chrome/Application/chrome.exe"
            if not chrome.is_file():
                raise RuntimeError("Open the displayed sign-in URL in Chrome")
            subprocess.Popen([str(chrome), url], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             **windows_subprocess_kwargs(hide_window=False))
        while not result and time.monotonic() < deadline:
            server.handle_request()
    if not result:
        raise TimeoutError("Firebase sign-in timed out; retry Login")
    return result


if __name__ == "__main__":
    interactive_login(timeout=600)
    print("Amretra Firebase connected and protected with Windows DPAPI.")
