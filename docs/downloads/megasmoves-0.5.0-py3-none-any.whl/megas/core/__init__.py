"""Megas Worker Core."""

