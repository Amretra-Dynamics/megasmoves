"""Installed + logged-in probes for coding agents on the Worker machine.

Health reports feed Connected Agents on phone/web. Principles:

- **installed**: a real runnable binary is findable (PATH or known install path).
- **authenticated**: agent-specific env key or an official credential file that
  actually contains token/key material — never IDE chrome, session caches,
  marketplace folders, or "config exists so must be logged in".
- Prefer **unknown** over a false "not logged in" / "logged in".
- Never raise from probes (Worker heartbeat must stay resilient).
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any


def _home() -> Path:
    return Path.home()


def _any_file(*candidates: Path) -> bool:
    for path in candidates:
        try:
            if path.expanduser().is_file():
                return True
        except Exception:
            continue
    return False


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        raw = path.expanduser().read_text(encoding="utf-8", errors="replace")
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _env_set(*names: str) -> bool:
    return any(bool(str(os.environ.get(name) or "").strip()) for name in names)


def _credential_json_looks_signed_in(data: dict[str, Any] | None) -> bool:
    """True only when JSON carries credential-like fields, not arbitrary config."""
    if not isinstance(data, dict) or not data:
        return False

    leaf_keys = {
        "access_token",
        "refresh_token",
        "id_token",
        "token",
        "tokens",
        "api_key",
        "apiKey",
        "key",
        "OPENAI_API_KEY",
        "account_id",
        "auth_mode",
    }

    def node_has_secret(node: Any, depth: int = 0) -> bool:
        if depth > 3:
            return False
        if isinstance(node, dict):
            for key, value in node.items():
                if str(key) in leaf_keys and value not in (None, "", {}, []):
                    return True
                if node_has_secret(value, depth + 1):
                    return True
        elif isinstance(node, list):
            return any(node_has_secret(item, depth + 1) for item in node)
        return False

    return node_has_secret(data)


def _xdg_data_home() -> Path:
    raw = str(os.environ.get("XDG_DATA_HOME") or "").strip()
    if raw:
        return Path(raw)
    # Unix default. On Windows OpenCode often still uses ~/.local/share.
    return _home() / ".local" / "share"


def _opencode_auth_files() -> list[Path]:
    """Official OpenCode/Kilo credential files only (not config-only trees).

    Documented location: ``~/.local/share/opencode/auth.json`` (XDG data home).
    """
    home = _home()
    local = Path(os.environ.get("LOCALAPPDATA") or "")
    return [
        _xdg_data_home() / "opencode" / "auth.json",
        home / ".local" / "share" / "opencode" / "auth.json",
        home / ".opencode" / "auth.json",
        # Windows ports sometimes mirror under LocalAppData.
        local / "opencode" / "auth.json" if str(local) else Path(),
    ]


def probe_authentication_state(agent_type: str, binary_path: str = "") -> str:
    """Best-effort logged-in detection. Never raises.

    Returns: authenticated | unauthenticated | unknown
    """
    agent = (agent_type or "").strip().lower()
    home = _home()
    installed = bool(str(binary_path or "").strip())

    try:
        if agent in {"codex_cli", "codex"}:
            if _env_set("OPENAI_API_KEY", "CODEX_API_KEY"):
                return "authenticated"
            data = _read_json(home / ".codex" / "auth.json")
            if _credential_json_looks_signed_in(data):
                return "authenticated"
            # Codex often stores a non-empty auth.json for ChatGPT login.
            if data:
                return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"claude_code", "claude"}:
            if _env_set("ANTHROPIC_API_KEY", "CLAUDE_API_KEY"):
                return "authenticated"
            for path in (
                home / ".claude" / ".credentials.json",
                home / ".claude" / "credentials.json",
                home / ".config" / "claude" / "credentials.json",
                home / ".anthropic" / "credentials.json",
            ):
                if _credential_json_looks_signed_in(_read_json(path)):
                    return "authenticated"
            data = _read_json(home / ".claude.json")
            if isinstance(data, dict) and (
                data.get("sessionKey") or data.get("oauthAccount") or data.get("primaryApiKey") or data.get("apiKey")
            ):
                return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"gemini_cli", "gemini"}:
            if _env_set("GEMINI_API_KEY", "GOOGLE_API_KEY", "GOOGLE_GENAI_API_KEY"):
                return "authenticated"
            if (home / ".gemini" / "antigravity-cli").is_dir() or (home / ".gemini").is_dir():
                return "authenticated"
            for path in (
                home / ".gemini" / "oauth_creds.json",
                home / ".config" / "gemini" / "oauth_creds.json",
                home / ".config" / "gcloud" / "application_defaultcredentials.json",
            ):
                if path.is_file() and (
                    _credential_json_looks_signed_in(_read_json(path)) or path.stat().st_size > 2
                ):
                    return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"antigravity", "agy"}:
            if (home / ".gemini").is_dir() or (home / ".antigravity").is_dir() or (home / ".agy").is_dir():
                return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent == "aider":
            if _env_set(
                "OPENAI_API_KEY",
                "ANTHROPIC_API_KEY",
                "AIDER_API_KEY",
                "GEMINI_API_KEY",
            ):
                return "authenticated"
            # .aider directory is not proof of provider login.
            return "unauthenticated" if installed else "unknown"

        if agent in {"grok_build", "grok"}:
            # Official: XAI_API_KEY fallback, session tokens in ~/.grok/auth.json
            # (docs.x.ai / grok-build authentication guide).
            if _env_set("XAI_API_KEY", "GROK_API_KEY"):
                return "authenticated"
            data = _read_json(home / ".grok" / "auth.json")
            if data:  # any successful login writes this file
                return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"kimi_code", "kimi"}:
            if _env_set("MOONSHOT_API_KEY", "KIMI_API_KEY"):
                return "authenticated"
            for path in (
                home / ".kimi" / "credentials.json",
                home / ".kimi" / "auth.json",
                home / ".config" / "kimi" / "credentials.json",
            ):
                if _credential_json_looks_signed_in(_read_json(path)):
                    return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"glm_code", "glm"}:
            if _env_set("ZHIPUAI_API_KEY", "GLM_API_KEY"):
                return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"kilo_code", "kilocode", "opencode", "kilo"}:
            # Kilo CLI is OpenCode-family. Do NOT treat OPENAI_API_KEY as Kilo login
            # (that is Codex/OpenAI and caused false positives).
            if _env_set("KILO_API_KEY", "KILOCODE_API_KEY", "OPENCODE_API_KEY"):
                return "authenticated"
            for path in _opencode_auth_files():
                if not str(path):
                    continue
                if _credential_json_looks_signed_in(_read_json(path)):
                    return "authenticated"
            for path in (
                home / ".kilocode" / "auth.json",
                home / ".kilocode" / "credentials.json",
                home / ".config" / "kilocode" / "auth.json",
            ):
                if _credential_json_looks_signed_in(_read_json(path)):
                    return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"cline", "cline_cli"}:
            if _env_set("CLINE_API_KEY"):
                return "authenticated"
            providers = _read_json(home / ".cline" / "data" / "settings" / "providers.json")
            if providers:
                return "authenticated"
            return "unauthenticated" if installed else "unknown"

        if agent in {"devin", "devin_cli"}:
            if _env_set("WINDSURF_API_KEY", "DEVIN_API_KEY"):
                return "authenticated"
            # Credential filenames are intentionally not assumed. Devin can use
            # several account/auth backends; show unknown until a documented,
            # non-interactive status contract is available.
            return "unknown"

        return "unknown"
    except Exception:
        return "unknown"


async def check_codex_health(binary_name: str = "codex") -> tuple[str, str | None, dict[str, Any]]:
    """Runs a real health check on the Codex binary.

    Returns:
        (health_state, health_reason, details_dict)
    """
    binary_path = shutil.which(binary_name)
    if not binary_path:
        if Path(binary_name).is_file():
            binary_path = str(Path(binary_name).resolve())
        else:
            return "unhealthy", f"Executable '{binary_name}' not found on PATH or filesystem.", {
                "detected": False,
                "installed": False,
                "version": "",
                "executable_path": "",
                "authentication_state": "unknown",
            }

    details: dict[str, Any] = {
        "detected": True,
        "installed": True,
        "executable_path": binary_path,
        "version": "",
        "capabilities": ["code_editing", "read_only"],
        "authentication_state": "unknown",
    }

    async def run_cmd_bounded(cmd: list[str], timeout: float = 8.0):
        from megas.adapters.base import windows_subprocess_kwargs

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                **windows_subprocess_kwargs(new_group=False),
            )
        except Exception as e:
            return -1, b"", b"", f"Process error: {str(e)}"

        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return proc.returncode or 0, stdout or b"", stderr or b"", None
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            return -1, b"", b"", "timeout"

    # 1. Version parsing
    ret_code, stdout, stderr, err = await run_cmd_bounded([binary_path, "--version"])
    if err:
        details["authentication_state"] = probe_authentication_state("codex_cli", binary_path)
        return "unhealthy", f"Version check failed: {err}", details

    output_str = (stdout.decode(errors="replace") + stderr.decode(errors="replace")).strip()
    if ret_code != 0:
        details["authentication_state"] = probe_authentication_state("codex_cli", binary_path)
        return "unhealthy", f"Version check returned error exit code {ret_code}. Output: {output_str}", details

    version = "0.0.0"
    for word in output_str.split():
        if any(c.isdigit() for c in word) and "." in word:
            version = word.strip("vV,;()")
            break
    if not version and output_str:
        version = output_str.splitlines()[0]

    details["version"] = version

    # 2. Required command mode ('exec') is supported
    ret_code, stdout, stderr, err = await run_cmd_bounded([binary_path, "exec", "--help"])
    if err:
        details["authentication_state"] = probe_authentication_state("codex_cli", binary_path)
        return "unhealthy", f"Command mode check failed: {err}", details

    help_str = (stdout.decode(errors="replace") + stderr.decode(errors="replace")).lower()
    if "exec" not in help_str and "usage" not in help_str and ret_code != 0:
        details["authentication_state"] = probe_authentication_state("codex_cli", binary_path)
        return "unhealthy", f"Required command mode 'exec' is not supported. Help output: {help_str}", details

    # 3. Process can be cancelled test
    try:
        from megas.adapters.base import windows_subprocess_kwargs

        # This probe spawns a real `codex exec`, and Codex persists a rollout file for
        # every run. Pointed at the user's real CODEX_HOME it polluted their history with
        # one "wait-cancel-test-prompt" conversation per health check — 1,833 of them on a
        # single machine, which then flooded the phone's Codex chat list. Give the probe a
        # throwaway CODEX_HOME so it still exercises spawn/terminate without writing into
        # the owner's conversations.
        probe_env = dict(os.environ)
        probe_home = Path(tempfile.gettempdir()) / "megas-codex-healthprobe"
        try:
            probe_home.mkdir(parents=True, exist_ok=True)
            probe_env["CODEX_HOME"] = str(probe_home)
        except Exception:
            # If the throwaway home cannot be created, fall back to the real env rather
            # than failing the health check.
            pass

        proc = await asyncio.create_subprocess_exec(
            binary_path,
            "exec",
            "wait-cancel-test-prompt",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=probe_env,
            **windows_subprocess_kwargs(new_group=False),
        )
        await asyncio.sleep(0.05)
        if proc.returncode is None:
            proc.terminate()
        await proc.wait()
    except Exception as e:
        details["authentication_state"] = probe_authentication_state("codex_cli", binary_path)
        return "unhealthy", f"Process cancellation test failed: {str(e)}", details

    details["authentication_state"] = probe_authentication_state("codex_cli", binary_path)
    return "healthy", None, details


def _known_binary_paths(agent_type: str) -> list[Path]:
    """Well-known *binary* install locations only (not session/IDE trees)."""
    home = _home()
    local = Path(os.environ.get("LOCALAPPDATA") or "")
    agent = (agent_type or "").strip().lower()
    if agent in {"grok_build", "grok"}:
        return [
            home / ".grok" / "bin" / "grok.exe",
            home / ".grok" / "bin" / "grok",
        ]
    if agent in {"antigravity", "agy"}:
        return [
            local / "agy" / "bin" / "agy.exe" if str(local) else Path(),
            local / "agy" / "bin" / "agy" if str(local) else Path(),
        ]
    if agent in {"codex_cli", "codex"}:
        # Prefer standalone Codex CLI (supports `codex exec --json`). The OpenAI
        # desktop app binary often lands first on PATH and fails headless chat.
        packages = home / ".codex" / "packages" / "standalone" / "releases"
        standalone: list[Path] = []
        try:
            if packages.is_dir():
                for release in sorted(packages.iterdir(), reverse=True):
                    for name in ("codex.exe", "codex"):
                        candidate = release / "bin" / name
                        if not candidate.is_file():
                            # nested arch folder: releases/0.x-x86_64-.../bin/codex.exe
                            for child in release.iterdir() if release.is_dir() else []:
                                nested = child / "bin" / name
                                if nested.is_file():
                                    standalone.append(nested)
                        else:
                            standalone.append(candidate)
        except OSError:
            pass
        return [
            *standalone,
            home / ".codex" / "bin" / "codex.exe",
            home / ".codex" / "bin" / "codex",
            local / "Programs" / "OpenAI" / "Codex" / "bin" / "codex.exe" if str(local) else Path(),
        ]
    return []


def _binary_names_for(agent_type: str) -> list[str]:
    mapping = {
        "claude_code": ["claude"],
        "gemini_cli": ["gemini"],
        "aider": ["aider"],
        "antigravity": ["agy", "antigravity"],
        "kilo_code": ["kilocode", "kilo"],
        "grok_build": ["grok"],
        "kimi_code": ["kimi"],
        "glm_code": ["glm"],
        "codex_cli": ["codex"],
        # OpenCode is a related CLI; keep distinct from kilo_code identity.
        "opencode": ["opencode"],
        "cline": ["cline"],
        "devin_cli": ["devin"],
    }
    return mapping.get(agent_type, [agent_type.replace("_", "-")])


def _resolve_binary(agent_type: str, binary_path: str = "") -> str:
    path = (binary_path or "").strip()
    if path and Path(path).is_file():
        return path
    for candidate in _binary_names_for(agent_type):
        found = shutil.which(candidate)
        if found:
            return found
    for candidate in _known_binary_paths(agent_type):
        try:
            if candidate and candidate.is_file():
                return str(candidate)
        except Exception:
            continue
    return ""


async def check_agent_presence(
    agent_type: str,
    binary_path: str = "",
    display_name: str = "",
) -> dict[str, Any]:
    """Light presence + login probe for non-Codex agents (no long subprocess).

    Installed = runnable binary found. Auth is independent but only reported when
    installed; otherwise authentication_state is unknown (avoids "not logged in"
    for agents that simply aren't on the machine).
    """
    path = _resolve_binary(agent_type, binary_path)
    detected = bool(path)
    auth = (
        probe_authentication_state(agent_type, path)
        if detected
        else "unknown"
    )
    return {
        "detected": detected,
        "installed": detected,
        "executable_path": path,
        "executable_version": "1.0.0" if detected else "",
        "authentication_state": auth,
        "capabilities": ["code_editing", "read_only"] if detected else [],
        "health_state": "healthy" if detected else "unhealthy",
        "health_reason": (
            None
            if detected
            else f"{display_name or agent_type} executable not found."
        ),
        "logged_in": bool(detected and auth == "authenticated"),
    }


__all__ = [
    "check_codex_health",
    "check_agent_presence",
    "probe_authentication_state",
]
