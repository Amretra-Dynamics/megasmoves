"""Connect this device's embedded operator using OpenAI's official tunnel client."""
from __future__ import annotations

import argparse
import getpass
import os
from pathlib import Path
import re
import subprocess

from megas.credential_store import WindowsDPAPICredentialStore
from megas.adapters.base import windows_subprocess_kwargs


def connect(tunnel_id: str, *, executable: Path, client: Path, prompt_key: bool = False):
    if not re.fullmatch(r"tunnel_[a-zA-Z0-9_-]{16,80}", tunnel_id):
        raise ValueError("Enter the tunnel ID from OpenAI Platform settings")
    if not executable.is_file() or not client.is_file():
        raise FileNotFoundError("MegasMoves or the official tunnel-client is missing")
    store = WindowsDPAPICredentialStore(Path.home() / ".megas" / "chatgpt-tunnel.credential")
    if prompt_key or not store.exists():
        key = getpass.getpass("OpenAI tunnel runtime API key (hidden): ").strip()
        if not key.startswith("sk-") or len(key) > 4096:
            raise ValueError("A runtime API key is required")
        store.write(key)
    environment = dict(os.environ)
    environment["MEGAS_TUNNEL_RUNTIME_KEY"] = store.read()
    # No credential in argv or configuration. The supervised child inherits it.
    command = f'"{executable.resolve()}" serve'
    args = [str(client), "runtimes", "connect", "--alias", "megasmoves-device",
            "--profile", "megasmoves-device", "--tunnel-id", tunnel_id,
            "--mcp-command", command, "--runtime-api-key", "env:MEGAS_TUNNEL_RUNTIME_KEY"]
    subprocess.run(args, env=environment, check=True, stdin=subprocess.DEVNULL,
                   timeout=60, **windows_subprocess_kwargs())
    subprocess.run([str(client), "runtimes", "status", "megasmoves-device", "--json"],
                   env=environment, check=True, stdin=subprocess.DEVNULL,
                   timeout=10, **windows_subprocess_kwargs())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tunnel-id", required=True)
    parser.add_argument("--key-prompt", action="store_true")
    parser.add_argument("--executable", type=Path, required=True)
    parser.add_argument("--client", type=Path, default=Path.home() / "AppData/Local/MegasMoves/tools/openai-tunnel/tunnel-client.exe")
    args = parser.parse_args()
    connect(args.tunnel_id, executable=args.executable, client=args.client, prompt_key=args.key_prompt)


if __name__ == "__main__":
    main()
