"""Account-scoped Telegram Desktop integration for Megas.

This adapter intentionally reuses the already-authorized Telegram Desktop process
through Windows UI Automation.  It never reads or copies Telegram tdata auth
keys.  A hash of the active multi-account window marker is persisted locally and
checked before every chat/message operation so switching Telegram accounts makes
the integration fail closed.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import validate

from .operate.windows.discovery import create_backend
from .operate.windows.models import ElementSelector


def _tool(name: str, description: str, properties: dict[str, Any], required: list[str],
          *, read_only: bool, open_world: bool = False) -> dict[str, Any]:
    return {
        "name": name,
        "description": description,
        "inputSchema": {
            "type": "object",
            "additionalProperties": False,
            "properties": properties,
            "required": required,
        },
        "annotations": {
            "readOnlyHint": read_only,
            "destructiveHint": False,
            "openWorldHint": open_world,
        },
    }


_TEXT = {"type": "string", "minLength": 1, "maxLength": 4000}
_LIMIT = {"type": "integer", "minimum": 1, "maximum": 100}


def tools() -> list[dict[str, Any]]:
    return [
        _tool(
            "telegram_desktop_status",
            "Check the already-signed-in Telegram Desktop capability and account lock without exposing account names.",
            {}, [], read_only=True,
        ),
        _tool(
            "telegram_desktop_bind_current_account",
            "Bind Megas to the Telegram account currently active in Telegram Desktop. Stores only a hash of the account marker; no Telegram credentials.",
            {"acknowledge": {"type": "boolean", "const": True}},
            ["acknowledge"], read_only=False,
        ),
        _tool(
            "telegram_desktop_unbind_account",
            "Remove the local Telegram account binding. Does not log out of Telegram or modify Telegram data.",
            {}, [], read_only=False,
        ),
        _tool(
            "telegram_desktop_find_chats",
            "Search the bound Telegram Desktop account for chats/groups and return bounded visible matches.",
            {"query": _TEXT, "limit": _LIMIT}, ["query"], read_only=True,
        ),
        _tool(
            "telegram_desktop_open_chat",
            "Open one exact chat/group in the bound Telegram Desktop account using its existing signed-in session.",
            {"chat": _TEXT}, ["chat"], read_only=False,
        ),
        _tool(
            "telegram_desktop_topics",
            "Open a bound-account chat/group and list visible Telegram forum topics when the Desktop accessibility tree exposes a forum/topic view.",
            {"chat": _TEXT, "limit": _LIMIT}, ["chat"], read_only=True,
        ),
        _tool(
            "telegram_desktop_read_visible",
            "Read a bounded set of currently rendered messages from a chat, optionally after opening an exact forum topic.",
            {"chat": _TEXT, "topic": _TEXT, "limit": _LIMIT}, ["chat"], read_only=True,
        ),
        _tool(
            "telegram_desktop_draft",
            "Put text in the composer of a bound-account chat/topic without sending it.",
            {"chat": _TEXT, "topic": _TEXT, "text": {"type": "string", "minLength": 1, "maxLength": 20000}},
            ["chat", "text"], read_only=False,
        ),
        _tool(
            "telegram_desktop_send",
            "Send a message from the bound Telegram Desktop account. confirm_send must be true.",
            {
                "chat": _TEXT,
                "topic": _TEXT,
                "text": {"type": "string", "minLength": 1, "maxLength": 20000},
                "confirm_send": {"type": "boolean", "const": True},
            },
            ["chat", "text", "confirm_send"], read_only=False, open_world=True,
        ),
    ]


def _result(value: dict[str, Any]) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": json.dumps(value, ensure_ascii=False)}],
        "structuredContent": value,
        "isError": False,
    }


class TelegramDesktopIntegration:
    def __init__(
        self,
        home: str | Path | None = None,
        *,
        backend_factory: Callable[[], Any] | None = None,
    ) -> None:
        configured = os.getenv("MEGAS_HOME")
        self.home = Path(home or configured or (Path.home() / ".megas")).expanduser()
        self.state_path = self.home / "telegram_desktop.json"
        self.backend_factory = backend_factory or create_backend

    @staticmethod
    def _clean(value: str) -> str:
        return value.replace("\u200e", "").replace("\u200f", "").strip()

    @classmethod
    def _account_marker(cls, title: str) -> str | None:
        title = cls._clean(title)
        if " @ " not in title:
            return None
        marker = cls._clean(title.rsplit(" @ ", 1)[1])
        return marker or None

    @staticmethod
    def _marker_hash(marker: str) -> str:
        return hashlib.sha256(marker.casefold().encode("utf-8")).hexdigest()

    def _load_state(self) -> dict[str, Any]:
        if not self.state_path.exists():
            return {"version": 1}
        value = json.loads(self.state_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or value.get("version") != 1:
            raise RuntimeError("invalid Telegram Desktop binding state")
        return value

    def _save_state(self, value: dict[str, Any]) -> None:
        self.home.mkdir(parents=True, exist_ok=True)
        temp = self.state_path.with_suffix(".tmp")
        temp.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
        temp.replace(self.state_path)

    def _backend_and_window(self):
        backend = self.backend_factory()
        windows = [
            w for w in backend.list_windows()
            if (getattr(w, "executable", None) or "").lower() == "telegram.exe"
        ]
        if not windows:
            raise RuntimeError("Telegram Desktop is not running")
        visible = [w for w in windows if getattr(w, "is_visible", True)]
        return backend, (visible[0] if visible else windows[0])

    def _guard(self):
        backend, window = self._backend_and_window()
        state = self._load_state()
        expected = state.get("account_hash")
        if not expected:
            raise PermissionError(
                "Telegram account is not bound. Activate the intended Telegram account and bind current account first."
            )
        marker = self._account_marker(window.title)
        if not marker:
            raise PermissionError("Cannot verify the active Telegram account marker; refusing access.")
        if self._marker_hash(marker) != expected:
            raise PermissionError("Active Telegram account does not match the bound account; refusing access.")
        return backend, window

    @staticmethod
    def _invoke(backend, element) -> None:
        if "Invoke" in (element.patterns or []):
            backend.invoke(element.element_id)
        elif "SelectionItem" in (element.patterns or []):
            backend.select_item(element.element_id)
        else:
            backend.focus(element.element_id)

    @staticmethod
    def _visible_name(name: str | None) -> str:
        return (name or "").replace("\u200e", "").replace("\u200f", "").strip()

    def _tree(self, backend, window, limit: int = 900) -> list[dict[str, Any]]:
        return backend.accessibility_tree(window, max_nodes=limit)

    def _search_field(self, backend, window):
        candidates = backend.find_elements(window, ElementSelector(name="Search", control_type="Edit"))
        if not candidates:
            raise RuntimeError("Telegram global Search field is not available")
        # Prefer the outer Value-only field over its Text child.
        return sorted(candidates, key=lambda e: ("Text" in (e.patterns or []), len(e.automation_id or "")))[0]

    def _composer(self, backend, window):
        candidates = backend.find_elements(window, ElementSelector(name="Write a message...", control_type="Edit"))
        if not candidates:
            raise RuntimeError("Telegram message composer is not available in the current chat")
        return sorted(candidates, key=lambda e: ("Text" in (e.patterns or []), len(e.automation_id or "")))[0]

    @classmethod
    def _name_matches(cls, actual: str | None, wanted: str) -> bool:
        a = cls._visible_name(actual).casefold()
        w = cls._visible_name(wanted).casefold()
        return a == w or a.startswith(w + "\n") or a.startswith(w + " ")

    def _find_chat_matches(self, backend, window, query: str, limit: int) -> list[dict[str, Any]]:
        field = self._search_field(backend, window)
        backend.set_value(field.element_id, query)
        time.sleep(0.35)
        tree = self._tree(backend, window)
        found: list[dict[str, Any]] = []
        seen: set[str] = set()
        for node in tree:
            if node.get("control_type") not in {"ListItem", "DataItem"}:
                continue
            bounds = node.get("bounds") or {}
            if bounds and float(bounds.get("left", 9999)) > 340:
                continue
            name = self._visible_name(node.get("name"))
            if not name or query.casefold() not in name.casefold():
                continue
            if name in seen:
                continue
            seen.add(name)
            found.append({"name": name, "control_type": node.get("control_type")})
            if len(found) >= limit:
                break
        return found

    def _open_chat(self, backend, window, chat: str) -> None:
        field = self._search_field(backend, window)
        backend.set_value(field.element_id, chat)
        time.sleep(0.35)
        tree = self._tree(backend, window)
        chosen = None
        for node in tree:
            if node.get("control_type") not in {"ListItem", "DataItem"}:
                continue
            bounds = node.get("bounds") or {}
            if bounds and float(bounds.get("left", 9999)) > 340:
                continue
            if self._name_matches(node.get("name"), chat):
                chosen = node
                break
        if chosen is None:
            raise LookupError(f"Telegram chat not found: {chat}")
        element = backend.get_element(chosen["element_id"])
        if element is None:
            raise RuntimeError("Telegram chat result became stale")
        self._invoke(backend, element)
        time.sleep(0.25)

    def _open_topic(self, backend, window, topic: str) -> None:
        tree = self._tree(backend, window)
        for node in tree:
            if node.get("control_type") not in {"ListItem", "DataItem"}:
                continue
            if self._name_matches(node.get("name"), topic):
                element = backend.get_element(node["element_id"])
                if element is None:
                    continue
                self._invoke(backend, element)
                time.sleep(0.2)
                return
        raise LookupError(f"Visible Telegram forum topic not found: {topic}")

    def _visible_messages(self, backend, window, limit: int) -> list[str]:
        tree = self._tree(backend, window)
        messages: list[str] = []
        seen: set[str] = set()
        for node in tree:
            if node.get("control_type") not in {"DataItem", "ListItem"}:
                continue
            bounds = node.get("bounds") or {}
            if not bounds:
                continue
            left = float(bounds.get("left", 0))
            top = float(bounds.get("top", -1))
            height = float(bounds.get("height", 0))
            if left < 320 or top < 70 or top > 1030 or height <= 0:
                continue
            name = self._visible_name(node.get("name"))
            if not name or name in seen:
                continue
            # Avoid obvious navigation controls accidentally represented as list items.
            if name in {"Search", "Info", "Chat menu", "Main menu"}:
                continue
            seen.add(name)
            messages.append(name)
        return messages[-limit:]

    def status(self) -> dict[str, Any]:
        try:
            backend, window = self._backend_and_window()
            marker = self._account_marker(window.title)
            uia_ready = True
            try:
                node_count = len(self._tree(backend, window, 40))
            except Exception:
                uia_ready = False
                node_count = 0
        except Exception as exc:
            return {
                "telegram_running": False,
                "uia_ready": False,
                "bound": bool(self._load_state().get("account_hash")),
                "error": str(exc),
            }
        state = self._load_state()
        expected = state.get("account_hash")
        matches = bool(expected and marker and self._marker_hash(marker) == expected)
        local = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        tdata = local / "Packages" / "TelegramMessengerLLP.TelegramDesktop_t4vj0pshhgkwm" / "LocalCache" / "Roaming" / "Telegram Desktop UWP" / "tdata"
        return {
            "telegram_running": True,
            "uia_ready": uia_ready,
            "uia_sample_nodes": node_count,
            "existing_login_store_present": tdata.exists(),
            "account_marker_available": marker is not None,
            "bound": bool(expected),
            "bound_matches_active": matches if expected else None,
            "requires_new_telegram_login": False,
        }

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        spec = next((s for s in tools() if s["name"] == name), None)
        if spec is None:
            raise ValueError("unknown Telegram Desktop operation")
        validate(arguments, spec["inputSchema"])

        if name == "telegram_desktop_status":
            return _result(self.status())

        if name == "telegram_desktop_bind_current_account":
            _backend, window = self._backend_and_window()
            marker = self._account_marker(window.title)
            if not marker:
                raise RuntimeError("Telegram does not expose a verifiable active-account marker in the window title")
            state = {
                "version": 1,
                "account_hash": self._marker_hash(marker),
                "bound_at": datetime.now(timezone.utc).isoformat(),
                "source": "telegram-desktop-window-marker",
            }
            self._save_state(state)
            return _result({"bound": True, "verified": True, "account_name_stored": False})

        if name == "telegram_desktop_unbind_account":
            if self.state_path.exists():
                self.state_path.unlink()
            return _result({"bound": False})

        backend, window = self._guard()
        if name == "telegram_desktop_find_chats":
            limit = int(arguments.get("limit", 20))
            return _result({"matches": self._find_chat_matches(backend, window, arguments["query"], limit)})

        if name == "telegram_desktop_open_chat":
            self._open_chat(backend, window, arguments["chat"])
            return _result({"opened": True, "chat": arguments["chat"], "account_verified": True})

        if name == "telegram_desktop_topics":
            self._open_chat(backend, window, arguments["chat"])
            tree = self._tree(backend, window)
            limit = int(arguments.get("limit", 50))
            topics: list[str] = []
            seen: set[str] = set()
            for node in tree:
                aid = str(node.get("automation_id") or "")
                if "Forum" not in aid and "Topic" not in aid:
                    continue
                if node.get("control_type") not in {"ListItem", "DataItem", "Button"}:
                    continue
                value = self._visible_name(node.get("name"))
                if value and value not in seen:
                    seen.add(value)
                    topics.append(value)
                    if len(topics) >= limit:
                        break
            return _result({
                "chat": arguments["chat"],
                "topics": topics,
                "topic_semantics_detected": bool(topics),
                "note": None if topics else "No forum/topic semantic controls are currently rendered; the chat may not be a forum or topics may need to be opened.",
            })

        if name == "telegram_desktop_read_visible":
            self._open_chat(backend, window, arguments["chat"])
            topic = arguments.get("topic")
            if topic:
                self._open_topic(backend, window, topic)
            messages = self._visible_messages(backend, window, int(arguments.get("limit", 40)))
            return _result({"chat": arguments["chat"], "topic": topic, "messages": messages, "account_verified": True})

        if name in {"telegram_desktop_draft", "telegram_desktop_send"}:
            self._open_chat(backend, window, arguments["chat"])
            topic = arguments.get("topic")
            if topic:
                self._open_topic(backend, window, topic)
            composer = self._composer(backend, window)
            backend.set_value(composer.element_id, arguments["text"])
            time.sleep(0.15)
            if name == "telegram_desktop_draft":
                return _result({"drafted": True, "sent": False, "chat": arguments["chat"], "topic": topic})
            # Re-verify account after navigating and immediately before the irreversible send.
            self._guard()
            send = backend.find_elements(window, ElementSelector(name="Send", control_type="Button"))
            if not send:
                raise RuntimeError("Telegram Send button is not available after composing the message")
            self._invoke(backend, send[0])
            return _result({"sent": True, "chat": arguments["chat"], "topic": topic, "account_verified": True})

        raise ValueError("unknown Telegram Desktop operation")
