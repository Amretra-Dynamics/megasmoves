"""Provider-neutral conversation identity and capability contracts.

Provider adapters may populate these records from any storage or runtime.  The core
does not assume SQLite, Projects, Desktop/CLI surfaces, exact resume, or child imports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, Sequence


@dataclass(frozen=True)
class ProviderCapabilities:
    """Explicit provider abilities; ``False`` means unsupported, not unavailable."""

    history_discovery: bool = False
    message_read: bool = False
    project_metadata: bool = False
    lineage_metadata: bool = False
    create_conversation: bool = False
    exact_resume: bool = False
    import_conversation: bool = False
    interactive_runtime: bool = False
    headless_runtime: bool = False
    streaming: bool = False
    cancellation: bool = False
    restart_recovery: bool = False


class ConversationProviderAdapter(Protocol):
    """Boundary consumed by the shared thread service.

    Concrete adapters may implement only the capabilities their provider supports;
    unsupported operations must return an explicit degraded/unsupported result.
    """

    provider_id: str

    def provider_capabilities(self) -> ProviderCapabilities: ...

    def discover_threads(self) -> Sequence[Mapping[str, Any]]: ...

    def read_thread(self, native_id: str) -> Mapping[str, Any] | None: ...

    def continue_thread(self, native_id: str, prompt: str) -> Mapping[str, Any]: ...


@dataclass(frozen=True)
class NativeConversationIdentity:
    """One provider-native identity, independent of how the provider stores it."""

    provider: str
    native_id: str
    provider_installation_id: str = ""
    account_id: str = ""
    source_surface: str = ""
    source_system: str = ""
    worker_id: str = ""
    parent_native_id: str = ""
    lineage_class: str = ""


@dataclass
class LogicalThread:
    """Canonical Megas thread projection containing one or more native identities."""

    logical_thread_id: str
    owner_email: str = ""
    provider: str = ""
    provider_installation_id: str = ""
    source_system: str = ""
    worker_id: str = ""
    native_identities: list[NativeConversationIdentity] = field(default_factory=list)
    current_execution_native_id: str = ""
    project_scope: str = ""
    project_id: str = ""
    project_label: str = ""
    workspace_uris: list[str] = field(default_factory=list)
    continuation_status: str = "unknown"
    continuation_capability: str = "unknown"
    synchronization_status: str = "unknown"

    @classmethod
    def from_provider_record(
        cls,
        record: Mapping[str, Any],
        *,
        logical_thread_id: str | None = None,
        owner_email: str = "",
        worker_id: str = "",
    ) -> "LogicalThread":
        """Build the core projection without interpreting provider-specific fields."""
        native_id = str(record.get("native_id") or "").strip()
        meta = record.get("metadata_json") or {}
        if isinstance(meta, str):
            import json
            try:
                meta = json.loads(meta)
            except Exception:
                meta = {}
        if not isinstance(meta, dict):
            meta = {}
        identity = NativeConversationIdentity(
            provider=str(record.get("agent_type") or record.get("provider") or "").strip(),
            native_id=native_id,
            provider_installation_id=str(meta.get("provider_installation_id") or ""),
            account_id=str(meta.get("account_id") or ""),
            source_surface=str(meta.get("source_surface") or ""),
            source_system=str(meta.get("source_system") or ""),
            worker_id=worker_id,
            parent_native_id=str(meta.get("parent_native_id") or ""),
            lineage_class=str(meta.get("lineage_class") or ""),
        )
        workspace = meta.get("workspace_uris") or meta.get("project_folders") or []
        if isinstance(workspace, str):
            workspace = [workspace]
        return cls(
            logical_thread_id=logical_thread_id or native_id,
            owner_email=owner_email,
            provider=identity.provider,
            provider_installation_id=identity.provider_installation_id,
            source_system=identity.source_system,
            worker_id=worker_id,
            native_identities=[identity] if native_id else [],
            current_execution_native_id=str(meta.get("execution_native_id") or native_id),
            project_scope=str(meta.get("provider_scope") or meta.get("project_scope") or ""),
            project_id=str(meta.get("project_id") or ""),
            project_label=str(meta.get("project_label") or ""),
            workspace_uris=[str(x) for x in workspace if str(x).strip()],
            continuation_status=str(meta.get("continuation_status") or "unknown"),
            continuation_capability=str(meta.get("continuation_capability") or "unknown"),
            synchronization_status=str(meta.get("synchronization_status") or "unknown"),
        )
