"""Evidence-bound coding-provider limit state.

Provider stderr may prove that a limit was reached, but an unrelated successful
command does not prove that the account reset. Recovery is emitted only from a
provider-native quota snapshot (or another future source carrying equivalent
structured evidence).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _percent(value: object) -> int | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return max(0, min(100, int(round(number))))


def _iso_from_unix(value: object) -> str | None:
    try:
        timestamp = float(value)
    except (TypeError, ValueError):
        return None
    if timestamp <= 0:
        return None
    try:
        return datetime.fromtimestamp(
            timestamp,
            tz=timezone.utc,
        ).isoformat()
    except (OverflowError, OSError, ValueError):
        return None


def normalize_codex_rate_limits(
    value: object,
    *,
    method: str = "account/rateLimits/updated",
) -> dict[str, Any] | None:
    """Project the official Codex app-server quota shape into safe state.

    The official contract reports usage as ``usedPercent``. Megas sends the
    smallest remaining percentage across returned windows because that is the
    effective account constraint. Missing windows stay missing; they are never
    invented as 100%.
    """

    root = value if isinstance(value, dict) else {}
    rate_limits = (
        root.get("rateLimits")
        if isinstance(root.get("rateLimits"), dict)
        else root
    )
    if not isinstance(rate_limits, dict):
        return None

    windows: list[dict[str, Any]] = []
    remaining_values: list[int] = []
    reset_values: list[tuple[int, str]] = []
    for name in ("primary", "secondary"):
        raw = rate_limits.get(name)
        if not isinstance(raw, dict):
            continue
        used = _percent(raw.get("usedPercent"))
        remaining = 100 - used if used is not None else None
        resets_at = _iso_from_unix(raw.get("resetsAt"))
        window: dict[str, Any] = {"name": name}
        if used is not None:
            window["used_percent"] = used
            window["remaining_percent"] = remaining
            remaining_values.append(remaining)
        try:
            duration = int(raw.get("windowDurationMins"))
        except (TypeError, ValueError):
            duration = 0
        if duration > 0:
            window["window_duration_minutes"] = duration
        if resets_at:
            window["resets_at"] = resets_at
            if remaining is not None:
                reset_values.append((remaining, resets_at))
        windows.append(window)

    reached_type = str(
        rate_limits.get("rateLimitReachedType") or ""
    ).strip()
    remaining = min(remaining_values) if remaining_values else None
    limited = bool(reached_type) or remaining == 0
    expected_available_at = None
    if reset_values:
        # Prefer the reset time belonging to the most constrained window.
        expected_available_at = sorted(reset_values, key=lambda item: item[0])[0][1]

    if not windows and not reached_type:
        return None

    payload: dict[str, Any] = {
        "agent_type": "codex_cli",
        "limit_status": "limited" if limited else "available",
        "provider_observed": True,
        "evidence_source": "codex_app_server",
        "evidence_method": method,
        "observed_at": _utc_now(),
        "windows": windows,
    }
    if remaining is not None:
        payload["remaining_percent"] = remaining
    if expected_available_at:
        payload["expected_available_at"] = expected_available_at
    if reached_type:
        payload["code"] = reached_type[:120]
        payload["kind"] = "usage_limit"
    return payload


@dataclass(frozen=True)
class LimitTransition:
    event_type: str | None
    payload: dict[str, Any]


class EvidenceBoundLimitStateStore(dict[str, dict[str, Any]]):
    """Dict-compatible state store that blocks success-based fake recovery.

    Legacy Worker code writes parsed provider errors with normal ``dict`` syntax
    and calls ``pop`` after any successful command. ``pop`` is deliberately a
    no-op here. Only :meth:`observe_provider_snapshot` may remove a limit and
    emit a recovery transition.
    """

    def __setitem__(self, key: str, value: dict[str, Any]) -> None:
        payload = dict(value or {})
        payload.setdefault("agent_type", str(key))
        payload.setdefault("limit_status", "limited")
        payload.setdefault("provider_observed", False)
        payload.setdefault("evidence_source", "provider_error")
        payload.setdefault("observed_at", _utc_now())
        dict.__setitem__(self, str(key), payload)

    def pop(self, key: str, default: Any = None) -> Any:
        # A successful turn proves only that this one request succeeded. It does
        # not prove a quota reset or a restored percentage.
        return default

    def observe_provider_snapshot(
        self,
        agent_type: str,
        snapshot: dict[str, Any],
    ) -> LimitTransition:
        agent = str(agent_type or "").strip()
        payload = dict(snapshot or {})
        payload["agent_type"] = agent
        payload["provider_observed"] = True
        payload.setdefault("observed_at", _utc_now())
        previous = dict.get(self, agent)
        was_limited = bool(previous) and str(
            previous.get("limit_status") or "limited"
        ) in {"limited", "retry_available"}
        is_limited = str(payload.get("limit_status") or "") == "limited"

        if is_limited:
            dict.__setitem__(self, agent, payload)
            payload.setdefault("kind", "usage_limit")
            payload.setdefault(
                "message",
                "Codex provider reports that its usage limit is reached.",
            )
            return LimitTransition(
                "agent_limit_reached" if not was_limited else None,
                payload,
            )

        # Available snapshots clear prior state because the provider itself,
        # not a successful task heuristic, reported the transition.
        if agent in self:
            dict.pop(self, agent, None)
        if was_limited:
            remaining = _percent(payload.get("remaining_percent"))
            if remaining is not None:
                payload["remaining_percent"] = remaining
                if remaining == 100:
                    payload["reset_to_percent"] = 100
            payload["limit_status"] = "available"
            payload.setdefault(
                "message",
                "Codex provider reports that usage is available again.",
            )
            return LimitTransition("agent_limit_recovered", payload)
        return LimitTransition(None, payload)


def heartbeat_snapshot_for_transition(
    transition: LimitTransition,
) -> dict[str, Any]:
    """Return the provider snapshot shape consumed by backend heartbeat.

    A provider-observed recovery is published once as ``retry_available`` so
    the existing backend transition detector sends Android a single exact reset
    notification. The next provider poll returns ordinary ``available`` and
    therefore cannot repeat that notification.
    """

    payload = dict(transition.payload)
    if transition.event_type == "agent_limit_recovered":
        payload["limit_status"] = "retry_available"
        payload["transition_event"] = "agent_limit_recovered"
    return payload


def heartbeat_snapshot_after_durable_event(
    transition: LimitTransition,
) -> dict[str, Any]:
    """Avoid a duplicate heartbeat reset after an in-session recovery event.

    When an active coding session already emits ``agent_limit_recovered`` into
    the durable event stream, Android receives that notification through the
    session pipeline. Heartbeat therefore carries ordinary ``available`` for
    the same observation. Proactive background polls still use
    :func:`heartbeat_snapshot_for_transition` to create their one-shot reset.
    """

    if transition.event_type == "agent_limit_recovered":
        return dict(transition.payload)
    return heartbeat_snapshot_for_transition(transition)


def project_limit_snapshots_into_health(
    agents_health: dict[str, Any],
    snapshots: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Overlay provider evidence and suppress timer-inferred reset claims."""

    for raw_agent, raw_health in list(agents_health.items()):
        if not isinstance(raw_health, dict):
            continue
        if (
            str(raw_health.get("limit_status") or "") == "retry_available"
            and not bool(raw_health.get("provider_observed"))
        ):
            raw_health["limit_status"] = "limited"
            raw_health["retry_window_open"] = True
            raw_health.pop("reset_to_percent", None)

    for raw_agent, raw_snapshot in snapshots.items():
        agent = str(raw_agent or "").strip()
        if not agent or not isinstance(raw_snapshot, Mapping):
            continue
        health = agents_health.get(agent)
        if not isinstance(health, dict):
            health = {
                "agent_id": agent,
                "agent_type": agent,
            }
        for key, value in raw_snapshot.items():
            if key in {
                "agent_type",
                "limit_status",
                "provider_observed",
                "evidence_source",
                "evidence_method",
                "observed_at",
                "expected_available_at",
                "remaining_percent",
                "reset_to_percent",
                "retry_after_seconds",
                "transition_event",
                "code",
                "kind",
                "message",
                "windows",
            }:
                health[key] = value
        health["agent_type"] = agent
        agents_health[agent] = health
    return agents_health
