"""Bounded, read-only discovery of selected startup Python imports.

Do not execute repository files, install dependencies, or mutate environments.
Check module imports with the exact executable selected by the workspace command.
These are *startup probes*, not a full dependency resolver.
"""
from __future__ import annotations

import ast
import re
import tomllib
from pathlib import Path
from typing import Sequence

MAX_DECLARATION_BYTES = 512 * 1024
MAX_ENTRYPOINT_BYTES = 1024 * 1024
REVIEWED_IMPORTS = {
    "fastapi": "fastapi",
    "pydantic-settings": "pydantic_settings",
    "uvicorn": "uvicorn",
}
_REVIEWED_MODULES = frozenset(REVIEWED_IMPORTS.values())
_ENTRYPOINT = re.compile(r"^[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*$", re.ASCII)
_PACKAGE = re.compile(r"^([a-zA-Z][a-zA-Z0-9._-]*)\s*(?=\[|[<>=!~; ]|$)")


def _package_name(specification: str) -> str | None:
    match = _PACKAGE.match(specification.strip())
    return match.group(1).lower().replace("_", "-").replace(".", "-") if match else None


def _bounded_read(path: Path, *, limit: int = MAX_DECLARATION_BYTES,
                  kind: str = "dependency declaration") -> str:
    with path.open("rb") as handle:
        raw = handle.read(limit + 1)
    if len(raw) > limit:
        raise ValueError(f"Python {kind} exceeds allowed size")
    return raw.decode("utf-8")


def reviewed_python_startup_imports(directory: Path) -> tuple[str, ...]:
    """Find declared imports using a fixed reviewed mapping, never arbitrary code."""
    packages: set[str] = set()
    requirements = directory / "requirements.txt"
    if requirements.is_file():
        for line in _bounded_read(requirements).splitlines():
            declaration = line.split("#", 1)[0].strip()
            if declaration and not declaration.startswith("-"):
                name = _package_name(declaration)
                if name:
                    packages.add(name)
    pyproject = directory / "pyproject.toml"
    if pyproject.is_file():
        data = tomllib.loads(_bounded_read(pyproject))
        declarations = data.get("project", {}).get("dependencies", [])
        if isinstance(declarations, list):
            for item in declarations:
                if isinstance(item, str):
                    name = _package_name(item)
                    if name:
                        packages.add(name)
    return tuple(REVIEWED_IMPORTS[package] for package in sorted(packages) if package in REVIEWED_IMPORTS)


def reviewed_python_entrypoint_imports(directory: Path, command: Sequence[str]) -> tuple[str, ...]:
    """Statically inspect reviewed direct imports of a local uvicorn entrypoint.

    Source is bounded and parsed as an AST. Nothing from the source is executed.
    Only modules from the fixed reviewed import catalog are returned.
    """
    if len(command) < 4 or list(command[1:3]) != ["-m", "uvicorn"]:
        return ()
    module = command[3].split(":", 1)[0]
    if not _ENTRYPOINT.fullmatch(module):
        return ()
    root = directory.resolve()
    entrypoint = root.joinpath(*module.split(".")).with_suffix(".py").resolve()
    if not entrypoint.is_relative_to(root):
        raise ValueError("Python entrypoint must remain inside the trusted project")
    if not entrypoint.is_file():
        return ()
    tree = ast.parse(_bounded_read(entrypoint, limit=MAX_ENTRYPOINT_BYTES,
                                   kind="entrypoint source"), filename=str(entrypoint))
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names = (alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names = (node.module,)
        else:
            continue
        for name in names:
            root_module = name.split(".", 1)[0]
            if root_module in _REVIEWED_MODULES:
                found.add(root_module)
    return tuple(sorted(found))
