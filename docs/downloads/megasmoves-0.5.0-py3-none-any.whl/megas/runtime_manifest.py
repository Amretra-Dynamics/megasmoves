from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from importlib import metadata
import os
from pathlib import Path
import platform
import shutil
import sys
from typing import Any

from .adapter_certification import (
    CertificationDecision,
    adapter_authentication_identity,
    certificate_summary,
    installation_identity,
    load_installation_certificate,
)
from .config import WorkerConfig
from .operate.gate import is_operate_enabled
from .operate.windows.capability import build_capability_reports
from .operate.browser.capability import browser_capability_report


RUNTIME_MANIFEST_SCHEMA = "megas.worker-runtime.v1"
WORKER_PROTOCOL_VERSION = 1

# Recognized product agent IDs. Gemini CLI is intentionally absent: Google
# requests are canonicalized to the Antigravity adapter by agent_catalog.
AGENT_TYPES = {
    "aider",
    "antigravity",
    "claude_code",
    "codex_cli",
    "cursor_cli",
    "jules_cli",
    "kilo_code",
    "kiro_code",
    "grok_build",
    "kimi_code",
    "glm_code",
    "opencode",
    "cline",
    "devin_cli",
}

BUILTIN_ROUTING_CAPABILITIES = {
    "heartbeat",
    "session_events",
    "evidence",
    "custom_shell",
    "safe_shell_command",
    "git",
    "terminal",
    "create_commit",
    "create_draft_pr",
    "branch_cleanup",
    "runtime_refresh",
    "checkpoint",
    "network",
    "megas_context_file",
}


def _agent_adapter_classes() -> dict[str, type]:
    from .adapters.aider import AiderAdapter
    from .adapters.antigravity import AntigravityAdapter
    from .adapters.claude import ClaudeCodeAdapter
    from .adapters.cline import ClineAdapter
    from .adapters.codex import CodexCliAdapter
    from .adapters.cursor import CursorCliAdapter
    from .adapters.devin import DevinCliAdapter
    from .adapters.grok_build import GrokBuildAdapter
    from .adapters.jules import JulesCliAdapter
    from .adapters.kilo import KiloCodeAdapter
    from .adapters.kiro import KiroCodeAdapter
    from .adapters.opencode import OpenCodeAdapter

    return {
        "aider": AiderAdapter,
        "antigravity": AntigravityAdapter,
        "claude_code": ClaudeCodeAdapter,
        "codex_cli": CodexCliAdapter,
        "cursor_cli": CursorCliAdapter,
        "jules_cli": JulesCliAdapter,
        "kilo_code": KiloCodeAdapter,
        "kiro_code": KiroCodeAdapter,
        "grok_build": GrokBuildAdapter,
        "opencode": OpenCodeAdapter,
        "cline": ClineAdapter,
        "devin_cli": DevinCliAdapter,
    }


def _worker_version() -> str:
    from . import __version__

    return __version__


def _host_platform_block() -> dict[str, Any]:
    try:
        from .host_environment import build_host_platform

        return build_host_platform()
    except Exception:
        return {
            "system": platform.system(),
            "release": platform.release(),
            "architecture": platform.machine(),
            "os_family": "unknown",
            "os_label": platform.system() or "Unknown OS",
            "display": platform.system() or "Unknown OS",
            "environment": "native",
            "wsl": False,
            "distro_id": "",
            "distro_name": "",
            "distro_version": "",
            "shell": "",
            "shell_label": "",
            "python_implementation": platform.python_implementation(),
        }


def _distribution_version() -> str | None:
    if bool(getattr(sys, "frozen", False)):
        return _worker_version()
    try:
        return metadata.version("megas")
    except metadata.PackageNotFoundError:
        return None


def _auth_mode(agent_id: str, adapter: object) -> str:
    env_modes: dict[str, tuple[str, ...]] = {
        "codex_cli": ("OPENAI_API_KEY", "CODEX_API_KEY"),
        "claude_code": ("ANTHROPIC_API_KEY",),
        "cursor_cli": ("CURSOR_API_KEY",),
        "jules_cli": ("JULES_API_KEY",),
        "devin_cli": ("DEVIN_API_TOKEN", "DEVIN_API_KEY"),
        "grok_build": ("XAI_API_KEY", "GROK_API_KEY"),
        "opencode": ("OPENCODE_API_KEY",),
        "kilo_code": ("KILO_API_KEY",),
        "kiro_code": ("KIRO_API_KEY",),
        "cline": ("CLINE_API_KEY",),
        "aider": ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY", "DEEPSEEK_API_KEY"),
    }
    if any(os.getenv(name, "").strip() for name in env_modes.get(agent_id, ())):
        return "api_key"
    try:
        if bool(getattr(adapter, "is_authenticated")()):
            return "account"
    except Exception:
        pass
    return "unauthenticated"


def _certification_for(
    *,
    agent_id: str,
    adapter: object,
    executable: Path | str,
    version: str,
    auth_mode: str,
    execution_mode: str,
) -> CertificationDecision:
    explicit_identity = adapter_authentication_identity(adapter)
    identity = installation_identity(
        provider_id=agent_id,
        executable=executable,
        provider_version=version,
        adapter_contract_version=str(getattr(adapter, "contract_version", "unknown")),
        auth_mode=auth_mode,
        execution_mode=execution_mode,
        authentication_identity=explicit_identity,
    )
    _certificate, decision = load_installation_certificate(identity)
    return decision


def _agent_inventory(
    config: WorkerConfig | None = None,
) -> tuple[dict[str, dict[str, Any]], set[str]]:
    if config is not None:
        try:
            from .agent_catalog import apply_agent_env_from_config

            apply_agent_env_from_config(config)
        except Exception:
            pass

    reports: dict[str, dict[str, Any]] = {}
    certified_agents: set[str] = set()
    agents_cfg = getattr(config, "agents", None) if config is not None else None
    if not isinstance(agents_cfg, dict):
        agents_cfg = {}

    for agent_id, adapter_class in _agent_adapter_classes().items():
        entry = agents_cfg.get(agent_id) if isinstance(agents_cfg.get(agent_id), dict) else {}
        if entry.get("enabled") is False:
            reports[agent_id] = {
                "status": "unavailable",
                "version": None,
                "supported_versions": "unknown",
                "contract_version": "1.0",
                "binary": None,
                "execution_modes": [],
                "reason": "disabled_in_config",
                "certification_status": "disabled",
                "certification_reason": "disabled_in_config",
                "installation_fingerprint": None,
                "verified_capabilities": [],
                "auth_mode": "unknown",
                "execution_mode": "inspect",
            }
            continue

        try:
            adapter = adapter_class([])
            executable = adapter.discover_executable()
            if not executable:
                try:
                    from .agent_catalog import discover_binary, get_spec

                    found = discover_binary(get_spec(agent_id), config=config)
                    if found is not None:
                        executable = found
                        binary_env = str(getattr(adapter, "binary_env", "") or "")
                        if binary_env:
                            os.environ.setdefault(binary_env, str(found))
                except Exception:
                    executable = None

            version = adapter.detect_version() if executable else None
            health = str(adapter.health_status()) if executable else "unavailable"
            auth_mode = _auth_mode(agent_id, adapter)
            execution_mode = "inspect"
            base_report: dict[str, Any] = {
                "status": "unavailable",
                "version": version,
                "supported_versions": str(adapter.supported_versions()),
                "contract_version": str(adapter.contract_version),
                "binary": Path(executable).name if executable else None,
                "execution_modes": [],
                "reason": "binary_not_found" if not executable else "runtime_certification_required",
                "certification_status": "not_verified",
                "certification_reason": "runtime_certification_required",
                "installation_fingerprint": None,
                "verified_capabilities": [],
                "auth_mode": auth_mode,
                "execution_mode": execution_mode,
            }

            if not executable:
                reports[agent_id] = base_report
                continue
            if health == "quarantined":
                reports[agent_id] = {
                    **base_report,
                    "status": "quarantined",
                    "reason": "adapter_health_quarantined",
                    "certification_status": "quarantined",
                    "certification_reason": "adapter_health_quarantined",
                }
                continue
            if health != "available":
                reports[agent_id] = {
                    **base_report,
                    "status": "detected",  # Binary found but health check failed
                    "reason": f"adapter_health:{health}",
                    "certification_reason": f"adapter_health:{health}",
                }
                continue
            if not version:
                reports[agent_id] = {
                    **base_report,
                    "status": "detected",  # Binary found but version unreadable
                    "reason": "provider_version_unverified",
                    "certification_status": "not_verified",
                    "certification_reason": "provider_version_unverified",
                }
                continue
            if auth_mode == "unauthenticated":
                reports[agent_id] = {
                    **base_report,
                    "status": "detected",  # Binary found but not authenticated
                    "reason": "provider_authentication_required",
                    "certification_status": "not_verified",
                    "certification_reason": "provider_authentication_required",
                }
                continue

            decision = _certification_for(
                agent_id=agent_id,
                adapter=adapter,
                executable=executable,
                version=version,
                auth_mode=auth_mode,
                execution_mode=execution_mode,
            )
            summary = certificate_summary(decision)
            report = {
                **base_report,
                # Visibility: "detected" if binary exists and authenticated, "available" if certified
                # This matches the research report: authenticated+detected agents should be VISIBLE
                "status": "available" if decision.certified else "detected",
                "reason": decision.reason,
                "certification_status": summary["status"],
                "certification_reason": summary["reason"],
                "installation_fingerprint": summary["installation_fingerprint"],
                "verified_capabilities": summary["verified_capabilities"],
                "execution_modes": [execution_mode] if decision.certified else [],
                "certified_at": summary["issued_at"],
                "certification_expires_at": summary["expires_at"],
            }
            reports[agent_id] = report
            if decision.certified:
                certified_agents.add(agent_id)
        except Exception as exc:
            reports[agent_id] = {
                "status": "quarantined",
                "version": None,
                "supported_versions": "unknown",
                "contract_version": "unknown",
                "binary": None,
                "execution_modes": [],
                "reason": type(exc).__name__,
                "certification_status": "quarantined",
                "certification_reason": type(exc).__name__,
                "installation_fingerprint": None,
                "verified_capabilities": [],
                "auth_mode": "unknown",
                "execution_mode": "inspect",
            }
    return reports, certified_agents


def build_runtime_manifest(config: WorkerConfig) -> dict[str, Any]:
    checked_at = datetime.now(timezone.utc).isoformat()
    agents, certified_agents = _agent_inventory(config)
    operate_enabled = is_operate_enabled()

    windows_reports = build_capability_reports()
    windows_capabilities = {report.name for report in windows_reports if report.available}
    browser_report = browser_capability_report()
    browser_capabilities = (
        {"browser", "browser.playwright", f"browser.{browser_report.browser}"}
        if browser_report.available and browser_report.browser
        else set()
    )

    ssh_installed = bool(shutil.which("ssh") or shutil.which("ssh.exe"))
    ssh_capabilities: set[str] = set()
    if operate_enabled and ssh_installed:
        ssh_capabilities = {"shell.ssh", "remote.ssh"}

    routing_capabilities = sorted(
        BUILTIN_ROUTING_CAPABILITIES
        | certified_agents
        | windows_capabilities
        | browser_capabilities
        | ssh_capabilities
    )

    reports_by_name: dict[str, dict[str, Any]] = {
        name: {
            "name": name,
            "status": "available",
            "contract_version": "1.0",
            "certification_status": "builtin",
            "policy_scopes": ["local_worker"],
        }
        for name in sorted(BUILTIN_ROUTING_CAPABILITIES)
    }
    for report in windows_reports:
        reports_by_name[report.name] = {
            "name": report.name,
            "status": "available" if report.available else "unavailable",
            "contract_version": report.adapter_version,
            "certification_status": report.certification_status,
            "policy_scopes": list(report.policy_scope),
            "reasons": list(report.reasons),
        }
    for name in sorted(browser_capabilities):
        reports_by_name[name] = {
            "name": name,
            "status": "available",
            "contract_version": "1.0",
            "certification_status": "runtime_detected",
            "policy_scopes": ["local_worker", "browser_native"],
        }

    if ssh_capabilities:
        for name in sorted(ssh_capabilities):
            reports_by_name[name] = {
                "name": name,
                "status": "available",
                "contract_version": "1.0",
                "certification_status": "runtime_detected",
                "policy_scopes": ["local_worker", "ssh_client"],
                "reasons": ["OpenSSH client present and Operate enabled by owner"],
            }
    else:
        ssh_reasons = ["operate_disabled_by_owner"] if not operate_enabled else ["ssh_client_not_found"]
        for name in ("shell.ssh", "remote.ssh"):
            reports_by_name[name] = {
                "name": name,
                "status": "unavailable",
                "contract_version": "1.0",
                "certification_status": "unavailable",
                "policy_scopes": ["local_worker", "ssh_client"],
                "reasons": ssh_reasons,
            }

    if not browser_capabilities:
        reports_by_name["browser"] = {
            "name": "browser",
            "status": "unavailable",
            "contract_version": "1.0",
            "certification_status": "unavailable",
            "policy_scopes": ["local_worker", "browser_native"],
            "reasons": list(browser_report.reasons),
        }

    for agent_id, report in sorted(agents.items()):
        # ``CertificationDecision.status`` uses the local evidence state
        # ``verified``.  The Worker/backend wire contract intentionally uses
        # ``certified`` for an executable coding-agent capability.  Keep that
        # mapping at the manifest boundary so provider-local evidence terms do
        # not make a healthy agent fail backend validation and disappear from
        # the connected-agent catalogue.
        wire_certification_status = (
            "certified"
            if report.get("status") == "available"
            and report.get("certification_status") == "verified"
            else str(report.get("certification_status") or "not_verified")
        )
        report["certification_status"] = wire_certification_status
        reports_by_name[agent_id] = {
            "name": agent_id,
            "status": str(report["status"]),
            "contract_version": str(report["contract_version"]),
            "certification_status": wire_certification_status,
            "policy_scopes": ["local_worker", "coding_agent"],
            "version": report.get("version"),
            "supported_versions": report.get("supported_versions"),
            "reasons": [str(report.get("certification_reason") or report.get("reason") or "not_verified")],
            "installation_fingerprint": report.get("installation_fingerprint"),
            "verified_capabilities": list(report.get("verified_capabilities") or []),
        }
    capability_reports = [reports_by_name[name] for name in sorted(reports_by_name)]

    configured = {str(item).strip() for item in config.capabilities if str(item).strip()}
    recognized = (
        BUILTIN_ROUTING_CAPABILITIES
        | AGENT_TYPES
        | {report.name for report in windows_reports}
        | {
            "browser",
            "browser.playwright",
            "browser.chrome",
            "browser.edge",
            "shell.ssh",
            "remote.ssh",
        }
    )
    ignored = sorted(configured - recognized)
    quarantined_agents = sorted(
        agent_id for agent_id, report in agents.items() if report.get("status") == "quarantined"
    )

    reasons: list[str] = []
    if quarantined_agents and not certified_agents:
        reasons.extend(f"agent_quarantined:{agent_id}" for agent_id in quarantined_agents)
    detected_uncertified = sorted(
        agent_id
        for agent_id, report in agents.items()
        if report.get("binary") and report.get("status") == "unavailable"
    )
    if detected_uncertified and not certified_agents:
        reasons.append("no_runtime_certified_coding_agent")
    frozen = bool(getattr(sys, "frozen", False))
    distribution_version = _distribution_version()
    if frozen and distribution_version and distribution_version != _worker_version():
        reasons.append("worker_distribution_version_mismatch")
    if ignored and not certified_agents and not routing_capabilities:
        reasons.append("unrecognized_config_capabilities_ignored")
    if not certified_agents and not detected_uncertified and not reasons:
        reasons.append("no_coding_agent_available")

    return {
        "schema_version": RUNTIME_MANIFEST_SCHEMA,
        "protocol_version": WORKER_PROTOCOL_VERSION,
        "generated_at": checked_at,
        "worker": {
            "version": _worker_version(),
            "python_version": platform.python_version(),
            "frozen_binary": frozen,
        },
        "platform": _host_platform_block(),
        "capabilities": routing_capabilities,
        "capability_reports": capability_reports,
        "products": {
            "operate": {"enabled": operate_enabled, "enable_command": "megas operate enable"},
            "security": {"availability": "waitlist", "operational": False},
        },
        "agents": agents,
        "workspace_policy": {
            "allowed_root_count": len(config.allowed_folders),
            "configured": bool(config.allowed_folders),
        },
        "health": {
            "status": "degraded" if reasons else "healthy",
            "reasons": reasons,
            "checked_at": checked_at,
        },
    }


def runtime_capabilities_from_manifest(manifest: dict[str, Any]) -> list[str]:
    capabilities = manifest.get("capabilities")
    if not isinstance(capabilities, list):
        return []
    return [str(item) for item in capabilities]


def local_certification_details(config: WorkerConfig) -> dict[str, Any]:
    """Local-only diagnostics may include richer native capability details."""
    manifest = build_runtime_manifest(config)
    manifest["windows"] = [asdict(report) for report in build_capability_reports()]
    manifest["environment"] = {"operating_system": os.name}
    return manifest
