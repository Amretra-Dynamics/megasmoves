from __future__ import annotations

import json
from typing import Any

from jsonschema import Draft202012Validator

from .chitraagni_operator import _compact, _tool, _uuid
from .chitraagni_operator_extended import FullChitraagniOperatorCatalog


def _object_or_null() -> dict[str, Any]:
    return {"type": ["object", "null"]}


def _array() -> dict[str, Any]:
    return {"type": "array"}


def _confirm_property() -> dict[str, Any]:
    return {"type": "boolean", "const": True}


COMPLETE_TOOLS: list[dict[str, Any]] = [
    _tool(
        "chitraagni_account_context",
        "Read the linked user's Chitraagni identity plus the complete authorized workspace/project/product index in one call.",
        {},
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_context",
        "Read a broad AI-ready snapshot of one authorized Chitraagni Project: products, current screens, schemas, workflows, versions, design system, product-scoped screens/R5 state, and optional quality/codegen/history snapshots.",
        {
            "project_id": {"type": "string"},
            "include_quality": {"type": "boolean", "default": True},
            "include_codegen": {"type": "boolean", "default": False},
            "include_version_snapshots": {"type": "boolean", "default": False},
            "max_products": {"type": "integer", "minimum": 1, "maximum": 100, "default": 50},
            "max_versions": {"type": "integer", "minimum": 1, "maximum": 100, "default": 50},
        },
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_product_context",
        "Read an AI-ready Product context: Product memory, parent Project, Product-scoped screens, R5 collaboration state, schemas, workflows, versions, design system, and optional quality/codegen.",
        {
            "product_id": {"type": "string"},
            "include_quality": {"type": "boolean", "default": True},
            "include_codegen": {"type": "boolean", "default": False},
        },
        ["product_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_quality",
        "Read the deterministic Chitraagni quality report for an authorized Project/current or explicit version.",
        {
            "project_id": {"type": "string"},
            "version_id": {"type": ["string", "null"]},
        },
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_codegen_react_next",
        "Read the deterministic React/Next code bundle generated from an authorized Chitraagni Project/current or explicit version.",
        {
            "project_id": {"type": "string"},
            "version_id": {"type": ["string", "null"]},
        },
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_design_token_sets_list",
        "List current-version design token sets for one authorized Project.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_design_token_set_get",
        "Read one authorized design token set.",
        {"token_set_id": {"type": "string"}},
        ["token_set_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_design_token_set_create",
        "Create one design token set in an authorized Project's current version.",
        {
            "project_id": {"type": "string"},
            "token_set_key": {"type": "string"},
            "name": {"type": "string"},
            "description": {"type": "string"},
            "tokens_json": _array(),
            "modes_json": {"type": "object"},
            "metadata_json": {"type": "object"},
        },
        ["project_id", "token_set_key", "name"],
    ),
    _tool(
        "chitraagni_design_token_set_update",
        "Update explicit fields on one current-version design token set.",
        {
            "token_set_id": {"type": "string"},
            "token_set_key": {"type": "string"},
            "name": {"type": "string"},
            "description": {"type": "string"},
            "tokens_json": _array(),
            "modes_json": {"type": "object"},
            "metadata_json": {"type": "object"},
        },
        ["token_set_id"],
    ),
    _tool(
        "chitraagni_design_token_set_delete",
        "Delete one current-version design token set. Requires explicit confirm=true.",
        {"token_set_id": {"type": "string"}, "confirm": _confirm_property()},
        ["token_set_id", "confirm"],
        destructive=True,
    ),
    _tool(
        "chitraagni_component_definitions_list",
        "List current-version component definitions for one authorized Project.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_component_definition_get",
        "Read one authorized component definition.",
        {"component_definition_id": {"type": "string"}},
        ["component_definition_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_component_definition_create",
        "Create one reusable component definition in an authorized Project's current version.",
        {
            "project_id": {"type": "string"},
            "component_key": {"type": "string"},
            "name": {"type": "string"},
            "kind": {"type": "string", "default": "component"},
            "description": {"type": "string"},
            "props_schema_json": {"type": "object"},
            "slots_json": _array(),
            "variants_json": _array(),
            "states_json": _array(),
            "default_props_json": {"type": "object"},
            "token_bindings_json": {"type": "object"},
            "constraints_json": {"type": "object"},
            "responsive_json": {"type": "object"},
            "metadata_json": {"type": "object"},
        },
        ["project_id", "component_key", "name"],
    ),
    _tool(
        "chitraagni_component_definition_update",
        "Update explicit fields on one current-version component definition.",
        {
            "component_definition_id": {"type": "string"},
            "component_key": {"type": "string"},
            "name": {"type": "string"},
            "kind": {"type": "string"},
            "description": {"type": "string"},
            "props_schema_json": {"type": "object"},
            "slots_json": _array(),
            "variants_json": _array(),
            "states_json": _array(),
            "default_props_json": {"type": "object"},
            "token_bindings_json": {"type": "object"},
            "constraints_json": {"type": "object"},
            "responsive_json": {"type": "object"},
            "metadata_json": {"type": "object"},
        },
        ["component_definition_id"],
    ),
    _tool(
        "chitraagni_component_definition_delete",
        "Delete one current-version component definition. Requires explicit confirm=true.",
        {
            "component_definition_id": {"type": "string"},
            "confirm": _confirm_property(),
        },
        ["component_definition_id", "confirm"],
        destructive=True,
    ),
    _tool(
        "chitraagni_product_screens_list",
        "List current Product-owned screen revisions for an authorized Product.",
        {"project_id": {"type": "string"}, "product_id": {"type": "string"}},
        ["project_id", "product_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_product_screen_get",
        "Read one current Product-owned screen revision.",
        {
            "project_id": {"type": "string"},
            "product_id": {"type": "string"},
            "screen_id": {"type": "string"},
        },
        ["project_id", "product_id", "screen_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_product_screen_create",
        "Create one Product-owned screen revision in the current Project version.",
        {
            "project_id": {"type": "string"},
            "product_id": {"type": "string"},
            "page_key": {"type": "string"},
            "purpose": {"type": "string"},
            "primary_action": {"type": "string"},
            "secondary_actions_json": _array(),
            "required_regions_json": _array(),
            "components_json": _array(),
            "data_requirements_json": _array(),
            "required_states_json": _array(),
            "related_features_json": _array(),
            "related_entities_json": _array(),
            "page_priority": {"type": "integer"},
        },
        ["project_id", "product_id", "page_key"],
    ),
    _tool(
        "chitraagni_product_screen_update",
        "Update explicit fields on one current Product-owned screen revision.",
        {
            "project_id": {"type": "string"},
            "product_id": {"type": "string"},
            "screen_id": {"type": "string"},
            "page_key": {"type": "string"},
            "purpose": {"type": "string"},
            "primary_action": {"type": "string"},
            "secondary_actions_json": _array(),
            "required_regions_json": _array(),
            "components_json": _array(),
            "data_requirements_json": _array(),
            "required_states_json": _array(),
            "related_features_json": _array(),
            "related_entities_json": _array(),
            "page_priority": {"type": "integer"},
        },
        ["project_id", "product_id", "screen_id"],
    ),
    _tool(
        "chitraagni_product_screen_delete",
        "Delete one current Product-owned screen revision. Requires explicit confirm=true.",
        {
            "project_id": {"type": "string"},
            "product_id": {"type": "string"},
            "screen_id": {"type": "string"},
            "confirm": _confirm_property(),
        },
        ["project_id", "product_id", "screen_id", "confirm"],
        destructive=True,
    ),
    _tool(
        "chitraagni_r5_state",
        "Read the server-authoritative R5 visual review/library collaboration state for one authorized Product.",
        {"product_id": {"type": "string"}},
        ["product_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_r5_command",
        "Apply one server-authorized and audited R5 review/library command for an authorized Product.",
        {
            "product_id": {"type": "string"},
            "action": {"type": "string"},
            "correlation_id": {"type": ["string", "null"]},
            "base_review_updated_at": {"type": ["string", "null"]},
            "base_library_updated_at": {"type": ["string", "null"]},
            "review_bundle": _object_or_null(),
            "library_bundle": _object_or_null(),
            "metadata": {"type": "object"},
        },
        ["product_id", "action"],
    ),
]


def _result(value: Any) -> dict[str, Any]:
    text = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str)
    return {
        "content": [{"type": "text", "text": text}],
        "structuredContent": value,
        "isError": False,
    }


class CompleteChitraagniOperatorCatalog(FullChitraagniOperatorCatalog):
    """Normal MegasMCP Chitraagni surface: all mounted deterministic product data plus actions."""

    def tools(self) -> list[dict[str, Any]]:
        tools = [*super().tools(), *json.loads(json.dumps(COMPLETE_TOOLS))]
        seen: set[str] = set()
        for tool in tools:
            name = str(tool.get("name") or "")
            if not name or name in seen:
                raise ValueError(f"duplicate or empty Chitraagni operator tool: {name}")
            seen.add(name)
        return sorted(tools, key=lambda row: str(row["name"]))

    @staticmethod
    def _complete_tool(name: str) -> dict[str, Any] | None:
        return next((tool for tool in COMPLETE_TOOLS if tool["name"] == name), None)

    @staticmethod
    def _query(path: str, version_id: str | None) -> str:
        if not version_id:
            return path
        return f"{path}?version_id={version_id}"

    @staticmethod
    def _require_confirm(arguments: dict[str, Any]) -> None:
        if arguments.get("confirm") is not True:
            raise ValueError("confirm must be true for this destructive operation")

    def account_context(self) -> dict[str, Any]:
        return {
            "user": self._api("GET", "/me"),
            "workspaces": self._api("GET", "/workspaces"),
            "projects": self._api("GET", "/projects"),
            "products": self._api("GET", "/products"),
        }

    def project_context(
        self,
        project_id: str,
        *,
        include_quality: bool = True,
        include_codegen: bool = False,
        include_version_snapshots: bool = False,
        max_products: int = 50,
        max_versions: int = 50,
    ) -> dict[str, Any]:
        pid = _uuid(project_id, "project_id")
        project = self._api("GET", f"/projects/{pid}")
        products = list(self._api("GET", f"/projects/{pid}/products") or [])[:max_products]
        versions = list(self._api("GET", f"/projects/{pid}/versions") or [])[:max_versions]
        value: dict[str, Any] = {
            "project": project,
            "products": products,
            "screens": self._api("GET", f"/projects/{pid}/screens"),
            "schemas": self._api("GET", f"/projects/{pid}/schemas"),
            "workflows": self._api("GET", f"/projects/{pid}/workflows"),
            "versions": versions,
            "design_token_sets": self._api("GET", f"/projects/{pid}/design-token-sets"),
            "component_definitions": self._api("GET", f"/projects/{pid}/component-definitions"),
            "product_context": [],
        }
        for product in products:
            if not isinstance(product, dict) or not product.get("id"):
                continue
            product_id = _uuid(product["id"], "product_id")
            value["product_context"].append(
                {
                    "product": product,
                    "screens": self._api("GET", f"/projects/{pid}/products/{product_id}/screens"),
                    "r5": self._api("GET", f"/products/{product_id}/r5/state"),
                }
            )
        if include_quality:
            value["quality"] = self._api("GET", f"/projects/{pid}/quality")
        if include_codegen:
            value["codegen_react_next"] = self._api("GET", f"/projects/{pid}/codegen/react-next")
        if include_version_snapshots:
            snapshots: list[Any] = []
            for version in versions:
                if isinstance(version, dict) and version.get("id"):
                    version_id = _uuid(version["id"], "version_id")
                    snapshots.append(self._api("GET", f"/versions/{version_id}/snapshot"))
            value["version_snapshots"] = snapshots
        return value

    def product_context(
        self,
        product_id: str,
        *,
        include_quality: bool = True,
        include_codegen: bool = False,
    ) -> dict[str, Any]:
        product_uuid = _uuid(product_id, "product_id")
        product = self._api("GET", f"/products/{product_uuid}")
        if not isinstance(product, dict) or not product.get("project_id"):
            raise RuntimeError("Chitraagni Product response is missing project_id")
        project_id = _uuid(product["project_id"], "project_id")
        value: dict[str, Any] = {
            "product": product,
            "project": self._api("GET", f"/projects/{project_id}"),
            "screens": self._api("GET", f"/projects/{project_id}/products/{product_uuid}/screens"),
            "r5": self._api("GET", f"/products/{product_uuid}/r5/state"),
            "schemas": self._api("GET", f"/projects/{project_id}/schemas"),
            "workflows": self._api("GET", f"/projects/{project_id}/workflows"),
            "versions": self._api("GET", f"/projects/{project_id}/versions"),
            "design_token_sets": self._api("GET", f"/projects/{project_id}/design-token-sets"),
            "component_definitions": self._api("GET", f"/projects/{project_id}/component-definitions"),
        }
        if include_quality:
            value["quality"] = self._api("GET", f"/projects/{project_id}/quality")
        if include_codegen:
            value["codegen_react_next"] = self._api("GET", f"/projects/{project_id}/codegen/react-next")
        return value

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        tool = self._complete_tool(name)
        if tool is None:
            return super().call(name, arguments)
        if not isinstance(arguments, dict):
            raise ValueError("Chitraagni tool arguments must be a JSON object")
        errors = sorted(
            Draft202012Validator(tool["inputSchema"]).iter_errors(arguments),
            key=lambda row: list(row.path),
        )
        if errors:
            raise ValueError("invalid Chitraagni tool input: " + errors[0].message)

        if name == "chitraagni_account_context":
            value = self.account_context()
        elif name == "chitraagni_project_context":
            value = self.project_context(
                arguments["project_id"],
                include_quality=arguments.get("include_quality", True),
                include_codegen=arguments.get("include_codegen", False),
                include_version_snapshots=arguments.get("include_version_snapshots", False),
                max_products=arguments.get("max_products", 50),
                max_versions=arguments.get("max_versions", 50),
            )
        elif name == "chitraagni_product_context":
            value = self.product_context(
                arguments["product_id"],
                include_quality=arguments.get("include_quality", True),
                include_codegen=arguments.get("include_codegen", False),
            )
        elif name in {"chitraagni_project_quality", "chitraagni_project_codegen_react_next"}:
            project_id = _uuid(arguments["project_id"], "project_id")
            version_id = arguments.get("version_id")
            if version_id is not None:
                version_id = _uuid(version_id, "version_id")
            suffix = "/quality" if name.endswith("quality") else "/codegen/react-next"
            value = self._api("GET", self._query(f"/projects/{project_id}{suffix}", version_id))
        elif name == "chitraagni_design_token_sets_list":
            project_id = _uuid(arguments["project_id"], "project_id")
            value = self._api("GET", f"/projects/{project_id}/design-token-sets")
        elif name == "chitraagni_design_token_set_get":
            row_id = _uuid(arguments["token_set_id"], "token_set_id")
            value = self._api("GET", f"/design-token-sets/{row_id}")
        elif name == "chitraagni_design_token_set_create":
            project_id = _uuid(arguments["project_id"], "project_id")
            body = {
                "token_set_key": arguments["token_set_key"],
                "name": arguments["name"],
                "description": arguments.get("description", ""),
                "tokens_json": arguments.get("tokens_json", []),
                "modes_json": arguments.get("modes_json", {}),
                "metadata_json": arguments.get("metadata_json", {}),
            }
            value = self._api("POST", f"/projects/{project_id}/design-token-sets", body)
        elif name == "chitraagni_design_token_set_update":
            row_id = _uuid(arguments["token_set_id"], "token_set_id")
            body = _compact(arguments, ("token_set_key", "name", "description", "tokens_json", "modes_json", "metadata_json"))
            if not body:
                raise ValueError("at least one token-set field must be supplied")
            value = self._api("PUT", f"/design-token-sets/{row_id}", body)
        elif name == "chitraagni_design_token_set_delete":
            self._require_confirm(arguments)
            row_id = _uuid(arguments["token_set_id"], "token_set_id")
            value = self._api("DELETE", f"/design-token-sets/{row_id}")
            if value is None:
                value = {"deleted": True, "token_set_id": row_id}
        elif name == "chitraagni_component_definitions_list":
            project_id = _uuid(arguments["project_id"], "project_id")
            value = self._api("GET", f"/projects/{project_id}/component-definitions")
        elif name == "chitraagni_component_definition_get":
            row_id = _uuid(arguments["component_definition_id"], "component_definition_id")
            value = self._api("GET", f"/component-definitions/{row_id}")
        elif name == "chitraagni_component_definition_create":
            project_id = _uuid(arguments["project_id"], "project_id")
            body = {
                "component_key": arguments["component_key"],
                "name": arguments["name"],
                "kind": arguments.get("kind", "component"),
                "description": arguments.get("description", ""),
                "props_schema_json": arguments.get("props_schema_json", {}),
                "slots_json": arguments.get("slots_json", []),
                "variants_json": arguments.get("variants_json", []),
                "states_json": arguments.get("states_json", []),
                "default_props_json": arguments.get("default_props_json", {}),
                "token_bindings_json": arguments.get("token_bindings_json", {}),
                "constraints_json": arguments.get("constraints_json", {}),
                "responsive_json": arguments.get("responsive_json", {}),
                "metadata_json": arguments.get("metadata_json", {}),
            }
            value = self._api("POST", f"/projects/{project_id}/component-definitions", body)
        elif name == "chitraagni_component_definition_update":
            row_id = _uuid(arguments["component_definition_id"], "component_definition_id")
            body = _compact(
                arguments,
                (
                    "component_key", "name", "kind", "description", "props_schema_json",
                    "slots_json", "variants_json", "states_json", "default_props_json",
                    "token_bindings_json", "constraints_json", "responsive_json", "metadata_json",
                ),
            )
            if not body:
                raise ValueError("at least one component-definition field must be supplied")
            value = self._api("PUT", f"/component-definitions/{row_id}", body)
        elif name == "chitraagni_component_definition_delete":
            self._require_confirm(arguments)
            row_id = _uuid(arguments["component_definition_id"], "component_definition_id")
            value = self._api("DELETE", f"/component-definitions/{row_id}")
            if value is None:
                value = {"deleted": True, "component_definition_id": row_id}
        elif name == "chitraagni_product_screens_list":
            project_id = _uuid(arguments["project_id"], "project_id")
            product_id = _uuid(arguments["product_id"], "product_id")
            value = self._api("GET", f"/projects/{project_id}/products/{product_id}/screens")
        elif name == "chitraagni_product_screen_get":
            project_id = _uuid(arguments["project_id"], "project_id")
            product_id = _uuid(arguments["product_id"], "product_id")
            screen_id = _uuid(arguments["screen_id"], "screen_id")
            value = self._api("GET", f"/projects/{project_id}/products/{product_id}/screens/{screen_id}")
        elif name == "chitraagni_product_screen_create":
            project_id = _uuid(arguments["project_id"], "project_id")
            product_id = _uuid(arguments["product_id"], "product_id")
            body = {
                "page_key": arguments["page_key"],
                "purpose": arguments.get("purpose", ""),
                "primary_action": arguments.get("primary_action", ""),
                "secondary_actions_json": arguments.get("secondary_actions_json", []),
                "required_regions_json": arguments.get("required_regions_json", []),
                "components_json": arguments.get("components_json", []),
                "data_requirements_json": arguments.get("data_requirements_json", []),
                "required_states_json": arguments.get("required_states_json", []),
                "related_features_json": arguments.get("related_features_json", []),
                "related_entities_json": arguments.get("related_entities_json", []),
                "page_priority": arguments.get("page_priority", 0),
            }
            value = self._api("POST", f"/projects/{project_id}/products/{product_id}/screens", body)
        elif name == "chitraagni_product_screen_update":
            project_id = _uuid(arguments["project_id"], "project_id")
            product_id = _uuid(arguments["product_id"], "product_id")
            screen_id = _uuid(arguments["screen_id"], "screen_id")
            body = _compact(
                arguments,
                (
                    "page_key", "purpose", "primary_action", "secondary_actions_json",
                    "required_regions_json", "components_json", "data_requirements_json",
                    "required_states_json", "related_features_json", "related_entities_json", "page_priority",
                ),
            )
            if not body:
                raise ValueError("at least one product-screen field must be supplied")
            value = self._api("PUT", f"/projects/{project_id}/products/{product_id}/screens/{screen_id}", body)
        elif name == "chitraagni_product_screen_delete":
            self._require_confirm(arguments)
            project_id = _uuid(arguments["project_id"], "project_id")
            product_id = _uuid(arguments["product_id"], "product_id")
            screen_id = _uuid(arguments["screen_id"], "screen_id")
            value = self._api("DELETE", f"/projects/{project_id}/products/{product_id}/screens/{screen_id}?confirm=true")
        elif name == "chitraagni_r5_state":
            product_id = _uuid(arguments["product_id"], "product_id")
            value = self._api("GET", f"/products/{product_id}/r5/state")
        elif name == "chitraagni_r5_command":
            product_id = _uuid(arguments["product_id"], "product_id")
            body = {
                "action": arguments["action"],
                "correlation_id": arguments.get("correlation_id"),
                "base_review_updated_at": arguments.get("base_review_updated_at"),
                "base_library_updated_at": arguments.get("base_library_updated_at"),
                "review_bundle": arguments.get("review_bundle"),
                "library_bundle": arguments.get("library_bundle"),
                "metadata": arguments.get("metadata", {}),
            }
            value = self._api("POST", f"/products/{product_id}/r5/commands", body)
        else:
            raise KeyError(name)
        return _result(value)


__all__ = ["COMPLETE_TOOLS", "CompleteChitraagniOperatorCatalog"]
