from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from .chitraagni_authority import ChitraagniAuthorityStore, chitraagni_authority_scope
from .chitraagni_operator_runtime import RuntimeChitraagniOperatorCatalog
from .operator_account import DEFAULT_CHITRAAGNI_API_BASE, OperatorAccountStore


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="megas account",
        description=(
            "Use the one Amretra identity for Megas MCP and Chitraagni while keeping "
            "machine-local Chitraagni tool authority explicit and deny-by-default."
        ),
    )
    parser.add_argument("--json", action="store_true")
    sub = parser.add_subparsers(dest="account_command", required=True)

    status = sub.add_parser("status", help="show Amretra identity and Megas MCP operator status")
    status.add_argument(
        "--verify",
        action="store_true",
        help="verify the current Amretra credential against the configured Chitraagni target",
    )

    login = sub.add_parser(
        "login",
        help="authenticate the current user with Amretra using browser PKCE and native secure storage",
    )
    login.add_argument("--api-base", default=DEFAULT_CHITRAAGNI_API_BASE)
    login.add_argument(
        "--timeout",
        type=float,
        default=180.0,
        help="maximum seconds to wait for the interactive Amretra browser callback",
    )
    login.add_argument("--api-timeout", type=float, default=15.0)

    sub.add_parser(
        "logout",
        help="remove the local Amretra OAuth credential and identity state from Megas",
    )

    sub.add_parser(
        "chitraagni-permissions",
        help="inspect exact local Chitraagni tool grants plus remote/production-write gates",
    )
    allow_tool = sub.add_parser(
        "allow-chitraagni-tool",
        help="approve the exact current contract fingerprint of one Chitraagni tool for this Amretra identity and API target",
    )
    allow_tool.add_argument("--tool", required=True)
    revoke_tool = sub.add_parser(
        "revoke-chitraagni-tool",
        help="revoke one exact Chitraagni tool grant immediately",
    )
    revoke_tool.add_argument("--tool", required=True)

    sub.add_parser(
        "allow-chitraagni-remote",
        help="allow Chitraagni API access when the target is non-loopback HTTPS",
    )
    sub.add_parser(
        "revoke-chitraagni-remote",
        help="deny remote Chitraagni API access for the current Amretra identity/target",
    )
    sub.add_parser(
        "allow-chitraagni-production-write",
        help="add the explicit production.write gate required for hosted Chitraagni mutations",
    )
    sub.add_parser(
        "revoke-chitraagni-production-write",
        help="revoke production.write immediately while leaving current-scope tool grants unchanged",
    )
    return parser


def _binding(store: OperatorAccountStore) -> Any:
    binding = store.load().chitraagni
    if binding is None:
        raise PermissionError("Amretra login is required; run `megas account login`")
    return binding


def _authority_scope(store: OperatorAccountStore) -> str:
    binding = _binding(store)
    return chitraagni_authority_scope(
        api_base=binding.api_base,
        user_id=binding.amretra_user_id,
    )


def _catalog_for_identity(store: OperatorAccountStore) -> RuntimeChitraagniOperatorCatalog:
    return RuntimeChitraagniOperatorCatalog(_binding(store))


def _tool_contract(store: OperatorAccountStore, tool_name: str) -> dict[str, Any]:
    name = str(tool_name or "").strip()
    catalog = _catalog_for_identity(store)
    tool = next((row for row in catalog.tools() if row.get("name") == name), None)
    if tool is None:
        raise ValueError(f"unknown Chitraagni operator tool: {name}")
    return tool


def run(args: argparse.Namespace) -> Any:
    store = OperatorAccountStore()
    authority = ChitraagniAuthorityStore()

    if args.account_command == "status":
        value = store.status(verify=args.verify)
        binding = store.load().chitraagni
        if binding is not None:
            scope = chitraagni_authority_scope(
                api_base=binding.api_base,
                user_id=binding.amretra_user_id,
            )
            value["chitraagni_local_authority"] = authority.status(
                RuntimeChitraagniOperatorCatalog(binding).tools(),
                api_base=binding.api_base,
                scope=scope,
            )
        else:
            value["chitraagni_local_authority"] = authority.status()
        return value

    if args.account_command == "login":
        return store.login_amretra(
            api_base=args.api_base,
            login_timeout=args.timeout,
            api_timeout=args.api_timeout,
        )

    if args.account_command == "logout":
        value = store.logout_amretra()
        value["chitraagni_authority_cleared"] = authority.clear()
        return value

    if args.account_command == "chitraagni-permissions":
        binding = store.load().chitraagni
        if binding is None:
            return authority.status()
        scope = chitraagni_authority_scope(
            api_base=binding.api_base,
            user_id=binding.amretra_user_id,
        )
        tools = RuntimeChitraagniOperatorCatalog(binding).tools()
        return authority.status(tools, api_base=binding.api_base, scope=scope)

    if args.account_command == "allow-chitraagni-tool":
        scope = _authority_scope(store)
        grant = authority.grant_tool(_tool_contract(store, args.tool), scope=scope)
        return {
            "tool": grant.tool,
            "fingerprint": grant.fingerprint,
            "granted_at": grant.granted_at,
            "authority_scope": scope,
            "allowed": True,
        }

    if args.account_command == "revoke-chitraagni-tool":
        scope = _authority_scope(store)
        return {"tool": args.tool, "revoked": authority.revoke_tool(args.tool, scope=scope)}

    if args.account_command == "allow-chitraagni-remote":
        scope = _authority_scope(store)
        authority.set_remote_access(True, scope=scope)
        return {"remote_access": True, "authority_scope": scope}

    if args.account_command == "revoke-chitraagni-remote":
        scope = _authority_scope(store)
        authority.set_remote_access(False, scope=scope)
        return {"remote_access": False, "authority_scope": scope}

    if args.account_command == "allow-chitraagni-production-write":
        scope = _authority_scope(store)
        authority.set_production_write(True, scope=scope)
        return {"production_write": True, "authority_scope": scope}

    if args.account_command == "revoke-chitraagni-production-write":
        scope = _authority_scope(store)
        authority.set_production_write(False, scope=scope)
        return {"production_write": False, "authority_scope": scope}

    raise ValueError(f"unknown account command: {args.account_command}")


def _emit(value: Any, machine: bool) -> None:
    if machine:
        print(json.dumps(value, indent=2, sort_keys=True, default=str))
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                print(f"{key}: {json.dumps(item, sort_keys=True, default=str)}")
            else:
                print(f"{key}: {item}")
        return
    print(value)


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))
    try:
        _emit(run(args), args.json)
    except (
        FileNotFoundError,
        TimeoutError,
        ValueError,
        RuntimeError,
        PermissionError,
        OSError,
        json.JSONDecodeError,
    ) as exc:
        if args.json:
            _emit({"error": type(exc).__name__, "message": str(exc)}, True)
        else:
            print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


__all__ = ["build_parser", "main", "run"]
