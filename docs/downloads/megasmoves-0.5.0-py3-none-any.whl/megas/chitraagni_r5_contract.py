from __future__ import annotations

from typing import Any


# Audited against Chitraagni main's deterministic
# backend/app/services/r5_authorization.py. Keep this explicit so MCP clients
# receive a useful schema instead of guessing backend command strings.
R5_REVIEW_ACTIONS: tuple[str, ...] = (
    "collaboration.bootstrap",
    "collaborator.set_role",
    "review.create",
    "review.comment",
    "review.resolve_comment",
    "review.set_status",
    "decision.create",
    "decision.set_status",
    "checkpoint.record",
    "branch.fork",
    "branch.merge",
    "restore.apply",
)

R5_LIBRARY_ACTIONS: tuple[str, ...] = (
    "library.pack.create",
    "library.version.publish",
    "library.install",
    "library.upgrade",
    "library.deprecate",
)

R5_ACTIONS: tuple[str, ...] = (*R5_REVIEW_ACTIONS, *R5_LIBRARY_ACTIONS)


def harden_runtime_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Apply backend-known R5 semantics to the production MCP tool catalog.

    `chitraagni_r5_command` multiplexes multiple state-changing commands and
    includes restore/merge/deprecate operations, so it must conservatively
    advertise destructiveHint=true. Chitraagni remains the final authorization
    boundary for each concrete command and supplied state transition.
    """

    found = False
    for tool in tools:
        if tool.get("name") != "chitraagni_r5_command":
            continue
        found = True
        schema = tool.get("inputSchema")
        if not isinstance(schema, dict):
            raise ValueError("chitraagni_r5_command is missing inputSchema")
        properties = schema.get("properties")
        if not isinstance(properties, dict):
            raise ValueError("chitraagni_r5_command inputSchema is missing properties")
        action = properties.get("action")
        if not isinstance(action, dict):
            raise ValueError("chitraagni_r5_command inputSchema is missing action")
        action["type"] = "string"
        action["enum"] = list(R5_ACTIONS)
        action["description"] = "Exact server-authorized R5 command name."
        annotations = tool.setdefault("annotations", {})
        if not isinstance(annotations, dict):
            raise ValueError("chitraagni_r5_command annotations must be an object")
        annotations["readOnlyHint"] = False
        annotations["destructiveHint"] = True
        annotations["openWorldHint"] = False
    if not found:
        raise ValueError("production Chitraagni catalog is missing chitraagni_r5_command")
    return tools


__all__ = [
    "R5_ACTIONS",
    "R5_LIBRARY_ACTIONS",
    "R5_REVIEW_ACTIONS",
    "harden_runtime_tools",
]
