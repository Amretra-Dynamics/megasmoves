from __future__ import annotations

from typing import Any, Iterable


# Chitraagni main revision used for the mounted-route and request-field audit that
# established this contract. This is evidence, not a runtime dependency: Megas
# never downloads or executes Chitraagni source to construct its MCP surface.
AUDITED_CHITRAAGNI_MAIN_SHA = "af868bba9fe199d9bf4ecdf21ef7b8b7d3c8842d"
ROUTE_CONTRACT_VERSION = 3

# Canonical semantic routes only. Compatibility aliases (entities/behaviors and
# Project-scoped R5 aliases) intentionally map to the same typed capability and
# do not create duplicate MCP tools.
ROUTES: tuple[dict[str, str], ...] = (
    # structured.py
    {"module": "structured", "method": "GET", "path": "/health", "tool": "chitraagni_health"},
    {"module": "structured", "method": "GET", "path": "/me", "tool": "chitraagni_me"},
    {"module": "structured", "method": "GET", "path": "/workspaces", "tool": "chitraagni_workspaces_list"},
    {"module": "structured", "method": "GET", "path": "/workspaces/{workspace_id}", "tool": "chitraagni_workspace_get"},
    {"module": "structured", "method": "GET", "path": "/workspaces/{workspace_id}/projects", "tool": "chitraagni_workspace_projects_list"},
    {"module": "structured", "method": "POST", "path": "/workspaces/{workspace_id}/projects", "tool": "chitraagni_project_create"},
    {"module": "structured", "method": "GET", "path": "/projects", "tool": "chitraagni_projects_list"},
    {"module": "structured", "method": "GET", "path": "/projects/{project_id}", "tool": "chitraagni_project_get"},
    {"module": "structured", "method": "GET", "path": "/projects/{project_id}/products", "tool": "chitraagni_project_products_list"},
    {"module": "structured", "method": "GET", "path": "/products", "tool": "chitraagni_products_list"},
    {"module": "structured", "method": "POST", "path": "/projects/{project_id}/products", "tool": "chitraagni_product_create"},
    {"module": "structured", "method": "GET", "path": "/products/{product_id}", "tool": "chitraagni_product_get"},
    {"module": "structured", "method": "GET", "path": "/projects/{project_id}/products/{product_id}", "tool": "chitraagni_project_product_get"},
    {"module": "product_updates", "method": "PUT", "path": "/projects/{project_id}/products/{product_id}", "tool": "chitraagni_product_update"},
    {"module": "structured", "method": "GET", "path": "/projects/{project_id}/screens", "tool": "chitraagni_project_screens_list"},
    {"module": "structured", "method": "POST", "path": "/projects/{project_id}/screens", "tool": "chitraagni_screen_create"},
    {"module": "structured", "method": "GET", "path": "/screens/{screen_id}", "tool": "chitraagni_screen_get"},
    {"module": "structured", "method": "PUT", "path": "/screens/{screen_id}", "tool": "chitraagni_screen_update"},
    {"module": "structured", "method": "DELETE", "path": "/screens/{screen_id}?confirm=true", "tool": "chitraagni_screen_delete"},
    # design_primitives.py
    {"module": "design_primitives", "method": "GET", "path": "/projects/{project_id}/schemas", "tool": "chitraagni_project_schemas_list"},
    {"module": "design_primitives", "method": "POST", "path": "/projects/{project_id}/schemas", "tool": "chitraagni_schema_create"},
    {"module": "design_primitives", "method": "GET", "path": "/schemas/{schema_id}", "tool": "chitraagni_schema_get"},
    {"module": "design_primitives", "method": "PUT", "path": "/schemas/{schema_id}", "tool": "chitraagni_schema_update"},
    {"module": "design_primitives", "method": "DELETE", "path": "/schemas/{schema_id}", "tool": "chitraagni_schema_delete"},
    {"module": "design_primitives", "method": "GET", "path": "/projects/{project_id}/workflows", "tool": "chitraagni_project_workflows_list"},
    {"module": "design_primitives", "method": "POST", "path": "/projects/{project_id}/workflows", "tool": "chitraagni_workflow_create"},
    {"module": "design_primitives", "method": "GET", "path": "/workflows/{workflow_id}", "tool": "chitraagni_workflow_get"},
    {"module": "design_primitives", "method": "PUT", "path": "/workflows/{workflow_id}", "tool": "chitraagni_workflow_update"},
    {"module": "design_primitives", "method": "DELETE", "path": "/workflows/{workflow_id}", "tool": "chitraagni_workflow_delete"},
    {"module": "design_primitives", "method": "GET", "path": "/projects/{project_id}/versions", "tool": "chitraagni_project_versions_list"},
    {"module": "design_primitives", "method": "POST", "path": "/projects/{project_id}/versions", "tool": "chitraagni_version_snapshot"},
    {"module": "design_primitives", "method": "GET", "path": "/versions/{version_id}", "tool": "chitraagni_version_get"},
    {"module": "design_primitives", "method": "PUT", "path": "/versions/{version_id}", "tool": "chitraagni_version_update"},
    {"module": "design_primitives", "method": "POST", "path": "/versions/{version_id}/activate", "tool": "chitraagni_version_activate"},
    {"module": "design_primitives", "method": "GET", "path": "/versions/{version_id}/snapshot", "tool": "chitraagni_version_snapshot_get"},
    {"module": "design_primitives", "method": "DELETE", "path": "/versions/{version_id}", "tool": "chitraagni_version_delete"},
    # design_system.py
    {"module": "design_system", "method": "GET", "path": "/projects/{project_id}/design-token-sets", "tool": "chitraagni_design_token_sets_list"},
    {"module": "design_system", "method": "POST", "path": "/projects/{project_id}/design-token-sets", "tool": "chitraagni_design_token_set_create"},
    {"module": "design_system", "method": "GET", "path": "/design-token-sets/{token_set_id}", "tool": "chitraagni_design_token_set_get"},
    {"module": "design_system", "method": "PUT", "path": "/design-token-sets/{token_set_id}", "tool": "chitraagni_design_token_set_update"},
    {"module": "design_system", "method": "DELETE", "path": "/design-token-sets/{token_set_id}", "tool": "chitraagni_design_token_set_delete"},
    {"module": "design_system", "method": "GET", "path": "/projects/{project_id}/component-definitions", "tool": "chitraagni_component_definitions_list"},
    {"module": "design_system", "method": "POST", "path": "/projects/{project_id}/component-definitions", "tool": "chitraagni_component_definition_create"},
    {"module": "design_system", "method": "GET", "path": "/component-definitions/{component_definition_id}", "tool": "chitraagni_component_definition_get"},
    {"module": "design_system", "method": "PUT", "path": "/component-definitions/{component_definition_id}", "tool": "chitraagni_component_definition_update"},
    {"module": "design_system", "method": "DELETE", "path": "/component-definitions/{component_definition_id}", "tool": "chitraagni_component_definition_delete"},
    # product_screens.py
    {"module": "product_screens", "method": "GET", "path": "/projects/{project_id}/products/{product_id}/screens", "tool": "chitraagni_product_screens_list"},
    {"module": "product_screens", "method": "POST", "path": "/projects/{project_id}/products/{product_id}/screens", "tool": "chitraagni_product_screen_create"},
    {"module": "product_screens", "method": "GET", "path": "/projects/{project_id}/products/{product_id}/screens/{screen_id}", "tool": "chitraagni_product_screen_get"},
    {"module": "product_screens", "method": "PUT", "path": "/projects/{project_id}/products/{product_id}/screens/{screen_id}", "tool": "chitraagni_product_screen_update"},
    {"module": "product_screens", "method": "DELETE", "path": "/projects/{project_id}/products/{product_id}/screens/{screen_id}?confirm=true", "tool": "chitraagni_product_screen_delete"},
    # codegen.py
    {"module": "codegen", "method": "GET", "path": "/projects/{project_id}/codegen/react-next", "tool": "chitraagni_project_codegen_react_next"},
    {"module": "codegen", "method": "GET", "path": "/projects/{project_id}/quality", "tool": "chitraagni_project_quality"},
    # r5_commands.py: Product-scoped routes are canonical for Megas. The Project-
    # scoped forms are authorization-equivalent aliases implemented by Chitraagni.
    {"module": "r5_commands", "method": "GET", "path": "/products/{product_id}/r5/state", "tool": "chitraagni_r5_state"},
    {"module": "r5_commands", "method": "POST", "path": "/products/{product_id}/r5/commands", "tool": "chitraagni_r5_command"},
)

# Mounted authentication/session routes that deliberately remain human/local
# account-boundary operations rather than normal AI tools. `/auth/me` supplies
# the authoritative Amretra user ID that the legacy `/me` alias omits.
HUMAN_AUTH_ROUTES: tuple[dict[str, str], ...] = (
    {"method": "GET", "path": "/auth/amretra/start", "reason": "starts human Amretra OAuth login"},
    {"method": "GET", "path": "/auth/amretra/callback", "reason": "exchanges human OAuth authorization code"},
    {"method": "POST", "path": "/auth/amretra/logout", "reason": "human/session credential lifecycle"},
    {"method": "GET", "path": "/auth/me", "reason": "pinned cross-product identity verification"},
    {"method": "POST", "path": "/auth/bootstrap", "reason": "human account bootstrap boundary"},
)


def route_coverage(tool_names: Iterable[str]) -> dict[str, Any]:
    available = {str(name) for name in tool_names if str(name)}
    rows = [{**route, "covered": route["tool"] in available} for route in ROUTES]
    missing = sorted({row["tool"] for row in rows if not row["covered"]})
    return {
        "version": ROUTE_CONTRACT_VERSION,
        "audited_chitraagni_main_sha": AUDITED_CHITRAAGNI_MAIN_SHA,
        "route_count": len(rows),
        "covered_route_count": sum(1 for row in rows if row["covered"]),
        "complete": not missing,
        "missing_tools": missing,
        "routes": rows,
        "human_auth_routes": [dict(row) for row in HUMAN_AUTH_ROUTES],
    }


def assert_route_coverage(tool_names: Iterable[str]) -> dict[str, Any]:
    report = route_coverage(tool_names)
    if report["missing_tools"]:
        raise RuntimeError(
            "Megas MCP mounted-route contract is incomplete: "
            + ", ".join(report["missing_tools"])
        )
    return report


__all__ = [
    "AUDITED_CHITRAAGNI_MAIN_SHA",
    "HUMAN_AUTH_ROUTES",
    "ROUTES",
    "ROUTE_CONTRACT_VERSION",
    "assert_route_coverage",
    "route_coverage",
]
