"""Smart product lifecycle for the installed Megas CLI binary.

First-time product setup is always fetched from the website:
  curl -fsSL https://megasmoves.io/install.sh | sh
  irm https://megasmoves.io/install.ps1 | iex

Once the binary exists, this module decides among:
  connect   — no valid pairing yet (website approval)
  update    — production has a newer binary
  reinstall — force refresh binary + autostart (pairing kept)
  repair    — pairing ok, fix Worker/autostart/PATH only
  healthy   — nothing required

Never wipes user config: allowed_folders, agents, machine_name stay intact.
Never uses ``megas install`` for the product (that command installs coding agents).
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from typing import Any, Literal

import httpx

from megas.config import WorkerConfig, load_config
from megas.service import daemon_status, service_installed, worker_connection_age_sec
from megas.updater import current_version, platform_id

Recommended = Literal["connect", "update", "reinstall", "repair", "healthy"]


@dataclass
class ProductAssessment:
    recommended: Recommended
    reasons: list[str] = field(default_factory=list)
    paired: bool = False
    token_valid: bool | None = None  # None = unknown (offline)
    running: bool = False
    connected: bool = False
    service_ok: bool = False
    update_available: bool = False
    local_version: str = ""
    remote_version: str = ""
    preserves: list[str] = field(default_factory=list)

    def summary_line(self) -> str:
        labels = {
            "connect": "needs website connect (pairing)",
            "update": "update available (keeps pairing + settings)",
            "reinstall": "needs force refresh (keeps pairing + settings)",
            "repair": "needs repair (Worker/autostart; keeps pairing + settings)",
            "healthy": "healthy",
        }
        return labels.get(self.recommended, self.recommended)


def _probe_token(config: WorkerConfig) -> bool | None:
    """True if pairing works, False if rejected, None if network/unknown."""
    if not config.is_paired:
        return False
    try:
        plat = platform_id()
    except Exception:
        plat = "windows-amd64" if os.name == "nt" else "linux-amd64"
    try:
        with httpx.Client(timeout=8.0, follow_redirects=False) as client:
            response = client.get(
                f"{config.rest_base_url}/api/v1/cli/releases/latest",
                params={"platform": plat, "worker_id": config.worker_id},
                headers={"X-Megas-Worker-Token": config.worker_token},
            )
        if response.status_code == 200:
            return True
        if response.status_code in {401, 403, 404}:
            return False
        return None
    except Exception:
        return None


def _remote_version(api_base: str | None = None) -> str:
    try:
        from megas.cli.update_notice import check_for_update

        notice = check_for_update(api_base=api_base, force=False)
        if notice:
            return str(notice.get("remote_version") or "")
    except Exception:
        pass
    return ""


def assess_product(*, api_base: str | None = None, config: WorkerConfig | None = None) -> ProductAssessment:
    """Detect what this machine needs without mutating user configuration."""
    cfg = config or load_config()
    local = current_version()
    preserves = [
        "pairing (when token still valid)",
        "allowed folders / workspaces",
        "agent preferences",
        "machine name",
    ]
    assessment = ProductAssessment(
        recommended="healthy",
        local_version=local,
        preserves=preserves,
        paired=bool(cfg.is_paired),
    )

    daemon = daemon_status()
    assessment.running = bool(daemon.get("running"))
    age = worker_connection_age_sec()
    assessment.connected = age is not None and age >= 0
    assessment.service_ok = service_installed()

    if not cfg.is_paired:
        assessment.recommended = "connect"
        assessment.token_valid = False
        assessment.reasons.append("This machine is not paired to a Megas account yet.")
        return assessment

    token_ok = _probe_token(cfg)
    assessment.token_valid = token_ok
    if token_ok is False:
        assessment.recommended = "connect"
        assessment.reasons.append("Stored pairing is expired or rejected. Website reconnect required.")
        assessment.reasons.append("Your workspaces and agent settings on this machine are kept.")
        return assessment

    # Update check (best-effort; never blocks repair decisions).
    try:
        from megas.cli.update_notice import check_for_update

        notice = check_for_update(api_base=api_base, force=False)
        if notice:
            assessment.update_available = True
            assessment.remote_version = str(notice.get("remote_version") or "")
    except Exception:
        pass

    needs_repair = False
    if not assessment.service_ok:
        needs_repair = True
        assessment.reasons.append("Autostart is not installed.")
    if not assessment.running:
        needs_repair = True
        assessment.reasons.append("Worker process is not running.")
    elif not assessment.connected:
        needs_repair = True
        assessment.reasons.append("Worker is up but not CONNECTED to production.")

    if needs_repair and assessment.update_available:
        # Prefer update (refresh binary + reconnect) over bare repair when behind.
        assessment.recommended = "update"
        assessment.reasons.append(
            f"Newer release available: {local} → {assessment.remote_version}."
        )
        assessment.reasons.append("Update keeps pairing and all local settings.")
        return assessment

    if needs_repair:
        assessment.recommended = "repair"
        assessment.reasons.append("Repair refreshes autostart + Worker only (no config wipe).")
        return assessment

    if assessment.update_available:
        assessment.recommended = "update"
        assessment.reasons.append(
            f"Newer release available: {local} → {assessment.remote_version}."
        )
        assessment.reasons.append("Run megas update when ready (keeps pairing + settings).")
        return assessment

    assessment.recommended = "healthy"
    assessment.reasons.append("Pairing valid, Worker CONNECTED, no required action.")
    return assessment


def format_assessment(assessment: ProductAssessment) -> str:
    lines = [
        f"Megas status: {assessment.summary_line()}",
        f"  version:  {assessment.local_version or '?'}"
        + (f"  (latest {assessment.remote_version})" if assessment.remote_version else ""),
        f"  paired:   {'yes' if assessment.paired else 'no'}"
        + (
            f"  token={'ok' if assessment.token_valid else 'invalid' if assessment.token_valid is False else 'unchecked'}"
            if assessment.paired
            else ""
        ),
        f"  worker:   {'running' if assessment.running else 'stopped'}"
        f"  connected={'yes' if assessment.connected else 'no'}"
        f"  autostart={'yes' if assessment.service_ok else 'no'}",
    ]
    for reason in assessment.reasons:
        lines.append(f"  • {reason}")
    if assessment.recommended != "healthy":
        lines.append("  keeps: " + "; ".join(assessment.preserves))
    return "\n".join(lines)


def recommended_command(assessment: ProductAssessment) -> str:
    """CLI product command only — never website install wording as the primary path."""
    return {
        "connect": "megas connect",
        "update": "megas update",
        "reinstall": "megas reinstall",
        "repair": "megas start",  # repair path uses start + install-service in apply
        "healthy": "megas status",
    }.get(assessment.recommended, "megas status")


def website_first_setup_hint() -> str:
    """Only when the product binary is missing entirely (not a CLI subcommand)."""
    if os.name == "nt":
        return "irm https://megasmoves.io/install.ps1 | iex"
    return "curl -fsSL https://megasmoves.io/install.sh | sh"


__all__ = [
    "ProductAssessment",
    "assess_product",
    "format_assessment",
    "recommended_command",
    "website_first_setup_hint",
]
