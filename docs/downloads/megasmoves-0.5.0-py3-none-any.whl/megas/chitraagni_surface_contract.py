from __future__ import annotations

from typing import Any, Iterable


SURFACE_CONTRACT_VERSION = 2

# This is product semantics, not a REST proxy allowlist. Each mounted row names
# the typed Megas MCP capabilities required to operate the same durable domain
# represented by the Chitraagni human frontend.
_SURFACES: tuple[dict[str, Any], ...] = (
    {
        "key": "account",
        "frontend": ["Account", "Workspace switcher", "Project switcher"],
        "kind": "mounted",
        "state": "identity, workspaces, projects and products",
        "required_tools": [
            "chitraagni_health",
            "chitraagni_me",
            "chitraagni_workspaces_list",
            "chitraagni_workspace_get",
            "chitraagni_workspace_projects_list",
            "chitraagni_project_create",
            "chitraagni_projects_list",
            "chitraagni_project_get",
            "chitraagni_products_list",
            "chitraagni_project_products_list",
            "chitraagni_product_get",
            "chitraagni_project_product_get",
        ],
    },
    {
        "key": "products",
        "frontend": ["Products", "Product overview"],
        "kind": "mounted",
        "state": "Product records and Product memory",
        "required_tools": [
            "chitraagni_product_create",
            "chitraagni_product_update",
            "chitraagni_product_get",
            "chitraagni_project_products_list",
            "chitraagni_product_context",
        ],
    },
    {
        "key": "pages",
        "frontend": ["Pages", "Surfaces", "Product screens"],
        "kind": "mounted",
        "state": "Project-version and Product-owned structured screens",
        "required_tools": [
            "chitraagni_project_screens_list",
            "chitraagni_screen_create",
            "chitraagni_screen_get",
            "chitraagni_screen_update",
            "chitraagni_screen_delete",
            "chitraagni_product_screens_list",
            "chitraagni_product_screen_get",
            "chitraagni_product_screen_create",
            "chitraagni_product_screen_update",
            "chitraagni_product_screen_delete",
        ],
    },
    {
        "key": "schema",
        "frontend": ["Schema", "Entities"],
        "kind": "mounted",
        "state": "structured schemas/entities",
        "required_tools": [
            "chitraagni_project_schemas_list",
            "chitraagni_schema_create",
            "chitraagni_schema_get",
            "chitraagni_schema_update",
            "chitraagni_schema_delete",
        ],
    },
    {
        "key": "userflow",
        "frontend": ["Userflow", "Flows"],
        "kind": "mounted",
        "state": "trigger/action/result workflows",
        "required_tools": [
            "chitraagni_project_workflows_list",
            "chitraagni_workflow_create",
            "chitraagni_workflow_get",
            "chitraagni_workflow_update",
            "chitraagni_workflow_delete",
        ],
    },
    {
        "key": "design-system",
        "frontend": ["Design", "Visual styling", "Reusable components"],
        "kind": "mounted",
        "state": "design token sets and component definitions",
        "required_tools": [
            "chitraagni_design_token_sets_list",
            "chitraagni_design_token_set_get",
            "chitraagni_design_token_set_create",
            "chitraagni_design_token_set_update",
            "chitraagni_design_token_set_delete",
            "chitraagni_component_definitions_list",
            "chitraagni_component_definition_get",
            "chitraagni_component_definition_create",
            "chitraagni_component_definition_update",
            "chitraagni_component_definition_delete",
        ],
    },
    {
        "key": "versions",
        "frontend": ["History", "Versions"],
        "kind": "mounted",
        "state": "Project versions and immutable snapshots",
        "required_tools": [
            "chitraagni_project_versions_list",
            "chitraagni_version_snapshot",
            "chitraagni_version_get",
            "chitraagni_version_snapshot_get",
            "chitraagni_version_update",
            "chitraagni_version_activate",
            "chitraagni_version_delete",
        ],
    },
    {
        "key": "quality-codegen",
        "frontend": ["Quality", "Generated implementation"],
        "kind": "mounted",
        "state": "deterministic quality report and React/Next bundle",
        "required_tools": [
            "chitraagni_project_quality",
            "chitraagni_project_codegen_react_next",
        ],
    },
    {
        "key": "visual-review",
        "frontend": ["Visuals", "Review", "Library"],
        "kind": "mounted",
        "state": "R5 server-authoritative Product review/library collaboration state",
        "required_tools": ["chitraagni_r5_state", "chitraagni_r5_command"],
    },
    {
        "key": "context-search",
        "frontend": ["Project overview", "Product context", "Tools"],
        "kind": "composite",
        "state": "bounded composition/search over mounted authorized domains",
        "required_tools": [
            "chitraagni_account_context",
            "chitraagni_account_snapshot",
            "chitraagni_project_context",
            "chitraagni_product_context",
            "chitraagni_find",
        ],
    },
    {
        "key": "sales-assistant",
        "frontend": ["Sales Assistant"],
        "kind": "composite",
        "state": "sales-oriented view over Project/Product/schema/workflow/screen context",
        "required_tools": [
            "chitraagni_project_context",
            "chitraagni_product_context",
            "chitraagni_find",
        ],
        "note": "No separate deterministic CRM/lead/pipeline domain is mounted on Chitraagni main.",
    },
    {
        "key": "features",
        "frontend": ["Features"],
        "kind": "frontend-only",
        "state": "historical frontend record view",
        "required_tools": [],
        "note": "No deterministic Feature CRUD surface is mounted by Chitraagni main; Megas must not fabricate one.",
    },
    {
        "key": "decisions",
        "frontend": ["Decisions"],
        "kind": "frontend-only",
        "state": "historical frontend record view",
        "required_tools": [],
        "note": "No deterministic Decision CRUD surface is mounted by Chitraagni main; Megas must not fabricate one.",
    },
    {
        "key": "system-design",
        "frontend": ["System Design"],
        "kind": "frontend-only",
        "state": "empty frontend workbook section",
        "required_tools": [],
        "note": "Chitraagni main currently has no dedicated deterministic system-design domain.",
    },
    {
        "key": "market-analysis",
        "frontend": ["Market Analysis"],
        "kind": "frontend-only",
        "state": "legacy research/agent-oriented surface",
        "required_tools": [],
        "note": "Deterministic Chitraagni main does not mount the historical research/agent APIs.",
    },
)


def surface_map(tool_names: Iterable[str]) -> dict[str, Any]:
    available = {str(name) for name in tool_names if str(name)}
    rows: list[dict[str, Any]] = []
    mounted_missing: list[str] = []
    for source in _SURFACES:
        required = list(source.get("required_tools") or [])
        missing = [name for name in required if name not in available]
        row = {
            **source,
            "required_tools": required,
            "missing_tools": missing,
            "operator_ready": not missing if source["kind"] != "frontend-only" else False,
        }
        rows.append(row)
        if source["kind"] in {"mounted", "composite"} and missing:
            mounted_missing.extend(missing)
    unique_missing = sorted(set(mounted_missing))
    return {
        "version": SURFACE_CONTRACT_VERSION,
        "principle": "frontend surface -> durable domain -> mounted deterministic API -> typed Megas MCP capability",
        "complete_for_mounted_domains": not unique_missing,
        "missing_operator_tools": unique_missing,
        "surfaces": rows,
    }


def installed_chitraagni_tools() -> list[dict[str, Any]]:
    """Return the static production tool descriptors without account/network access."""

    from .chitraagni_field_contract import installed_production_tools

    return installed_production_tools()


def installed_chitraagni_tool_names() -> set[str]:
    """Return the static production tool names without account/network access."""

    return {
        str(tool.get("name") or "")
        for tool in installed_chitraagni_tools()
        if str(tool.get("name") or "")
    }


def _filtered_tools(tool_names: Iterable[str] | None) -> list[dict[str, Any]]:
    tools = installed_chitraagni_tools()
    if tool_names is None:
        return tools
    allowed = {str(name) for name in tool_names if str(name)}
    return [tool for tool in tools if str(tool.get("name") or "") in allowed]


def _attach_contracts(report: dict[str, Any], tools: list[dict[str, Any]]) -> dict[str, Any]:
    names = {str(tool.get("name") or "") for tool in tools if str(tool.get("name") or "")}
    from .chitraagni_field_contract import field_parity
    from .chitraagni_route_contract import ROUTES, route_coverage

    report["route_contract"] = route_coverage(names)
    report["field_contract"] = field_parity(ROUTES, tools)
    report["complete_for_mounted_domains"] = bool(
        report["complete_for_mounted_domains"]
        and not report["route_contract"]["missing_tools"]
        and report["field_contract"]["complete"]
    )
    return report


def installed_surface_map() -> dict[str, Any]:
    tools = installed_chitraagni_tools()
    report = surface_map(
        str(tool.get("name") or "") for tool in tools if str(tool.get("name") or "")
    )
    return _attach_contracts(report, tools)


def assert_mounted_surface_complete(tool_names: Iterable[str] | None = None) -> dict[str, Any]:
    tools = _filtered_tools(tool_names)
    names = {str(tool.get("name") or "") for tool in tools if str(tool.get("name") or "")}
    report = surface_map(names)
    missing = report["missing_operator_tools"]
    if missing:
        raise RuntimeError(
            "Megas MCP is missing typed Chitraagni capabilities required by mounted domains: "
            + ", ".join(missing)
        )

    from .chitraagni_field_contract import assert_field_parity
    from .chitraagni_route_contract import ROUTES, assert_route_coverage

    report["route_contract"] = assert_route_coverage(names)
    report["field_contract"] = assert_field_parity(ROUTES, tools)
    report["complete_for_mounted_domains"] = True
    return report


__all__ = [
    "SURFACE_CONTRACT_VERSION",
    "assert_mounted_surface_complete",
    "installed_chitraagni_tool_names",
    "installed_chitraagni_tools",
    "installed_surface_map",
    "surface_map",
]
