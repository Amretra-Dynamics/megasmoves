"""Read-only evidence about a service log file; never invent event-level timestamps.

Logs append across restarts. Even when an active PID has written to the log,
individual returned lines may be from a previous run. These fields classify the
*file*, not each line; consumers must not infer a current crash from log text.
"""
from __future__ import annotations

from datetime import datetime, timezone
from math import isfinite
from pathlib import Path
import time
from typing import Any


def observed_log_metadata(
    path: Path, *, process_alive: bool, started_at: float | str | None = None,
    now_seconds: float | None = None,
) -> dict[str, Any]:
    """Return bounded, serializable file timestamps and conservative provenance.

    A log written since a start timestamp may still contain old appended lines.
    File timestamps can be manipulated, so this is observational metadata only.
    """
    try:
        modified = path.stat().st_mtime
    except FileNotFoundError:
        return {
            "log_last_modified_at": None,
            "log_age_seconds": None,
            "log_origin": "no-log-file",
            "service_process_alive": bool(process_alive),
            "log_modified_since_service_start": None,
            "log_may_include_prior_runs": False,
        }

    started = None
    if started_at is not None and not isinstance(started_at, bool):
        try:
            candidate = float(started_at)
            if isfinite(candidate) and candidate > 0:
                started = candidate
        except (TypeError, ValueError, OverflowError):
            pass
    written_since_start = modified >= started if started is not None else None
    if not process_alive:
        origin = "historical-log"
    elif started is None:
        origin = "unattributed-running-process-log"
    elif written_since_start:
        origin = "file-modified-since-service-start"
    else:
        origin = "historical-log"

    now = time.time() if now_seconds is None else now_seconds
    return {
        "log_last_modified_at": datetime.fromtimestamp(modified, timezone.utc).isoformat(),
        "log_age_seconds": max(0, int(now - modified)),
        "log_origin": origin,
        "service_process_alive": bool(process_alive),
        "log_modified_since_service_start": written_since_start,
        "log_may_include_prior_runs": True,
    }
