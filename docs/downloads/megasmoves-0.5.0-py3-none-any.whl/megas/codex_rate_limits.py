"""Bounded Codex app-server rate-limit probe.

This module performs a read-only ``account/rateLimits/read`` request against the
installed Codex app server. It returns only the normalized, non-secret snapshot
used by Worker heartbeat/Android notifications; raw provider frames never leave
this process.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Optional

from .adapters.base import prefer_console_free_tool_path, resolve_cli_argv
from .adapters.process_control import (
    agent_process_group_kwargs,
    terminate_process_tree,
)
from .provider_limit_state import normalize_codex_rate_limits


_MAX_FRAME_BYTES = 2 * 1024 * 1024


async def _read_json_frame(
    reader: asyncio.StreamReader,
    *,
    timeout_seconds: float,
) -> dict[str, Any]:
    raw = await asyncio.wait_for(reader.readline(), timeout=timeout_seconds)
    if not raw:
        raise RuntimeError("Codex app-server closed before returning rate limits")
    if len(raw) > _MAX_FRAME_BYTES:
        raise RuntimeError("Codex app-server rate-limit frame exceeded the limit")
    try:
        value = json.loads(raw.decode("utf-8", errors="strict"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Codex app-server returned invalid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError("Codex app-server returned a non-object frame")
    return value


async def read_codex_rate_limits(
    *,
    binary: str = "codex",
    command_prefix: Optional[list[str]] = None,
    cwd: Path | str | None = None,
    environment: Optional[dict[str, str]] = None,
    timeout_seconds: float = 8.0,
) -> dict[str, Any] | None:
    """Return one provider-observed Codex quota snapshot, or ``None``.

    The probe initializes the official app-server protocol, requests
    ``account/rateLimits/read``, ignores unrelated notifications, and terminates
    the child process in every outcome. Provider errors fail closed as ``None``;
    they are not reclassified as quota state.
    """

    timeout = min(max(float(timeout_seconds), 1.0), 30.0)
    prefix = [str(item) for item in (command_prefix or resolve_cli_argv(binary)) if str(item)]
    if not prefix:
        return None
    workdir = Path(cwd or Path.home()).expanduser()
    if not workdir.is_dir():
        workdir = Path.home()
    env = prefer_console_free_tool_path(dict(environment or os.environ))
    env.setdefault("NO_COLOR", "1")

    process: asyncio.subprocess.Process | None = None
    try:
        process = await asyncio.create_subprocess_exec(
            *prefix,
            "app-server",
            "--stdio",
            cwd=str(workdir),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
            env=env,
            **agent_process_group_kwargs(),
        )
        if process.stdin is None or process.stdout is None:
            return None

        async def send(payload: dict[str, Any]) -> None:
            process.stdin.write(
                (json.dumps(payload, separators=(",", ":")) + "\n").encode("utf-8")
            )
            await process.stdin.drain()

        await send(
            {
                "id": 1,
                "method": "initialize",
                "params": {
                    "clientInfo": {
                        "name": "megas_moves",
                        "title": "Megas Moves",
                        "version": "0.2.17",
                    },
                    "capabilities": {"experimentalApi": True},
                },
            }
        )

        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        initialized = False
        requested = False
        while loop.time() < deadline:
            remaining = max(0.05, deadline - loop.time())
            frame = await _read_json_frame(
                process.stdout,
                timeout_seconds=remaining,
            )

            # Provider-initiated requests are declined safely. Quota reads must
            # never trigger approvals or user interaction.
            if "id" in frame and "method" in frame:
                await send({"id": frame["id"], "result": {"decision": "decline"}})
                continue

            if frame.get("id") == 1:
                if frame.get("error"):
                    return None
                await send({"method": "initialized"})
                initialized = True
                await send(
                    {
                        "id": 2,
                        "method": "account/rateLimits/read",
                        "params": {},
                    }
                )
                requested = True
                continue

            if frame.get("id") == 2:
                if frame.get("error"):
                    return None
                result = frame.get("result")
                return normalize_codex_rate_limits(
                    result,
                    method="account/rateLimits/read",
                )

            if frame.get("method") == "account/rateLimits/updated":
                params = frame.get("params")
                snapshot = normalize_codex_rate_limits(
                    params,
                    method="account/rateLimits/updated",
                )
                if snapshot and initialized and requested:
                    return snapshot
        return None
    except (
        OSError,
        RuntimeError,
        asyncio.TimeoutError,
        asyncio.IncompleteReadError,
        BrokenPipeError,
    ):
        return None
    finally:
        if process is not None and process.returncode is None:
            await terminate_process_tree(process, timeout=2.0)
