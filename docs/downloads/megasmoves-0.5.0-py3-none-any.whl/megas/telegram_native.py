"""Account-locked native Telegram integration for MegasMoves.

The public MCP surface is transport-independent.  The first production transport uses
Telegram MTProto through Telethon so it can run completely in the background without
interacting with Telegram Desktop.  Session material and API credentials are protected
with Windows DPAPI on the user's machine.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import io
import getpass
import json
import os
import queue
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import validate

STATE_VERSION = 1
TRANSPORT_NAME = "telethon-mtproto"
MAX_CHAT_RESULTS = 100
MAX_TOPIC_RESULTS = 100
MAX_MESSAGE_RESULTS = 100
MAX_DIALOG_SCAN = 2000
OPERATION_TIMEOUT_SECONDS = 45


def _run_bounded_operation(operation):
    async def run():
        return await asyncio.wait_for(operation, timeout=OPERATION_TIMEOUT_SECONDS)
    return asyncio.run(run())


def _megas_home(home: str | Path | None = None) -> Path:
    if home is not None:
        return Path(home).expanduser()
    configured = os.environ.get("MEGAS_HOME", "").strip()
    return Path(configured).expanduser() if configured else Path.home() / ".megas"


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


@dataclass(frozen=True)
class TelegramBinding:
    user_id: int
    label: str | None = None
    source: str = "telegram-auth"

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": STATE_VERSION,
            "user_id": int(self.user_id),
            "label": self.label,
            "source": self.source,
        }


class TelegramBindingStore:
    def __init__(self, home: str | Path | None = None) -> None:
        self.path = _megas_home(home) / "operator" / "telegram.binding.json"

    def read(self) -> TelegramBinding | None:
        if not self.path.is_file():
            return None
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict) or int(raw.get("version") or 0) != STATE_VERSION:
            raise ValueError("unsupported Telegram binding state")
        user_id = int(raw.get("user_id") or 0)
        if user_id <= 0:
            raise ValueError("Telegram binding has an invalid user id")
        label = str(raw.get("label") or "").strip() or None
        source = str(raw.get("source") or "telegram-auth").strip() or "telegram-auth"
        return TelegramBinding(user_id=user_id, label=label, source=source)

    def write(self, binding: TelegramBinding) -> None:
        if int(binding.user_id) <= 0:
            raise ValueError("Telegram user id must be positive")
        _atomic_json(self.path, binding.to_dict())

    def clear(self) -> bool:
        if not self.path.exists():
            return False
        self.path.unlink()
        return True

    def delete(self) -> bool:
        if not self.path.exists():
            return False
        self.path.unlink()
        return True


class TelegramSecretStore:
    """DPAPI-backed app credentials and StringSession storage on Windows."""

    def __init__(self, home: str | Path | None = None) -> None:
        root = _megas_home(home) / "operator"
        self.app_path = root / "telegram.app.credential"
        self.session_path = root / "telegram.session.credential"

    @staticmethod
    def _store(path: Path):
        if os.name != "nt":
            raise RuntimeError("Telegram secure local storage currently requires Windows DPAPI")
        from megas.credential_store import WindowsDPAPICredentialStore
        return WindowsDPAPICredentialStore(path=path)

    def app_configured(self) -> bool:
        env_id = (os.environ.get("MEGAS_TELEGRAM_API_ID") or os.environ.get("TELEGRAM_API_ID") or "").strip()
        env_hash = (os.environ.get("MEGAS_TELEGRAM_API_HASH") or os.environ.get("TELEGRAM_API_HASH") or "").strip()
        return bool(env_id and env_hash) or self.app_path.is_file()

    def read_app(self) -> tuple[int, str]:
        env_id = (os.environ.get("MEGAS_TELEGRAM_API_ID") or os.environ.get("TELEGRAM_API_ID") or "").strip()
        env_hash = (os.environ.get("MEGAS_TELEGRAM_API_HASH") or os.environ.get("TELEGRAM_API_HASH") or "").strip()
        if env_id and env_hash:
            return int(env_id), env_hash
        payload = json.loads(self._store(self.app_path).read())
        api_id = int(payload.get("api_id") or 0)
        api_hash = str(payload.get("api_hash") or "").strip()
        if api_id <= 0 or not api_hash:
            raise ValueError("stored Telegram app credentials are malformed")
        return api_id, api_hash

    def write_app(self, api_id: int, api_hash: str) -> None:
        api_id = int(api_id)
        api_hash = str(api_hash or "").strip()
        if api_id <= 0 or len(api_hash) < 16:
            raise ValueError("invalid Telegram api_id/api_hash")
        self._store(self.app_path).write(json.dumps({"api_id": api_id, "api_hash": api_hash}, separators=(",", ":")))

    def session_exists(self) -> bool:
        return self.session_path.is_file()

    def read_session(self) -> str:
        return self._store(self.session_path).read()

    def write_session(self, value: str) -> None:
        self._store(self.session_path).write(value)

    def delete_session(self) -> bool:
        if not self.session_path.exists():
            return False
        return self._store(self.session_path).delete()


_AUTH_LOCK = threading.RLock()
_AUTH_THREAD: threading.Thread | None = None
_AUTH_READY = threading.Event()
_AUTH_STATE: dict[str, Any] = {"state": "idle"}
_AUTH_PASSWORD_QUEUE: queue.Queue[str] = queue.Queue(maxsize=1)


def _clear_auth_password_queue() -> None:
    while True:
        try:
            _AUTH_PASSWORD_QUEUE.get_nowait()
        except queue.Empty:
            return


def _auth_state_update(**values: Any) -> None:
    with _AUTH_LOCK:
        _AUTH_STATE.update(values)


def _auth_state_public() -> dict[str, Any]:
    with _AUTH_LOCK:
        allowed = {
            "state", "started_at", "expires_at", "qr_ascii", "qr_data_url", "qr_login_url",
            "error",
        }
        return {k: v for k, v in _AUTH_STATE.items() if k in allowed and v is not None}


def _qr_ascii(url: str) -> str:
    import qrcode
    qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=1, border=1)
    qr.add_data(url)
    qr.make(fit=True)
    rows = qr.get_matrix()
    return "\n".join("".join("â–ˆâ–ˆ" if cell else "  " for cell in row) for row in rows)


def _qr_data_url(url: str) -> str:
    import qrcode

    image = qrcode.make(url)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def _display_name(entity: Any) -> str | None:
    title = str(getattr(entity, "title", "") or "").strip()
    if title:
        return title
    parts = [str(getattr(entity, "first_name", "") or "").strip(), str(getattr(entity, "last_name", "") or "").strip()]
    name = " ".join(part for part in parts if part).strip()
    return name or None


def _iso(value: Any) -> str | None:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    return None


def _limit(value: Any, maximum: int, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(1, min(maximum, parsed))


def _assert_bound_user(actual_user_id: int, binding: TelegramBinding) -> None:
    if int(actual_user_id) != int(binding.user_id):
        raise PermissionError(
            f"Telegram account mismatch: bound user id {binding.user_id}, authenticated user id {int(actual_user_id)}"
        )


def _tool_result(value: dict[str, Any]) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": json.dumps(value, ensure_ascii=False, default=str)}],
        "structuredContent": value,
        "isError": False,
    }


def tools() -> list[dict[str, Any]]:
    integer_id = {"type": "integer"}
    limit = {"type": "integer", "minimum": 1, "maximum": 100}
    specs: list[tuple[str, dict[str, Any], list[str], str, bool, bool]] = [
        ("status", {}, [], "Show whether Telegram is connected to MegasMoves.", True, False),
        ("auth_begin", {}, [], "Connect Telegram to MegasMoves using a QR code.", False, True),
        ("auth_status", {}, [], "Check Telegram connection progress.", True, False),
        ("chats_list", {
            "scope": {"type": "string", "enum": ["groups", "channels", "users", "all"]},
            "query": {"type": "string", "maxLength": 200},
            "limit": limit,
        }, [], "List chats from the connected Telegram account. Defaults to groups and supergroups.", True, True),
        ("chat_find", {
            "query": {"type": "string", "minLength": 1, "maxLength": 200},
            "limit": limit,
        }, ["query"], "Find Telegram chats by title or username.", True, True),
        ("topics_list", {
            "chat_id": integer_id,
            "query": {"type": "string", "maxLength": 200},
            "limit": limit,
        }, ["chat_id"], "List forum topics in a Telegram group.", True, True),
        ("messages_read", {
            "chat_id": integer_id,
            "topic_id": {"type": "integer", "minimum": 1},
            "limit": limit,
        }, ["chat_id"], "Read a bounded recent message window from one chat or forum topic.", True, True),
        ("messages_search", {
            "chat_id": integer_id,
            "query": {"type": "string", "minLength": 1, "maxLength": 500},
            "topic_id": {"type": "integer", "minimum": 1},
            "limit": limit,
        }, ["chat_id", "query"], "Search a bounded set of messages in one chat or forum topic.", True, True),
        ("message_send", {
            "chat_id": integer_id,
            "message": {"type": "string", "minLength": 1, "maxLength": 4000},
            "topic_id": {"type": "integer", "minimum": 1},
            "reply_to_message_id": {"type": "integer", "minimum": 1},
        }, ["chat_id", "message"], "Send or reply using the connected Telegram account.", False, True),
        ("disconnect", {}, [], "Disconnect Telegram from MegasMoves on this device.", False, True),
    ]
    out = []
    for suffix, properties, required, description, readonly, open_world in specs:
        out.append({
            "name": "telegram_" + suffix,
            "description": description,
            "inputSchema": {
                "type": "object",
                "properties": properties,
                "required": required,
                "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": readonly,
                "destructiveHint": suffix == "disconnect",
                "openWorldHint": open_world,
            },
        })
    return out


class TelegramOperator:
    def __init__(self, home: str | Path | None = None) -> None:
        self.home = _megas_home(home)
        self.bindings = TelegramBindingStore(self.home)
        self.secrets = TelegramSecretStore(self.home)

    def bind(self, user_id: int, label: str | None = None, source: str = "manual") -> TelegramBinding:
        binding = TelegramBinding(int(user_id), str(label or "").strip() or None, source)
        self.bindings.write(binding)
        return binding

    def _binding(self) -> TelegramBinding:
        binding = self.bindings.read()
        if binding is None:
            raise PermissionError("Telegram is not bound to an allowed user id")
        return binding

    def _accept_authorized_identity(self, user_id: int, label: str | None = None) -> TelegramBinding:
        """Adopt the first authorized Telegram account, then fail closed on mismatches."""
        existing = self.bindings.read()
        if existing is None:
            return self.bind(int(user_id), label, source="telegram-auth")
        _assert_bound_user(int(user_id), existing)
        return existing

    @staticmethod
    def _telethon():
        try:
            import telethon
            return telethon
        except Exception as exc:
            raise RuntimeError("Telegram native runtime is not installed") from exc

    def local_status(self) -> dict[str, Any]:
        binding = self.bindings.read()
        try:
            version = self._telethon().__version__
            runtime = True
        except Exception:
            version = None
            runtime = False
        return {
            "transport": TRANSPORT_NAME,
            "runtime_available": runtime,
            "runtime_version": version,
            "desktop_ui_required": False,
            "desktop_session_touched": False,
            "bound": binding is not None,
            "bound_user_id": binding.user_id if binding else None,
            "bound_label": binding.label if binding else None,
            "app_credentials_configured": self.secrets.app_configured(),
            "native_session_stored": self.secrets.session_exists(),
        }

    def status(self) -> dict[str, Any]:
        debug = self.local_status()
        available = bool(debug["runtime_available"] and debug["app_credentials_configured"])
        base = {
            "available": available,
            "connected": False,
            "state": "not_connected" if available else "unavailable",
            "uses_telegram_api": True,
        }
        if not available:
            base["message"] = "Telegram connection is unavailable in this MegasMoves build."
            return base
        if not (debug["native_session_stored"] and debug["bound"]):
            base["action"] = "connect"
            return base
        try:
            remote = _run_bounded_operation(self._account_info())
            return {
                **base,
                "connected": True,
                "state": "connected",
                "action": "disconnect",
                "account": {
                    "display_name": remote.get("display_name"),
                    "username": remote.get("username"),
                },
            }
        except Exception as exc:
            # Expose only exception *types*, never Telegram tokens, session
            # strings or account identifiers. This distinguishes packaging
            # faults from authentication failures during local diagnostics.
            return {
                **base,
                "state": "needs_reconnect",
                "action": "connect",
                "message": "Telegram connection could not be verified.",
                "error_type": type(exc).__name__,
                "error_cause_type": type(exc.__cause__).__name__ if exc.__cause__ else None,
            }

    def configure_app(self, api_id: int, api_hash: str) -> None:
        self.secrets.write_app(api_id, api_hash)

    def auth_begin(self) -> dict[str, Any]:
        global _AUTH_THREAD
        binding = self.bindings.read()
        if not self.secrets.app_configured():
            raise RuntimeError("Telegram connection is unavailable in this MegasMoves build.")
        with _AUTH_LOCK:
            if _AUTH_THREAD is not None and _AUTH_THREAD.is_alive():
                return _auth_state_public()
            _AUTH_READY.clear()
            _clear_auth_password_queue()
            _AUTH_STATE.clear()
            _AUTH_STATE.update({
                "state": "starting",
                "started_at": datetime.now(timezone.utc).isoformat(),
                "bound_user_id": binding.user_id if binding else None,
                "transport": TRANSPORT_NAME,
            })
            _AUTH_THREAD = threading.Thread(target=self._auth_thread_main, name="MegasTelegramAuth", daemon=True)
            _AUTH_THREAD.start()
        _AUTH_READY.wait(timeout=20)
        return _auth_state_public()

    def auth_password(self, password: str) -> dict[str, Any]:
        value = str(password or "")
        if not value or len(value) > 512:
            raise ValueError("A valid Telegram 2-step verification password is required")
        with _AUTH_LOCK:
            if str(_AUTH_STATE.get("state") or "") != "password_required":
                raise RuntimeError("Telegram is not waiting for a 2-step verification password")
            if _AUTH_THREAD is None or not _AUTH_THREAD.is_alive():
                raise RuntimeError("Telegram authorization is no longer active")
            _clear_auth_password_queue()
            _AUTH_PASSWORD_QUEUE.put_nowait(value)
            _AUTH_STATE.update({"state": "verifying_password", "error": None})
        return self.auth_status()

    def auth_status(self) -> dict[str, Any]:
        raw = _auth_state_public()
        value = {"state": str(raw.get("state") or "idle")}
        for key in ("qr_login_url", "qr_ascii", "qr_data_url", "expires_at", "error"):
            if raw.get(key) is not None:
                value[key] = raw.get(key)
        return value

    def _auth_thread_main(self) -> None:
        try:
            asyncio.run(self._auth_worker())
        except Exception as exc:
            _auth_state_update(state="failed", error=str(exc)[:800])
            _AUTH_READY.set()

    async def _auth_worker(self) -> None:
        from telethon import TelegramClient
        from telethon.errors import SessionPasswordNeededError
        from telethon.sessions import StringSession

        api_id, api_hash = self.secrets.read_app()
        binding = self.bindings.read()
        client = TelegramClient(StringSession(), api_id, api_hash, device_model="MegasMoves", app_version="0.5.0")
        try:
            await client.connect()
            qr = await client.qr_login()
            _auth_state_update(
                state="waiting_for_scan",
                qr_login_url=qr.url,
                qr_ascii=_qr_ascii(qr.url),
                qr_data_url=_qr_data_url(qr.url),
                expires_at=_iso(qr.expires),
            )
            _AUTH_READY.set()
            try:
                await qr.wait(timeout=120)
            except SessionPasswordNeededError:
                from telethon.errors import PasswordHashInvalidError

                loop = asyncio.get_running_loop()
                deadline = loop.time() + 180.0
                _auth_state_update(
                    state="password_required",
                    error=None,
                    qr_ascii=None,
                    qr_login_url=None,
                )
                while True:
                    remaining = deadline - loop.time()
                    if remaining <= 0:
                        _auth_state_update(state="expired", error="Telegram 2-step verification timed out; start again.")
                        return
                    try:
                        password = await asyncio.wait_for(
                            asyncio.to_thread(_AUTH_PASSWORD_QUEUE.get),
                            timeout=remaining,
                        )
                    except asyncio.TimeoutError:
                        _auth_state_update(state="expired", error="Telegram 2-step verification timed out; start again.")
                        return
                    try:
                        _auth_state_update(state="verifying_password", error=None)
                        await client.sign_in(password=password)
                        break
                    except PasswordHashInvalidError:
                        _auth_state_update(state="password_required", error="Incorrect password. Try again.")
                    finally:
                        password = ""
            me = await client.get_me()
            if me is None:
                raise RuntimeError("Telegram QR authorization completed without an account identity")
            binding = self._accept_authorized_identity(int(me.id), _display_name(me))
            self.secrets.write_session(client.session.save())
            _auth_state_update(
                state="authorized",
                authorized_user_id=int(me.id),
                bound_user_id=binding.user_id,
                qr_ascii=None,
                qr_data_url=None,
                qr_login_url=None,
            )
        except asyncio.TimeoutError:
            _auth_state_update(state="expired", error="Telegram QR authorization expired; start it again.")
        finally:
            _AUTH_READY.set()
            _clear_auth_password_queue()
            await asyncio.wait_for(client.disconnect(), timeout=5)

    async def _authorized_client(self):
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        api_id, api_hash = self.secrets.read_app()
        if not self.secrets.session_exists():
            raise PermissionError("Telegram native session is not authorized; run telegram_auth_begin first")
        binding = self._binding()
        client = TelegramClient(StringSession(self.secrets.read_session()), api_id, api_hash, device_model="MegasMoves", app_version="0.5.0")
        await client.connect()
        if not await client.is_user_authorized():
            await asyncio.wait_for(client.disconnect(), timeout=5)
            raise PermissionError("stored Telegram session is no longer authorized")
        me = await client.get_me()
        if me is None:
            await asyncio.wait_for(client.disconnect(), timeout=5)
            raise PermissionError("Telegram session has no user identity")
        try:
            _assert_bound_user(int(me.id), binding)
        except Exception:
            await asyncio.wait_for(client.disconnect(), timeout=5)
            raise
        return client, me

    async def _revoke_current_session(self) -> bool:
        if not (self.secrets.app_configured() and self.secrets.session_exists()):
            return False
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        api_id, api_hash = self.secrets.read_app()
        client = TelegramClient(StringSession(self.secrets.read_session()), api_id, api_hash, device_model="MegasMoves", app_version="0.5.0")
        try:
            await client.connect()
            if not await client.is_user_authorized():
                return False
            await client.log_out()
            return True
        finally:
            try:
                await asyncio.wait_for(client.disconnect(), timeout=5)
            except Exception:
                pass

    def disconnect(self) -> dict[str, Any]:
        remote_revoked = False
        try:
            remote_revoked = _run_bounded_operation(self._revoke_current_session())
        except Exception:
            remote_revoked = False
        self.secrets.delete_session()
        self.bindings.delete()
        _clear_auth_password_queue()
        with _AUTH_LOCK:
            _AUTH_STATE.clear()
            _AUTH_STATE.update({"state": "idle"})
        return {
            "connected": False,
            "state": "not_connected",
            "remote_session_revoked": remote_revoked,
        }

    async def _finish_client(self, client: Any) -> None:
        try:
            saved = client.session.save()
            if saved:
                self.secrets.write_session(saved)
        finally:
            await asyncio.wait_for(client.disconnect(), timeout=5)

    async def _account_info(self) -> dict[str, Any]:
        client, me = await self._authorized_client()
        try:
            return {
                "user_id": int(me.id),
                "display_name": _display_name(me),
                "username": str(getattr(me, "username", "") or "") or None,
            }
        finally:
            await self._finish_client(client)

    @staticmethod
    def _chat_kind(entity: Any) -> str:
        name = entity.__class__.__name__
        if name == "User":
            return "user"
        if name == "Chat":
            return "group"
        if name == "Channel":
            if bool(getattr(entity, "megagroup", False)):
                return "supergroup"
            return "channel"
        return name.lower()

    @classmethod
    def _chat_row(cls, dialog: Any) -> dict[str, Any]:
        entity = dialog.entity
        return {
            "chat_id": int(dialog.id),
            "title": str(dialog.title or _display_name(entity) or ""),
            "kind": cls._chat_kind(entity),
            "username": str(getattr(entity, "username", "") or "") or None,
            "forum": bool(getattr(entity, "forum", False)),
            "unread_count": int(getattr(dialog, "unread_count", 0) or 0),
        }

    async def _resolve_chat(self, client: Any, chat_id: int) -> tuple[Any, dict[str, Any]]:
        chat_id = int(chat_id)
        async for dialog in client.iter_dialogs(limit=MAX_DIALOG_SCAN):
            if int(dialog.id) == chat_id:
                return dialog.entity, self._chat_row(dialog)
        raise KeyError(f"Telegram chat {chat_id} was not found in the bound account")

    async def _chats(self, scope: str = "groups", query: str = "", limit: int = 50) -> dict[str, Any]:
        client, _ = await self._authorized_client()
        try:
            scope = (scope or "groups").strip().lower()
            query_cf = str(query or "").strip().casefold()
            result = []
            scanned = 0
            async for dialog in client.iter_dialogs(limit=MAX_DIALOG_SCAN):
                scanned += 1
                row = self._chat_row(dialog)
                kind = row["kind"]
                if scope == "groups" and kind not in {"group", "supergroup"}:
                    continue
                if scope == "channels" and kind != "channel":
                    continue
                if scope == "users" and kind != "user":
                    continue
                haystack = f"{row['title']} {row.get('username') or ''}".casefold()
                if query_cf and query_cf not in haystack:
                    continue
                result.append(row)
                if len(result) >= limit:
                    break
            return {"scope": scope, "query": query or None, "chats": result, "count": len(result),
                    "scanned_count": scanned, "scan_limit": MAX_DIALOG_SCAN,
                    "scan_limit_reached": scanned >= MAX_DIALOG_SCAN}
        finally:
            await self._finish_client(client)

    async def _topics(self, chat_id: int, query: str, limit: int) -> dict[str, Any]:
        from telethon import functions
        client, _ = await self._authorized_client()
        try:
            entity, chat = await self._resolve_chat(client, chat_id)
            if not bool(getattr(entity, "forum", False)):
                raise ValueError("requested Telegram chat is not a forum-enabled group")
            peer = await client.get_input_entity(entity)
            result = await client(functions.messages.GetForumTopicsRequest(
                peer=peer,
                offset_date=None,
                offset_id=0,
                offset_topic=0,
                limit=limit,
                q=str(query or "").strip() or None,
            ))
            topics = []
            for topic in list(getattr(result, "topics", []) or [])[:limit]:
                if topic.__class__.__name__ == "ForumTopicDeleted":
                    continue
                topics.append({
                    "topic_id": int(getattr(topic, "id", 0) or 0),
                    "title": str(getattr(topic, "title", "") or ""),
                    "top_message_id": int(getattr(topic, "top_message", 0) or 0),
                    "unread_count": int(getattr(topic, "unread_count", 0) or 0),
                    "closed": bool(getattr(topic, "closed", False)),
                    "pinned": bool(getattr(topic, "pinned", False)),
                    "date": _iso(getattr(topic, "date", None)),
                })
            return {"chat": chat, "query": query or None, "topics": topics, "count": len(topics)}
        finally:
            await self._finish_client(client)

    @staticmethod
    def _entity_labels(result: Any) -> dict[int, str]:
        from telethon import utils
        labels: dict[int, str] = {}
        for entity in list(getattr(result, "users", []) or []) + list(getattr(result, "chats", []) or []):
            try:
                labels[int(utils.get_peer_id(entity))] = _display_name(entity) or str(getattr(entity, "username", "") or "")
            except Exception:
                continue
        return labels

    @staticmethod
    def _message_row(message: Any, labels: dict[int, str] | None = None) -> dict[str, Any]:
        from telethon import utils
        sender_id = None
        from_id = getattr(message, "from_id", None)
        if from_id is not None:
            try:
                sender_id = int(utils.get_peer_id(from_id))
            except Exception:
                sender_id = None
        reply = getattr(message, "reply_to", None)
        top_id = int(getattr(reply, "reply_to_top_id", 0) or 0) or None if reply is not None else None
        reply_id = int(getattr(reply, "reply_to_msg_id", 0) or 0) or None if reply is not None else None
        return {
            "message_id": int(getattr(message, "id", 0) or 0),
            "date": _iso(getattr(message, "date", None)),
            "sender_id": sender_id,
            "sender_name": (labels or {}).get(sender_id) if sender_id is not None else None,
            "text": str(getattr(message, "message", "") or ""),
            "reply_to_message_id": reply_id,
            "topic_id": top_id,
        }

    @staticmethod
    def _topic_matches(message: Any, topic_id: int) -> bool:
        """Fail closed on messages not provably belonging to a forum topic."""
        mid = int(getattr(message, "id", 0) or 0)
        if topic_id != 1 and mid == topic_id:
            return True  # The topic creation service message
        action = getattr(message, "action", None)
        if action is not None and action.__class__.__name__ == "MessageActionTopicCreate":
            return False
        reply = getattr(message, "reply_to", None)
        if reply is not None:
            top = int(getattr(reply, "reply_to_top_id", 0) or 0)
            if top:
                return top == topic_id
            if bool(getattr(reply, "forum_topic", False)):
                direct = int(getattr(reply, "reply_to_msg_id", 0) or 0)
                return topic_id != 1 and direct == topic_id
        return topic_id == 1

    @staticmethod
    async def _verified_forum_topic(client: Any, entity: Any, topic_id: int) -> Any:
        from telethon import functions
        if not bool(getattr(entity, "forum", False)):
            raise ValueError("Topic ID requires a forum-enabled Telegram group")
        topic_id = int(topic_id)
        if topic_id <= 0:
            raise ValueError("topic_id must be positive")
        peer = await client.get_input_entity(entity)
        result = await client(functions.messages.GetForumTopicsByIDRequest(
            peer=peer, topics=[topic_id],
        ))
        matches = [
            t for t in list(getattr(result, "topics", []) or [])
            if t.__class__.__name__ != "ForumTopicDeleted"
            and int(getattr(t, "id", 0) or 0) == topic_id
        ]
        if not matches:
            raise KeyError(f"Telegram topic {topic_id} was not found in the selected group")
        return matches[0]

    async def _messages_read(self, chat_id: int, topic_id: int | None, limit: int) -> dict[str, Any]:
        from telethon import functions
        client, _ = await self._authorized_client()
        try:
            entity, chat = await self._resolve_chat(client, chat_id)
            if chat["forum"] and topic_id is None:
                raise ValueError("Select a topic_id to read a forum-enabled group; 1 means General")
            rows: list[dict[str, Any]] = []
            scan_limited = False
            if topic_id is not None:
                topic_id = int(topic_id)
                await self._verified_forum_topic(client, entity, topic_id)
                if topic_id == 1:
                    scan_cap = max(500, limit * 20)
                    scanned = 0
                    async for message in client.iter_messages(entity, limit=scan_cap):
                        scanned += 1
                        if self._topic_matches(message, topic_id):
                            row = self._message_row(message)
                            row["topic_id"] = topic_id
                            rows.append(row)
                            if len(rows) >= limit:
                                break
                    scan_limited = scanned >= scan_cap and len(rows) < limit
                else:
                    peer = await client.get_input_entity(entity)
                    result = await client(functions.messages.GetRepliesRequest(
                        peer=peer, msg_id=topic_id, offset_id=0, offset_date=None,
                        add_offset=0, limit=min(limit * 3, 300),
                        max_id=0, min_id=0, hash=0,
                    ))
                    labels = self._entity_labels(result)
                    for message in list(getattr(result, "messages", []) or []):
                        if not self._topic_matches(message, topic_id):
                            continue
                        row = self._message_row(message, labels)
                        row["topic_id"] = topic_id
                        rows.append(row)
                        if len(rows) >= limit:
                            break
            else:
                async for message in client.iter_messages(entity, limit=limit):
                    rows.append(self._message_row(message))
            return {
                "chat": chat, "topic_id": topic_id, "messages": rows,
                "count": len(rows), "scope_verified": topic_id is not None,
                "scan_limited": scan_limited,
            }
        finally:
            await self._finish_client(client)

    async def _messages_search(self, chat_id: int, query: str, topic_id: int | None, limit: int) -> dict[str, Any]:
        from telethon import functions, types
        client, _ = await self._authorized_client()
        try:
            entity, chat = await self._resolve_chat(client, chat_id)
            if chat["forum"] and topic_id is None:
                raise ValueError("Select topic_id when searching a forum-enabled group")
            rows: list[dict[str, Any]] = []
            scan_limited = False
            if topic_id is not None:
                topic_id = int(topic_id)
                await self._verified_forum_topic(client, entity, topic_id)
                if topic_id == 1:
                    scan_cap = max(500, limit * 20)
                    scanned = 0
                    async for message in client.iter_messages(entity, search=query, limit=scan_cap):
                        scanned += 1
                        if self._topic_matches(message, 1):
                            row = self._message_row(message)
                            row["topic_id"] = 1
                            rows.append(row)
                            if len(rows) >= limit:
                                break
                    scan_limited = scanned >= scan_cap and len(rows) < limit
                else:
                    peer = await client.get_input_entity(entity)
                    result = await client(functions.messages.SearchRequest(
                        peer=peer, q=query, filter=types.InputMessagesFilterEmpty(),
                        min_date=None, max_date=None, offset_id=0, add_offset=0,
                        limit=min(limit * 3, 300), max_id=0, min_id=0,
                        hash=0, top_msg_id=topic_id,
                    ))
                    labels = self._entity_labels(result)
                    for message in list(getattr(result, "messages", []) or []):
                        if not self._topic_matches(message, topic_id):
                            continue
                        row = self._message_row(message, labels)
                        row["topic_id"] = topic_id
                        rows.append(row)
                        if len(rows) >= limit:
                            break
            else:
                async for message in client.iter_messages(entity, search=query, limit=limit):
                    rows.append(self._message_row(message))
            return {
                "chat": chat, "topic_id": topic_id, "query": query,
                "messages": rows, "count": len(rows),
                "scope_verified": topic_id is not None, "scan_limited": scan_limited,
            }
        finally:
            await self._finish_client(client)

    async def _send(self, chat_id: int, message: str, topic_id: int | None, reply_to_message_id: int | None) -> dict[str, Any]:
        from telethon import functions, types
        client, me = await self._authorized_client()
        try:
            entity, chat = await self._resolve_chat(client, chat_id)
            if chat["forum"] and topic_id is None:
                raise ValueError("Select topic_id before sending to a forum group")
            if topic_id is not None:
                topic_id = int(topic_id)
                topic = await self._verified_forum_topic(client, entity, topic_id)
                if bool(getattr(topic, "closed", False)):
                    raise PermissionError("The selected Telegram topic is closed")
            if reply_to_message_id is not None:
                reply_to_message_id = int(reply_to_message_id)
                target = await client.get_messages(entity, ids=reply_to_message_id)
                if target is None:
                    raise KeyError("Reply target is missing from the selected chat")
                if topic_id is not None and not self._topic_matches(target, topic_id):
                    raise PermissionError("Reply target does not belong to the selected topic")

            if topic_id not in (None, 1) and reply_to_message_id not in (None, topic_id):
                # Telegram requires explicit top_msg_id for nested topic replies.
                # This keeps them in the right topic if a parent is deleted.
                peer = await client.get_input_entity(entity)
                updates = await client(functions.messages.SendMessageRequest(
                    peer=peer,
                    message=message,
                    reply_to=types.InputReplyToMessage(
                        reply_to_msg_id=reply_to_message_id, top_msg_id=topic_id,
                    ),
                ))
                sent_id = int(getattr(updates, "id", 0) or 0)
                if not sent_id:
                    for update in list(getattr(updates, "updates", []) or []):
                        if update.__class__.__name__ == "UpdateMessageID":
                            sent_id = int(getattr(update, "id", 0) or 0)
                            break
                        item = getattr(update, "message", None)
                        if item is not None and getattr(update, "out", False):
                            sent_id = int(getattr(item, "id", 0) or 0)
                sent = None
                if sent_id:
                    try:
                        sent = await client.get_messages(entity, ids=sent_id)
                    except Exception:
                        pass  # Do not retry a message that may already be sent.
            else:
                # General topic is normal group history, not a reply to id=1.
                reply_target = (
                    reply_to_message_id if reply_to_message_id is not None else
                    topic_id if topic_id not in (None, 1) else None
                )
                sent = await client.send_message(entity, message, reply_to=reply_target)
            row = self._message_row(sent) if sent is not None else None
            if row is not None and topic_id is not None:
                row["topic_id"] = topic_id
            return {
                "sent": True,
                "account_user_id": int(me.id),
                "chat": chat,
                "topic_id": topic_id,
                "reply_to_message_id": reply_to_message_id,
                "message": row,
                "message_id_verified": row is not None,
            }
        finally:
            await self._finish_client(client)

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        spec = next((spec for spec in tools() if spec["name"] == name), None)
        if spec is None:
            raise ValueError("unknown Telegram operation")
        validate(arguments, spec["inputSchema"])
        operation = name.removeprefix("telegram_")
        if operation == "status":
            return _tool_result(self.status())
        if operation == "auth_begin":
            return _tool_result(self.auth_begin())
        if operation == "auth_status":
            return _tool_result(self.auth_status())
        if operation == "chats_list":
            value = _run_bounded_operation(self._chats(
                str(arguments.get("scope") or "groups"),
                str(arguments.get("query") or ""),
                _limit(arguments.get("limit"), MAX_CHAT_RESULTS, 50),
            ))
            return _tool_result(value)
        if operation == "chat_find":
            value = _run_bounded_operation(self._chats(
                "all", str(arguments["query"]), _limit(arguments.get("limit"), 20, 20)
            ))
            return _tool_result(value)
        if operation == "topics_list":
            value = _run_bounded_operation(self._topics(
                int(arguments["chat_id"]), str(arguments.get("query") or ""),
                _limit(arguments.get("limit"), MAX_TOPIC_RESULTS, 50),
            ))
            return _tool_result(value)
        if operation == "messages_read":
            value = _run_bounded_operation(self._messages_read(
                int(arguments["chat_id"]),
                int(arguments["topic_id"]) if arguments.get("topic_id") is not None else None,
                _limit(arguments.get("limit"), MAX_MESSAGE_RESULTS, 50),
            ))
            return _tool_result(value)
        if operation == "disconnect":
            return _tool_result(self.disconnect())
        if operation == "messages_search":
            value = _run_bounded_operation(self._messages_search(
                int(arguments["chat_id"]), str(arguments["query"]),
                int(arguments["topic_id"]) if arguments.get("topic_id") is not None else None,
                _limit(arguments.get("limit"), MAX_MESSAGE_RESULTS, 50),
            ))
            return _tool_result(value)
        if operation == "message_send":
            value = _run_bounded_operation(self._send(
                int(arguments["chat_id"]), str(arguments["message"]),
                int(arguments["topic_id"]) if arguments.get("topic_id") is not None else None,
                int(arguments["reply_to_message_id"]) if arguments.get("reply_to_message_id") is not None else None,
            ))
            return _tool_result(value)
        raise ValueError("unknown Telegram operation")


def _cli(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m megas.telegram_native")
    sub = parser.add_subparsers(dest="command", required=True)
    configure = sub.add_parser("configure-app", help="Store Telegram api_id/api_hash locally using Windows DPAPI")
    configure.add_argument("--api-id", type=int, default=None)
    bind = sub.add_parser("bind", help="Advanced: pin this installation to one Telegram numeric user id")
    bind.add_argument("user_id", type=int)
    bind.add_argument("--label", default=None)
    sub.add_parser("status", help="Show secret-free Telegram integration status")
    args = parser.parse_args(argv)
    operator = TelegramOperator()
    if args.command == "configure-app":
        api_id = args.api_id or int(input("Telegram api_id: ").strip())
        api_hash = getpass.getpass("Telegram api_hash (hidden): ").strip()
        operator.configure_app(api_id, api_hash)
        print("Telegram app credentials stored with Windows DPAPI.")
        return 0
    if args.command == "bind":
        result = operator.bind(args.user_id, args.label)
        print(json.dumps(result.to_dict(), indent=2))
        return 0
    if args.command == "status":
        print(json.dumps(operator.local_status(), indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(_cli())
