from __future__ import annotations

import dataclasses
import logging
import os
from pathlib import Path
import re
import shutil
import subprocess
from typing import Any, Dict, List, Optional

from .adapters.base import prefer_console_free_tool_path, windows_subprocess_kwargs

logger = logging.getLogger("megas_worker_repository_binding")


@dataclasses.dataclass
class RepositoryVerificationResult:
    status: str  # "match", "stale_commit", "remote_mismatch", "workspace_missing", "dirty_workspace"
    is_valid: bool
    provider_repository_id: str
    expected_commit: str
    actual_commit: str
    expected_branch: str
    actual_branch: str
    dirty_files: List[str] = dataclasses.field(default_factory=list)
    error_detail: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


def verify_repository_workspace(
    workspace_dir: str,
    pinned_binding: Dict[str, Any],
) -> RepositoryVerificationResult:
    """Verifies that the local workspace matches the pinned repository binding before task execution."""
    expected_repo_id = str(pinned_binding.get("provider_repository_id") or "").strip()
    canonical_remote_id = _canonicalize_remote_url(str(pinned_binding.get("canonical_remote_identity") or pinned_binding.get("canonical_url") or "").strip())
    expected_commit = str(pinned_binding.get("base_commit") or pinned_binding.get("commit_sha") or "").strip()
    expected_branch = str(pinned_binding.get("branch") or pinned_binding.get("target_ref") or "").strip()

    # Fail closed if binding is incomplete
    if not (expected_repo_id or canonical_remote_id) or not expected_commit:
        return RepositoryVerificationResult(
            status="incomplete_binding",
            is_valid=False,
            provider_repository_id=expected_repo_id or canonical_remote_id,
            expected_commit=expected_commit,
            actual_commit="",
            expected_branch=expected_branch,
            actual_branch="",
            error_detail="Repository binding is incomplete: missing required repository identity or base_commit.",
        )

    dir_path = Path(workspace_dir).resolve()
    if not dir_path.exists() or not (dir_path / ".git").exists():
        return RepositoryVerificationResult(
            status="workspace_missing",
            is_valid=False,
            provider_repository_id=expected_repo_id or canonical_remote_id,
            expected_commit=expected_commit,
            actual_commit="",
            expected_branch=expected_branch,
            actual_branch="",
            error_detail=f"Workspace directory '{workspace_dir}' does not exist or is not a git repository.",
        )

    # 1. Verify remote origin URL
    try:
        remote_url = _run_git_cmd_strict(dir_path, ["config", "--get", "remote.origin.url"])
    except RuntimeError as e:
        return RepositoryVerificationResult(
            status="git_verification_failed",
            is_valid=False,
            provider_repository_id=expected_repo_id or canonical_remote_id,
            expected_commit=expected_commit,
            actual_commit="",
            expected_branch=expected_branch,
            actual_branch="",
            error_detail=f"Git remote configuration check failed: {e}",
        )

    actual_repo_id = _canonicalize_remote_url(remote_url)

    # Check remote identity against both expected_repo_id and canonical_remote_id
    matches_expected = _repo_ids_match(expected_repo_id, actual_repo_id) if expected_repo_id else False
    matches_canonical = _repo_ids_match(canonical_remote_id, actual_repo_id) if canonical_remote_id else False

    if not (matches_expected or matches_canonical):
        return RepositoryVerificationResult(
            status="remote_mismatch",
            is_valid=False,
            provider_repository_id=actual_repo_id,
            expected_commit=expected_commit,
            actual_commit="",
            expected_branch=expected_branch,
            actual_branch="",
            error_detail=f"Remote repository mismatch: expected '{expected_repo_id or canonical_remote_id}' but found '{actual_repo_id}' ({remote_url}).",
        )

    # 2. Verify HEAD commit and branch
    try:
        actual_commit = _run_git_cmd_strict(dir_path, ["rev-parse", "HEAD"]).strip()
        actual_branch = _run_git_cmd_strict(dir_path, ["rev-parse", "--abbrev-ref", "HEAD"]).strip()
    except RuntimeError as e:
        return RepositoryVerificationResult(
            status="git_verification_failed",
            is_valid=False,
            provider_repository_id=actual_repo_id or expected_repo_id,
            expected_commit=expected_commit,
            actual_commit="",
            expected_branch=expected_branch,
            actual_branch="",
            error_detail=f"Git status/commit check failed: {e}",
        )

    if actual_branch == "HEAD":
        actual_branch = "detached"

    # 3. Check dirty files (fail closed on git status error)
    try:
        dirty_status = _run_git_cmd_strict(dir_path, ["status", "--porcelain"])
    except RuntimeError as e:
        return RepositoryVerificationResult(
            status="git_verification_failed",
            is_valid=False,
            provider_repository_id=actual_repo_id or expected_repo_id,
            expected_commit=expected_commit,
            actual_commit=actual_commit,
            expected_branch=expected_branch,
            actual_branch=actual_branch,
            error_detail=f"Git status check failed: {e}",
        )
    dirty_files = [line[3:].strip() for line in dirty_status.splitlines() if line.strip()]
    allow_dirty = pinned_binding.get("allow_dirty") is True

    if dirty_files and not allow_dirty:
        return RepositoryVerificationResult(
            status="dirty_workspace",
            is_valid=False,
            provider_repository_id=actual_repo_id or expected_repo_id,
            expected_commit=expected_commit,
            actual_commit=actual_commit,
            expected_branch=expected_branch,
            actual_branch=actual_branch,
            dirty_files=dirty_files,
            error_detail=f"Workspace has {len(dirty_files)} uncommitted/dirty files. Clean checkout required.",
        )

    # 4. Verify branch match (exact match, no main/master bypass)
    allow_detached = pinned_binding.get("allow_detached") is True
    if expected_branch and expected_branch != "HEAD":
        if actual_branch != expected_branch and not (actual_branch == "detached" and allow_detached):
            return RepositoryVerificationResult(
                status="branch_mismatch",
                is_valid=False,
                provider_repository_id=actual_repo_id or expected_repo_id,
                expected_commit=expected_commit,
                actual_commit=actual_commit,
                expected_branch=expected_branch,
                actual_branch=actual_branch,
                dirty_files=dirty_files,
                error_detail=f"Branch mismatch: expected '{expected_branch}' but local branch is '{actual_branch}'.",
            )

    # 5. Verify commit match
    if expected_commit and not actual_commit.startswith(expected_commit) and not expected_commit.startswith(actual_commit):
        return RepositoryVerificationResult(
            status="stale_commit",
            is_valid=False,
            provider_repository_id=actual_repo_id or expected_repo_id,
            expected_commit=expected_commit,
            actual_commit=actual_commit,
            expected_branch=expected_branch,
            actual_branch=actual_branch,
            dirty_files=dirty_files,
            error_detail=f"Workspace commit stale: expected '{expected_commit}' but local HEAD is at '{actual_commit}'.",
        )

    return RepositoryVerificationResult(
        status="match",
        is_valid=True,
        provider_repository_id=actual_repo_id or expected_repo_id,
        expected_commit=expected_commit,
        actual_commit=actual_commit,
        expected_branch=expected_branch,
        actual_branch=actual_branch,
        dirty_files=dirty_files,
    )


def _run_git_cmd_strict(cwd: Path, args: List[str]) -> str:
    try:
        env = prefer_console_free_tool_path(dict(os.environ))
        git_env_path = env.get("PATH") or env.get("Path")
        git_executable = shutil.which("git", path=git_env_path) or "git"
        res = subprocess.run(
            [git_executable] + args,
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
            check=False,
            **windows_subprocess_kwargs(),
        )
        if res.returncode != 0:
            raise RuntimeError(res.stderr.strip() or f"git {' '.join(args)} returned code {res.returncode}")
        return res.stdout.strip()
    except Exception as e:
        if isinstance(e, RuntimeError):
            raise
        raise RuntimeError(f"git {' '.join(args)} failed: {e}") from e


def _canonicalize_remote_url(url: str) -> str:
    if not url:
        return ""
    clean = url.strip()
    if clean.lower().startswith("github:") or clean.lower().startswith("git:"):
        return clean.lower()
    if clean.endswith(".git"):
        clean = clean[:-4]

    # Handle SSH git@github.com:owner/repo
    if "git@" in clean and ":" in clean:
        parts = clean.split(":", 1)[1]
        return f"github:{parts.strip('/')}"

    # Handle HTTPS https://github.com/owner/repo
    if "github.com/" in clean:
        parts = clean.split("github.com/", 1)[1]
        return f"github:{parts.strip('/')}"

    return f"git:{clean}"


def _repo_ids_match(expected: str, actual: str) -> bool:
    if not expected or not actual:
        return False
    if expected == actual:
        return True
    exp_clean = expected.split(":", 1)[-1].strip().lower()
    act_clean = actual.split(":", 1)[-1].strip().lower()
    return exp_clean == act_clean
