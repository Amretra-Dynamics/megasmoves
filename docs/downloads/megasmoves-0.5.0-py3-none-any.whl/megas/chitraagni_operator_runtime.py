from __future__ import annotations

import json
import time
from contextlib import contextmanager
from typing import Any, Iterator

from jsonschema import Draft202012Validator

from .chitraagni_field_contract import apply_production_field_overlays
from .chitraagni_http import CHITRAAGNI_IDENTITY_PATH, request_json
from .chitraagni_operator import _compact, _required_text, _uuid
from .chitraagni_operator_context import AccountChitraagniOperatorCatalog
from .chitraagni_r5_contract import harden_runtime_tools
from .mcp.operator_activity import current_operator_operation_id


PREFETCH_TTL_SECONDS = 2.0
_FIELD_OVERLAY_CALLS = {
    "chitraagni_product_create",
    "chitraagni_product_update",
    "chitraagni_version_snapshot",
}


class RuntimeChitraagniOperatorCatalog(AccountChitraagniOperatorCatalog):
    """Production Chitraagni catalog used by Megas MCP.

    A high-level MCP operation may need many Chitraagni API reads. The linked
    identity is verified once with the exact credential token that will be used
    for the complete operation. Nested context helpers reuse that pinned token,
    then discard it when the operation finishes. Production calls also use the
    bounded Chitraagni HTTP transport so one account response cannot consume
    unbounded process memory.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._operation_depth = 0
        self._operation_token: str | None = None
        self._prefetched_token: str | None = None
        self._prefetched_at = 0.0

    def tools(self) -> list[dict[str, Any]]:
        # The base catalog is intentionally reusable, while this production
        # catalog pins backend-known semantics and the fields audited against the
        # current deterministic Chitraagni main revision.
        return apply_production_field_overlays(harden_runtime_tools(super().tools()))

    def _validate_production_call(self, name: str, arguments: dict[str, Any]) -> None:
        if not isinstance(arguments, dict):
            raise ValueError("Chitraagni tool arguments must be a JSON object")
        tool = next((row for row in self.tools() if row.get("name") == name), None)
        if tool is None:
            # Preserve the normal KeyError path in the underlying catalog for
            # truly unknown capabilities.
            return
        schema = tool.get("inputSchema")
        if not isinstance(schema, dict):
            raise ValueError(f"Chitraagni tool {name} is missing inputSchema")
        errors = sorted(
            Draft202012Validator(schema).iter_errors(arguments),
            key=lambda row: list(row.path),
        )
        if errors:
            raise ValueError("invalid Chitraagni tool input: " + errors[0].message)

    def verify_identity(self) -> dict[str, Any]:
        token = self.binding.token()
        identity = request_json(
            "GET",
            self.binding.api_base + CHITRAAGNI_IDENTITY_PATH,
            token=token,
            timeout=self.timeout_seconds,
        )
        if not isinstance(identity, dict):
            raise RuntimeError("Chitraagni /me returned an invalid identity response")

        current_id = str(identity.get("id") or "").strip()
        if current_id != self.binding.user_id:
            raise PermissionError(
                "Chitraagni credential resolved to a different Chitraagni product record; relink explicitly before operating another account"
            )

        current_amretra_user_id = str(identity.get("amretra_user_id") or "").strip()
        if current_amretra_user_id != self.binding.amretra_user_id:
            raise PermissionError(
                "Chitraagni credential resolved to a different Amretra identity; relink explicitly before operating another account"
            )
        if self.binding.credential_kind == "firebase-owner-local":
            self.binding.validate()
            if identity.get("identity_provider") != "firebase-owner-local" or identity.get("firebase_uid") != self.binding.firebase_uid:
                raise PermissionError("Chitraagni did not verify the pinned local owner")
        elif identity.get("identity_provider") not in {None, "amretra"}:
            raise PermissionError("Chitraagni did not resolve the credential through Amretra identity")
        if identity.get("is_active") is False:
            raise PermissionError("linked Chitraagni product access is inactive")

        self._prefetched_token = token
        self._prefetched_at = time.monotonic()
        return identity

    def _take_prefetched_token(self) -> str | None:
        token = self._prefetched_token
        age = time.monotonic() - self._prefetched_at
        self._prefetched_token = None
        self._prefetched_at = 0.0
        if token and age <= PREFETCH_TTL_SECONDS:
            return token
        return None

    @contextmanager
    def operation(self) -> Iterator[None]:
        root = self._operation_depth == 0
        if root:
            token = self._take_prefetched_token()
            if token is None:
                self.verify_identity()
                token = self._take_prefetched_token()
            if token is None:
                raise RuntimeError("failed to pin verified Chitraagni credential")
            self._operation_token = token
        self._operation_depth += 1
        try:
            yield
        finally:
            self._operation_depth -= 1
            if root:
                self._operation_token = None
                self._prefetched_token = None
                self._prefetched_at = 0.0

    def _api(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        token = self._operation_token
        if token is None:
            with self.operation():
                return self._api(method, path, body)
        operation_id = current_operator_operation_id()
        metadata_headers = (
            {"X-Megas-Operation-Id": operation_id}
            if operation_id is not None
            else None
        )
        try:
            return request_json(
                method,
                self.binding.api_base + path,
                token=token,
                body=body,
                timeout=self.timeout_seconds,
                metadata_headers=metadata_headers,
            )
        except Exception as exc:
            message = str(exc).replace(token, "[REDACTED]")
            if isinstance(exc, PermissionError):
                raise PermissionError(message) from exc
            if isinstance(exc, ValueError):
                raise ValueError(message) from exc
            raise RuntimeError(message) from exc

    @staticmethod
    def _result(value: Any) -> dict[str, Any]:
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps(value, sort_keys=True, ensure_ascii=False, default=str),
                }
            ],
            "structuredContent": value,
            "isError": False,
        }

    def _call_current_field_contract(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if name == "chitraagni_product_create":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api(
                "POST",
                f"/projects/{project_id}/products",
                {
                    "name": _required_text(arguments, "name"),
                    "product_type": arguments.get("product_type", "web_app"),
                    "platform": arguments.get("platform"),
                    "goal": arguments.get("goal", ""),
                    "description": arguments.get("description", ""),
                    "imported_source_type": arguments.get("imported_source_type", "manual"),
                    "imported_source_details_json": arguments.get(
                        "imported_source_details_json", {}
                    ),
                    "product_memory_json": arguments.get("product_memory_json", {}),
                },
            )
            return self._result(value)

        if name == "chitraagni_product_update":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            product_id = _uuid(arguments.get("product_id"), "product_id")
            body = _compact(
                arguments,
                (
                    "name",
                    "product_type",
                    "platform",
                    "goal",
                    "description",
                    "imported_source_type",
                    "imported_source_details_json",
                    "product_memory_json",
                    "workflow_status",
                ),
            )
            if not body:
                raise ValueError("at least one product field must be supplied")
            value = self._api(
                "PUT",
                f"/projects/{project_id}/products/{product_id}",
                body,
            )
            return self._result(value)

        if name == "chitraagni_version_snapshot":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api(
                "POST",
                f"/projects/{project_id}/versions",
                {
                    "label": arguments.get("label"),
                    "source_type": arguments.get("source_type", "manual_snapshot"),
                    "status": arguments.get("status", "saved"),
                },
            )
            return self._result(value)

        raise KeyError(name)

    def account_context(self) -> dict[str, Any]:
        with self.operation():
            return super().account_context()

    def project_context(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        with self.operation():
            return super().project_context(*args, **kwargs)

    def product_context(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        with self.operation():
            return super().product_context(*args, **kwargs)

    def account_snapshot(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        with self.operation():
            return super().account_snapshot(*args, **kwargs)

    def find(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        with self.operation():
            return super().find(*args, **kwargs)

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        # Validate before reading a credential or touching the linked account.
        # This makes the schema enforced rather than merely advertised.
        self._validate_production_call(name, arguments)
        with self.operation():
            if name in _FIELD_OVERLAY_CALLS:
                return self._call_current_field_contract(name, arguments)
            return super().call(name, arguments)


__all__ = ["PREFETCH_TTL_SECONDS", "RuntimeChitraagniOperatorCatalog"]
