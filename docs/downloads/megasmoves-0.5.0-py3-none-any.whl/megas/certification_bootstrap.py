"""Bounded post-connect certification for already authenticated local CLIs.

The worker used to publish only certificates created by ``megas agents setup``.
That left a newly paired Windows machine permanently detected-but-unavailable,
even when the provider CLI was already signed in.  This module performs the
same installation-scoped proof in the background after the outbound worker
connection is healthy.  It never delays the first heartbeat and it never
promotes a provider unless the ordinary certificate evaluator accepts it.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import threading
from typing import Any

from .adapter_certification import (
    adapter_authentication_identity,
    installation_fingerprint,
    installation_identity,
    load_installation_certificate,
)


_RUN_LOCK = threading.Lock()
_RETRY_AFTER = timedelta(minutes=15)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_time(value: object) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _timeout_seconds() -> float:
    try:
        raw = float(os.getenv("MEGAS_AUTO_CERTIFICATION_TIMEOUT_SEC", "90") or "90")
    except (TypeError, ValueError):
        raw = 90.0
    return min(max(raw, 30.0), 300.0)


def certify_authenticated_agents(config: Any) -> dict[str, str]:
    """Register and certify eligible installed CLIs without a manual setup loop.

    Results are intentionally compact and privacy-safe: no executable path,
    account identity, provider output, or credential material is returned.
    A failed proof remains unavailable; a retry happens only when the
    installation/authentication fingerprint changes or after a short backoff.
    """

    if str(os.getenv("MEGAS_AUTO_CERTIFICATION", "true")).strip().lower() in {
        "0",
        "false",
        "no",
        "off",
    }:
        return {"_status": "disabled_by_owner"}
    if not _RUN_LOCK.acquire(blocking=False):
        return {"_status": "already_running"}

    try:
        from .certification_runner import certify_agent_installation
        from .config import save_config
        from .runtime_manifest import _agent_adapter_classes, _auth_mode

        if not isinstance(getattr(config, "agents", None), dict):
            config.agents = {}
        outcomes: dict[str, str] = {}
        dirty = False
        now = _now()

        for provider_id, adapter_class in _agent_adapter_classes().items():
            entry = config.agents.get(provider_id)
            entry = dict(entry) if isinstance(entry, dict) else {}
            if entry.get("enabled") is False:
                outcomes[provider_id] = "disabled_in_config"
                continue
            try:
                adapter = adapter_class([])
                executable = adapter.discover_executable()
                if executable is None:
                    continue
                version = adapter.detect_version()
                if not version or str(adapter.health_status()) != "available":
                    outcomes[provider_id] = "runtime_not_ready"
                    continue
                auth_mode = _auth_mode(provider_id, adapter)
                if auth_mode == "unauthenticated":
                    outcomes[provider_id] = "authentication_required"
                    continue
                identity = installation_identity(
                    provider_id=provider_id,
                    executable=Path(executable),
                    provider_version=str(version),
                    adapter_contract_version=str(
                        getattr(adapter, "contract_version", "unknown")
                    ),
                    auth_mode=auth_mode,
                    execution_mode="inspect",
                    authentication_identity=adapter_authentication_identity(adapter),
                )
                fingerprint = installation_fingerprint(identity)
                _certificate, decision = load_installation_certificate(identity)
                entry.update(
                    {
                        "enabled": True,
                        "binary": str(Path(executable)),
                        "binary_path": str(Path(executable)),
                        "auto_registered": True,
                        "updated_at": now.isoformat(),
                    }
                )
                config.agents[provider_id] = entry
                dirty = True
                if decision.certified:
                    entry["certified"] = True
                    entry["certification_status"] = decision.status
                    entry["certification_reason"] = decision.reason
                    outcomes[provider_id] = "already_certified"
                    continue
                if not identity.get("authentication_identity"):
                    entry["certified"] = False
                    entry["certification_status"] = "incomplete"
                    entry["certification_reason"] = "authentication_identity_unverified"
                    outcomes[provider_id] = "authentication_identity_unverified"
                    continue
                previous = _parse_time(entry.get("auto_certification_attempted_at"))
                if (
                    entry.get("auto_certification_fingerprint") == fingerprint
                    and previous is not None
                    and now - previous < _RETRY_AFTER
                ):
                    outcomes[provider_id] = "retry_deferred"
                    continue

                entry["auto_certification_fingerprint"] = fingerprint
                entry["auto_certification_attempted_at"] = now.isoformat()
                result = certify_agent_installation(
                    provider_id,
                    timeout_seconds=_timeout_seconds(),
                )
                entry["certified"] = bool(result.certified)
                entry["certification_status"] = str(result.status)
                entry["certification_reason"] = str(result.reason)
                outcomes[provider_id] = (
                    "certified" if result.certified else str(result.reason)
                )
            except Exception as exc:
                entry["certified"] = False
                entry["certification_status"] = "not_verified"
                entry["certification_reason"] = type(exc).__name__
                entry["auto_certification_attempted_at"] = now.isoformat()
                config.agents[provider_id] = entry
                dirty = True
                outcomes[provider_id] = type(exc).__name__

        if dirty:
            save_config(config)
        return outcomes
    finally:
        _RUN_LOCK.release()


__all__ = ["certify_authenticated_agents"]
