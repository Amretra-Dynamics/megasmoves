"""Megas Worker CLI shell."""

