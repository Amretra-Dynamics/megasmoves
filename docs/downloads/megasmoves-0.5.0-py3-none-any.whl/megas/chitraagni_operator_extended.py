from __future__ import annotations

import json
from typing import Any

from jsonschema import Draft202012Validator

from .chitraagni_operator import (
    ChitraagniOperatorCatalog,
    _compact,
    _tool,
    _uuid,
)


EXTENDED_TOOLS: list[dict[str, Any]] = [
    _tool(
        "chitraagni_health",
        "Read the deterministic Chitraagni runtime health contract without exposing credentials.",
        {},
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_me",
        "Read the identity of the linked and currently verified Chitraagni user.",
        {},
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_workspaces_list",
        "List workspaces authorized for the linked Chitraagni user.",
        {},
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_workspace_get",
        "Read one workspace authorized for the linked Chitraagni user.",
        {"workspace_id": {"type": "string"}},
        ["workspace_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_workspace_projects_list",
        "List Projects inside one workspace authorized for the linked Chitraagni user.",
        {"workspace_id": {"type": "string"}},
        ["workspace_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_create",
        "Create one Project inside an authorized Chitraagni workspace. Project identity remains Chitraagni-owned.",
        {
            "workspace_id": {"type": "string"},
            "name": {"type": "string", "minLength": 1, "maxLength": 256},
            "description": {"type": "string", "maxLength": 16000},
            "product_type": {"type": "string", "maxLength": 256},
            "domain": {"type": "string", "maxLength": 256},
        },
        ["workspace_id", "name"],
    ),
    _tool(
        "chitraagni_projects_list",
        "List projects authorized for the linked Chitraagni user.",
        {},
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_get",
        "Read one project authorized for the linked Chitraagni user.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_products_list",
        "List all Product surfaces authorized for the linked Chitraagni user.",
        {},
        [],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_products_list",
        "List Product surfaces inside one authorized Project.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_product_get",
        "Read one Product surface authorized for the linked Chitraagni user.",
        {"product_id": {"type": "string"}},
        ["product_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_product_get",
        "Read one Product only when it belongs to the explicitly supplied authorized Project.",
        {
            "project_id": {"type": "string"},
            "product_id": {"type": "string"},
        },
        ["project_id", "product_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_product_update",
        "Update explicit editable fields on one Product surface in an authorized Project.",
        {
            "project_id": {"type": "string"},
            "product_id": {"type": "string"},
            "name": {"type": "string"},
            "product_type": {"type": "string"},
            "platform": {"type": ["string", "null"]},
            "goal": {"type": "string"},
            "description": {"type": "string"},
            "product_memory_json": {"type": "object"},
            "workflow_status": {"type": "string"},
        },
        ["project_id", "product_id"],
    ),
    _tool(
        "chitraagni_project_screens_list",
        "List current-version structured screens for one authorized Project.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_screen_get",
        "Read one structured screen authorized for the linked user.",
        {"screen_id": {"type": "string"}},
        ["screen_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_project_schemas_list",
        "List current-version schemas for one authorized Project.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_schema_get",
        "Read one schema authorized for the linked user.",
        {"schema_id": {"type": "string"}},
        ["schema_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_schema_delete",
        "Delete one current-version schema. Requires explicit confirm=true.",
        {
            "schema_id": {"type": "string"},
            "confirm": {"type": "boolean", "const": True},
        },
        ["schema_id", "confirm"],
        destructive=True,
    ),
    _tool(
        "chitraagni_project_workflows_list",
        "List current-version workflows for one authorized Project.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_workflow_get",
        "Read one workflow authorized for the linked user.",
        {"workflow_id": {"type": "string"}},
        ["workflow_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_workflow_delete",
        "Delete one current-version workflow. Requires explicit confirm=true.",
        {
            "workflow_id": {"type": "string"},
            "confirm": {"type": "boolean", "const": True},
        },
        ["workflow_id", "confirm"],
        destructive=True,
    ),
    _tool(
        "chitraagni_project_versions_list",
        "List structured Project versions and show which version is current.",
        {"project_id": {"type": "string"}},
        ["project_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_version_get",
        "Read metadata for one authorized Project version.",
        {"version_id": {"type": "string"}},
        ["version_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_version_snapshot_get",
        "Read the complete structured snapshot for one authorized Project version.",
        {"version_id": {"type": "string"}},
        ["version_id"],
        read_only=True,
    ),
    _tool(
        "chitraagni_version_update",
        "Update label and/or status metadata for one authorized Project version.",
        {
            "version_id": {"type": "string"},
            "label": {"type": ["string", "null"]},
            "status": {"type": ["string", "null"]},
        },
        ["version_id"],
    ),
    _tool(
        "chitraagni_version_delete",
        "Delete one non-current Project version when Chitraagni permits it. Requires explicit confirm=true.",
        {
            "version_id": {"type": "string"},
            "confirm": {"type": "boolean", "const": True},
        },
        ["version_id", "confirm"],
        destructive=True,
    ),
]


class FullChitraagniOperatorCatalog(ChitraagniOperatorCatalog):
    """The normal MegasMCP Chitraagni operator, including typed inspection tools."""

    def tools(self) -> list[dict[str, Any]]:
        tools = [*super().tools(), *json.loads(json.dumps(EXTENDED_TOOLS))]
        seen: set[str] = set()
        for tool in tools:
            name = str(tool.get("name") or "")
            if not name or name in seen:
                raise ValueError(f"duplicate or empty Chitraagni operator tool: {name}")
            seen.add(name)
        return sorted(tools, key=lambda row: str(row["name"]))

    @staticmethod
    def _extended_tool(name: str) -> dict[str, Any] | None:
        return next((tool for tool in EXTENDED_TOOLS if tool["name"] == name), None)

    @staticmethod
    def _require_confirm(arguments: dict[str, Any]) -> None:
        if arguments.get("confirm") is not True:
            raise ValueError("confirm must be true for this destructive operation")

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        tool = self._extended_tool(name)
        if tool is None:
            return super().call(name, arguments)
        if not isinstance(arguments, dict):
            raise ValueError("Chitraagni tool arguments must be a JSON object")
        errors = sorted(
            Draft202012Validator(tool["inputSchema"]).iter_errors(arguments),
            key=lambda row: list(row.path),
        )
        if errors:
            raise ValueError("invalid Chitraagni tool input: " + errors[0].message)

        if name == "chitraagni_health":
            value = self._api("GET", "/health")
        elif name == "chitraagni_me":
            value = self._api("GET", "/me")
        elif name == "chitraagni_workspaces_list":
            value = self._api("GET", "/workspaces")
        elif name == "chitraagni_workspace_get":
            workspace_id = _uuid(arguments.get("workspace_id"), "workspace_id")
            value = self._api("GET", f"/workspaces/{workspace_id}")
        elif name == "chitraagni_workspace_projects_list":
            workspace_id = _uuid(arguments.get("workspace_id"), "workspace_id")
            value = self._api("GET", f"/workspaces/{workspace_id}/projects")
        elif name == "chitraagni_project_create":
            workspace_id = _uuid(arguments.get("workspace_id"), "workspace_id")
            name_value = str(arguments.get("name") or "").strip()
            if not name_value:
                raise ValueError("name is required")
            body = _compact(arguments, ("description", "product_type", "domain"))
            body["name"] = name_value
            value = self._api("POST", f"/workspaces/{workspace_id}/projects", body)
        elif name == "chitraagni_projects_list":
            value = self._api("GET", "/projects")
        elif name == "chitraagni_project_get":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api("GET", f"/projects/{project_id}")
        elif name == "chitraagni_products_list":
            value = self._api("GET", "/products")
        elif name == "chitraagni_project_products_list":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api("GET", f"/projects/{project_id}/products")
        elif name == "chitraagni_product_get":
            product_id = _uuid(arguments.get("product_id"), "product_id")
            value = self._api("GET", f"/products/{product_id}")
        elif name == "chitraagni_project_product_get":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            product_id = _uuid(arguments.get("product_id"), "product_id")
            value = self._api("GET", f"/projects/{project_id}/products/{product_id}")
        elif name == "chitraagni_product_update":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            product_id = _uuid(arguments.get("product_id"), "product_id")
            body = _compact(
                arguments,
                (
                    "name",
                    "product_type",
                    "platform",
                    "goal",
                    "description",
                    "product_memory_json",
                    "workflow_status",
                ),
            )
            if not body:
                raise ValueError("at least one product field must be supplied")
            value = self._api("PUT", f"/projects/{project_id}/products/{product_id}", body)
        elif name == "chitraagni_project_screens_list":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api("GET", f"/projects/{project_id}/screens")
        elif name == "chitraagni_screen_get":
            screen_id = _uuid(arguments.get("screen_id"), "screen_id")
            value = self._api("GET", f"/screens/{screen_id}")
        elif name == "chitraagni_project_schemas_list":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api("GET", f"/projects/{project_id}/schemas")
        elif name == "chitraagni_schema_get":
            schema_id = _uuid(arguments.get("schema_id"), "schema_id")
            value = self._api("GET", f"/schemas/{schema_id}")
        elif name == "chitraagni_schema_delete":
            self._require_confirm(arguments)
            schema_id = _uuid(arguments.get("schema_id"), "schema_id")
            value = self._api("DELETE", f"/schemas/{schema_id}")
            if value is None:
                value = {"deleted": True, "schema_id": schema_id}
        elif name == "chitraagni_project_workflows_list":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api("GET", f"/projects/{project_id}/workflows")
        elif name == "chitraagni_workflow_get":
            workflow_id = _uuid(arguments.get("workflow_id"), "workflow_id")
            value = self._api("GET", f"/workflows/{workflow_id}")
        elif name == "chitraagni_workflow_delete":
            self._require_confirm(arguments)
            workflow_id = _uuid(arguments.get("workflow_id"), "workflow_id")
            value = self._api("DELETE", f"/workflows/{workflow_id}")
            if value is None:
                value = {"deleted": True, "workflow_id": workflow_id}
        elif name == "chitraagni_project_versions_list":
            project_id = _uuid(arguments.get("project_id"), "project_id")
            value = self._api("GET", f"/projects/{project_id}/versions")
        elif name == "chitraagni_version_get":
            version_id = _uuid(arguments.get("version_id"), "version_id")
            value = self._api("GET", f"/versions/{version_id}")
        elif name == "chitraagni_version_snapshot_get":
            version_id = _uuid(arguments.get("version_id"), "version_id")
            value = self._api("GET", f"/versions/{version_id}/snapshot")
        elif name == "chitraagni_version_update":
            version_id = _uuid(arguments.get("version_id"), "version_id")
            body = _compact(arguments, ("label", "status"))
            if not body:
                raise ValueError("at least one version field must be supplied")
            value = self._api("PUT", f"/versions/{version_id}", body)
        elif name == "chitraagni_version_delete":
            self._require_confirm(arguments)
            version_id = _uuid(arguments.get("version_id"), "version_id")
            value = self._api("DELETE", f"/versions/{version_id}")
            if value is None:
                value = {"deleted": True, "version_id": version_id}
        else:
            raise KeyError(name)

        text = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str)
        return {
            "content": [{"type": "text", "text": text}],
            "structuredContent": value,
            "isError": False,
        }


__all__ = ["EXTENDED_TOOLS", "FullChitraagniOperatorCatalog"]
